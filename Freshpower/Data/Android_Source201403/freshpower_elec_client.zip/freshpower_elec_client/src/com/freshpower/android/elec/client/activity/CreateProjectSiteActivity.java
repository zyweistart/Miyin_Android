package com.freshpower.android.elec.client.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageView;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;

public class CreateProjectSiteActivity extends Activity {
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.activity_project_site);
		ActivityUtil.addActivity(this);
		
		ImageView returnButton = (ImageView)findViewById(R.id.create_project_site_return);
	 	returnButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				CreateProjectSiteActivity.this.onBackPressed();
			}
		});
	}
}