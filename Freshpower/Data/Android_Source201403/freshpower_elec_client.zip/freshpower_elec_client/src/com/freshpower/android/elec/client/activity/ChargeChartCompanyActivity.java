package com.freshpower.android.elec.client.activity;

import java.util.List;
import java.util.Map;

import org.apache.http.conn.HttpHostConnectException;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.netapi.ChargeDetailCompanyApi;

public class ChargeChartCompanyActivity extends Activity {
	private double[] sumChargeDoubleList = null;
	private ProgressDialog processProgress;
	private static final int CLIENTBURTHEN_FINISH = 0x100;//��ҵ���ɼ���
	private static final int SYSTEM_ERROR = 0x500;//ϵͳ�쳣
	private static final int CONNECTTIMEOUT = 0x400;//���粻�ȶ�
	private static final int SYSTEM_FINISH = 0x200;//ִ�����
	private static final int NO_DATA = 0x300;//��ѯ������
	private String meterId;// ��·ID
	private String meterName;// ��·����
	private Map<String,Object> chargeMap;
	private TextView charge;
	private TextView maxCharge;
	private TextView maxChargeTime;
	private TextView chargeFactor;
	private TextView currLoad;
	private String maxChargeStr;
	private String maxChargeTimeStr;
	private String chargeFactorStr;
	private String currLoadStr;
	private Button queryBtn;
	private Dialog noticeDialog;
	private TextView setThresholdText;
	private TextView searchMsg;
	private LinearLayout searchLine;
	private LinearLayout searchLoad;
	private String selectType = "Hour";
	private List<Map<String, Object>> chargeDetailMap;
	private RadioButton hourSearch;
	private RadioButton daySearch;
	private TextView chargerTitle;
	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		setContentView(R.layout.company_activity_change_chart);
		ActivityUtil.addActivity(this);
		charge = (TextView)findViewById(R.id.chargeNowText);
		maxCharge = (TextView)findViewById(R.id.maxChargeText);
		maxChargeTime = (TextView)findViewById(R.id.maxChargeTimeText);
		chargeFactor = (TextView)findViewById(R.id.chargeFactorText);
		currLoad = (TextView)findViewById(R.id.currLoadText);
		Intent intent = this.getIntent();
		meterId = intent.getStringExtra("meterId");
		meterName = intent.getStringExtra("meterName");
//		chargerTitle = (TextView)findViewById(R.id.chargerTitle);
//		chargerTitle.setText(meterName+this.getResources().getString(R.string.charge_curve));
		processProgress = ProgressDialog.show(ChargeChartCompanyActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		//�߳����ݴ���
		new Thread(){
			public void run() {
				Message msgMessage = null;
				try{
					//��ҵ���ɼ���
					chargeMap = ChargeDetailCompanyApi.getSumChargeDoubleList(meterId, selectType);
					sumChargeDoubleList = (double[])chargeMap.get("sumChargeDoubleList");
					maxChargeStr = (chargeMap.get("maxLoad")!=null&&!chargeMap.get("maxLoad").toString().equals(""))?chargeMap.get("maxLoad").toString()+"kW":"";
					maxChargeTimeStr = chargeMap.get("maxTime")==null?"":chargeMap.get("maxTime").toString();
					chargeFactorStr = chargeMap.get("FHL")==null?"":chargeMap.get("FHL").toString();
					currLoadStr = (chargeMap.get("currLoad")!=null&&!chargeMap.get("currLoad").toString().equals(""))?chargeMap.get("currLoad").toString()+"kW":"";
					msgMessage = new Message();
					if(chargeMap.get("isData").equals("1")) {
						msgMessage.what = CLIENTBURTHEN_FINISH;
					} else if(chargeMap.get("isData").equals("0")){
						msgMessage.what = NO_DATA;
					}
					ChargeChartCompanyActivity.this.xHandler.sendMessage(msgMessage);
				} 
				catch(HttpHostConnectException e) {
					Toast.makeText(ChargeChartCompanyActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show();
				}
				catch (Exception e) {
					msgMessage = new Message();
					msgMessage.what = SYSTEM_ERROR;
					ChargeChartCompanyActivity.this.xHandler.sendMessage(msgMessage);
					e.printStackTrace();
				} finally {
					msgMessage = new Message();
					msgMessage.what = SYSTEM_FINISH;
					ChargeChartCompanyActivity.this.xHandler.sendMessage(msgMessage);
				}
			};
		}.start();
		setClientBurthenCurveChart();
		ImageView returnButton = (ImageView)findViewById(R.id.charge_back_left);
		returnButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				ChargeChartCompanyActivity.this.onBackPressed();
			}
		});
		
		// ��ѯ�¼�
		ImageView findBtn = (ImageView) findViewById(R.id.findBtn);
		findBtn.setOnClickListener(new mapSearchDialogIbClickListener());
	}
	
	private Handler xHandler = new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case CLIENTBURTHEN_FINISH:
				setClientBurthenCurveChart();
				break;
			case SYSTEM_ERROR:
				Toast.makeText(ChargeChartCompanyActivity.this, R.string.msg_abnormal_net2work, Toast.LENGTH_SHORT).show(); 		
				break;
			case CONNECTTIMEOUT:
				Toast.makeText(ChargeChartCompanyActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show(); 		
				break;
			case NO_DATA:
				setClientBurthenCurveChart();
				Toast.makeText(ChargeChartCompanyActivity.this, R.string.noSearchResultMsg, Toast.LENGTH_SHORT).show(); 		
				break;
			case SYSTEM_FINISH:
				processProgress.dismiss();
				break;
			default:
				break;
			}
		};
				
	};
	
	/**
	 * ����������ͼ
	 */
	private void setClientBurthenCurveChart() {
		maxCharge.setText(maxChargeStr);
		maxChargeTime.setText(maxChargeTimeStr);
		chargeFactor.setText(chargeFactorStr);
		currLoad.setText(currLoadStr);
		LinearLayout curveChart = (LinearLayout)findViewById(R.id.curveChart);
		if(selectType.equals("Hour")) {
			ClientBurthenCurveCompanyChart clientBurthenCurveChart = new ClientBurthenCurveCompanyChart();
			clientBurthenCurveChart.setSumChargeDoubleList(sumChargeDoubleList);
			clientBurthenCurveChart.setType("chargeDetil");
			clientBurthenCurveChart.setTitle(meterName);
			clientBurthenCurveChart.exe(ChargeChartCompanyActivity.this, curveChart);
		} else {
			ClientChargeDetailCurveCompanyChart clientBurthenCurveChart = new ClientChargeDetailCurveCompanyChart();
			clientBurthenCurveChart.setSumChargeDoubleList(sumChargeDoubleList);
			clientBurthenCurveChart.setTitle(meterName);
			clientBurthenCurveChart.exe(ChargeChartCompanyActivity.this, curveChart);
		}
	}
	
	private class mapSearchDialogIbClickListener implements
	View.OnClickListener {
		@Override
		public void onClick(View v) {
			LayoutInflater factory = LayoutInflater
					.from(ChargeChartCompanyActivity.this);
			final View dialogView = factory.inflate(R.layout.activity_history_search,
					null);
			dialogView.setBackgroundResource(android.R.color.white);
			setThresholdText = (TextView) dialogView.findViewById(R.id.set_threshold_text);
			setThresholdText.setText(R.string.charge_detail_history_query);
			searchMsg = (TextView) dialogView.findViewById(R.id.search_msg);
			searchMsg.setVisibility(View.GONE);
			searchLine = (LinearLayout) dialogView.findViewById(R.id.search_line);
			searchLine.setVisibility(View.GONE);
			searchLoad = (LinearLayout) dialogView.findViewById(R.id.search_load);
			searchLoad.setVisibility(View.VISIBLE);
			hourSearch = (RadioButton) dialogView.findViewById(R.id.hour_search);
			daySearch = (RadioButton) dialogView.findViewById(R.id.day_search);
			if(selectType.equals("Hour")) {
				hourSearch.setChecked(true);
			} else if(selectType.equals("Day")) {
				daySearch.setChecked(true);
			}
			queryBtn = (Button)dialogView.findViewById(R.id.set_threshold_submit);
			queryBtn.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							processProgress = ProgressDialog.show(ChargeChartCompanyActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
							new Thread(){
								public void run() {
									Message msgMessage = null;
									try {
										if(hourSearch.isChecked()) {
											selectType = "Hour";
										} else if(daySearch.isChecked()) {
											selectType = "Day";
										}
										//��ҵ���ɼ���
										chargeMap = ChargeDetailCompanyApi.getSumChargeDoubleList(meterId, selectType);
										sumChargeDoubleList = (double[])chargeMap.get("sumChargeDoubleList");
										maxChargeStr = (chargeMap.get("maxLoad")!=null&&!chargeMap.get("maxLoad").toString().equals(""))?chargeMap.get("maxLoad").toString()+"kW":"";
										maxChargeTimeStr = chargeMap.get("maxTime")==null?"":chargeMap.get("maxTime").toString();
										chargeFactorStr = chargeMap.get("FHL")==null?"":chargeMap.get("FHL").toString();
										currLoadStr = (chargeMap.get("currLoad")!=null&&!chargeMap.get("currLoad").toString().equals(""))?chargeMap.get("currLoad").toString()+"kW":"";
										noticeDialog.cancel();
										msgMessage = new Message();
										if(chargeMap.get("isData").equals("1")) {
											msgMessage.what = CLIENTBURTHEN_FINISH;
										} else if(chargeMap.get("isData").equals("0")){
											msgMessage.what = NO_DATA;
										}
										ChargeChartCompanyActivity.this.xHandler.sendMessage(msgMessage);
									}
									catch(HttpHostConnectException e) {
										Toast.makeText(ChargeChartCompanyActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show();
									}
									catch (Exception e) {
										msgMessage = new Message();
										msgMessage.what = SYSTEM_ERROR;
										ChargeChartCompanyActivity.this.xHandler.sendMessage(msgMessage);
										e.printStackTrace();
									} finally {
										msgMessage = new Message();
										msgMessage.what = SYSTEM_FINISH;
										ChargeChartCompanyActivity.this.xHandler.sendMessage(msgMessage);
									}
								}
							}.start();
						}
					});
			// ����Ի���
			AlertDialog alertDialog = new AlertDialog.Builder(ChargeChartCompanyActivity.this).create();
			alertDialog.setView(dialogView,0,0,0,0);
			noticeDialog = alertDialog;
			noticeDialog.show();
			
			ImageView closebtn = (ImageView)dialogView.findViewById(R.id.search_close);
			closebtn.setOnClickListener(new OnClickListener(){
				public void onClick(View arg0) {
					noticeDialog.cancel();
				}
			});
		}
	}
}
