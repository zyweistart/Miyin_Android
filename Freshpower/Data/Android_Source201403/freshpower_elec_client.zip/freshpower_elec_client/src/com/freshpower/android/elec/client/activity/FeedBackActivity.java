package com.freshpower.android.elec.client.activity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.conn.HttpHostConnectException;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.StringUtil;
import com.freshpower.android.elec.client.domain.FeedBackInfo;
import com.freshpower.android.elec.client.netapi.FeedBackDateApi;

import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class FeedBackActivity extends Activity {
	EditText feedbackinfo_et;
	EditText feedbackmail_et;
	EditText feedbacktel_et;
	private FeedBackInfo feedBack;
	private ProgressDialog processProgress;
	private Handler handler = new Handler();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_feedback);
		ActivityUtil.addActivity(this);
		Button feedback_submit=(Button)findViewById(R.id.feedback_submit);
		feedbackinfo_et=(EditText)findViewById(R.id.feedbackinfo_et);
		feedbackmail_et=(EditText)findViewById(R.id.feedbackmail_et);
		feedbacktel_et=(EditText)findViewById(R.id.feedbacktel_et);

		ImageView iv=(ImageView)findViewById(R.id.nav_left);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				FeedBackActivity.this.onBackPressed();
			}
		});

		feedback_submit.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				String feedBackInfo =feedbackinfo_et.getText().toString();
				String feedBackMail =feedbackmail_et.getText().toString();
				String feedBackTel =feedbacktel_et.getText().toString();
				if(feedBackInfo.equals(""))
				{
					Toast.makeText(FeedBackActivity.this, R.string.feedback_note_msg,Toast.LENGTH_SHORT).show();
					return;
				}
				if(feedBackMail.equals(""))
				{
					Toast.makeText(FeedBackActivity.this, R.string.feedback_mail_msg,Toast.LENGTH_SHORT).show();
					return;
				}else{
					Pattern pattern = Pattern.compile(StringUtil.ISEMAIL);
					Matcher matcher = pattern.matcher(feedBackMail);
					if(!matcher.matches()){
						Toast.makeText(FeedBackActivity.this, R.string.feedback_mailnot_msg,Toast.LENGTH_SHORT).show();
						return;
					}
				}
				for (int i = 0; i < feedBackMail.length(); i++) { 
					String backMail = feedBackMail.substring(i, i+1); 
					//����һ��Pattern,ͬʱ����һ���������ʽ.  
					boolean backMailBoolean = java.util.regex.Pattern.matches("[\u4E00-\u9FA5]", backMail); 
					if(backMailBoolean){
						Toast.makeText(FeedBackActivity.this, R.string.feedback_mailnot_msg,Toast.LENGTH_SHORT).show();
						return;
					}

				}
				if(feedBackTel.equals(""))
				{
					Toast.makeText(FeedBackActivity.this, R.string.feedback_tel_msg,Toast.LENGTH_SHORT).show();
					return;
				}else if(feedBackTel.length()!=11){
					Toast.makeText(FeedBackActivity.this, R.string.feedback_telnot_msg,Toast.LENGTH_SHORT).show();
					return;
				}
				feedBack=new FeedBackInfo();
				processProgress = ProgressDialog.show(FeedBackActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
				feedBack.setFeedBackInfo(feedBackInfo);
				feedBack.setFeedBackMail(feedBackMail);
				feedBack.setFeedBackTel(feedBackTel);

				new Thread(new Runnable(){

					String msgContent;
					@Override
					public void run() {
						String rs = "0";
						msgContent="��л���ķ���,���ǻᾡ�촦�����������";
						try {
							rs=FeedBackDateApi.postFeedBackDate(feedBack);
						}catch (HttpHostConnectException e) {
							msgContent = getResources().getString(R.string.msg_abnormal_network);
						}catch (Exception e) {
							msgContent = getResources().getString(R.string.msg_abnormal_network);
						}finally{

							processProgress.dismiss();

							handler.post(new Runnable() {
								@Override
								public void run() {
									Toast.makeText(FeedBackActivity.this, msgContent, Toast.LENGTH_SHORT).show(); 								
								}
							});

							if(rs.equals("1")){
								Intent intent = new Intent(FeedBackActivity.this, FeedBackActivity.class);
								startActivity(intent);
								finish();	
							}
						}
					}

				}).start();
			}
		});
	}

}
