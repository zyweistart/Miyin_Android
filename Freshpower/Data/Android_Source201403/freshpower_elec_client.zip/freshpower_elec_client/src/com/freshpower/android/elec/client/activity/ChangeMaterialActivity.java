package com.freshpower.android.elec.client.activity;

import org.apache.http.conn.HttpHostConnectException;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.camera.CaptureActivity;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.netapi.ScanInfoDateApi;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

public class ChangeMaterialActivity extends Activity {
	EditText oldSerialNoText = null;
	EditText newSerialNo = null;
	String oldSerialNo = "";
	String serialNo;
	
	private ProgressDialog processProgress;
	private Handler handler = new Handler();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_change_material);
		ActivityUtil.addActivity(this);
		getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		Intent intent = getIntent();
		oldSerialNo= intent.getStringExtra("serialNo");
		ImageView closebtn = (ImageView)findViewById(R.id.change_close);
		oldSerialNoText = (EditText)findViewById(R.id.change_old_text1);
		oldSerialNoText.setEnabled(false);
		Button submit = (Button)findViewById(R.id.change_submit);
		RelativeLayout scanSerialLyt = (RelativeLayout)findViewById(R.id.scanSerialLyt);
		oldSerialNoText.setText(oldSerialNo);
		newSerialNo = (EditText)findViewById(R.id.change_edit_text2);
		submit.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				processProgress = ProgressDialog.show(ChangeMaterialActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
				serialNo = newSerialNo.getText().toString().replaceAll(" ", "");
				//Log.d("sum", serialNo);
				new Thread(new Runnable(){
					String content;
					@Override
					public void run() {
						try {
							if(serialNo.length()!=12){
								content = "��Ų����Ϲ���";
							}else{
								Spinner scanOperationSpinner = (Spinner)findViewById(R.id.scanchangeSpinner);
								int changeReason = (int) scanOperationSpinner.getSelectedItemId();
								String result = ScanInfoDateApi.changeMeter("", "", oldSerialNo, serialNo,String.valueOf(changeReason));
								if(Integer.parseInt(result)>0){
									content = "�����ɹ���";
								}else {
									content =  ScanInfoDateApi.showMsg(result);
								}
							}
						} catch (HttpHostConnectException e) {
							content = "�������粻�ȶ������Ժ����ԣ�";
							e.printStackTrace();
						} catch (Exception e) {
							content = "�������粻�ȶ������Ժ����ԣ�";
							e.printStackTrace();
						}finally{
							processProgress.dismiss();
							handler.post(new Runnable() {
								@Override
								public void run() {
									Toast.makeText(ChangeMaterialActivity.this, content, Toast.LENGTH_SHORT).show(); 
									ChangeMaterialActivity.this.finish();
								}
							});
						}
					}
					
				}).start();
			}
		});
		scanSerialLyt.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				Intent intent = new Intent(ChangeMaterialActivity.this, CaptureActivity.class);
				intent.putExtra("operateType", "phoneDebug");
				startActivityForResult(intent, AppConstant.RequestResultCode.REQUEST_SCANACTIVITY);
			}
		});
		closebtn.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				ChangeMaterialActivity.this.onBackPressed();
			}
		});
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if(requestCode == AppConstant.RequestResultCode.RESULT_SCANACTIVITY){
			if(data!=null){
				String twoDimCode = data.getStringExtra("twoDimCode");
				if(twoDimCode.length()>=12){
					twoDimCode = twoDimCode.substring(0,4)+" "+twoDimCode.substring(4,8)+" "+twoDimCode.substring(8,12);
				}else{
					Toast.makeText(ChangeMaterialActivity.this, "��ɨ����ȷ�Ķ�ά�룡", Toast.LENGTH_SHORT).show();
					return;
				}
				newSerialNo.setText(twoDimCode);
				//scanSerialNoStr = twoDimCode;
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
}
