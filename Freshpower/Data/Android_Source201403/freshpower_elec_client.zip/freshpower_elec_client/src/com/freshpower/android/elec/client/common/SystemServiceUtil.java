/**   
 * @{#} SystemServiceUtil.java Create on 2013-5-1 ����04:39:45   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.client.common;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import com.freshpower.android.elec.client.R;

/**
 * @author <a href="mailto:yangz@freshpower.cn">yangz</a>
 * @version 1.0
 */

public class SystemServiceUtil {

	public static boolean openGPSSettings(Context mContext) {
		LocationManager alm = (LocationManager) mContext
				.getSystemService(Context.LOCATION_SERVICE);
		if (alm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)) {
			return true;
		} else {
			//Log.d("BID", "SystemServiceUtil..openGPSSettings");
			Toast.makeText(mContext, R.string.msg_gps_info_openAlert,
					Toast.LENGTH_LONG).show();
			Intent myIntent = new Intent(
					Settings.ACTION_LOCATION_SOURCE_SETTINGS);
			mContext.startActivity(myIntent);
			return false;
		}
	}

	public static boolean isGpsOpen(Context mContext) {
		LocationManager alm = (LocationManager) mContext
				.getSystemService(Context.LOCATION_SERVICE);
		if (alm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * �����жϷ����Ƿ�����.
	 * 
	 * @param context
	 * @param className
	 *            �жϵķ�������
	 * @return true ������ false ��������
	 */
	public static boolean isServiceRunning(Context mContext, String className) {
		ActivityManager activityManager = (ActivityManager) mContext
				.getSystemService(Context.ACTIVITY_SERVICE);
		for (RunningServiceInfo service : activityManager
				.getRunningServices(Integer.MAX_VALUE)) {
			if (service.service.getClassName().equals(className)) {
				return true;
			}
		}
		return false;
	}

	public static boolean openInternet(Context mContext) {
		boolean isEnable;
		String internetServce = Context.TELEPHONY_SERVICE;
		TelephonyManager telephonyManager = (TelephonyManager) mContext
				.getSystemService(internetServce);
		WifiManager wifiManager = (WifiManager) mContext
				.getSystemService(Context.WIFI_SERVICE);
		if (telephonyManager.getDataState() == TelephonyManager.DATA_CONNECTED
				|| wifiManager.getWifiState() == WifiManager.WIFI_STATE_ENABLED) {
			isEnable = true;
		} else {
			isEnable = false;
			Intent myIntent = new Intent(Settings.ACTION_WIRELESS_SETTINGS);
			mContext.startActivity(myIntent);
		}
		return isEnable;
	}

	public static boolean isNetworkConnected(Context context) {
		boolean isConn = false;
		if (context != null) {
			ConnectivityManager mConnectivityManager = (ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo mNetworkInfo = mConnectivityManager
					.getActiveNetworkInfo();
			if (mNetworkInfo != null) {
				isConn = mNetworkInfo.isAvailable();
			}
		}
		return isConn;
	}

	/**
	 * �ֻ�ͨѶ����
	 * 
	 * @param mContext
	 *            ������
	 * @return �ֻ�ͨѶ�������
	 */
	public static TelephonyManager getTelephonyManager(Context mContext) {
		return (TelephonyManager) mContext
				.getSystemService(mContext.TELEPHONY_SERVICE);
	}

	/**
	 * Ӧ���Ƿ�װ
	 * 
	 * @param mContext
	 *            ������
	 * @return
	 */
	public static boolean isAppsInstalled(Context mContext, String packageName) {
		try {
			mContext.getPackageManager().getApplicationInfo(packageName, 0);
			return true;
		} catch (PackageManager.NameNotFoundException e) {
			return false;
		}
	}

}
