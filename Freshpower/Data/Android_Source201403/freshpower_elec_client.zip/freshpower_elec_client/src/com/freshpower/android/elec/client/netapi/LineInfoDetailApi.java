package com.freshpower.android.elec.client.netapi;

import java.io.File;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.client.common.AppCache;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.conf.AppConfig;
import com.freshpower.android.elec.client.domain.CheckUpDetailInfo;
import com.freshpower.android.elec.client.domain.LineDetailInfo;
import com.freshpower.android.elec.client.domain.LoginInfo;

public class LineInfoDetailApi extends JsonDataApi {
	private static final String ACTION_NAME = "AppHisMeterElec.aspx";
	/**
	 * ��ȡ�豸��ϸ��Ϣ
	 * @param qttask����id
	 * @param qtkey�豸id
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getLineDetailInfoList(String qttask,String qtkey) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd()); 
		api.addParam("CP_ID","149");
		api.addParam("MeterID","236");
		api.addParam("sDate","2013-12-31");
		api.addParam("eDate","2013-12-31");
		api.addParam("SelectType","Day");
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getFpsWebSite()+File.separator+ACTION_NAME,AppConstant.ETG_INTERFACE_CHARSET);
		Log.d("BID", "jsonResult:"+jsonResult.toString());
		JSONObject rows = jsonResult.getJSONObject("Rows");
		LineDetailInfo lineInfo = null;
		List<LineDetailInfo> lineInfoList = new ArrayList<LineDetailInfo>();
		if(Integer.valueOf(rows.getString("result"))>0){
			JSONArray jsonObj = jsonResult.getJSONArray("table1");
			for(int i=0;i<jsonObj.size();i++){
				lineInfo=new LineDetailInfo();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				lineInfo.setTotalFee(table1.getString("TotalFee")==null?"":table1.getString("TotalFee"));//�ۼƵ��
				lineInfo.setTotalPower(table1.getString("TotalPower")==null?"":table1.getString("TotalPower"));//�ۼƵ���
				lineInfo.setTipFee(table1.getString("TipFee")==null?"":table1.getString("TipFee"));//�����
				lineInfo.setTipPower(table1.getString("TipPower")==null?"":table1.getString("TipPower"));//������
				lineInfo.setPeakFee(table1.getString("PeakFee")==null?"":table1.getString("PeakFee"));//�߷���
				lineInfo.setPeakPower(table1.getString("PeakPower")==null?"":table1.getString("PeakPower"));//�߷����
				lineInfo.setValleyFee(table1.getString("ValleyFee")==null?"":table1.getString("ValleyFee"));//�͹ȵ��
				lineInfo.setValleyPower(table1.getString("ValleyPower")==null?"":table1.getString("ValleyPower"));//�͹ȵ���
				lineInfo.setAvgPrice(table1.getString("AvgPrice")==null?"":table1.getString("AvgPrice"));//ƽ�����
				lineInfo.setDate(table1.getString("AvgPrice")==null?"":table1.getString("AvgPrice"));//����
				lineInfoList.add(lineInfo);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("lineInfoList", lineInfoList);
//		map.put("totalCount", rows.getString("TotalCount"));
		map.put("result", rows.getString("result"));
		return map;
	}
}
