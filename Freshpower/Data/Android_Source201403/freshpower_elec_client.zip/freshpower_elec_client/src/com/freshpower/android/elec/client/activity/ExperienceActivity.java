package com.freshpower.android.elec.client.activity;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.SizeUtil;

import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TabWidget;
import android.widget.TextView;

public class ExperienceActivity extends TabActivity {
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.activity_experience);
		TabHost tabHost = getTabHost();
		double[] sumCharge = (double[])getIntent().getExtras().getDoubleArray("sumCharge");
		
		Intent priceShowIntent = new Intent();
		Bundle bundle = new Bundle();
		bundle.putDoubleArray("sumCharge", sumCharge);
		priceShowIntent.putExtras(bundle);
		priceShowIntent.setClass(this, UserExperienceActivity.class);
		TabHost.TabSpec priceShowTS = tabHost.newTabSpec("������ͼ");
		Resources res = getResources();
		priceShowTS.setIndicator("������ͼ");
		priceShowTS.setContent(priceShowIntent);
		tabHost.addTab(priceShowTS);
		
		Intent quotationIntent = new Intent();
		quotationIntent.setClass(this, UserExperienceDetailInfoActivity.class);
		TabHost.TabSpec quotationTS = tabHost.newTabSpec("�б���ʽ");
		quotationTS.setIndicator("�б���ʽ");
		quotationTS.setContent(quotationIntent);
		tabHost.addTab(quotationTS);
		
		TabWidget tabWidget = tabHost.getTabWidget();
		 for (int i =0; i < tabWidget.getChildCount(); i++) {
			 tabWidget.getChildAt(i).getLayoutParams().height = SizeUtil.dip2px(this, 40F);
			 tabWidget.getChildAt(i).getLayoutParams().width = SizeUtil.dip2px(this, 65F);
			 tabWidget.getChildAt(i).setBackgroundResource(R.color.purple);
			 TextView tv = (TextView) tabWidget.getChildAt(i).findViewById(android.R.id.title);
			 tv.setTextSize(15);
			 tv.setTextColor(this.getResources().getColorStateList(android.R.color.white));
		 }
		
		// �����¼�
		ImageView returnButton = (ImageView) findViewById(R.id.buy_return);
		returnButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				ExperienceActivity.this.onBackPressed();
			}
		});
	}
	
}

