package com.freshpower.android.elec.client.netapi;

import java.io.File;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.client.common.AppCache;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.common.DateUtil;
import com.freshpower.android.elec.client.common.LogFactory;
import com.freshpower.android.elec.client.common.StringUtil;
import com.freshpower.android.elec.client.conf.AppConfig;
import com.freshpower.android.elec.client.domain.ChargeDetailCompany;
import com.freshpower.android.elec.client.domain.LoginInfo;


public class ChargeDetailCompanyApi extends JsonDataApi {
	private static DecimalFormat df = new DecimalFormat("0.00");
	private static LogFactory logger = LogFactory.getLogger(ChargeDetailCompanyApi.class);
	
	/**
	 * ��ȡ��ϸ�����б��ӿ�
	 * @param pageSize
	 * @param pageNum
	 * @param meterName ��·����
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getChargeDetailList(int pageSize,int pageNum, String meterName) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo = (LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("CP_ID", loginInfo.getCpId());
		api.addParam("PageIndex", String.valueOf(pageNum).trim());
		api.addParam("PageSize", String.valueOf(pageSize).trim());
		if(!StringUtil.isEmpty(meterName)) {
			api.addParam("MeterName", URLEncoder.encode(meterName, AppConstant.ETG_INTERFACE_CHARSET));
		}
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getFpsWebSite() + File.separator + "AppMeterFhReport.aspx", AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("MeterFhList");
		ChargeDetailCompany chargeDetail = null;
		List<ChargeDetailCompany> chargeDetailList = new ArrayList<ChargeDetailCompany>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				chargeDetail = new ChargeDetailCompany();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				chargeDetail.setMeterId(StringUtil.isEmpty(table1.getString("METER_ID"))?"":table1.getString("METER_ID"));
				chargeDetail.setMeterName(StringUtil.isEmpty(table1.getString("METER_NAME"))?"":table1.getString("METER_NAME"));
				chargeDetail.setpPower(StringUtil.isEmpty(table1.getString("P_POWER"))?"":df.format(Double.valueOf(table1.getString("P_POWER"))));
				chargeDetail.setSwichStatus(StringUtil.isEmpty(table1.getString("SWITCH_STATUSTxt"))?"":table1.getString("SWITCH_STATUSTxt"));
				chargeDetail.setFactor(StringUtil.isEmpty(table1.getString("FACTOR"))?"":df.format(Double.valueOf(table1.getString("FACTOR"))));
				chargeDetail.setCurrent("Ia="+(StringUtil.isEmpty(table1.getString("I_A"))?"":df.format(Double.valueOf(table1.getString("I_A"))))
						+" Ib="+(StringUtil.isEmpty(table1.getString("I_B"))?"":df.format(Double.valueOf(table1.getString("I_B"))))
						+" Ic="+(StringUtil.isEmpty(table1.getString("I_C"))?"":df.format(Double.valueOf(table1.getString("I_C")))));
				chargeDetailList.add(chargeDetail);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("remark", rows.getString("remark"));
		map.put("chargeDetailList", chargeDetailList);
		map.put("result", rows.getString("result"));
		map.put("totalCount", rows.getString("TotalCount"));
		return map;
	}
	
	/**
	 * ��ȡ����/������ҵ���ɽӿ�
	 * 
	 * @param meterId
	 *            ��·ID
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getSumChargeDoubleList(String meterId, String selectType) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo = (LoginInfo) AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("CP_ID", loginInfo.getCpId());
		api.addParam("MeterID", meterId);
		api.addParam("SelectType", selectType);
		if(selectType.equals("Day")) {
			api.addParam("sDate", DateUtil.getLastMonthDate(-30, "yyyy-MM-dd"));
			api.addParam("eDate", DateUtil.getLastMonthDate(-1, "yyyy-MM-dd"));
		}
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance()
				.getFpsWebSite() + File.separator + "AppMeterHisFhReport.aspx",
				AppConstant.ETG_INTERFACE_CHARSET);
		logger.d("elec","rul="+AppConfig.getInstance()
				.getFpsWebSite() + File.separator + "AppMeterHisFhReport.aspx?CP_ID="+loginInfo.getCpId()+"&MeterID="+meterId+"&SelectType="+selectType);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONObject meterFactor = jsonResult.getJSONObject("MeterFactor");
		JSONArray jsonObj = jsonResult.getJSONArray("MeterFhList");
		double[] sumChargeDoubleList = null;
		if(jsonObj != null) {
			sumChargeDoubleList = new double[jsonObj.size()];
			if (Integer.valueOf(rows.getString("result")) > 0) {
				for (int i = 0; i < jsonObj.size(); i++) {
					JSONObject table = (JSONObject) jsonObj.get(i);
					sumChargeDoubleList[i] = Double.parseDouble(table
							.getString("����"));
				}
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("remark", rows.getString("remark"));
		map.put("result", rows.getString("result"));
		map.put("sumChargeDoubleList", sumChargeDoubleList);
		if(meterFactor != null) {
			map.put("currLoad", rows.getString("CurrLoad"));
			map.put("maxLoad", meterFactor.getString("MaxLoad"));
			map.put("maxTime", meterFactor.getString("MaxTime"));
			map.put("FHL", meterFactor.getString("FHL"));
		}
		if(meterFactor != null && jsonObj != null) {
			map.put("isData", "1");
		} else {
			map.put("isData", "0");
		}
		return map;
	}
	
}
