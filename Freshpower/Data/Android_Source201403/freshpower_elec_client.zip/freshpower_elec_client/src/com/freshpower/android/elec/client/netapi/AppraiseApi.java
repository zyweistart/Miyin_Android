package com.freshpower.android.elec.client.netapi;

import java.io.File;
import java.net.URLEncoder;

import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.conf.AppConfig;

public class AppraiseApi extends JsonDataApi {
	
	private static final String ACTION_NAME = "addSuggest.aspx";
	
	/**
	 * �繤������Ϣ�ӿ�
	 * @param content ����
	 * @param starNum �������Ǹ���
	 * @return
	 * @throws Exception
	 */
	public static String submitAppraise(String content, String starNum) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("content", URLEncoder.encode(content, AppConstant.ETG_INTERFACE_CHARSET));
		api.addParam("StarNum", starNum);
		api.addParam("msgType", "3");
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getFpsWebSite() + File.separator + ACTION_NAME, AppConstant.ETG_INTERFACE_CHARSET);
		return jsonResult.getString("rs");
	}
}
