package com.freshpower.android.elec.client.activity;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Calendar;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.AppCache;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.common.DateUtil;
import com.freshpower.android.elec.client.common.StringUtil;
import com.freshpower.android.elec.client.domain.LoginInfo;

public class CheckRecordSearchCompanyActivity extends Activity {
	
	private EditText startDateEt;
	private EditText endDateEt;
	private String startDateEtStr;
	private String endDateEtStr;
	private EditText currentEt;
	private Calendar currentDate;
	private int mYear;
	private int mMonth;
	private int mDay;
	private int mHour;
	private int mMinute;
	private static final int DATE_DIALOG_ID = 0;
	private static final int TIME_DIALOG_ID = 1;
	
	private EditText cpNameText;
	private EditText siteNameText;
	private String searchCpName;
	private String searchSiteName;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.company_activity_check_record_search);
		ActivityUtil.addActivity(this);
		startDateEt = (EditText) findViewById(R.id.checkRecordStartDate);
		endDateEt = (EditText) findViewById(R.id.checkRecordEndDate);
		startDateEt.setText(DateUtil.amountDateStr(Calendar.DAY_OF_MONTH, -30).substring(0, 10));
		endDateEt.setText(DateUtil.getNowDate());
		startDateEt.setInputType(InputType.TYPE_NULL);
		startDateEt.setOnClickListener(new dateListener());
		endDateEt.setInputType(InputType.TYPE_NULL);
		endDateEt.setOnClickListener(new dateListener());
		startDateEtStr = startDateEt.getText().toString();
		endDateEtStr = endDateEt.getText().toString();
		LoginInfo loginInfo = (LoginInfo) AppCache.get(AppCache.LOGININFO_OBJ);
		cpNameText = (EditText)findViewById(R.id.searchCpName);
		cpNameText.setText(loginInfo.getCpName());
		Button btn = (Button)findViewById(R.id.checkRecordSearchSub);
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(CheckRecordSearchCompanyActivity.this,CheckRecordListCompanyActivity.class);
				startDateEt = (EditText) findViewById(R.id.checkRecordStartDate);
				endDateEt = (EditText) findViewById(R.id.checkRecordEndDate);
				startDateEtStr = startDateEt.getText().toString();
				endDateEtStr = endDateEt.getText().toString();
				cpNameText = (EditText)findViewById(R.id.searchCpName);
				searchCpName = cpNameText.getText().toString();
				siteNameText = (EditText)findViewById(R.id.searchSiteName);
				searchSiteName = siteNameText.getText().toString();
				if(StringUtil.isEmpty(searchCpName)) {
					Toast.makeText(CheckRecordSearchCompanyActivity.this, R.string.check_cp_name_msg, Toast.LENGTH_SHORT).show();
					return;
				}
				intent.putExtra("searchCpName", searchCpName);
				intent.putExtra("searchSiteName", searchSiteName);
				intent.putExtra("taskStartDate", startDateEtStr);
				intent.putExtra("taskEndDate", endDateEtStr);
				intent.putExtra("toPageType", "CheckRecordListActivity");
				startActivity(intent);
			}
		});
		// �����¼�
		ImageView returnButton = (ImageView) findViewById(R.id.checkSearchReturn);
		returnButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				CheckRecordSearchCompanyActivity.this.onBackPressed();
			}
		});
	}
	
	class dateListener implements View.OnClickListener {
		@Override
		public void onClick(View v) {
			currentEt = (EditText) v;
			// ��õ�ǰ�����ڣ�
			currentDate = Calendar.getInstance();
			mYear = currentDate.get(Calendar.YEAR);
			mMonth = currentDate.get(Calendar.MONTH);
			mDay = currentDate.get(Calendar.DAY_OF_MONTH);
			showDialog(DATE_DIALOG_ID);
		}
	}

	// ��Ҫ���嵯����DatePicker�Ի�����¼���������
	private DatePickerDialog.OnDateSetListener mDateSetListener = new DatePickerDialog.OnDateSetListener() {
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			mYear = year;
			mMonth = monthOfYear;
			mDay = dayOfMonth;
			// �����ı������ݣ�
			currentEt.setText(new StringBuilder().append(mYear).append("-")
					.append(mMonth + 1).append("-")// �õ����·�+1����Ϊ��0��ʼ
					.append(mDay));
		}
	};

	// ��Ҫ���嵯����TimePicker�Ի�����¼���������
	private TimePickerDialog.OnTimeSetListener mTimeSetListener = new TimePickerDialog.OnTimeSetListener() {

		@Override
		public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
			mHour = hourOfDay;
			mMinute = minute;
			currentEt.setText(new StringBuilder().append(pad(mHour))
					.append(":").append(pad(mMinute)));
		}
	};

	private static String pad(int c) {
		if (c >= 10)
			return String.valueOf(c);
		else
			return "0" + String.valueOf(c);
	}

	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DATE_DIALOG_ID:
			return new DatePickerDialog(this, mDateSetListener, mYear, mMonth,
					mDay);
		case TIME_DIALOG_ID:
			return new TimePickerDialog(this, mTimeSetListener, mHour, mMinute,
					false);
		}
		return null;
	}
}
