package com.freshpower.android.elec.client.activity;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import android.app.AlertDialog;
import android.app.Dialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.AppCache;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.common.FileUtil;
import com.freshpower.android.elec.client.common.StringUtil;
import com.freshpower.android.elec.client.common.SysSetGroupOneAdapter;
import com.freshpower.android.elec.client.common.UpdateManager;
import com.freshpower.android.elec.client.domain.LoginInfo;

public class ToolActivity extends FrameActivity{
	private RoundCornerListView groupTwolistview;
	private RoundCornerListView groupOnelistview;
	private RoundCornerListView groupThreelistview;
	private String[] menuNames;
	private int[] menuIcoIds;
	private String[] conditionValue;
	private ImageButton homeBtn;
	private Resources res;
	private boolean isUpdate=false;
	Integer update;
	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_tool);
		res = getResources();
		UpdateManager updateManager=new UpdateManager(ToolActivity.this);
		isUpdate=updateManager.isUpdate();
		findViews();
		setAdapter();
	}

	private void setAdapter(){
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		if (null!=loginInfo){
			Log.d("BID","getLoginName========"+loginInfo.getLoginName());
			groupOnelistview.setAdapter(new SimpleAdapter(this,getGroupOnelistData(), R.layout.listitem_style_one, new String[] { AppConstant.ListItemCtlName.MENU_ICO, AppConstant.ListItemCtlName.MENU_NAME,AppConstant.ListItemCtlName.CONDITION_VALUE}, new int[] { R.id.menuIco,R.id.menuName,R.id.conditionValue}));
			setListViewHeightBasedOnChildren(groupOnelistview);
		}else{
			groupOnelistview.setVisibility(View.GONE);
		}

		SysSetGroupOneAdapter sysOneAdapter = new SysSetGroupOneAdapter(getGroupTwolistData(),ToolActivity.this,R.layout.setup);
		groupTwolistview.setAdapter(sysOneAdapter);
		setListViewHeightBasedOnChildren(groupTwolistview);

		groupThreelistview.setAdapter(new SimpleAdapter(this,getGroupThreelistData(), R.layout.listitem_style_one, new String[] { AppConstant.ListItemCtlName.MENU_ICO, AppConstant.ListItemCtlName.MENU_NAME}, new int[] { R.id.menuIco,R.id.menuName}));
		setListViewHeightBasedOnChildren(groupThreelistview);
		groupThreelistview.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent,
					View view, int position, long id) {
				Map<String, Object> listItem = (Map<String, Object>)parent.getItemAtPosition(position);
				UpdateManager manager = new UpdateManager(ToolActivity.this);
				if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_ICO).toString())==R.drawable.recommendation){//����
					Intent intent = new Intent(Intent.ACTION_SEND); // �����������͵�����
					intent.setType("text/plain");
					intent.putExtra(Intent.EXTRA_SUBJECT, "subject");
					intent.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.msg_share_msg)); // ����������
					ToolActivity.this.startActivity(Intent.createChooser(intent, getResources().getString(R.string.menu_share)));// Ŀ��Ӧ��ѡ��Ի���ı���
				}
				else if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_ICO).toString())==R.drawable.opinion){
					Intent it = new Intent(ToolActivity.this,FeedBackActivity.class);
					startActivity(it);
				}else if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_ICO).toString())==R.drawable.about){
					Intent it = new Intent(ToolActivity.this,AboutActivity.class);
					startActivity(it);
				}else if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_ICO).toString())==R.drawable.contact){
					// ����Ի���
					AlertDialog.Builder builder = new Builder(ToolActivity.this);
					builder.setTitle(R.string.soft_call_freshpower_title);
					builder.setPositiveButton(R.string.soft_validate_validatebtn,
							new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+AppConstant.PHONE_NUM_FRESHPOEWR));  
							ToolActivity.this.startActivity(intent);
						}
					});
					builder.setNegativeButton(R.string.soft_validate_cancle,
							new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							dialog.dismiss();
						}
					});
					builder.setCancelable(false);
					Dialog noticeDialog = builder.create();
					noticeDialog.setCanceledOnTouchOutside(false);
					noticeDialog.show();
				}else if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_ICO).toString())==R.drawable.checkupdate_new){
					Toast.makeText(ToolActivity.this, R.string.soft_update_checking, Toast.LENGTH_SHORT).show();
					manager.checkUpdate(false);
				}else if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_ICO).toString())==R.drawable.checkupdate){
					Toast.makeText(ToolActivity.this, R.string.soft_update_checking, Toast.LENGTH_SHORT).show();
					manager.checkUpdate(false);
				}
			}

		});

	}
	protected void onResume() {
		homeBtn = (ImageButton) findViewById(R.id.toolbtn);
		if(homeBtn!=null){
			homeBtn.setOnClickListener(null);
			homeBtn.setBackgroundResource(R.drawable.toolbtn_select);
		}

		TextView toolBtnTv = (TextView)findViewById(R.id.toolBtnTv);
		toolBtnTv.setTextColor(getResources().getColor(R.color.white));

		super.onResume();
	}
	private void findViews(){
		groupOnelistview = (RoundCornerListView)findViewById(R.id.setMenulistviewOne);
		groupTwolistview = (RoundCornerListView)findViewById(R.id.setMenulistviewTwo);
		groupThreelistview = (RoundCornerListView)findViewById(R.id.setMenulistviewThree);
	}
	private List<Map<String, Object>> getGroupTwolistData(){
		menuNames=res.getStringArray(R.array.soft_myelectric_menuNames);
		menuIcoIds = new int[]{ R.drawable.tip ,R.drawable.vibration, R.drawable.gps};
		Boolean ckStatus[] = new Boolean[]{true,false,true}; 

		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < menuNames.length; i++)
		{
			Map<String, Object> listItem = new HashMap<String, Object>();
			listItem.put("menuIcoId", menuIcoIds[i]);
			listItem.put("menuNames", menuNames[i]);
			listItem.put("ckStatus", ckStatus[i]);
			listItems.add(listItem);
		}
		return listItems;
	}
	private List<Map<String, Object>> getGroupOnelistData(){
		menuNames=res.getStringArray(R.array.soft_user_menuNames);
		menuIcoIds = new int[]{ R.drawable.account};
		
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < menuNames.length; i++)
		{
			Map<String, Object> listItem = new HashMap<String, Object>();
			listItem.put(AppConstant.ListItemCtlName.MENU_ICO, menuIcoIds[i]);
			listItem.put(AppConstant.ListItemCtlName.MENU_NAME, menuNames[i]);
			String name=validateLoginInfo();
			if(null!=name&&!"".equals(name)){
				listItem.put(AppConstant.ListItemCtlName.CONDITION_VALUE, name);
				listItems.add(listItem);
			}
		}
		return listItems;
	}

	private List<Map<String, Object>> getGroupThreelistData(){
		if(isUpdate){
			update=R.drawable.checkupdate_new;
		}else{
			update=R.drawable.checkupdate;
		}
		menuNames=res.getStringArray(R.array.soft_setup_menuNames);
		menuIcoIds = new int[]{R.drawable.recommendation,R.drawable.about,R.drawable.contact,update,R.drawable.opinion};
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < menuNames.length; i++)
		{
			Map<String, Object> listItem = new HashMap<String, Object>();
			listItem.put(AppConstant.ListItemCtlName.MENU_ICO, menuIcoIds[i]);
			listItem.put(AppConstant.ListItemCtlName.MENU_NAME, menuNames[i]);
			listItems.add(listItem);
		}
		return listItems;
	}
	/***
	 * ��̬����listview�ĸ߶�
	 * 
	 * @param listView
	 */
	public void setListViewHeightBasedOnChildren(ListView listView) {
		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null) {
			return;
		}
		int totalHeight = 0;
		for (int i = 0; i < listAdapter.getCount(); i++) {
			View listItem = listAdapter.getView(i, null, listView);
			//View listItem = inflater.inflate(android.R.layout.simple_expandable_list_item_1, null);
			listItem.measure(0, 0);
			totalHeight += listItem.getMeasuredHeight();
		}
		ViewGroup.LayoutParams params = listView.getLayoutParams();
		params.height = totalHeight
				+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
		listView.setLayoutParams(params);
	}
	/*
	 * 
	 */
	public String  validateLoginInfo(){
		String name = null;
		if(!StringUtil.isEmpty(AppCache.LOGININFO_OBJ)){
			LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
			if(null!=loginInfo&&!"".equals(loginInfo)){
				name=loginInfo.getLoginName();
			}
		}
		return name;
	}
}
