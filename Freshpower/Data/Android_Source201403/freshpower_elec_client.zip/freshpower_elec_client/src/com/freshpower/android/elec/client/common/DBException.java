package com.freshpower.android.elec.client.common;

/**
 * @author yangz
 *
 */
public class DBException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8084564202522488076L;
	public DBException() {
		
	}
	/**
	 * 
	 * @param message Message to use for the exception
	 */
	public DBException(String message) {
		super(message);
	}
	/**
	 * 
	 * @param e Exception
	 */
	public DBException(Exception e){
		super(e.getMessage());
	}
	/**
    * Constructor based on a message and an existing exception.
    *
    * @param msg   Message to use for the exception
    * @param cause The root caues to chain
    */
	public DBException(String msg, Throwable cause) {
		super(msg, cause);
	}
}
