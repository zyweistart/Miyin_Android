/**   
 * @{#} StringUtil.java Create on 2013-1-4 ����02:44:37   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.client.common;   
  
/**   
 * @author <a href="mailto:yangz@freshpower.cn">yangz</a>  
 * @version 1.0   
 */

public class StringUtil {
	
	/**
	 * �Ƿ�Ϊ��
	 * @param str ��Ҫ����ֵ
	 * @return
	 */
	public static boolean isEmpty(String str) {
		return str == null || str.trim().length() == 0;
    }
	
	
	
	public static String ISEMAIL = "([\\w[_-][\\.]]+@+[\\w[_-]]+\\.+[A-Za-z]{2,3})|([\\"
			+ "w[_-][\\.]]+@+[\\w[_-]]+\\.+[\\w[_-]]+\\.+[A-Za-z]{2,3})|"
			+ "([\\w[_-][\\.]]+@+[\\w[_-]]+\\.+[\\w[_-]]+\\.+[\\w[_-]]+"
			+ "\\.+[A-Za-z]{2,3})"; // ��֤����
	public static final String IS18IDCARD = "((11|12|13|14|15|21|22|23|31|32|33|34|35|36|37|41|42|43|44|45|46|50|51"
			+ "|52|53|54|61|62|63|64|65|71|81|82|91)\\d{4})((((19|20)(([02468][048])|([13579][26]"
			+ "))0229))|((20[0-9][0-9])|(19[0-9][0-9]))((((0[1-9])|(1[0-2]))((0[1-9])|(1\\d)"
			+ "|(2[0-8])))|((((0[1,3-9])|(1[0-2]))(29|30))|(((0[13578])|(1[02]))31))))"
			+ "((\\d{3}(x|X))|(\\d{4}))";// ��֤18λ������֤����
}
  
