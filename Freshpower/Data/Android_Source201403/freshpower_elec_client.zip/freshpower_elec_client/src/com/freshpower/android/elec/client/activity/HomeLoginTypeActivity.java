package com.freshpower.android.elec.client.activity;

import org.apache.http.conn.HttpHostConnectException;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class HomeLoginTypeActivity extends Activity {
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.activity_home_logintype);
		ImageView experienceiv=(ImageView)findViewById(R.id.homeExperienceLogin);
		experienceiv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(HomeLoginTypeActivity.this,HomeActivity.class);
				intent.putExtra("isFirst", "isFirst");
				startActivity(intent);
				finish();	
			}
		});
		ImageView companyiv=(ImageView)findViewById(R.id.homeCompanyLogin);
		companyiv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(HomeLoginTypeActivity.this,LoginActivity.class);
				startActivity(intent);
				finish();
			}
		});

	}
}
