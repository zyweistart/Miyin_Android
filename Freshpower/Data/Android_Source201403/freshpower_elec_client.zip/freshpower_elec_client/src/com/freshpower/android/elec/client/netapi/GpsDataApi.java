/**   
 * @{#} GpsDataApi.java Create on 2013-4-24 ����02:23:32   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.client.netapi;

import java.io.File;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import android.util.Log;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.conf.AppConfig;
import com.freshpower.android.elec.client.domain.GpsDataInfo;
import com.freshpower.android.elec.client.domain.LoginInfo;

/**
 * @author <a href="mailto:yangz@freshpower.cn">yangz</a>
 * @version 1.0
 * GPS������ݻ�ȡ
 */
public class GpsDataApi extends JsonDataApi {
	private static final String ACTION_NAME_APPFOUND = "AppFoundE.aspx";//�ҵ繤����

	/**
	 * �ҵ繤gps��Ϣ
	 * @cpId �ͻ�ID
	 * @return �繤GPS��Ϣ����
	 * @throws Exception
	 */
	public static List<GpsDataInfo> getFoundE(String cpId) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("CP_ID", cpId);
		JSONObject jsonResult = api
				.getForJsonResult(AppConfig.getInstance().getFpsWebSite()+ File.separator + ACTION_NAME_APPFOUND,AppConstant.ETG_INTERFACE_CHARSET);
		
		JSONArray FoundEJA = jsonResult.getJSONArray("FoundE");
		
		List<GpsDataInfo> gpsDataInfoList = null;
		GpsDataInfo gpsDataInfo = null;
		LoginInfo loginInfo = null;
		JSONObject jsonObj = null;
		
		int result = jsonResult.getJSONObject("Rows").getIntValue("result");
		if(result==1 && FoundEJA!=null){
			gpsDataInfoList = new ArrayList<GpsDataInfo>();
			for (int i = 0; i < FoundEJA.size(); i++) {
				gpsDataInfo = new GpsDataInfo();
				loginInfo = new LoginInfo();
				jsonObj = (JSONObject)FoundEJA.get(i);
				gpsDataInfo.setLongitude(Double.parseDouble(jsonObj.getString("LONGITUDE")==null?"0":jsonObj.getString("LONGITUDE")));
				gpsDataInfo.setLatitude(Double.parseDouble(jsonObj.getString("LATITUDE")==null?"0":jsonObj.getString("LATITUDE")));
				loginInfo.setUserName(jsonObj.getString("USER_NAME"));
				loginInfo.setPhoneNum(jsonObj.getString("MB"));
				gpsDataInfo.setLoginInfo(loginInfo);
				gpsDataInfoList.add(gpsDataInfo);
			}
		}
		return gpsDataInfoList;
	}
	

}
