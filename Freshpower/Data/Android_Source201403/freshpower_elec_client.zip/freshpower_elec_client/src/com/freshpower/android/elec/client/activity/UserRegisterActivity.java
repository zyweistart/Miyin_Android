package com.freshpower.android.elec.client.activity;

import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.conn.HttpHostConnectException;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.DBOperater;
import com.freshpower.android.elec.client.common.FileUtil;
import com.freshpower.android.elec.client.common.MD5;
import com.freshpower.android.elec.client.common.StringUtil;
import com.freshpower.android.elec.client.domain.LoginInfo;
import com.freshpower.android.elec.client.domain.UserRegisterInfo;
import com.freshpower.android.elec.client.netapi.LoginInfoDataApi;

public class UserRegisterActivity  extends Activity {
	private UserRegisterInfo userRegisterInfo;
	private Button loginSub;
	private ProgressDialog processProgress;
	private Handler handler = new Handler();

	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_userregister);
		ActivityUtil.addActivity(this);
		loginSub=(Button)findViewById(R.id.loginRegisterSub);
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				UserRegisterActivity.this.onBackPressed();
			}
		});
		loginSub.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				EditText loginRegisterName_et=(EditText)findViewById(R.id.loginRegisterName);
				EditText loginRegisterTel_et=(EditText)findViewById(R.id.loginRegisterTel);
				EditText loginRegisterCardNum_et=(EditText)findViewById(R.id.loginRegisterCardNum);
				EditText loginRegisterAddress_et=(EditText)findViewById(R.id.loginRegisterAddress);
				Pattern pattern;
				Matcher matcher;
				if(loginRegisterName_et.getText().toString().equals(""))
				{
					Toast.makeText(UserRegisterActivity.this, R.string.user_register_name, Toast.LENGTH_SHORT).show();
					return;
				}
				if(loginRegisterTel_et.getText().toString().equals(""))
				{
					Toast.makeText(UserRegisterActivity.this, R.string.user_register_tel, Toast.LENGTH_SHORT).show();
					return;
				}else if(11!=loginRegisterTel_et.getText().toString().length()){
					Toast.makeText(UserRegisterActivity.this, R.string.user_register_telNot, Toast.LENGTH_SHORT).show();
					return;
				}
				if(loginRegisterCardNum_et.getText().toString().equals(""))
				{
					Toast.makeText(UserRegisterActivity.this, R.string.user_register_card, Toast.LENGTH_SHORT).show();
					return;
				}
				else {
					pattern = Pattern.compile(StringUtil.IS18IDCARD);
					matcher = pattern.matcher(loginRegisterCardNum_et.getText().toString());
					if(!matcher.matches()){
						Toast.makeText(UserRegisterActivity.this, R.string.user_register_cardNot, Toast.LENGTH_SHORT).show();
						return;
					}
				}
				if(loginRegisterAddress_et.getText().toString().equals(""))
				{
					Toast.makeText(UserRegisterActivity.this, R.string.user_register_address, Toast.LENGTH_SHORT).show();
					return;
				}
				userRegisterInfo=new UserRegisterInfo();
				userRegisterInfo.setLoginRegisterName(loginRegisterName_et.getText().toString());
				userRegisterInfo.setLoginRegisterTel(loginRegisterTel_et.getText().toString());
				userRegisterInfo.setLoginRegisterCardNum(loginRegisterCardNum_et.getText().toString());
				userRegisterInfo.setLoginRegisterAddress(loginRegisterAddress_et.getText().toString());
				processProgress = ProgressDialog.show(UserRegisterActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
				new Thread(new Runnable(){
					String msgContent;
					@Override
					public void run() {
						String crmRs="0";
						try {
							//					Intent intent =getIntent();
							//					if(intent.getStringExtra("fileNot")!=null&&!intent.getStringExtra("fileNot").equals("")&&intent.getStringExtra("fileNot").equals("0")){//�ļ�������
							//						String rs=LoginInfoDataApi.getRegisterInfoAuditTrms(userRegisterInfo);//���״̬�ӿ�
							//						//�ӿ� �õ���
							//						if(rs.equals("1")){//���ͨ��
							//							Intent intent1 = new Intent(UserRegisterActivity.this,UserExperienceActivity.class);
							//							startActivity(intent1);
							//						}else if(rs.equals("0")){//��˲�ͨ��
							//							Toast.makeText(UserRegisterActivity.this, R.string.msg_auditnot_network,Toast.LENGTH_SHORT).show();
							//							return;
							//						}else if(rs.equals("2")){//�����
							//							Toast.makeText(UserRegisterActivity.this, R.string.msg_audit_network,Toast.LENGTH_SHORT).show();
							//							return;
							//						}else if(rs.equals("3")){//δ�ύ����   CRM��֤
							//							//�ӿ� CRM
							//							String crmRs=LoginInfoDataApi.getRegisterInfoCrm(userRegisterInfo);
							//							if("1".equals(crmRs)){//CRM�ж��Ƿ����   ����ֱ������
							//								Intent intent2 = new Intent(UserRegisterActivity.this, UserExperienceActivity.class);
							//								startActivity(intent2);
							//								finish();	
							//							}else if("0".equals(crmRs)){//������    �ϴ�ע����Ϣ
							//								writeLoginInfoContent(userRegisterInfo);
							//								Intent phonto = new Intent(UserRegisterActivity.this, PhontoActivity.class);
							//								phonto.putExtra("registerName", userRegisterInfo.getLoginRegisterName());
							//								phonto.putExtra("registerCardNum", userRegisterInfo.getLoginRegisterCardNum());
							//								phonto.putExtra("registerTel", userRegisterInfo.getLoginRegisterTel());
							//								phonto.putExtra("registerAddress", userRegisterInfo.getLoginRegisterAddress());
							//								startActivity(phonto);
							//								finish();	
							//							}else{//����ʧ��
							//								
							//							}
							//						}
							//					}else{
							//�ӿ� CRM
							crmRs=LoginInfoDataApi.getRegisterInfoCrm(userRegisterInfo);
							//					}
						}catch (HttpHostConnectException e) {
							msgContent = getResources().getString(R.string.msg_abnormal_network);
						}catch (Exception e) {
							msgContent = getResources().getString(R.string.msg_abnormal_network); 
						}finally{
							processProgress.dismiss();
//							handler.post(new Runnable() {
//								@Override
//								public void run() {
//									Toast.makeText(UserRegisterActivity.this, msgContent, Toast.LENGTH_SHORT).show(); 								
//								}
//							});
							if(crmRs.equals("1")){//CRM�ж��Ƿ����  
								Intent it = new Intent(UserRegisterActivity.this, HomeActivity.class);
								startActivity(it);
								finish();	
							}else if(crmRs.equals("0")){//������    �ϴ�ע����Ϣ
								//							writeLoginInfoContent(userRegisterInfo);
								Intent phonto = new Intent(UserRegisterActivity.this, PhontoActivity.class);
								phonto.putExtra("registerName", userRegisterInfo.getLoginRegisterName());
								phonto.putExtra("registerCardNum", userRegisterInfo.getLoginRegisterCardNum());
								phonto.putExtra("registerTel", userRegisterInfo.getLoginRegisterTel());
								phonto.putExtra("registerAddress", userRegisterInfo.getLoginRegisterAddress());
								startActivity(phonto);
							}
						}
					}
				}).start();
			}

		});
	}
	public void writeLoginInfoContent(UserRegisterInfo userRegisterInfo){
		if(!FileUtil.isFileExist(FileUtil.getElecFilePath())){
			DBOperater.openOrCreateDB(FileUtil.getElecFilePath());
			try {
				File dbFile = new File(FileUtil.getElecFilePath());
				FileUtil.createFolder(dbFile.getParent());
				FileUtil.createFile(dbFile);
			} catch (Exception e) {
				Log.e("dberror", e.toString());
				e.printStackTrace();
			}
		}else{
			String fileContent = FileUtil.read(FileUtil.getElecFilePath());
			fileContent = userRegisterInfo.getLoginRegisterName()
					+ "|"
					+ userRegisterInfo.getLoginRegisterTel()
					+ "|"
					+ userRegisterInfo.getLoginRegisterCardNum()
					+ "|"
					+ userRegisterInfo.getLoginRegisterAddress()
					+ "|"
					+ fileContent.substring(fileContent
							.lastIndexOf('|') + 1);
			FileUtil.writeBeforeClearContent(
					FileUtil.getElecFilePath(), fileContent); 
		}

	}

	@Override
	protected void onRestart() {
		loginSub.setEnabled(true);//�������ؼ�����Ϊ���� 
		super.onRestart();  
	}


}
