/**   
 * @{#} FileUtil.java Create on 2012-10-23 ����09:29:06   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.client.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

/**
 * 
 * @author <a href="mailto:yangz@freshpower.cn">yangz</a>
 * @version 1.0
 */
public class FileUtil {
	private final static String appFolder = "elecClient";
	private final static String dbFileName = "cache1_0.dat";
	private final static String elecFileName = "cache2_0.dat";
	public static String appFilesDir = "";

	public static String getSDPATH() {
		String sde = Environment.getExternalStorageState();
		String path = null;
		if (sde.equals(Environment.MEDIA_MOUNTED)) {
			path = Environment.getExternalStorageDirectory().toString();
		} else {
			path = appFilesDir;
		}
		return path;
	}

	/**
	 * ��ȡӦ���ļ���Ŀ¼
	 * 
	 * @return
	 */
	public static String getAppRootPath() {
		return getSDPATH() + File.separator + appFolder + File.separator;
	}

	/**
	 * ��װAPK��
	 * 
	 * @param apkPath
	 * @return
	 */
	public static void installApk(String apkPath, Activity activity) {
		String type = null;
		Intent intent = new Intent();
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setAction(android.content.Intent.ACTION_VIEW);
		String end = (apkPath.substring(apkPath.lastIndexOf(".") + 1,
				apkPath.length())).toLowerCase();
		if (end.equals("apk")) {
			type = "application/vnd.android.package-archive";
		}
		if (type != null) {
			intent.setDataAndType(Uri.fromFile(new File(apkPath)), type);
			activity.startActivity(intent);
		} else {
			Toast.makeText(activity, "δ�ҵ������ļ�", Toast.LENGTH_LONG).show();
		}
	}

	public static final String getDBFilePath() {
		return getAppRootPath() + dbFileName;
	}
	
	public static final String getElecFilePath() {
		return getAppRootPath() + elecFileName;
	}

	/**
	 * �ж��ļ�����Ŀ¼�Ƿ����
	 * 
	 * @param path
	 * @return
	 */
	public static boolean isFolderExist(String path) {
		File file = new File(path);
		return file.isDirectory() && file.exists();
	}

	/**
	 * �ж��ļ��Ƿ����
	 * 
	 * @param path
	 * @return
	 */
	public static boolean isFileExist(String path) {
		File file = new File(path);
		return file.isFile() && file.exists();
	}

	/**
	 * ����Ŀ¼
	 * 
	 * @param path
	 * @return
	 */
	public static File createFolder(String path) {
		File dir = new File(path);
		dir.mkdirs();
		return dir;
	}

	/**
	 * �����ı��ļ�
	 */
	public static void createFile(File file, String fileContext) {
		try {
			if (!file.exists()) {
				if (file.createNewFile() == false) {
					Log.e("FileUtil", "�ļ�����ʧ�ܣ�" + file.getAbsolutePath());
					return;
				}
			}
			FileWriter resultFile = new FileWriter(file);
			PrintWriter myFile = new PrintWriter(resultFile);
			myFile.print(fileContext);
			resultFile.close();
			myFile.close();
		} catch (IOException e) {
			Log.e("FileUtil.createFile", e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * �����ı��ļ�
	 */
	public static void createFile(File file) {
		try {
			if (!file.exists()) {
				if (file.createNewFile() == false) {
					Log.e("FileUtil", "�ļ�����ʧ�ܣ�" + file.getAbsolutePath());
					return;
				}
			}
			FileWriter resultFile = new FileWriter(file);
			PrintWriter myFile = new PrintWriter(resultFile);
			resultFile.close();
			myFile.close();
		} catch (IOException e) {
			Log.e("FileUtil.createFile", e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * �ļ����ݶ�ȡ
	 * 
	 * @param fileName
	 *            �ļ���
	 * @return
	 */
	public static String read(String fileName) {
		FileReader fr = null;
		BufferedReader br = null;
		StringBuffer sb = null;
		// �����ַ���
		try {
			fr = new FileReader(fileName);// �ַ��ļ���ȡ
			br = new BufferedReader(fr);// �����ַ���
			String line = br.readLine();
			sb = new StringBuffer();
			// ��ʼ��ȡ
			while (line != null) {
				sb.append(line);
				line = br.readLine();
			}
		} catch (Exception e) {
			Log.e("FileUtil.read", e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (br != null) {
					br.close();
				}
				if (fr != null) {
					fr.close();
				}
			} catch (IOException e) {
				Log.e("FileUtil.read clolse", e.getMessage());
				e.printStackTrace();
			}
		}
		return sb.toString();
	}

	/**
	 * д���ı��ļ�����
	 * 
	 * @param fileName
	 *            �ļ�����
	 * @param content
	 *            �ļ�����
	 */
	public static void write(String fileName, String content) {
		FileWriter fw = null;
		BufferedWriter bw = null;
		try {
			fw = new FileWriter(fileName, true); // ���� �ļ�д��
			bw = new BufferedWriter(fw);// �ַ������
			bw.write(content);
		} catch (Exception e) {
			Log.e("FileUtil.write", e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (bw != null) {
					bw.flush();
				}
				if (fw != null) {
					fw.close();
				}
			} catch (IOException e) {
				Log.e("FileUtil.write close", e.getMessage());
				e.printStackTrace();
			}
		}
	}

	public static void writeBeforeClearContent(String fileName, String content) {
		clearConent(fileName);
		write(fileName, content);
	}

	public static void clearConent(String fileName) {
		FileWriter fw = null;
		try {
			File f = new File(fileName);
			fw = new FileWriter(f);
			fw.write("");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (fw != null)
					fw.close();
			} catch (IOException e) {
				Log.e("FileUtil.clearConent close", e.getMessage());
				e.printStackTrace();
			}
		}

	}

	/**
	 * ��һ��InputStream���������д�뵽SD����
	 */
	public File write2SDFromInput(String path, String fileName,
			InputStream input) {
		File file = null;
		OutputStream output = null;
		try {
			creatSDDir(path);
			file = creatFileInSDCard(path + fileName);
			output = new FileOutputStream(file);
			byte buffer[] = new byte[4 * 1024];
			int temp;
			while ((temp = input.read(buffer)) != -1) {
				output.write(buffer, 0, temp);
			}
			output.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				output.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return file;
	}

	/**
	 * ��SD���ϴ���Ŀ¼
	 * 
	 * @param dirName
	 */
	public File creatSDDir(String dirName) {
		return createFolder(getSDPATH() + dirName);
	}

	/**
	 * ��SD���ϴ����ļ�
	 * 
	 * @throws IOException
	 */
	public File creatFileInSDCard(String fileName) throws IOException {
		File file = new File(getSDPATH() + fileName);
		file.createNewFile();
		return file;
	}

	/**
	 * ɾ���ļ�
	 * 
	 * @param fileName
	 *            �ļ�����·����
	 * @return
	 */
	public static boolean deleteFile(String fileName) {
		File file = new File(fileName);
		boolean flag = false;
		if (file.isFile() && file.exists()) {
			flag = file.delete();
		}
		return flag;
	}

	/**
	 * ɾ��SDCard���ļ�
	 * 
	 * @param fileName
	 *            �ļ�����·����
	 * @return
	 */
	public static boolean deleteFileInSDCard(String fileName) {
		return deleteFile(getSDPATH() + fileName);
	}
	
	
	
	
	public static boolean downLoadRun(String urlStr,String pictureName){
		try {
			// �ж�SD���Ƿ���ڣ������Ƿ���ж�дȨ��
			Log.d("BID", ""+Environment.getExternalStorageState().equals(
					Environment.MEDIA_MOUNTED));
			if (Environment.getExternalStorageState().equals(
					Environment.MEDIA_MOUNTED)) {
				// ��ô洢����·��
				String sdpath = getSDPATH();
				String mSavePath;
				mSavePath = sdpath + "/elecClient/download/toppicture";
				Log.d("BID", "mSavePath:"+mSavePath);
				URL url = new URL(urlStr+File.separator+pictureName);
				// ��������
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.connect();
				// ��ȡ�ļ���С
				int length = conn.getContentLength();
				// ����������
				Log.d("BID", "length:"+length);
				InputStream is = conn.getInputStream();

				File file = new File(mSavePath);
				// �ж��ļ�Ŀ¼�Ƿ����
				Log.d("BID", "file.exists:"+String.valueOf(file.exists()));
				if (!file.exists()) {
					file.mkdirs();
				}
				Log.d("BID", "file.exists:"+String.valueOf(file.exists()));
				File apkFile = new File(mSavePath, pictureName.split("\\.")[0]);
				FileOutputStream fos = new FileOutputStream(apkFile);
				// ����
				byte buf[] = new byte[1024];
				// д�뵽�ļ���
				do {
					int numread = is.read(buf);

					if (numread <= 0) {
						// �������
						break;
					}
					// д���ļ�
					fos.write(buf, 0, numread);
				} while (true);// һֱ���أ�ֱ���������
				fos.close();
				is.close();
			}
		} catch(FileNotFoundException e){
			Log.d("BID","FileNotFoundException:"+pictureName+"�ļ������ڣ�");
			return false;
		}catch (MalformedURLException e) {
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	/**  
	 *  ����·��ɾ��ָ����Ŀ¼���ļ������۴������  
	 *@param sPath  Ҫɾ����Ŀ¼���ļ�  
	 *@return ɾ���ɹ����� true�����򷵻� false��  
	 */  
	public static boolean deleteFolder(String sPath) {   
	    boolean flag = false;   
	    File file = new File(sPath);   
	    // �ж�Ŀ¼���ļ��Ƿ����   
	    if (!file.exists()) {  // �����ڷ��� false   
	        return flag;   
	    } else {   
	        // �ж��Ƿ�Ϊ�ļ�   
	        if (file.isFile()) {  // Ϊ�ļ�ʱ����ɾ���ļ�����   
	            return deleteFile(sPath);   
	        }else {  // ΪĿ¼ʱ����ɾ��Ŀ¼����   
	            return deleteDirectory(sPath);   
	        } 
	    } 
	} 
	
	
	/**  
	 * ɾ��Ŀ¼���ļ��У��Լ�Ŀ¼�µ��ļ�  
	 * @param   sPath ��ɾ��Ŀ¼���ļ�·��  
	 * @return  Ŀ¼ɾ���ɹ�����true�����򷵻�false  
	 */  
	public static boolean deleteDirectory(String sPath) {   
	    //���sPath�����ļ��ָ�����β���Զ������ļ��ָ���   
	    if (!sPath.endsWith(File.separator)) {   
	        sPath = sPath + File.separator;   
	    }   
	    File dirFile = new File(sPath);   
	    //���dir��Ӧ���ļ������ڣ����߲���һ��Ŀ¼�����˳�   
	    if (!dirFile.exists() || !dirFile.isDirectory()) {   
	        return false;   
	    }   
	    boolean flag = true;   
	    //ɾ���ļ����µ������ļ�(������Ŀ¼)   
	    File[] files = dirFile.listFiles();   
	    for (int i = 0; i < files.length; i++) {   
	        //ɾ�����ļ�   
	        if (files[i].isFile()) {   
	            flag = deleteFile(files[i].getAbsolutePath());   
	            if (!flag) break;   
	        } //ɾ����Ŀ¼   
	        else {   
	            flag = deleteDirectory(files[i].getAbsolutePath());   
	            if (!flag) break;   
	        }   
	    }   
	    if (!flag) return false;   
	    //ɾ����ǰĿ¼   
	    if (dirFile.delete()) {   
	        return true;   
	    } else {   
	        return false;   
	    }   
	}  
}