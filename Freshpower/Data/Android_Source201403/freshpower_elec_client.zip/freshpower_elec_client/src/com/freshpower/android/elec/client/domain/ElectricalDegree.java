package com.freshpower.android.elec.client.domain;

public class ElectricalDegree {
	private double factorPower;//�й�����
	private double spikesPower;//������
	private double peakPower;//�߷����
	private double troughPower;//�͹ȵ���
	private double expend;//ʵ������
	private double nowRead;//���ζ���
	private double lastRead;//�ϴζ���
	public double getExpend() {
		return expend;
	}
	public void setExpend(double expend) {
		this.expend = expend;
	}
	public double getNowRead() {
		return nowRead;
	}
	public void setNowRead(double nowRead) {
		this.nowRead = nowRead;
	}
	public double getLastRead() {
		return lastRead;
	}
	public void setLastRead(double lastRead) {
		this.lastRead = lastRead;
	}
	public double getFactorPower() {
		return factorPower;
	}
	public void setFactorPower(double factorPower) {
		this.factorPower = factorPower;
	}
	public double getSpikesPower() {
		return spikesPower;
	}
	public void setSpikesPower(double spikesPower) {
		this.spikesPower = spikesPower;
	}
	public double getPeakPower() {
		return peakPower;
	}
	public void setPeakPower(double peakPower) {
		this.peakPower = peakPower;
	}
	public double getTroughPower() {
		return troughPower;
	}
	public void setTroughPower(double troughPower) {
		this.troughPower = troughPower;
	}
}
