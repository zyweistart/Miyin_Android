package com.freshpower.android.elec.client.common;

import android.util.Log;

/**
 * 
 * @author yangz
 * ��־����
 */
public class LogFactory {
	private String LOGTAG;
	private boolean enable = true;
	
	private LogFactory(String logTag){
		StringBuffer sb = new StringBuffer();
		sb.append("elecClient")
		.append("_")
		.append(logTag)
		.append("_");
		this.LOGTAG = sb.toString();
	}
	
	public static LogFactory getLogger(Class cls){
		return new LogFactory(cls.getSimpleName());
	}
	
	public void e(String tag,String msg){
		outPutLog(Log.ERROR, tag, msg);
	}
	
	public void w(String tag,String msg){
		outPutLog(Log.WARN, tag, msg);
	}
	
	public void i(String tag,String msg){
		outPutLog(Log.INFO, tag, msg);
	}
	
	public void d(String tag,String msg){
		outPutLog(Log.DEBUG, tag, msg);
	}
	
	public void v(String tag,String msg){
		outPutLog(Log.VERBOSE, tag, msg);
	}
	
	/**
	 * ��Ϣ���
	 * @param priority �ȼ�
	 * @param tag ��ʶ
	 * @param msg ��Ϣ����
	 */
	private void outPutLog(int priority,String tag,String msg){
		if(enable){
			Log.println(priority, LOGTAG+tag , msg);
		}
	}
}
