package com.freshpower.android.elec.client.common;

import java.io.File;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * @author yangz
 *
 */
public class DBOperater {
	private String fileName;
	private DBOperater(String fileName){
		this.fileName = fileName;
		File file = new File(fileName);
		File parent = new File(file.getParent());
		if(!parent.exists()){
			parent.mkdirs();
		}
	}
	
	public static DBOperater getInstance(String fileName){
		return new DBOperater(fileName);
	}
	
	/**
	 * �򿪻򴴽����ݿ�
	 * @throws DBException 
	 */
	public SQLiteDatabase openOrCreateDB() throws DBException{
		SQLiteDatabase db = null;
		try{
			db = SQLiteDatabase.openOrCreateDatabase(fileName, null);
		}catch(Exception e){
			throw new DBException(e);
		}
		return db;
	}
	
	/**
	 * �����ݿ�
	 * @return
	 * @throws DBException 
	 */
	public SQLiteDatabase openDB() throws DBException{
		try{
			File file = new File(fileName);
			if(file.exists()){
				return SQLiteDatabase.openDatabase(fileName, null, SQLiteDatabase.OPEN_READWRITE);
			}else {
				return SQLiteDatabase.openOrCreateDatabase(fileName, null);
			}
		}catch(Exception e){
			throw new DBException(e);
		}
	}
	
	/**
	 * �ر����ݿ�
	 * @param db
	 * @throws DBException 
	 */
	public void closeDB(SQLiteDatabase db) throws DBException{
		try{
			db.close();
		}catch(Exception e){
			throw new DBException(e);
		}
	}
	
	/**
	 * ɾ�����ݿ�
	 * @return
	 * @throws DBException 
	 */
	public boolean deleteDB() throws DBException{
		try{
			File file = new File(fileName);
			if(file.exists()){
				return file.delete();
			}
			return true;
		}catch(Exception e){
			throw new DBException(e);
		}
	}
	
	/**
	 * ִ��SQL���
	 * @param sql
	 * @throws DBException 
	 */
	public void execQuery(String sql) throws DBException{
		try{
			SQLiteDatabase db = openDB();
			db.execSQL(sql);
			db.close();
		}catch(Exception e){
			throw new DBException(e);
		}
	}
	
	/**
	 * ִ��SQL���
	 * @param sql
	 * @throws DBException 
	 */
	public void execQuery(String sql,String[] args) throws DBException{
		try{
			SQLiteDatabase db = openDB();
			db.execSQL(sql,args);
			db.close();
		}catch(Exception e){
			throw new DBException(e);
		}
	}
	
	/**
	 * �򿪲�ѯ����ȡ�α���
	 * @param tableName
	 * @param condStr
	 * @return
	 * @throws DBException 
	 */
	public Cursor openQuery(String sql,String[] args) throws DBException{
		try{
			SQLiteDatabase db = openDB();
			Cursor cursor =db.rawQuery(sql, args);
			cursor.moveToFirst();
			db.close();
			return cursor;
		}catch(Exception e){
			throw new DBException(e);
		}
	}
	
	/**
	 * �ж����ݿ���Ƿ����
	 * @param tableName
	 * @return
	 * @throws DBException 
	 */
	public boolean isTableExists(String tableName) throws DBException{
		try{
			Cursor cursor = openQuery("select sqlist_master where tbl_name='"+tableName+"'",null);
			int count = cursor.getCount();
			cursor.close();
			return count>0;
		}catch(Exception e){
			throw new DBException(e);
		}
	}
	
	
	/**
	 * �򿪻򴴽����ݿ�
	 * @param ���ݿ��ļ�·��
	 */
	public static void openOrCreateDB(String fileName){
		File file = new File(fileName);
		openOrCreateDB(file);
	}
	
	/**
	 * �򿪻򴴽����ݿ�
	 * @param ���ݿ��ļ�·��
	 */
	public static void openOrCreateDB(File file){
		File parent = new File(file.getParent());
		if(!parent.exists()){
			parent.mkdirs();
		}
		SQLiteDatabase db = SQLiteDatabase.openOrCreateDatabase(file, null);
		db.close();
	}
	
}
