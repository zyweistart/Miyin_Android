package com.freshpower.android.elec.client.netapi;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.client.common.Base64;
import com.freshpower.android.elec.client.conf.AppConfig;
import com.freshpower.android.elec.client.domain.PurchaseType;

/**
 * 
 * @author yzsunlight
 *
 */
public class PurchaseTypeApi extends JsonDataApi {
	private static final String ACTION_NAME = "struts/app/getPurchaseTypeList.do";
	
	public static List<PurchaseType> getAppStoreInfo(String id,int type) throws Exception {
		 List<PurchaseType> purchaseTypeList = new ArrayList<PurchaseType>();
		 JsonDataApi api = JsonDataApi.getInstance();
		 api.addParam("id", id);
		 api.addParam("type", String.valueOf(type).trim());
		 JSONObject jsonResult =api.postForJsonResult(""+File.separator+ACTION_NAME); 
		 JSONArray jsonArray = jsonResult.getJSONArray("purchaseType");
		 PurchaseType purchaseType = null;
		 for (int i = 0; i < jsonArray.size(); i++) {
			 JSONObject jsonObj = (JSONObject) jsonArray.get(i);
			 purchaseType = new PurchaseType();
			 purchaseType.setId(jsonObj.getLong("id"));
			 purchaseType.setParentId(jsonObj.getLong("parentId"));
			 purchaseType.setName(new String(Base64.decode(jsonObj.getString("name")),"GBK"));
			 purchaseType.setHasChild(jsonObj.getIntValue("hasChild"));
			 purchaseType.setCode(jsonObj.getString("code"));
			 purchaseType.setType(jsonObj.getIntValue("type"));
			 purchaseTypeList.add(purchaseType);
		 }
		 return purchaseTypeList;
	}
}
