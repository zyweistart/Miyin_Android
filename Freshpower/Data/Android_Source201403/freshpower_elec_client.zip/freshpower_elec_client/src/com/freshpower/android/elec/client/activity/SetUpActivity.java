package com.freshpower.android.elec.client.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.SysSetGroupOneAdapter;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class SetUpActivity extends Activity{
	private LayoutInflater inflater;
	private RoundCornerListView groupOnelistview;
	private RoundCornerListView groupTwolistview;
	private Resources res;
	private String[] menuNames;
	private int[] menuIcoIds;
	private ImageButton systemBtn;
	private TextView textView;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.myelectric);
		ActivityUtil.addActivity(this);
		textView = (TextView) findViewById(R.id.topBarTextView);
		res = getResources();
		inflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		findViews();
		setAdapter();
	}
	private void findViews(){
		groupTwolistview = (RoundCornerListView)findViewById(R.id.setMenulistviewTwo);
	}
	private void setAdapter(){
		//groupOnelistview.setAdapter(new SimpleAdapter(this,getGroupOnelistData(), R.layout.sysset_listitem_groupone, new String[] {  "menuIcoId", "menuNames"}, new int[] {R.id.sysSetMenuIco,R.id.sysSetMenuName}));
		SysSetGroupOneAdapter sysOneAdapter = new SysSetGroupOneAdapter(getGroupOnelistData(),SetUpActivity.this,R.layout.setup);
		groupTwolistview.setAdapter(sysOneAdapter);
		setListViewHeightBasedOnChildren(groupTwolistview);
	}
	private List<Map<String, Object>> getGroupOnelistData(){
		menuNames=res.getStringArray(R.array.soft_user_menuNames);
		menuIcoIds = new int[]{ R.drawable.checkupdate,R.drawable.about};
		Boolean ckStatus[] = new Boolean[]{true,false}; 
		
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < menuNames.length; i++)
		{
			Map<String, Object> listItem = new HashMap<String, Object>();
			listItem.put("menuIcoId", menuIcoIds[i]);
			listItem.put("menuNames", menuNames[i]);
			listItem.put("ckStatus", ckStatus[i]);
			listItems.add(listItem);
		}
		
		return listItems;
	}
	
	/***
     * ��̬����listview�ĸ߶�
     * 
     * @param listView
     */
    public void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            return;
        }
        int totalHeight = 0;
        for (int i = 0; i < listAdapter.getCount(); i++) {
           View listItem = listAdapter.getView(i, null, listView);
        	//View listItem = inflater.inflate(android.R.layout.simple_expandable_list_item_1, null);
            listItem.measure(0, 0);
            totalHeight += listItem.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight
                + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        // params.height += 5;// if without this statement,the listview will be
        // a
        // little short
        // listView.getDividerHeight()��ȡ�����ָ���ռ�õĸ߶�
        // params.height���õ�����ListView������ʾ��Ҫ�ĸ߶�
        listView.setLayoutParams(params);
    }

}
