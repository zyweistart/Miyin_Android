/**   
 * @{#} SysSetGroupOneAdapter.java Create on 2012-11-5 ����11:00:47   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.client.activity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.location.LocationManager;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.common.SystemServiceUtil;

/**
 * @author <a href="mailto:yangz@freshpower.cn">yangz</a>
 * @version 1.0
 */

public class PhoneDebugSetGroupTwoAdapter extends BaseAdapter {

	List<Map<String, Object>> mData;
	Context mContext;
	int resource;
	private SharedPreferences trmsSharedPreferences;
	private Editor editor;
	private Intent intent;
	private String[] strArr;

	public PhoneDebugSetGroupTwoAdapter(List<Map<String, Object>> data,
			Context context, int resource) {
		this.mData = data;
		this.mContext = context;
		this.resource = resource;
		this.trmsSharedPreferences =  mContext.getSharedPreferences(AppConstant.SHARED_PREFERENCE_NAME, mContext.MODE_PRIVATE);
	}

	@Override
	public int getCount() {
		return mData == null ? 0 : mData.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHoder hoder = null;
		if (convertView == null) {
			hoder = new ViewHoder();
			convertView = LayoutInflater.from(mContext).inflate(resource, null);
			hoder.menuNameTv = (TextView) convertView
					.findViewById(R.id.sysSetMenuName);
			hoder.itemSp = (Spinner) convertView.findViewById(R.id.basicSp);
//			hoder.menuNameRemark = (TextView) convertView
//					.findViewById(R.id.sysSetMenuRemark);
			convertView.setTag(hoder);
		} else {
			hoder = (ViewHoder) convertView.getTag();
		}

		Map<String, Object> data = mData.get(position);
		hoder.menuNameTv.setText(String.valueOf(data.get("menuNames")));
		
		initItemSpinner(position,hoder.itemSp);
//		hoder.menuNameRemark.setText(String.valueOf(data.get("menuNamesRemark")));
		//binkCheckBoxListener(hoder,position);
		return convertView;
	}
	
	private void initItemSpinner(int position,Spinner spinner){
		int textRrrayResId=0;
		String sharedPreferencesName="";
		String sharedPreferencesIndexName="";
		if(position==0){
			textRrrayResId=R.array.baud_rate;
			sharedPreferencesName = AppConstant.SharedPreferencesKey.KEY_PREF_BAUDRATE;
			sharedPreferencesIndexName = AppConstant.SharedPreferencesKey.KEY_BAUDRATE_INDEX;
		}else if(position==1){
			textRrrayResId=R.array.data_bits;
			sharedPreferencesName = AppConstant.SharedPreferencesKey.KEY_PREF_DATABIT;
			sharedPreferencesIndexName = AppConstant.SharedPreferencesKey.KEY_DATABIT_INDEX;
		}else if(position==2){
			textRrrayResId=R.array.stop_bits;
			sharedPreferencesName = AppConstant.SharedPreferencesKey.KEY_PREF_STOPBIT;
			sharedPreferencesIndexName = AppConstant.SharedPreferencesKey.KEY_STOPBIT_INDEX;
		}else if(position==3){
			textRrrayResId=R.array.parity;
			sharedPreferencesName = AppConstant.SharedPreferencesKey.KEY_PREF_PARITY;
			sharedPreferencesIndexName = AppConstant.SharedPreferencesKey.KEY_PARITY_INDEX;
		}
		
		ArrayAdapter<CharSequence> baudAdapter = null;
		baudAdapter = ArrayAdapter.createFromResource(mContext, textRrrayResId,
				R.layout.my_spinner_textview);
		baudAdapter.setDropDownViewResource(R.layout.my_spinner_textview);		
		spinner.setAdapter(baudAdapter);
		spinner.setSelection(trmsSharedPreferences.getInt(sharedPreferencesIndexName, 0));
		spinner.setOnItemSelectedListener(new SpinnerOnSelectedListener(sharedPreferencesName,sharedPreferencesIndexName));
	}
	
	class SpinnerOnSelectedListener implements OnItemSelectedListener{
		private String sharedPreferencesName;
		private String sharedPreferencesIndexName;
		public SpinnerOnSelectedListener(String sharedPreferencesName,String sharedPreferencesIndexName) {
			this.sharedPreferencesName = sharedPreferencesName;
			this.sharedPreferencesIndexName = sharedPreferencesIndexName;
		}
		@Override
		public void onItemSelected(AdapterView<?> adapterView, View view, int position,
				long id) {
			String selected = adapterView.getItemAtPosition(position).toString();
			if(AppConstant.SharedPreferencesKey.KEY_PREF_PARITY.equals(sharedPreferencesName)){
				trmsSharedPreferences.edit().putString(sharedPreferencesName, String.valueOf(position)).commit();
			}else{
				trmsSharedPreferences.edit().putString(sharedPreferencesName, selected).commit();
			}
			trmsSharedPreferences.edit().putInt(AppConstant.ReadParam.CONFIGED, AppConstant.YES_NO_TYPE_YES).commit();
			trmsSharedPreferences.edit().putInt(sharedPreferencesIndexName, position).commit();
		}

		@Override
		public void onNothingSelected(AdapterView<?> parent) {
		}
	}
	

	static class ViewHoder {
		TextView menuNameTv;
		TextView menuNameRemark;
		Spinner itemSp;
	}

}
