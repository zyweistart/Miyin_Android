package com.freshpower.android.elec.client.domain;

public class ClientWarnComapny {
	    private String meterName;//"����1-��·1",--��·����
	    private String content;//----��������
	    private String alertLevel;//������������
		private String alertDate;//--��������
		private String alertReply;//�������
		public String getMeterName() {
			return meterName;
		}
		public void setMeterName(String meterName) {
			this.meterName = meterName;
		}
		public String getContent() {
			return content;
		}
		public void setContent(String content) {
			this.content = content;
		}
		public String getAlertLevel() {
			return alertLevel;
		}
		public void setAlertLevel(String alertLevel) {
			this.alertLevel = alertLevel;
		}
		public String getAlertDate() {
			return alertDate;
		}
		public void setAlertDate(String alertDate) {
			this.alertDate = alertDate;
		}
		public String getAlertReply() {
			return alertReply;
		}
		public void setAlertReply(String alertReply) {
			this.alertReply = alertReply;
		}
		

}
