package com.freshpower.android.elec.client.activity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.http.conn.HttpHostConnectException;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ImageView.ScaleType;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.DateUtil;
import com.freshpower.android.elec.client.common.FileUtil;
import com.freshpower.android.elec.client.common.GetCurrentData;
import com.freshpower.android.elec.client.common.UpdateManager;
import com.freshpower.android.elec.client.domain.ElectricityBillCompany;
import com.freshpower.android.elec.client.domain.RunStatus;
import com.freshpower.android.elec.client.netapi.ChartCompanyApi;
import com.freshpower.android.elec.client.netapi.ElectricityBillCompanyDataApi;

public class HomeCompanyActivity extends FrameActivity {
	DecimalFormat df = new DecimalFormat("0.00");
	private Resources res;
	private ImageButton homeBtn;
	public static GetCurrentData getCurrentData;

	//��ҳ�������ģ�� start
	TextView electricityOne;
	TextView electricityBillOne;
	TextView electricityTwo;
	TextView electricityBillTwo;
	TextView electricityThree;
	TextView electricityBillThree;
	TextView electricityFour;
	TextView electricityBillFour;
	TextView electricityFive;
	TextView electricityBillFive;
	TextView averagePrice;
	TextView day_ele;
	TextView day_bill;

	int hour=0;
	int day=0;
	private String totalElectricity;//�ܵ���
	private String totalElectriBillcity;//�ܵ��
	private String topElectricity;//������
	private String topElectriBillcity;//�����
	private String peakElectricity;//�߷����
	private String peakElectriBillcity;//�߷���
	private String lowElectricity;//�͹ȵ���
	private String lowElectriBillcity;//�͹ȵ��
	private String priceElectricity;//ƽ�����

	private double[] sumChargeDoubleList = null;// ����
	private List<RunStatus> runStatusList;

	//end
	private Timer timer = null;
	private File pictureNameFile;
	private String sdpath = FileUtil.getAppRootPath();// ��ô洢����·��
	private ProgressDialog processProgress;

	private static final int CLIENTBURTHEN_FINISH = 0x100;//��ҵ���ɼ���
	private static final int RUNSTATUS_FINISH = 0x110;//����״̬��������
	private static final int BILL_FINISH = 0x120;//����״̬��������
	private static final int SYSTEM_ERROR = 0x500;//ϵͳ�쳣
	private static final int CONNECTTIMEOUT = 0x400;//���粻�ȶ�
	private static final int SYSTEM_FINISH = 0x200;//ִ�����
	ElectricityBillCompany electricityBillCompany=null;
	
	
	private ViewPager viewPager; // android-support-v4�еĻ������
	private List<ImageView> imageViews; // ������ͼƬ����
	private int[] imageResId; // ͼƬID
	private LinearLayout dots; // ͼƬ�������ĵ���Щ��
	private int currentItem = 0; // ��ǰͼƬ��������
	private ScheduledExecutorService scheduledExecutorService;
	private Bitmap bitmap;
    private BitmapDrawable bitmapDrawable;

	@Override
	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_home);
		res = getResources();
		Intent updateIntent = getIntent();
		String isFirst =updateIntent.getStringExtra("isFirst");
		if(null!=isFirst&&isFirst.equals("isFirst")){
			UpdateManager manager = new UpdateManager(HomeCompanyActivity.this);
			manager.checkUpdate(true);
		}

		bindEvent();

		//����ҳ����ͷ������ͼƬ
		imageViews = new ArrayList<ImageView>();
		pictureNameFile = new File(sdpath+"download"+File.separator+"pictureNameFile.txt");
		try {
			if (android.os.Environment.getExternalStorageState().equals(
					android.os.Environment.MEDIA_MOUNTED) //�ж��Ƿ��SD���ж�дȨ��
					&& pictureNameFile.exists()){ //�жϸ��ļ����Ƿ����) 
				setTopPicture();
			}else{
				imageResId = new int[] { R.drawable.image1, R.drawable.image2};
				for (int i = 0; i < imageResId.length; i++) {
					ImageView imageView = new ImageView(this);
					imageView.setBackgroundResource(imageResId[i]);
					imageView.setScaleType(ScaleType.CENTER_CROP);
					imageViews.add(imageView);
					imageView.destroyDrawingCache();
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		dots = (LinearLayout)findViewById(R.id.dot);
		RelativeLayout.LayoutParams lp; 
		ImageView view;
		for(int i = 0 ; i < imageViews.size() ;i++){
			view = new ImageView(HomeCompanyActivity.this);
			lp = new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
			lp.setMargins(2, 0, 2, 0);
			view.setLayoutParams(lp);
			view.setImageResource(R.drawable.dot_unselected);
			dots.addView(view);
			view.destroyDrawingCache();
		}
		view = (ImageView)dots.getChildAt(0);
		view.setImageResource(R.drawable.dot_selected);
		
		viewPager = (ViewPager) findViewById(R.id.vp);
		viewPager.setAdapter(new TopPictureAdapter());// �������ViewPagerҳ���������
		// ����һ������������ViewPager�е�ҳ��ı�ʱ����
		viewPager.setOnPageChangeListener(new MyPageChangeListener());
		scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
		// ��Activity��ʾ������ÿ�������л�һ��ͼƬ��ʾ
		scheduledExecutorService.scheduleAtFixedRate(new ScrollTask(), 1, 3, TimeUnit.SECONDS);

		// ˢ��
		Button refreshButton = (Button)findViewById(R.id.refresh_button);
		refreshButton.setVisibility(View.VISIBLE);
		refreshButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				processProgress = ProgressDialog.show(HomeCompanyActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
        		//�߳����ݴ���
        		new Thread(){
        			public void run() {
        				Message msgMessage = null;
        				try{
        					//����״̬��������
        					runStatusList = ChartCompanyApi.getRunStatusList();
        					msgMessage = new Message();
        					msgMessage.what = RUNSTATUS_FINISH;
        					HomeCompanyActivity.this.xHandler.sendMessage(msgMessage);
        				} catch(HttpHostConnectException e) {
        					msgMessage = new Message();
        					msgMessage.what = CONNECTTIMEOUT;
        					HomeCompanyActivity.this.xHandler.sendMessage(msgMessage);
        				} catch (Exception e) {
        					msgMessage = new Message();
        					msgMessage.what = SYSTEM_ERROR;
        					HomeCompanyActivity.this.xHandler.sendMessage(msgMessage);
        					e.printStackTrace();
        				}finally{
        					processProgress.dismiss();
        				}
        			};
        		}.start();
			}
		});

		day_ele=(TextView)findViewById(R.id.day_ele);
		day_ele.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				setElectricityBill(electricityBillCompany,"1","second");
			}
		});
		day_bill=(TextView)findViewById(R.id.day_bill);
		day_bill.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				setElectricityBill(electricityBillCompany,"2","second");
			}
		});


		// ��ϸ���
		Button elebill=(Button)findViewById(R.id.elebill);
		elebill.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				TextView dayMonthBill=(TextView)findViewById(R.id.dayMonth);
				Intent intent = new Intent(HomeCompanyActivity.this,ElectricityBillCompanyActivity.class);
				intent.putExtra("dayMonth", dayMonthBill.getText());
				intent.putExtra("meterName", "");
				startActivity(intent);
			}
		});
		Button reportBtn = (Button)findViewById(R.id.reportBtn);
		reportBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(HomeCompanyActivity.this,CheckRecordSearchCompanyActivity.class);
				startActivity(intent);
			}
		});
		Button warnInfoBtn=(Button)findViewById(R.id.warnInfoBtn);
		warnInfoBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(HomeCompanyActivity.this,AlarmCompanyActivity.class);
				startActivity(intent);
			}
		});

		processProgress = ProgressDialog.show(HomeCompanyActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		//�߳����ݴ���
		new Thread(){
			public void run() {
				Message msgMessage = null;
				try{
					//��ҵ���ɼ���
					sumChargeDoubleList = ChartCompanyApi.getSumChargeDoubleList();
					msgMessage = new Message();
					msgMessage.what = CLIENTBURTHEN_FINISH;
					HomeCompanyActivity.this.xHandler.sendMessage(msgMessage);

					//����״̬��������
					runStatusList = ChartCompanyApi.getRunStatusList();
					msgMessage = new Message();
					msgMessage.what = RUNSTATUS_FINISH;
					HomeCompanyActivity.this.xHandler.sendMessage(msgMessage);

					electricityBillCompany=new ElectricityBillCompany();
					electricityBillCompany=ElectricityBillCompanyDataApi.getElectricityBillInfoList("ID", "Day");
					
					msgMessage = new Message();
					msgMessage.what = BILL_FINISH;
					HomeCompanyActivity.this.xHandler.sendMessage(msgMessage);
				} 
				catch(HttpHostConnectException e) {
					msgMessage = new Message();
					msgMessage.what = CONNECTTIMEOUT;
					HomeCompanyActivity.this.xHandler.sendMessage(msgMessage);
//					Toast.makeText(HomeCompanyActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show();
				}
				catch (Exception e) {
					msgMessage = new Message();
					msgMessage.what = SYSTEM_ERROR;
					HomeCompanyActivity.this.xHandler.sendMessage(msgMessage);
					e.printStackTrace();
				} finally {
					msgMessage = new Message();
					msgMessage.what = SYSTEM_FINISH;
					HomeCompanyActivity.this.xHandler.sendMessage(msgMessage);
				}
			};
		}.start();
	}

	private Handler xHandler = new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case CLIENTBURTHEN_FINISH:
				setClientBurthenCurveChart();// ��ҵ�ܸ�������ͼ
				timer = new Timer(true);// ��ҵ�ܸ�������ͼ�߳�
				timer.schedule(task, DateUtil.getDelayTime(), 3600000);// ��ʱn�����ִ�У�3600000����ִ��һ��
				break;
			case RUNSTATUS_FINISH:
				setRunStatusBarChart();// ����״̬����
				break;
			case BILL_FINISH:
				setElectricityBill(electricityBillCompany,"1","first");//��ѵ���
				break;
			case SYSTEM_ERROR:
				Toast.makeText(HomeCompanyActivity.this, R.string.msg_abnormal_net2work, Toast.LENGTH_SHORT).show(); 		
				break;
			case CONNECTTIMEOUT:
				Toast.makeText(HomeCompanyActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show(); 		
				break;
			case SYSTEM_FINISH:
				processProgress.dismiss();
				break;
			default:
				break;
			}
		};
				
	};

	//���¼�
	private void bindEvent() {

		//��ϸ���ɴ��¼�
		Button chargeButton = (Button)findViewById(R.id.view_charge_button);
		chargeButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent(HomeCompanyActivity.this,ChargeDetailListCompanyActivity.class);
				startActivity(intent);
			}
		});
	}


	@Override
	protected void onResume() {

		homeBtn = (ImageButton) findViewById(R.id.homeBtn);
		if(homeBtn!=null){
			homeBtn.setOnClickListener(null);
			homeBtn.setBackgroundResource(R.drawable.homebtn_select);
		} 

		TextView homeBtnTv = (TextView)findViewById(R.id.homeBtnTv);
		homeBtnTv.setTextColor(getResources().getColor(R.color.white));

		super.onResume();
	}

	@Override
	protected void onStop() {
		scheduledExecutorService.shutdown();
		super.onStop();
	}

	@Override
	protected void onRestart() {
		scheduledExecutorService = Executors.newSingleThreadScheduledExecutor(); 
		scheduledExecutorService.scheduleAtFixedRate(new ScrollTask(), 1, 3, TimeUnit.SECONDS);
		super.onRestart();
	}

	/**
	 * ��ҵ�ܸ�������ͼ
	 */
	private void setClientBurthenCurveChart() {
		ClientBurthenCurveCompanyChart clientBurthenCurveChart = new ClientBurthenCurveCompanyChart();
		LinearLayout curveChart = (LinearLayout)findViewById(R.id.curveChart);
		clientBurthenCurveChart.setSumChargeDoubleList(sumChargeDoubleList);
		clientBurthenCurveChart.exe(HomeCompanyActivity.this, curveChart);
	}

	/**
	 * ����״̬������״ͼ
	 */
	private void setRunStatusBarChart() {
		ClientRunStatusBarCompanyChart clientRunStatusBarCompanyChart = new ClientRunStatusBarCompanyChart();
		LinearLayout barChart = (LinearLayout)findViewById(R.id.barChart);
		clientRunStatusBarCompanyChart.setRunStatusList(runStatusList);
		clientRunStatusBarCompanyChart.exe(HomeCompanyActivity.this, barChart);
	}

	//��ѵ���
	private void setElectricityBill(ElectricityBillCompany electricityBillCompany,String str,String first){
		Calendar c=Calendar.getInstance();
		day=c.get(Calendar.DAY_OF_MONTH);
		TextView dayMonth=(TextView)findViewById(R.id.dayMonth);
		String selectType="Day";
		if(str.equals("1")){
			day_ele.setTextColor(getResources().getColor(R.color.station));
			day_ele.setBackgroundResource(R.drawable.hometab);
			day_bill.setBackgroundResource(R.drawable.hometab_select);
			day_bill.setTextColor(getResources().getColor(R.color.balck));
			dayMonth.setText("����");
			selectType="Day";
		}else{
			day_bill.setTextColor(getResources().getColor(R.color.station));
			day_bill.setBackgroundResource(R.drawable.hometab);
			day_ele.setBackgroundResource(R.drawable.hometab_select);
			day_ele.setTextColor(getResources().getColor(R.color.balck));
			dayMonth.setText("����");
			selectType="Month";
		}
		if(!first.equals("first")){
			electricityBillCompany=new ElectricityBillCompany();
			try {
				electricityBillCompany=ElectricityBillCompanyDataApi.getElectricityBillInfoList("ID", selectType);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if(null!=electricityBillCompany){
			priceElectricity=electricityBillCompany.getAvgPrice();
			totalElectricity=electricityBillCompany.getTotalPower();
			totalElectriBillcity=electricityBillCompany.getTotalFee();
			topElectricity=electricityBillCompany.getTipPower();
			topElectriBillcity=electricityBillCompany.getTipFee();
			peakElectricity=electricityBillCompany.getPeakPower();
			peakElectriBillcity=electricityBillCompany.getPeakFee();
			lowElectricity=electricityBillCompany.getValleyPower();
			lowElectriBillcity=electricityBillCompany.getValleyFee();
		}
		electricityTwo=(TextView)findViewById(R.id.electricityTwo);
		electricityTwo.setText(totalElectricity);//�ܵ���
		electricityBillTwo=(TextView)findViewById(R.id.electricityBillTwo);
		electricityBillTwo.setText(totalElectriBillcity);
		electricityThree=(TextView)findViewById(R.id.electricityThree);
		electricityThree.setText(topElectricity);//���
		electricityBillThree=(TextView)findViewById(R.id.electricityBillThree);
		electricityBillThree.setText(topElectriBillcity);
		electricityFour=(TextView)findViewById(R.id.electricityFour);
		electricityFour.setText(peakElectricity);//�߷�
		electricityBillFour=(TextView)findViewById(R.id.electricityBillFour);
		electricityBillFour.setText(peakElectriBillcity);
		electricityFive=(TextView)findViewById(R.id.electricityFive);
		electricityFive.setText(lowElectricity);//�͹�
		electricityBillFive=(TextView)findViewById(R.id.electricityBillFive);
		electricityBillFive.setText(lowElectriBillcity);
		averagePrice=(TextView)findViewById(R.id.averagePrice);
		averagePrice.setText(priceElectricity);
	}
	
	TimerTask task = new TimerTask(){  
		public void run() {  
			Message message = new Message();      
			message.what = 1;      
			handler.sendMessage(message);    
		}  
	};

	private Handler handler = new Handler(){  
		@SuppressLint("HandlerLeak")
		public void handleMessage(Message msg) {  
			try {
				switch (msg.what) {      
				case 1:      
					setClientBurthenCurveChart();
					break;      
				}      
				super.handleMessage(msg);  
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};  

	// �л���ǰ��ʾ��ͼƬ
	private Handler pictureHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			viewPager.setCurrentItem(currentItem);// �л���ǰ��ʾ��ͼƬ
		};
	};
	
	protected void onDestroy() {
		// TODO Auto-generated method stub
		// ��Activity���ɼ���ʱ��ֹͣ�л�
		scheduledExecutorService.shutdown();
		if(imageViews!=null){
			for (int i = 0; i < imageViews.size(); i++) {
				nullViewDrawable(imageViews.get(i));
			}
			imageViews.clear();
		}
		 if(bitmapDrawable!=null && !bitmapDrawable.getBitmap().isRecycled()){
		    	bitmapDrawable.getBitmap().recycle();
		    	bitmap.recycle();
	    }
		if(timer != null){
			timer.cancel(); //�˳���ʱ��
		}
		super.onDestroy();
	}
	@SuppressWarnings({ "deprecation", "deprecation" })
	private void setTopPicture() throws IOException{
		//-----------------��ȡ�ļ���---------------------
		FileReader file = new FileReader(sdpath+"download/pictureNameFile.txt");
		BufferedReader br = new BufferedReader(file);
		String temp = "";
		StringBuffer sb = new StringBuffer();
		while((temp = br.readLine())!=null){             
			sb.append(temp);             
		}
		//------------------------------------------------
		String[] fileName = sb.toString().split(",");
		String sdpath = FileUtil.getAppRootPath();// ��ô洢����·��
		String filePath = sdpath+"download/toppicture";
        File wall;// MMͼƬ
        String path;//ͼƬ·��
        RelativeLayout.LayoutParams lp2 = new RelativeLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT);  
        ImageView btn;
		for(int i = 0 ; i < fileName.length ; i++){
	        wall = new File(filePath+"/"+ fileName[i].split("\\.")[0]);//��ȡͼƬ�ļ�
	        path = wall.getAbsolutePath();// MMͼƬ·��
	        btn = new ImageView(HomeCompanyActivity.this);
			bitmap = BitmapFactory.decodeFile(path);//����bitmapͼƬ
			bitmapDrawable = new BitmapDrawable(bitmap);
		    btn.setBackgroundDrawable(bitmapDrawable);//����ͼƬչ��
		    btn.setLayoutParams(lp2);//����ͼƬ�Ŀ���
		    btn.setScaleType(ScaleType.FIT_CENTER);
		    imageViews.add(btn);//����ť���ӽ���ͷ������
		    btn.destroyDrawingCache();//�ͷ�ͼƬ��ռ�ڴ�
		}
		if(br!=null){
        	br.close();
        }
	}
	
	/**
	 * ���ViewPagerҳ���������
	 * 
	 * @author Administrator
	 * 
	 */
	private class TopPictureAdapter extends PagerAdapter {

		@Override
		public int getCount() {
			return imageViews.size();
		}

		@Override
		public Object instantiateItem(View arg0, int arg1) {
			((ViewPager) arg0).addView(imageViews.get(arg1));
			return imageViews.get(arg1);
		}

		@Override
		public void destroyItem(View arg0, int arg1, Object arg2) {
			((ViewPager) arg0).removeView((View) arg2);
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}

		@Override
		public void restoreState(Parcelable arg0, ClassLoader arg1) {

		}

		@Override
		public Parcelable saveState() {
			return null;
		}

		@Override
		public void startUpdate(View arg0) {

		}

		@Override
		public void finishUpdate(View arg0) {

		}
	}
	
	/**
	 * ��ViewPager��ҳ���״̬�����ı�ʱ����
	 * 
	 * @author Administrator
	 * 
	 */
	private class MyPageChangeListener implements OnPageChangeListener {
		private int oldPosition = 0;

		/**
		 * This method will be invoked when a new page becomes selected.
		 * position: Position index of the new selected page.
		 */
		public void onPageSelected(int position) {
			currentItem = position;
			ImageView image = (ImageView)(dots.getChildAt(oldPosition));
			image.setImageResource(R.drawable.dot_unselected);
			image = (ImageView)(dots.getChildAt(position));
			image.setImageResource(R.drawable.dot_selected);
			oldPosition = position;
		}

		public void onPageScrollStateChanged(int arg0) {

		}

		public void onPageScrolled(int arg0, float arg1, int arg2) {

		}
	}
	
	/**
	 * �����л�����
	 * 
	 * @author Administrator
	 * 
	 */
	private class ScrollTask implements Runnable {

		public void run() {
			synchronized (viewPager) {
				System.out.println("currentItem: " + currentItem);
				currentItem = (currentItem + 1) % imageViews.size();
				pictureHandler.obtainMessage().sendToTarget(); // ͨ��Handler�л�ͼƬ
			}
		}

	}

	/**
	 * �ͷ�ͼƬ�ڴ�ռ�
	 * @param view
	 */
	private void nullViewDrawable(View view){
		try {
			view.setBackgroundDrawable(null);
		} catch(Exception e){
			e.printStackTrace();
		}
		
		try {
			 ImageView imageView = (ImageView)view;
			 imageView.setImageDrawable(null);
			 imageView.setBackgroundDrawable(null);
		} catch(Exception e){
			e.printStackTrace();
		}
	}
}
