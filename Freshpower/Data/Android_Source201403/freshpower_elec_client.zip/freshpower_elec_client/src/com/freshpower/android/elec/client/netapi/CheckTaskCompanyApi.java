package com.freshpower.android.elec.client.netapi;

import java.io.File;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.client.common.AppCache;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.common.DateUtil;
import com.freshpower.android.elec.client.common.StringUtil;
import com.freshpower.android.elec.client.conf.AppConfig;
import com.freshpower.android.elec.client.domain.CheckTaskCompany;
import com.freshpower.android.elec.client.domain.LoginInfo;


public class CheckTaskCompanyApi extends JsonDataApi {
	private static final String CHECK_ACTION = "AppMonitoringAlarm.aspx";
	
	/**
	 * ��ȡѲ�������б�
	 * @param pageSize
	 * @param pageNum
	 * @param cpName �ͻ�����
	 * @param siteName վ������
	 * @param taskStartDate ����ʼʱ��
	 * @param taskEndDate �������ʱ��
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getCheckRecordList(int pageSize,int pageNum, String cpName, String siteName, String taskStartDate, String taskEndDate) throws Exception {
		taskEndDate = DateUtil.andOneDay(taskEndDate);
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "RW18");
		api.addParam("QTPINDEX", String.valueOf(pageNum).trim());
		api.addParam("QTPSIZE", String.valueOf(pageSize).trim());
		api.addParam("QTKEY", URLEncoder.encode(cpName, AppConstant.ETG_INTERFACE_CHARSET));
		api.addParam("QTKEY2", URLEncoder.encode(siteName, AppConstant.ETG_INTERFACE_CHARSET));
		api.addParam("QTD1", URLEncoder.encode(taskStartDate, AppConstant.ETG_INTERFACE_CHARSET));
		api.addParam("QTD2", URLEncoder.encode(taskEndDate, AppConstant.ETG_INTERFACE_CHARSET));
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+CHECK_ACTION,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("table1");
		CheckTaskCompany checkTask = null;
		List<CheckTaskCompany> checkTaskList = new ArrayList<CheckTaskCompany>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				checkTask = new CheckTaskCompany();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				checkTask.setTaskId(table1.getString("TASK_ID"));
				checkTask.setCpName(StringUtil.isEmpty(table1.getString("CP_NAME"))?"":table1.getString("CP_NAME"));
				checkTask.setSiteName(StringUtil.isEmpty(table1.getString("SITE_NAME"))?"":table1.getString("SITE_NAME"));
				checkTask.setName(StringUtil.isEmpty(table1.getString("NAME"))?"":table1.getString("NAME"));
				checkTask.setTaskDate(StringUtil.isEmpty(table1.getString("TASK_DATE"))?"":table1.getString("TASK_DATE"));
				checkTask.setCompleteDate(StringUtil.isEmpty(table1.getString("COMPLETE_DATE"))?"":table1.getString("COMPLETE_DATE"));
				checkTask.setIsComplete(table1.getString("IS_COMPLETE").equals("1")?"��":"��");
				checkTask.setRecompleteDate(StringUtil.isEmpty(table1.getString("RECOMPLETE_DATE"))?"":table1.getString("RECOMPLETE_DATE"));
				checkTaskList.add(checkTask);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("remark", rows.getString("remark"));
		map.put("checkTaskList", checkTaskList);
		map.put("result", rows.getString("result"));
		map.put("totalCount", rows.getString("TotalCount"));
		return map;
	}
}
