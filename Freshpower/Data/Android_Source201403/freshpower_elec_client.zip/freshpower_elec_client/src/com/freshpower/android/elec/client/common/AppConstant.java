/**   
 * @{#} AppConstant.java Create on 2012-11-20 ����11:00:13   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.client.common;

import java.util.HashMap;
import java.util.Map;

import com.freshpower.android.elec.client.R;


/**
 * @author <a href="mailto:yangz@freshpower.cn">yangz</a>
 * @version 1.0
 */

public class AppConstant {
	
	public static final int YES_NO_TYPE_NO = 0;// ��
	public static final int YES_NO_TYPE_YES = 1;// ��
	
	public static class FlashLightState {
		public static final int OPEN = 1;
		public static final int CLOSE = 0;
	}

	public static class AuthenticationInfo {
		public static final int TIME_OUT = -1;
		public static final int INVALID = 0;
	}

	public static class OptionsMenuBtn {
		public static final int OPTIONS_MENU_BTN_EXISTS = 1;
		public static final int OPTIONS_MENU_BTN_ABOUT = 2;
		public static final int OPTIONS_MENU_BTN_CHANGE_ACCOUNT = 3;
	}
	
	public static class GooglePlayPackageName {
		public static final String GOOGLE_PLAY_SERVICE = "com.google.android.gms";
		public static final String GOOGLE_PLAY_SOTRE = "com.android.vending";
	}
	
	public static class EnBottomBtnType {
		public static final int OTHER_BTN = 0;// ����
		public static final int INDEXPAGE_BTN = 1;
		public static final int ELECTRICPAGE_BTN = 2;
		public static final int EFFICIENCYPAGE_BTN = 3;
		public static final int RUNMANAGER_BTN = 4;
		public static final int MYCENTER_BTN = 5;
	}

	public static class CheckUpDetail{
		public static final String SCOUTCHECK_CONTENT = "SCOUTCHECK_CONTENT";
		public static final String SCOUTCHECK = "SCOUTCHECK";
	}
	
	public static class SharedPreferencesKey {
		public static final String FREQUENCY = "FREQUENCY";
		public static final String LIGHT_SET = "LIGHT_SET";
		public static final String GPS_SET = "GPS_SET";
		public static final String VIBRATION_SET = "VIBRATION_SET";
		public static final String TIP_SET = "TIP_SET";
		

	    public static final String KEY_PREF_BAUDRATE = "pref_BaudRate";
	    public static final String KEY_PREF_DATABIT = "pref_DataBit";
	    public static final String KEY_PREF_STOPBIT = "pref_StopBit";
	    public static final String KEY_PREF_PARITY = "pref_Parity";
	    public static final String KEY_BAUDRATE_INDEX = "baudRateIndex";
	    public static final String KEY_DATABIT_INDEX = "dataBitIndex";
	    public static final String KEY_STOPBIT_INDEX = "stopBitIndex";
	    public static final String KEY_PARITY_INDEX = "parityIndex";
	    public static final String KEY_PREF_FLOW = "pref_Flow";
	    public static final String KEY_PREF_INBUFFERSIZE = "pref_InBufferSize";
	    public static final String KEY_PREF_OUTBUFFERSIZE = "pref_OutBufferSize";
	    public static final String KEY_PREF_CLEARSENDEDIT = "pref_ClearSendEdit";
	    public static final String KEY_PREF_IOMODE = "pref_IOMode";
	    public static final String KEY_PREF_CHARSET = "pref_Charset";
	    public static final String KEY_PREF_AUTOWRAP = "pref_AutoWrap";
	    public static final String KEY_PREF_ECHO = "pref_Echo";
	    public static final String KEY_PREF_ECHOPREFIX = "pref_EchoPrefix";
	    public static final String KEY_PREF_LT = "pref_LT";
	}

	public static final String SHARED_PREFERENCE_NAME = "trms_preferences";
	public static final String PHONE_NUM_FRESHPOEWR = "4008263365";
	public static final String ETG_INTERFACE_CHARSET = "GBK";

	public static class GpsDataApiResult {
		public static final int RESULT_ERROR = 0;
		public static final int RESULT_SUCCESS = 1;
		public static final int RESULT_PERMISSION_NOT = 2;
		public static final int RESULT_PHONENUM_NOTEXIST = 3;
	}
	
	public static class ListItemCtlName{
		public static final String MENU_ICO = "menuIco";
		public static final String MENU_NAME = "menuName";
		public static final String MENU_SIZE = "menuSize";
		public static final String CONDITION_VALUE = "conditionValue";
		public static final String COMPANY_STATION = "company_station";
		public static final String COMPANY_CURRENT = "company_current";
	}
	public static class ListItemWarnName{
		public static final String WARN_ONE = "warnOne";
		public static final String WARN_TWO = "warnTwo";
		public static final String WARN_THREE = "warnThree";
		public static final String WARN_FOUR = "warnFour";
		public static final String WARN_FIVE = "warnFive";
		public static final String WARN_SIX = "warnSix";
		public static final String WARN_SEVEN = "warnSeven";
		public static final String WARN_EIGHT = "warnEight";
	}
	
	public static class PurchaseType{
		public static final int PURCHASE = 1;//�ɹ�����
		public static final int AREA = 2;//����
		public static final int TRADE = 3;//��ҵ
		public static final int TIME = 4;//ʱ��
	}
	
	public static class ExtraName{
		public static final String EXTRANAME_NAME="name";
		public static final String EXTRANAME_TYPE="type";
		public static final String EXTRANAME_ID="id";
		public static final String EXTRANAME_KEYWORDS="keyWords";
		public static final String EXTRANAME_CODE="code";
	}
	
	public static class Result{
		public static final int SUCCESS=1;
		public static final int NO_COUNT=0;
		public static final int ERROR=999;
	}
	
	/*
	 * some constants
	 */
	public static interface IOMode{
		public static final int text = 0;
		public static final int binary = 1;
	}
	public static interface LineTerminator{
		public static final int crlf = 0;
		public static final int cr = 1;
		public static final int lf = 2;
	}
	/*
	 * some constants end.
	 */
	
	/**
	 * ��ȡ����
	 * @author yzsunlight
	 *
	 */
	public static class ReadParam{
		public static final String CONFIGED="configed";
		public static final String SHAREDP_NAME_VOLTAGE="voltage";
		public static final String SHAREDP_NAME_ELECTRICITY="electricity";
		public static final String SHAREDP_NAME_POWER="power";
		public static final String SHAREDP_NAME_POWER_FACTOR="power_factor";
		public static final String SHAREDP_NAME_RATE="rate";
		public static final String SHAREDP_NAME_GROUP_ELECTRIC="group_electric";
		public static final String SHAREDP_NAME_POSITIVE_ELECTRIC="positive_electric";
		public static final String SHAREDP_NAME_STATUS_WORD="status_word";
		
		public static final int voltage=0;
		public static final int electricity=1;
		public static final int power=2;
		public static final int power_factor=3;
		public static final int rate=4;
		public static final int group_electric=5;
		public static final int positive_electric=6;
		public static final int status_word=7;
		
		public static Map<Integer,String> readParamMap = new HashMap<Integer,String>();
		static{
			readParamMap.put(voltage, SHAREDP_NAME_VOLTAGE);
			readParamMap.put(electricity, SHAREDP_NAME_ELECTRICITY);
			readParamMap.put(power, SHAREDP_NAME_POWER);
			readParamMap.put(power_factor, SHAREDP_NAME_POWER_FACTOR);
			readParamMap.put(rate, SHAREDP_NAME_RATE);
			readParamMap.put(group_electric, SHAREDP_NAME_GROUP_ELECTRIC);
			readParamMap.put(positive_electric, SHAREDP_NAME_POSITIVE_ELECTRIC);
			readParamMap.put(status_word, SHAREDP_NAME_STATUS_WORD);
		}
		
	}
	
	public static class RequestResultCode{
		public static final int REQUEST_PHONEDEBUGACTIVITY=120;//�ֻ�����ҳ������
		public static final int RESULT_PHONEDEBUGACTIVITY=120;//�ֻ�����ҳ������
		public static final int REQUEST_SCANACTIVITY = 300;//ɨ���������
		public static final int RESULT_SCANACTIVITY = 300;//ɨ���������
		public static final int REQUEST_SCANPROJECTACTIVITY=110;// ���̽�վɨ��㼯��
		public static final int RESULT_SCANPROJECTACTIVITY=110;// ���̽�վɨ��㼯��
		public static final int REQUEST_SCANCOLLECTORACTIVITY=100;// ���̽�վɨ��ɼ���
		public static final int RESULT_SCANCOLLECTORACTIVITY=100;// ���̽�վɨ��ɼ���
		public static final int REQUEST_USERSECOND=200;// �ر�ָ��activity
		public static final int RESULT_CANCEL=400;// ȡ��
		public static final int REQUEST_LINE=500;//��ѯ��·��ϸ��Ϣ
		public static final int RESULT_LINE=500;//��ѯ��·��ϸ��Ϣ
		public static final int REQUEST_LINE_TIME = 600;//��Ϣʱ��
		public static final int RESULT_LINE_TIME = 600;//��Ϣʱ��
	}
	
}
