package com.freshpower.android.elec.client.netapi;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.client.common.AppCache;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.conf.AppConfig;
import com.freshpower.android.elec.client.domain.LoginInfo;
import com.freshpower.android.elec.client.domain.OperationalAspect;

public class OperationalAspectApi extends JsonDataApi {
	private static final String ACTION_NAME = "AppMonitoringAlarm.aspx";
	/**
	 * ��ȡ�豸�б�
	 * @param qtTask ����ID
	 * @param qtKey �豸���� 1-������豸2-�����豸3-�����豸4-TRMS�豸
	 * @return
	 * @throws Exception
	 */
	public static List<OperationalAspect> getOperationalAspectList(String qtTask, String qtKey) throws Exception {
		LoginInfo loginInfo = (LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		JsonDataApi api = JsonDataApi.getInstance();
//		api.addParam("imei", loginInfo.getLoginName().trim());
//		api.addParam("authentication", loginInfo.getLoginPwd());
		api.addParam("imei","zhangyy");
		api.addParam("authentication","4836c90b7d1711efab1f0239d28817d1");
		api.addParam("GNID", "RW12");
		api.addParam("QTTASK", qtTask);
		api.addParam("QTKEY", qtKey);
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getEtgWebsite() + File.separator + ACTION_NAME, AppConstant.ETG_INTERFACE_CHARSET);
//		Log.d("BID","OperationalAspectApi=========jsonResult:"+jsonResult.toJSONString());
		JSONArray json = jsonResult.getJSONArray("table1");
		ArrayList<OperationalAspect> operationalAspectList = new ArrayList<OperationalAspect>();
		OperationalAspect operationalAspect = null;
		for(int i=0;i<json.size();i++){
			JSONObject rows = (JSONObject)json.get(i);
			operationalAspect = new OperationalAspect();
			operationalAspect.setTaskId(rows.getString("TASK_ID"));
			operationalAspect.setEqType(rows.getString("EQ_TYPE"));
			operationalAspect.setName(rows.getString("NAME"));
			operationalAspect.setEquipmentId(rows.getString("EQUIPMENT_ID"));
			operationalAspect.setRemark(rows.getString("REMARK"));
			operationalAspectList.add(operationalAspect);
		}
		return operationalAspectList;
	}
	
}
