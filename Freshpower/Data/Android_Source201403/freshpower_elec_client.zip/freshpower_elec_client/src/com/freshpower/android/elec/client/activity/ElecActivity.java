package com.freshpower.android.elec.client.activity;

import java.io.File;
import org.apache.http.conn.ConnectTimeoutException;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.AppCache;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.common.DBOperater;
import com.freshpower.android.elec.client.common.FileUtil;
import com.freshpower.android.elec.client.common.MD5;
import com.freshpower.android.elec.client.common.StringUtil;
import com.freshpower.android.elec.client.common.SystemServiceUtil;
import com.freshpower.android.elec.client.common.UpdateManager;
import com.freshpower.android.elec.client.conf.AppConfig;
import com.freshpower.android.elec.client.domain.LoginInfo;
import com.freshpower.android.elec.client.netapi.DownLoadPictureApi;
import com.freshpower.android.elec.client.netapi.LoginInfoDataApi;

public class ElecActivity extends Activity {

	private static final int NETWORKFINISH = 0x100;
	private static final int APKFINISH = 0x115;
	private static final int FINISH = 0x108;
	private static final int DBFINISH = 0x111;
	private static final int CONNECTTIMEOUT = 0x112;
	private static final int IMAGELOAD = 0x113;
	private ProgressBar progressBar;
	private TextView textView;
	private Message msgMessage;
	private SharedPreferences trmsSharedPreferences;
	private String versionStr ="Version ";

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.initwait);
		ActivityUtil.addActivity(this);
		FileUtil.appFilesDir = this.getFilesDir().getPath();
		progressBar = (ProgressBar) findViewById(R.id.circleProgressBar);
		progressBar.setIndeterminate(false);
		progressBar.setVisibility(View.VISIBLE);
		textView = (TextView) findViewById(R.id.statusText);
		TextView verCodeTv = (TextView)findViewById(R.id.verCodeTv);
		verCodeTv.setText(versionStr + getResources().getString(R.string.appVersion));
		trmsSharedPreferences = getSharedPreferences(
				AppConstant.SHARED_PREFERENCE_NAME, MODE_PRIVATE);
		/*if (!SystemServiceUtil.isNetworkConnected(ElecActivity.this)) {
			setNetworkMethod(ElecActivity.this);
			return;
		}*/
		new Thread() {
			public void run() {
				try {
					msgMessage = new Message();
					msgMessage.what = NETWORKFINISH;
					ElecActivity.this.xHandler.sendMessage(msgMessage);
					Thread.sleep(1000);
					// Log.d("BID", "openInternet...");
					// openInternet();
					// Log.d("BID", "openInternet finish...");
					
					if (!FileUtil.isFileExist(FileUtil.getDBFilePath())) {
						initDB(FileUtil.getDBFilePath());
						msgMessage = new Message();
						msgMessage.what = DBFINISH;
						ElecActivity.this.xHandler.sendMessage(msgMessage);
						Thread.sleep(1000);
					}
					
//					if (!FileUtil.isFileExist(FileUtil.getElecFilePath())) {
//						initDB(FileUtil.getElecFilePath());
//						msgMessage = new Message();
//						msgMessage.what = DBFINISH;
//						ElecActivity.this.xHandler.sendMessage(msgMessage);
//						Thread.sleep(1000);
//					}
					//Log.d("BID", "initAppConfig...");
					initAppConfig();

					
					try{
						if (android.os.Environment.getExternalStorageState().equals(
								android.os.Environment.MEDIA_MOUNTED)) {
							msgMessage = new Message();
							msgMessage.what = IMAGELOAD;
							ElecActivity.this.xHandler.sendMessage(msgMessage);
							DownLoadPictureApi.downLoadPicture();//ʵʱ������վ���µ�����ҳͼƬ
						}
					}catch(Exception e){
						e.printStackTrace();
					}
					if (AppCache.get(AppCache.LOGIN_AUTH_INFO)!=null && (Integer) AppCache.get(AppCache.LOGIN_AUTH_INFO) == AppConstant.AuthenticationInfo.TIME_OUT) {
						msgMessage = new Message();
						msgMessage.what = CONNECTTIMEOUT;
						ElecActivity.this.xHandler.sendMessage(msgMessage);
						return;
					}


					/*
					 * msgMessage = new Message(); msgMessage.what = APKFINISH;
					 * ElecActivity.this.xHandler.sendMessage(msgMessage);
					 * Thread.sleep(1000);
					 */

					msgMessage = new Message();
					msgMessage.what = FINISH;
					ElecActivity.this.xHandler.sendMessage(msgMessage);

				} catch (Exception e) {
					e.printStackTrace();
				}
			};
		}.start();
	}

	private Handler xHandler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case FINISH:
				textView.setText("�ɹ�...");
				openBrowserActivity();
				break;
			case APKFINISH:
				textView.setText("���������...");
				break;
			case NETWORKFINISH:
				textView.setText("������������...");
				break;
			case IMAGELOAD:
				textView.setText("���ݳ�ʼ��...");
				break;
			case DBFINISH:
				textView.setText("���ݳ�ʼ�����...");
				break;
			case CONNECTTIMEOUT:
				builderTimeOutDialog();
				break;
			default:
				break;
			}
		};
	};

	public void initDB(String filePath) {
		//DBOperater.openOrCreateDB(FileUtil.getDBFilePath());
		try {
			File dbFile = new File(filePath);
			FileUtil.createFolder(dbFile.getParent());
			FileUtil.createFile(dbFile);
		} catch (Exception e) {
			Log.e("dberror", e.toString());
			e.printStackTrace();
		}
	}

	/**
	 * ��ʼ��Ӧ������
	 */
	private void initAppConfig() {
		AppConfig appConfig = AppConfig.getInstance();
		appConfig.setAppVersion(getResources().getString(R.string.appVersion));
		appConfig.setEtgWebsite(getResources().getString(R.string.etgWebSite));
		appConfig.setFpsWebSite(getResources().getString(R.string.fpsWebSite));
		appConfig.setCrmWebSite(getResources().getString(R.string.crmWebSite));
		AppCache.put(AppCache.LOGIN_AUTH_INFO,
				AppConstant.AuthenticationInfo.INVALID);
	}

	private void openBrowserActivity() {
		Intent intent = new Intent();
		intent.putExtra("isFirst", "isFirst");
		if(isLoginInfo()){
			intent.setClass(ElecActivity.this, HomeCompanyActivity.class);
		}else{
			intent.setClass(ElecActivity.this, HomeLoginTypeActivity.class);
		}
		startActivity(intent);
		ElecActivity.this.finish();
	}

	/*
	 * �������������
	 */
	private void setNetworkMethod(final Context context) {
		AlertDialog.Builder builder = new Builder(context);
		builder.setTitle("����������ʾ")
		.setMessage("�������Ӳ�����,�Ƿ��������?")
		.setPositiveButton("����", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				Intent intent = new Intent(
						android.provider.Settings.ACTION_WIRELESS_SETTINGS);
				context.startActivity(intent);
			}
		})
		.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				ElecActivity thisActivity = (ElecActivity) context;
				thisActivity.finish();
			}
		});
		builder.setCancelable(false);
		Dialog noticeDialog = builder.create();
		noticeDialog.show();
	}

	private void builderTimeOutDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(ElecActivity.this);
		builder.setMessage(R.string.msg_abnormal_network);
		builder.setCancelable(false);
		builder.setPositiveButton(R.string.soft_btn_ok, new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				ElecActivity.this.finish();
			}
		});
		AlertDialog dialog = builder.create();
		dialog.show();
	}
	private boolean isLoginInfo() {
		boolean suc=false;
		String fileContent = FileUtil.read(FileUtil.getDBFilePath());
		FileUtil.deleteDirectory(FileUtil.getDBFilePath());
		if (!StringUtil.isEmpty(fileContent)){
			String str[]=fileContent.split("\\|");
			LoginInfo loginInfo=new LoginInfo();
			loginInfo.setLoginName(str[0].toString());
			loginInfo.setLoginPwd(str[1].toString());
			loginInfo.setCpId(str[2].toString());
			loginInfo.setCpName(str[3].toString());
			try {
				loginInfo=LoginInfoDataApi.getLoginInfo(loginInfo);
				if(loginInfo.getLoginStatus()==1){
					AppCache.put(AppCache.LOGININFO_OBJ, loginInfo);
					suc=true;
				}else{
					AppCache.remove(AppCache.LOGININFO_OBJ);
				}
			} catch (Exception e) {
				AppCache.remove(AppCache.LOGININFO_OBJ);
				e.printStackTrace();
			}
			
		}
		return suc;
	}


}