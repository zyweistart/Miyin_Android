/**   
 * @{#} GpsDataInfo.java Create on 2013-4-24 ����01:47:38   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.client.domain;   
  
/**   
 * @author <a href="mailto:yangz@freshpower.cn">yangz</a>  
 * GPS��Ϣ
 * @version 1.0   
 */

public class GpsDataInfo {
	private double longitude; //����
	private double latitude; //γ��
	private double speed; //�ٶ�
	private double direction; //����
	private String longitudeEW;
	private String latitudeNS;
	private String gpsTime; //GPSʱ��
	private LoginInfo LoginInfo;//��¼�û���Ϣ
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	public double getSpeed() {
		return speed;
	}
	public void setSpeed(double speed) {
		this.speed = speed;
	}
	public double getDirection() {
		return direction;
	}
	public void setDirection(double direction) {
		this.direction = direction;
	}
	public String getLongitudeEW() {
		return longitudeEW;
	}
	public void setLongitudeEW(String longitudeEW) {
		this.longitudeEW = longitudeEW;
	}
	public String getLatitudeNS() {
		return latitudeNS;
	}
	public void setLatitudeNS(String latitudeNS) {
		this.latitudeNS = latitudeNS;
	}
	public String getGpsTime() {
		return gpsTime;
	}
	public void setGpsTime(String gpsTime) {
		this.gpsTime = gpsTime;
	}
	public LoginInfo getLoginInfo() {
		return LoginInfo;
	}
	public void setLoginInfo(LoginInfo loginInfo) {
		LoginInfo = loginInfo;
	}
}
  
