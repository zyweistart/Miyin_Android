package com.freshpower.android.elec.client.activity;

import java.util.Random;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

public class InspectionTemperatureActivity extends Activity {
	TextView tmp_one_a;
	TextView tmp_one_b;
	TextView tmp_one_c;
	TextView tmp_one_d;
	TextView tmp_two_a;
	TextView tmp_two_b;
	TextView tmp_two_c;
	TextView tmp_two_d;
	ImageView tmp_left;
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.inspection_temperature);
		Random rand = new Random();
    	Integer randomNum = rand.nextInt(3);
		tmp_one_a=(TextView)findViewById(R.id.tmp_one_a);
		tmp_one_b=(TextView)findViewById(R.id.tmp_one_b);
		tmp_one_c=(TextView)findViewById(R.id.tmp_one_c);
		tmp_one_d=(TextView)findViewById(R.id.tmp_one_d);
		tmp_two_a=(TextView)findViewById(R.id.tmp_two_a);
		tmp_two_b=(TextView)findViewById(R.id.tmp_two_b);
		tmp_two_c=(TextView)findViewById(R.id.tmp_two_c);
		tmp_two_d=(TextView)findViewById(R.id.tmp_two_d);
		tmp_one_a.setText(String.valueOf(eleBill[randomNum][0]));
		tmp_one_b.setText(String.valueOf(eleBill[randomNum][1]));
		tmp_one_c.setText(String.valueOf(eleBill[randomNum][2]));
		tmp_one_d.setText(String.valueOf(eleBill[randomNum][3]));
		tmp_two_a.setText(String.valueOf(eleBill[randomNum][4]));
		tmp_two_b.setText(String.valueOf(eleBill[randomNum][5]));
		tmp_two_c.setText(String.valueOf(eleBill[randomNum][6]));
		tmp_two_d.setText(String.valueOf(eleBill[randomNum][7]));
		tmp_left=(ImageView)findViewById(R.id.tmp_left);
		tmp_left.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				InspectionTemperatureActivity.this.onBackPressed();
			}
		});
	}
	public static int[][] eleBill = {{54,44,42,47,56,43,46,48},{52,42,43,46,57,43,48,42},{55,44,46,41,59,45,42,41},{57,48,42,43,56,43,44,41}};
}
