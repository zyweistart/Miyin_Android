package com.freshpower.android.elec.client.activity;

import java.util.List;
import java.util.Map;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;

import com.freshpower.android.elec.client.R;



public class CheckTaskRecordCompanyAdapter extends BaseAdapter {

	List<Map<String, Object>> mData;
	Context mContext;
	int resource;
	public CheckTaskRecordCompanyAdapter(List<Map<String, Object>> data,
			Context context, int resource) {
		this.mData = data;
		this.mContext = context;
		this.resource = resource;
	}

	@Override
	public int getCount() {
		return mData == null ? 0 : mData.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	static class ViewHoder {
		TextView taskDateText;
		TextView siteNameText;
		TextView recompleteDateText;
		TextView nameText;
		TextView completeDateText;
		TextView isCompleteText;
		TableLayout checkRecordTable;
		LinearLayout checkRecordListitem;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHoder hoder = null;
		if (convertView == null) {
			hoder = new ViewHoder();
			convertView = LayoutInflater.from(mContext).inflate(resource, null);
			hoder.taskDateText = (TextView) convertView
					.findViewById(R.id.taskDateText);
			hoder.siteNameText = (TextView) convertView
					.findViewById(R.id.siteNameText);
			hoder.recompleteDateText = (TextView) convertView
					.findViewById(R.id.recompleteDateText);
			hoder.nameText = (TextView) convertView
					.findViewById(R.id.nameText);
			hoder.completeDateText = (TextView) convertView
					.findViewById(R.id.completeDateText);
			hoder.isCompleteText = (TextView) convertView
					.findViewById(R.id.isCompleteText);
			hoder.checkRecordTable = (TableLayout) convertView
					.findViewById(R.id.checkRecordTable);
			hoder.checkRecordListitem = (LinearLayout) convertView
					.findViewById(R.id.checkRecordListitem);
			convertView.setTag(hoder);
		} else {
			hoder = (ViewHoder) convertView.getTag();
		}
		Map<String, Object> data = mData.get(position);
		if(position % 2 ==1){
			hoder.checkRecordListitem.setBackgroundColor(mContext.getResources().getColor(R.color.bgcolor));
		}else{
			hoder.checkRecordListitem.setBackgroundColor(mContext.getResources().getColor(R.color.white));
		}
		hoder.taskDateText.setText(String.valueOf(data.get("taskDateText")));
		hoder.siteNameText.setText(String.valueOf(data.get("siteNameText")));
		hoder.recompleteDateText.setText(String.valueOf(data.get("recompleteDateText")));
		hoder.nameText.setText(String.valueOf(data.get("nameText")));
		hoder.completeDateText.setText(String.valueOf(data.get("completeDateText")));
		hoder.isCompleteText.setText(String.valueOf(data.get("isCompleteText")));
		if(data.get("isCompleteText").equals(mContext.getResources().getString(R.string.check_is_compelete_yes))) {
			hoder.isCompleteText.setTextColor(Color.parseColor("#009900"));
		} else {
			hoder.isCompleteText.setTextColor(Color.parseColor("#FF0000"));
		}
		RecordCheckTaskListener recordCheckTaskListener = new RecordCheckTaskListener();
		recordCheckTaskListener.setTaskId(String.valueOf(data.get("taskId")));
		hoder.checkRecordTable.setOnClickListener(recordCheckTaskListener);
		return convertView;
	}
	
	
	 class RecordCheckTaskListener implements View.OnClickListener{
		 
		private String taskId;
		
		public void setTaskId(String taskId) {
			this.taskId = taskId;
		}


		@Override
		public void onClick(View v) {
			Intent intent = new Intent(mContext, InspectionRecordCompanyActivity.class);
			intent.putExtra("taskId", taskId);
			mContext.startActivity(intent);
		}
	}

}
