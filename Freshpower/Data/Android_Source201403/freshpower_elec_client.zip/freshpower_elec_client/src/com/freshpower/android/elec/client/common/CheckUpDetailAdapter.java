/**   
 * @{#} SysSetGroupOneAdapter.java Create on 2012-11-5 ����11:00:47   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.client.common;

import java.util.List;
import java.util.Map;

import com.freshpower.android.elec.client.R;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CheckUpDetailAdapter extends BaseAdapter {

	List<Map<String, Object>> mData;
	Context mContext;
	int resource;
	private SharedPreferences trmsSharedPreferences;
	private Editor editor;
	private Intent intent;

	public CheckUpDetailAdapter(List<Map<String, Object>> data,
			Context context, int resource) {
		this.mData = data;
		this.mContext = context;
		this.resource = resource;
	}
	static class ViewHoder {
		LinearLayout checkStyleParent;
		TextView titleView;
		TextView contentView;
	}
	@Override
	public int getCount() {
		return mData == null ? 0 : mData.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@SuppressLint("NewApi")
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHoder hoder = null;
		if (convertView == null) {
			hoder = new ViewHoder();
			convertView = LayoutInflater.from(mContext).inflate(resource, null);
			hoder.checkStyleParent = (LinearLayout)convertView.findViewById(R.id.checkup_style_parent);
			hoder.contentView = (TextView)convertView.findViewById(R.id.checkup_demo_content);
			hoder.titleView = (TextView)convertView.findViewById(R.id.checkup_demo_title);
			convertView.setTag(hoder);
		} else {
			hoder = (ViewHoder) convertView.getTag();
		}
		
		if(position % 2 ==1){
			hoder.checkStyleParent.setBackgroundColor(mContext.getResources().getColor(R.color.bgcolor));
		}else{
			hoder.checkStyleParent.setBackgroundColor(mContext.getResources().getColor(R.color.white));
		}
		
		Map<String, Object> data = mData.get(position);
		hoder.titleView.setText(String.valueOf(data.get("SCOUTCHECK_CONTENT"))+":");//��������
		if(String.valueOf(data.get("SCOUTCHECK")).equals("56")){
			hoder.contentView.setTextColor(Color.parseColor("#009900"));
			hoder.contentView.setText("����");//��������
		}else if(String.valueOf(data.get("SCOUTCHECK")).equals("57")){
			hoder.contentView.setTextColor(Color.parseColor("#FF0000"));
			hoder.contentView.setText("�쳣");//��������
		}else if(String.valueOf(data.get("SCOUTCHECK")).equals("154")){
			hoder.contentView.setText("��");//��������
		}else{
			hoder.contentView.setText(String.valueOf(data.get("SCOUTCHECK")));//��������
		}
		
		return convertView;
	}
}
