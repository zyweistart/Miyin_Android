package com.freshpower.android.elec.client.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.conn.HttpHostConnectException;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.common.StringUtil;
import com.freshpower.android.elec.client.common.WarnComapnySetGroupOneAdapter;
import com.freshpower.android.elec.client.domain.ClientWarnComapny;
import com.freshpower.android.elec.client.netapi.ClientWarnComapnyDataApi;
import com.freshpower.android.elec.client.widget.PullDownListView;

public class ClientWarnComapnyActivity extends FrameActivity implements PullDownListView.OnRefreshListioner{
	private RoundCornerListView groupOnelistview;
	private Resources res;
	private List<ClientWarnComapny> warnDetailList;
	private PullDownListView mPullDownView;
	private ListView mListView;
	private WarnComapnySetGroupOneAdapter adapter; 
	private Handler mHandler = new Handler();
	private int maxAount = 20;//�������������ֵ
	private int pageSize = 10;//ÿҳ��ʾ
	private int currentPage =1;//��ǰҳ
	private int totalCnt=0;//�ܼ�¼��
	private int rs=999;//��ѯ���
	private ImageView imgV;
	List<Map<String, Object>> customerInfoMap;
	private ProgressDialog processProgress;
	private String warnName;
	private String warnLevel;
	private String catchNot="yes";
	private String result;
	private String type;

	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_clientwarn);
	}
	
	@Override
	protected void onResume() {
		res = getResources();
		if(null!=customerInfoMap&&customerInfoMap.size()>0){
			customerInfoMap.clear();
			adapter.notifyDataSetChanged();	
		}
		mPullDownView = (PullDownListView) findViewById(R.id.sreach_list);
		mPullDownView.setRefreshListioner(this);
		mListView = mPullDownView.mListView;
		processProgress = ProgressDialog.show(ClientWarnComapnyActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(){
			public void run() {
				customerInfoMap = getGroupOnelistData();
				Message msgMessage = new Message();
				ClientWarnComapnyActivity.this.xHandler.sendMessage(msgMessage);
			}
		}.start();
		super.onResume();
	}

	private Handler xHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {

			if(customerInfoMap!=null){
				adapter = new WarnComapnySetGroupOneAdapter(customerInfoMap,ClientWarnComapnyActivity.this,R.layout.listitem_clienwarn_comapny,warnDetailList);	
				mListView.setAdapter(adapter);
			}else{
				rs=AppConstant.Result.NO_COUNT;
			}
			if((!StringUtil.isEmpty(result)&&result.equals("0"))||totalCnt==0){
				Toast.makeText(ClientWarnComapnyActivity.this, R.string.noSearchResultMsg, Toast.LENGTH_SHORT).show();
			}else if(catchNot.equals("not")&&!StringUtil.isEmpty(result)&&!result.equals("0")){
				Toast.makeText(ClientWarnComapnyActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show();
			}

			setShow();
			//		progressRlt.setVisibility(View.GONE);
			mPullDownView.setVisibility(View.VISIBLE);
			processProgress.dismiss();
		};
	};

	private void setShow() {
		if(rs==AppConstant.Result.NO_COUNT){
			RelativeLayout noResultlayout = (RelativeLayout) findViewById(R.id.noResultlayout);
			noResultlayout.setVisibility(View.VISIBLE);
			mPullDownView.setMore(false);
		}else{
			mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
		}
		if(totalCnt<=pageSize){
			mPullDownView.setMore(false);
		}
	}
	private List<Map<String, Object>> getGroupOnelistData(){
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		Intent iet=getIntent();
		type=iet.getStringExtra("type");
		try {
			Map warnMap = ClientWarnComapnyDataApi.getWarnInfoList(pageSize, currentPage, type, "");
			result = String.valueOf(warnMap.get("result"));
			totalCnt = Integer.parseInt(String.valueOf(warnMap.get("totalCount")));
			warnDetailList=(List<ClientWarnComapny>) warnMap.get("clientWarnComapnyList");
			
			for (ClientWarnComapny clientWarnComapny:warnDetailList)
			{
				Map<String, Object> listItem = new HashMap<String, Object>();
				listItem.put("warnOne",clientWarnComapny.getMeterName());
				listItem.put("warnTwo",clientWarnComapny.getAlertDate());
				listItem.put("warnThree",clientWarnComapny.getAlertLevel());
				listItem.put("warnFour",clientWarnComapny.getAlertReply());
				listItem.put("warnFive",clientWarnComapny.getContent());
				listItems.add(listItem);
			}
		}catch (HttpHostConnectException e) {
			catchNot="not";
			e.printStackTrace();
		}catch (Exception e) {
			catchNot="not";
			e.printStackTrace();
		}
		return listItems;
	}
	/**
	 * ˢ�£������list������Ȼ�����¼��ظ�������
	 */
	public void onRefresh() {

		mHandler.postDelayed(new Runnable() {

			public void run() {
				customerInfoMap.clear();
				currentPage =1;
				customerInfoMap.addAll(getGroupOnelistData());

				mPullDownView.onRefreshComplete();//�����ʾˢ�´�����ɺ������ļ���ˢ�½�������
				mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				if(totalCnt<=pageSize){
					mPullDownView.setMore(false);
				}
				adapter.notifyDataSetChanged();	
			}
		}, 1500);


	}

	/**
	 * ���ظ��࣬��ԭ��������������������
	 */
	public void onLoadMore() {

		mHandler.postDelayed(new Runnable() {
			public void run() {
				//addLists(5);//ÿ�μ�������������
				
				if(null!=getGroupOnelistData()&&!"".equals(getGroupOnelistData())&&getGroupOnelistData().size()>0){
					currentPage++;
				}
				customerInfoMap.addAll(getGroupOnelistData());

				mPullDownView.onLoadMoreComplete();//�����ʾ���ظ��ദ����ɺ������ļ��ظ�����棨���ػ��������������ࣩ
				//if(list.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
				if(customerInfoMap.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
					mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				else
					mPullDownView.setMore(false);
				adapter.notifyDataSetChanged();	

			}
		}, 1500);
	}
	/***
	 * ��̬����listview�ĸ߶�
	 * 
	 * @param listView
	 */
	public void setListViewHeightBasedOnChildren(ListView listView) {
		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null) {
			return;
		}
		int totalHeight = 0;
		for (int i = 0; i < listAdapter.getCount(); i++) {
			View listItem = listAdapter.getView(i, null, listView);
			listItem.measure(0, 0);
			totalHeight += listItem.getMeasuredHeight();
		}
		ViewGroup.LayoutParams params = listView.getLayoutParams();
		params.height = totalHeight
				+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
		listView.setLayoutParams(params);
	}
}
