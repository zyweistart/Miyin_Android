package com.freshpower.android.elec.client.domain;

public class AggregatorInfo {
	private String serialNo;
	private String productNo;
	private String commuType;
	private String isOnLine;
	private String status;
	private String RegId;
	private String convergeId;
	private String siteId;
	private String cpId;
	private String convergeKey;
	private String cpName;
	private String siteName;
	private String tel;
	private String telName;
	private String linesCount;
	private String alarmCount;
	private String metersCount;
	private String errCount;
	private String result;//����ʱ���صĽ��
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	public String getProductNo() {
		return productNo;
	}
	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}
	public String getCommuType() {
		return commuType;
	}
	public void setCommuType(String commuType) {
		this.commuType = commuType;
	}
	public String getIsOnLine() {
		return isOnLine;
	}
	public void setIsOnLine(String isOnLine) {
		this.isOnLine = isOnLine;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRegId() {
		return RegId;
	}
	public void setRegId(String regId) {
		RegId = regId;
	}
	public String getConvergeId() {
		return convergeId;
	}
	public void setConvergeId(String convergeId) {
		this.convergeId = convergeId;
	}
	public String getSiteId() {
		return siteId;
	}
	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}
	public String getCpId() {
		return cpId;
	}
	public void setCpId(String cpId) {
		this.cpId = cpId;
	}
	public String getConvergeKey() {
		return convergeKey;
	}
	public void setConvergeKey(String convergeKey) {
		this.convergeKey = convergeKey;
	}
	public String getCpName() {
		return cpName;
	}
	public void setCpName(String cpName) {
		this.cpName = cpName;
	}
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getTelName() {
		return telName;
	}
	public void setTelName(String telName) {
		this.telName = telName;
	}
	public String getLinesCount() {
		return linesCount;
	}
	public void setLinesCount(String linesCount) {
		this.linesCount = linesCount;
	}
	public String getAlarmCount() {
		return alarmCount;
	}
	public void setAlarmCount(String alarmCount) {
		this.alarmCount = alarmCount;
	}
	public String getMetersCount() {
		return metersCount;
	}
	public void setMetersCount(String metersCount) {
		this.metersCount = metersCount;
	}
	public String getErrCount() {
		return errCount;
	}
	public void setErrCount(String errCount) {
		this.errCount = errCount;
	}
	
}
