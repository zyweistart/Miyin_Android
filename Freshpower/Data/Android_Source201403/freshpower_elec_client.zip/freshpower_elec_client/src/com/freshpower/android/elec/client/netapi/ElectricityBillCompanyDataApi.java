package com.freshpower.android.elec.client.netapi;

import java.io.File;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.client.common.AppCache;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.conf.AppConfig;
import com.freshpower.android.elec.client.domain.ElectricityBillCompany;
import com.freshpower.android.elec.client.domain.LineDetailInfo;
import com.freshpower.android.elec.client.domain.LoginInfo;

public class ElectricityBillCompanyDataApi {
	private static final String BILL_LIST = "AppComElec.aspx";
	private static final String BILL_DETAILED_LIST = "AppMeterElec.aspx";
	private static final String ACTION_NAME = "AppHisMeterElec.aspx";
	/**
	 * ��ҵ�����������
	 */
	public static ElectricityBillCompany getElectricityBillInfoList(String id,String selectType) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("CP_ID", loginInfo.getCpId());
		//		api.addParam("CP_ID", "149");
		api.addParam("SelectType", selectType);
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getFpsWebSite()+File.separator+BILL_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("ComElec");
		ElectricityBillCompany electricityBill = null;
		if(Integer.valueOf(rows.getString("result"))>0){
			electricityBill=new ElectricityBillCompany();
			JSONObject table1 = (JSONObject) jsonObj.get(0);
			electricityBill.setAvgPrice(table1.getString("AvgPrice")==null?"":table1.getString("AvgPrice"));
			electricityBill.setPeakFee(table1.getString("PeakFee")==null?"":table1.getString("PeakFee"));
			electricityBill.setPeakPower(table1.getString("PeakPower")==null?"":table1.getString("PeakPower"));
			electricityBill.setTipFee(table1.getString("TipFee")==null?"":table1.getString("TipFee"));
			electricityBill.setTipPower(table1.getString("TipPower")==null?"":table1.getString("TipPower"));
			electricityBill.setTotalFee(table1.getString("TotalFee")==null?"":table1.getString("TotalFee"));
			electricityBill.setTotalPower(table1.getString("TotalPower")==null?"":table1.getString("TotalPower"));
			electricityBill.setValleyFee(table1.getString("ValleyFee")==null?"":table1.getString("ValleyFee"));
			electricityBill.setValleyPower(table1.getString("ValleyPower")==null?"":table1.getString("ValleyPower"));
		}
		return electricityBill;
	}
	/**
	 * ��ҵ����������ϸ���
	 */
	public static Map<String,Object> getElectricityBillCompanyList(int pageSize,int pageNum,String selectType,String meterName) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("CP_ID", loginInfo.getCpId());
		api.addParam("SelectType", selectType);
		api.addParam("MeterName", URLEncoder.encode(meterName,"GBK").trim());
		api.addParam("PageIndex", String.valueOf(pageNum).trim());
		api.addParam("PageSize", String.valueOf(pageSize).trim());
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getFpsWebSite()+File.separator+BILL_DETAILED_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("MeterElecList");
		ElectricityBillCompany electricityBill = null;
		List<ElectricityBillCompany> electricityBillList = new ArrayList<ElectricityBillCompany>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				electricityBill=new ElectricityBillCompany();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				electricityBill.setAvgPrice(table1.getString("AvgPrice")==null?"":table1.getString("AvgPrice"));
				electricityBill.setTotalFee(table1.getString("TotalFee")==null?"":table1.getString("TotalFee"));
				electricityBill.setTotalPower(table1.getString("TotalPower")==null?"":table1.getString("TotalPower"));
				electricityBill.setMeterName(table1.getString("METER_NAME")==null?"":table1.getString("METER_NAME"));
				electricityBill.setMeterId(table1.getString("METER_ID")==null?"":table1.getString("METER_ID"));
				electricityBillList.add(electricityBill);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalCount", rows.getString("TotalCount"));
		map.put("result", rows.getString("result"));
		map.put("electricityBillList", electricityBillList);
		return map;
	}
	
	/**
	 * ��ȡ��·��ϸ��Ϣ
	 * @param qttask����id
	 * @param qtkey�豸id
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getLineDetailInfoList(String meterId,String date,String SelectType) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd()); 
		api.addParam("CP_ID",loginInfo.getCpId());
		api.addParam("MeterID",meterId);
		if(!date.equals("")){
			api.addParam("sDate",URLEncoder.encode(date,"GBK").trim());
			api.addParam("eDate",URLEncoder.encode(date,"GBK").trim());
		}
		api.addParam("SelectType",SelectType);
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getFpsWebSite()+File.separator+ACTION_NAME,AppConstant.ETG_INTERFACE_CHARSET);
		Log.d("BID", "jsonResult:"+jsonResult.toString());
		JSONObject rows = jsonResult.getJSONObject("Rows");
		LineDetailInfo lineInfo = null;
		List<LineDetailInfo> lineInfoList = new ArrayList<LineDetailInfo>();
		if(Integer.valueOf(rows.getString("result"))>0){
			JSONArray jsonObj = jsonResult.getJSONArray("MeterHisElecList");
			if(jsonObj!=null){
				for(int i=0;i<jsonObj.size();i++){
					lineInfo=new LineDetailInfo();
					JSONObject table1 = (JSONObject) jsonObj.get(i);
					lineInfo.setTotalFee(table1.getString("TotalFee")==null?"":table1.getString("TotalFee"));//�ۼƵ��
					lineInfo.setTotalPower(table1.getString("TotalPower")==null?"":table1.getString("TotalPower"));//�ۼƵ���
					lineInfo.setTipFee(table1.getString("TipFee")==null?"":table1.getString("TipFee"));//�����
					lineInfo.setTipPower(table1.getString("TipPower")==null?"":table1.getString("TipPower"));//������
					lineInfo.setPeakFee(table1.getString("PeakFee")==null?"":table1.getString("PeakFee"));//�߷���
					lineInfo.setPeakPower(table1.getString("PeakPower")==null?"":table1.getString("PeakPower"));//�߷����
					lineInfo.setValleyFee(table1.getString("ValleyFee")==null?"":table1.getString("ValleyFee"));//�͹ȵ��
					lineInfo.setValleyPower(table1.getString("ValleyPower")==null?"":table1.getString("ValleyPower"));//�͹ȵ���
					lineInfo.setAvgPrice(table1.getString("AvgPrice")==null?"":table1.getString("AvgPrice"));//ƽ�����
					lineInfo.setDate(table1.getString("Date")==null?"":table1.getString("Date"));//����
					lineInfoList.add(lineInfo);
				}
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("lineInfoList", lineInfoList);
//		map.put("totalCount", rows.getString("TotalCount"));
		map.put("result", rows.getString("result"));
		return map;
	}
}
