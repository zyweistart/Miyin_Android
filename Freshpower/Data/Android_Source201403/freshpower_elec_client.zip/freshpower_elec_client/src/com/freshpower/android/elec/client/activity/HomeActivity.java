package com.freshpower.android.elec.client.activity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ImageView.ScaleType;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityData;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.common.FileUtil;
import com.freshpower.android.elec.client.common.GetCurrentData;
import com.freshpower.android.elec.client.common.UpdateManager;
import com.freshpower.android.elec.client.domain.LoginInfo;

public class HomeActivity extends FrameActivity {
	DecimalFormat df = new DecimalFormat("0.00");
	private Resources res;
	private ImageButton homeBtn;
	public static GetCurrentData getCurrentData;
	
	//��ҳ�������ģ�� start
	TextView electricityOne;
	TextView electricityBillOne;
	TextView electricityTwo;
	TextView electricityBillTwo;
	TextView electricityThree;
	TextView electricityBillThree;
	TextView electricityFour;
	TextView electricityBillFour;
	TextView electricityFive;
	TextView electricityBillFive;
	TextView averagePrice;
	TextView day_ele;
	TextView day_bill;
	
	int hour=0;
	int day=0;
	Double totalElectricity;//�ܵ���
	Double totalElectriBillcity;//�ܵ��
	Double topElectricity;//������
	Double topElectriBillcity;//�����
	Double peakElectricity;//�߷����
	Double peakElectriBillcity;//�߷���
	Double lowElectricity;//�͹ȵ���
	Double lowElectriBillcity;//�͹ȵ��
	Double hourElectricity;//ÿСʱ����
	private double priceElectricity;//ƽ�����
	private double dayPriceElectricity;// ����ƽ����ۺ�����ƽ����۱�ֵ
	private double monthPriceElectricity;// ����ƽ����ۺ�����ƽ����۱�ֵ
	private double randomPrice;// ������ʷƽ�����
	private double[] sumChargeDoubleList = null;// ����
	//end
	private OnOffThread myThread = new OnOffThread();
	// ����ʱ����
	private TimerThread timerThread = new TimerThread();
	private int countDown = 0;
	
	private String maxLine;// ƽ�������ߵ���·
	private String minLine;// ƽ�������͵���·
	private String economizeFee;// ��Լ�ķ���
	private double[] outScaleArr;// ����������ߵ�ϵ������
	private double[] inScaleArr;// ����������е�ϵ������
	private String maxPrice;// ���ƽ���۸�
	private String minPrice;// ��Сƽ���۸�
	private File pictureNameFile;
	private String sdpath = FileUtil.getAppRootPath();// ��ô洢����·��
	
	private ViewPager viewPager; // android-support-v4�еĻ������
	private List<ImageView> imageViews; // ������ͼƬ����
	private int[] imageResId; // ͼƬID
	private LinearLayout dots; // ͼƬ�������ĵ���Щ��
	private int currentItem = 0; // ��ǰͼƬ��������
	private ScheduledExecutorService scheduledExecutorService;
	private Bitmap bitmap;
    private BitmapDrawable bitmapDrawable;
	@Override
	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_home);
		res = getResources();
		Intent updateIntent = getIntent();
		String isFirst =updateIntent.getStringExtra("isFirst");
		if(null!=isFirst&&isFirst.equals("isFirst")){
			UpdateManager manager = new UpdateManager(HomeActivity.this);
			manager.checkUpdate(true);
		}
		
		bindEvent();
		
		//����ҳ����ͷ������ͼƬ
		imageViews = new ArrayList<ImageView>();
		pictureNameFile = new File(sdpath+"download"+File.separator+"pictureNameFile.txt");
		try {
			if (android.os.Environment.getExternalStorageState().equals(
					android.os.Environment.MEDIA_MOUNTED) //�ж��Ƿ��SD���ж�дȨ��
					&& pictureNameFile.exists()){ //�жϸ��ļ����Ƿ����) 
				setTopPicture();
			}else{
				imageResId = new int[] { R.drawable.image1, R.drawable.image2 };
				for (int i = 0; i < imageResId.length; i++) {
					ImageView imageView = new ImageView(this);
					imageView.setBackgroundResource(imageResId[i]);
					imageView.setScaleType(ScaleType.CENTER_CROP);
					imageViews.add(imageView);
					imageView.destroyDrawingCache();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		dots = (LinearLayout)findViewById(R.id.dot);
		RelativeLayout.LayoutParams lp; 
		ImageView view;
		for(int i = 0 ; i < imageViews.size() ;i++){
			view = new ImageView(HomeActivity.this);
			lp = new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
			lp.setMargins(2, 0, 2, 0);
			view.setLayoutParams(lp);
			view.setImageResource(R.drawable.dot_unselected);
			dots.addView(view);
			view.destroyDrawingCache();
		}
		view = (ImageView)dots.getChildAt(0);
		view.setImageResource(R.drawable.dot_selected);
		
		viewPager = (ViewPager) findViewById(R.id.vp);
		viewPager.setAdapter(new TopPictureAdapter());// �������ViewPagerҳ���������
		// ����һ������������ViewPager�е�ҳ��ı�ʱ����
		viewPager.setOnPageChangeListener(new PictureChangeListener());
		scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
		// ��Activity��ʾ������ÿ�������л�һ��ͼƬ��ʾ
		scheduledExecutorService.scheduleAtFixedRate(new ScrollTask(), 1, 3, TimeUnit.SECONDS);
		
		// ��ҵ�ܸ���
		if(getCurrentData == null){
			getCurrentData = new GetCurrentData();
			getCurrentData.start();
		}
		setClientBurthenCurveChart();// ��ҵ�ܸ�������ͼ
		myThread.start();// ����״̬�����߳�
		//��ѵ���
		outScaleArr = ActivityData.getOutScale();
		inScaleArr = ActivityData.getInScale();
		Calendar cd=Calendar.getInstance();
		if(cd.get(Calendar.HOUR_OF_DAY)==0){
			hourElectricity=ActivityData.eleBill[cd.get(Calendar.HOUR_OF_DAY)];
		}else{
			hourElectricity=ActivityData.eleBill[cd.get(Calendar.HOUR_OF_DAY)-1];
		}
		day_ele=(TextView)findViewById(R.id.day_ele);
		day_ele.setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
        		setElectricityBill("1");	
			}
		});
		day_bill=(TextView)findViewById(R.id.day_bill);
		day_bill.setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
        		setElectricityBill("2");
			}
		});
		setElectricityBill("1");
		
		setPriceElectricity();
		
		// ��ϸ���
		Button elebill=(Button)findViewById(R.id.elebill);
		elebill.setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
        		timerThread.setDestory(true);
        		TextView dayMonthBill=(TextView)findViewById(R.id.dayMonth);
				Intent intent = new Intent(HomeActivity.this,ElectricityBillActivity.class);
				intent.putExtra("dayMonth", dayMonthBill.getText());
				intent.putExtra("hourElectricity", hourElectricity);
				intent.putExtra("outScaleArr", outScaleArr);
				intent.putExtra("inScaleArr", inScaleArr);
	    		startActivity(intent);
			}
		});
		Button reportBtn = (Button)findViewById(R.id.reportBtn);
		reportBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				timerThread.setDestory(true);
				Intent intent = new Intent(HomeActivity.this,InspectionActivity.class);
	    		startActivity(intent);
			}
		});
		Button warnInfoBtn=(Button)findViewById(R.id.warnInfoBtn);
		warnInfoBtn.setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
        		timerThread.setDestory(true);
				Intent intent = new Intent(HomeActivity.this,AlarmActivity.class);
	    		startActivity(intent);
			}
		});
		timerThread.start();// ��������ʱ�߳�
	}
	Bundle bundle;
	//���¼�
	private void bindEvent() {
		
		//��ϸ���ɴ��¼�
		Button chargeButton = (Button)findViewById(R.id.view_charge_button);
		chargeButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				timerThread.setDestory(true);
				Intent intent = new Intent();
				bundle = new Bundle();
				bundle.putDoubleArray("sumCharge", sumChargeDoubleList);
				intent.putExtras(bundle);
				intent.setClass(HomeActivity.this, ExperienceActivity.class);
				startActivity(intent);
			}
		});
	}


	@Override
	protected void onResume() {
		homeBtn = (ImageButton) findViewById(R.id.homeBtn);
		if(homeBtn!=null){
			homeBtn.setOnClickListener(null);
			homeBtn.setBackgroundResource(R.drawable.homebtn_select);
		} else {
			timerThread.setDestory(true);
		}

		TextView homeBtnTv = (TextView)findViewById(R.id.homeBtnTv);
		homeBtnTv.setTextColor(getResources().getColor(R.color.white));
		super.onResume();
	}
	
	@Override
	protected void onStop() {
		scheduledExecutorService.shutdown();
		if(myThread != null){
			myThread.setDestory(true);
		}
		if(timerThread != null){
			timerThread.setDestory(true);
		}
		super.onStop();
	}
	
	@Override
	protected void onRestart() {
		//���´�ʱ���ٴ�����ͼƬ�л�����
		scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
		// ��Activity��ʾ������ÿ�������л�һ��ͼƬ��ʾ
		scheduledExecutorService.scheduleAtFixedRate(new ScrollTask(), 1, 3, TimeUnit.SECONDS);
		super.onRestart();
	}
	
	/**
	 * ��ҵ�ܸ�������ͼ
	 */
	private void setClientBurthenCurveChart() {
		ClientBurthenCurveChart clientBurthenCurveChart = new ClientBurthenCurveChart();
		LinearLayout curveChart = (LinearLayout)findViewById(R.id.curveChart);
		sumChargeDoubleList = ActivityData.getRandomChargeData();// �����ȡ����
		clientBurthenCurveChart.setSumChargeDoubleList(sumChargeDoubleList);
		clientBurthenCurveChart.exe(HomeActivity.this, curveChart);
	}
	
	public double[] getSumChargeDoubleList() {
		return sumChargeDoubleList;
	}

	public void setSumChargeDoubleList(double[] sumChargeDoubleList) {
		this.sumChargeDoubleList = sumChargeDoubleList;
	}

	/**
	 * ����״̬������״ͼ
	 */
	private void setRunStatusBarChart() {
		double[] chargeData = GetCurrentData.chargeDoubleList.get(11);
		ClientRunStatusBarChart clientRunStatusBarChart = new ClientRunStatusBarChart();
		LinearLayout barChart = (LinearLayout)findViewById(R.id.barChart);
		clientRunStatusBarChart.setChargeData(chargeData);// ����
		clientRunStatusBarChart.setCurrentList(GetCurrentData.currentList.get(11));// ����
		clientRunStatusBarChart.exe(HomeActivity.this, barChart);
	}
	//��ѵ���
	private void setElectricityBill(String str){
		priceElectricity=0.06*1.406+0.6*1.108+0.34*0.596;
		Calendar c=Calendar.getInstance();
		day=c.get(Calendar.DAY_OF_MONTH);
		TextView dayMonth=(TextView)findViewById(R.id.dayMonth);
		if(str.equals("1")){
			hour=c.get(Calendar.HOUR_OF_DAY);
			day_ele.setTextColor(getResources().getColor(R.color.station));
			day_ele.setBackgroundResource(R.drawable.hometab);
			day_bill.setBackgroundResource(R.drawable.hometab_select);
			day_bill.setTextColor(getResources().getColor(R.color.balck));
    		dayMonth.setText("����");
		}else{
			hour=(day-1)*24;
			day_bill.setTextColor(getResources().getColor(R.color.station));
			day_bill.setBackgroundResource(R.drawable.hometab);
			day_ele.setBackgroundResource(R.drawable.hometab_select);
			day_ele.setTextColor(getResources().getColor(R.color.balck));
    		dayMonth.setText("����");
		}
		totalElectricity=hourElectricity*hour;
		totalElectriBillcity=totalElectricity*priceElectricity;
		topElectricity=totalElectricity*0.06;
		topElectriBillcity=totalElectricity*0.06*1.406;
		peakElectricity=totalElectricity*0.6;
		peakElectriBillcity=totalElectricity*0.6*1.108;
		lowElectricity=totalElectricity*0.34;
		lowElectriBillcity=totalElectricity*0.34*0.596;
		
		// �������㷨
		double totalElectricityFirst=totalElectricity*inScaleArr[0];
		double totalElectricityBillFirst=totalElectriBillcity*inScaleArr[0];
		double totalElectricitySecond=totalElectricity*inScaleArr[1];
		double totalElectricityBillSecond=totalElectriBillcity*inScaleArr[1];
		double b11 = (totalElectricityBillFirst*outScaleArr[0])/(totalElectricityFirst*0.2);
		double b12 = (totalElectricityBillFirst*outScaleArr[1])/(totalElectricityFirst*0.3);
		double b13 = (totalElectricityBillFirst*outScaleArr[2])/(totalElectricityFirst*0.5);
		double b21 = (totalElectricityBillSecond*outScaleArr[3])/(totalElectricitySecond*0.2);
		double b22 = (totalElectricityBillSecond*outScaleArr[4])/(totalElectricitySecond*0.3);
		double b23 = (totalElectricityBillSecond*outScaleArr[5])/(totalElectricitySecond*0.5);
		double[] priceArr = { b11, b12, b13, b21, b22, b23 };
		maxLine = ActivityData.getMaxLineName(priceArr);// ��ȡ��ߵ������
		minLine = ActivityData.getMinLineName(priceArr);// ��ȡ��͵������
		if(maxLine.equals("����B1-1")) {// �������ƽ���۸�
			maxPrice = df.format(b11);
		} else if(maxLine.equals("����B1-2")) {
			maxPrice = df.format(b12);
		} else if(maxLine.equals("����B1-3")) {
			maxPrice = df.format(b13);
		} else if(maxLine.equals("����B2-1")) {
			maxPrice = df.format(b21);
		} else if(maxLine.equals("����B2-2")) {
			maxPrice = df.format(b22);
		} else if(maxLine.equals("����B2-3")) {
			maxPrice = df.format(b23);
		}
		if(minLine.equals("����B1-1")) {// ������Сƽ���۸�
			minPrice = df.format(b11);
		} else if(minLine.equals("����B1-2")) {
			minPrice = df.format(b12);
		} else if(minLine.equals("����B1-3")) {
			minPrice = df.format(b13);
		} else if(minLine.equals("����B2-1")) {
			minPrice = df.format(b21);
		} else if(minLine.equals("����B2-2")) {
			minPrice = df.format(b22);
		} else if(minLine.equals("����B2-3")) {
			minPrice = df.format(b23);
		}
		int economizeFeeHour = (day-1)*24;
		double economizeFeeTotalElectricity = hourElectricity*economizeFeeHour;
		economizeFee = df.format(economizeFeeTotalElectricity*0.512);
		
		electricityTwo=(TextView)findViewById(R.id.electricityTwo);
		electricityTwo.setText(String.valueOf(df.format(totalElectricity))+"kWh");//�ܵ���
		electricityBillTwo=(TextView)findViewById(R.id.electricityBillTwo);
		electricityBillTwo.setText(String.valueOf(df.format(totalElectriBillcity))+"Ԫ");
		electricityThree=(TextView)findViewById(R.id.electricityThree);
		electricityThree.setText(String.valueOf(df.format(topElectricity))+"kWh");//���
		electricityBillThree=(TextView)findViewById(R.id.electricityBillThree);
		electricityBillThree.setText(String.valueOf(df.format(topElectriBillcity))+"Ԫ");
		electricityFour=(TextView)findViewById(R.id.electricityFour);
		electricityFour.setText(String.valueOf(df.format(peakElectricity))+"kWh");//�߷�
		electricityBillFour=(TextView)findViewById(R.id.electricityBillFour);
		electricityBillFour.setText(String.valueOf(df.format(peakElectriBillcity))+"Ԫ");
		electricityFive=(TextView)findViewById(R.id.electricityFive);
		electricityFive.setText(String.valueOf(df.format(lowElectricity))+"kWh");//�͹�
		electricityBillFive=(TextView)findViewById(R.id.electricityBillFive);
		electricityBillFive.setText(String.valueOf(df.format(lowElectriBillcity))+"Ԫ");
		averagePrice=(TextView)findViewById(R.id.averagePrice);
		averagePrice.setText(String.valueOf(df.format(priceElectricity))+"Ԫ/kWh");
	}
	
	/**
	 * ���õ��յ���ƽ����۱�ֵ
	 */
	private void setPriceElectricity(){
		double randomPrice = ActivityData.getBeforeAveragePrice();
		dayPriceElectricity = 0.95 - randomPrice;
		int hour=(day-1)*24;
		double totalElectricity=hourElectricity*hour;
		monthPriceElectricity = dayPriceElectricity*totalElectricity;
	}
	
	class OnOffThread extends Thread{
    	
    	private boolean isDestory=false;
    	
    	void setDestory(boolean isDestory){
    		this.isDestory = isDestory;
    	}
    	
    	@Override
    	public void run() {
    		try {
        		while(!isDestory){
					if(isDestory)break;
	            	Message msg  = new Message();
	            	msg.what = 1;
	            	handler.sendMessage(msg);
	            	Thread.sleep(5000);
        		}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
    	}
    }
	
	private Handler  handler = new Handler(){
    	public void handleMessage(android.os.Message msg) {
    		if(msg.what==1){
    			setRunStatusBarChart();// ����״̬������״ͼ
    		}
    	};
    };
    
    
	// �л���ǰ��ʾ��ͼƬ
	private Handler pictureHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			viewPager.setCurrentItem(currentItem);// �л���ǰ��ʾ��ͼƬ
		};
	};
    
    protected void onDestroy() {
    	scheduledExecutorService.shutdown();
		if(myThread != null){
			myThread.setDestory(true);
		}
		if(timerThread != null){
			timerThread.setDestory(true);
		}
		super.onDestroy();
	}
    
    // ������Ϣ�߳�
	class TimerThread extends Thread {
			
			private boolean isDestory = false;
	
			void setDestory(boolean isDestory) {
				this.isDestory = isDestory;
			}
			
			public void run() {
				try {
					while (!isDestory) {
						if (isDestory)
							break;
						Message msg = new Message();
						msg.what = 1;
						timerHandler.sendMessage(msg);
						Thread.sleep(1000);
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	
	 private Handler timerHandler = new Handler(){
	    	public void handleMessage(android.os.Message msg) {
				countDown++;
				if(countDown == 30) {// 30����ʾ
					Intent intent = new Intent();
					intent.putExtra("countDown", "30");
					intent.putExtra("dayPriceElectricity", String.valueOf(dayPriceElectricity));
					intent.putExtra("monthPriceElectricity", String.valueOf(monthPriceElectricity));
					intent.putExtra("priceElectricity", String.valueOf(priceElectricity));
					intent.putExtra("randomPrice", String.valueOf(randomPrice));
					intent.setClass(HomeActivity.this, ClientShowToIndustrial.class);
					startActivityForResult(intent, AppConstant.RequestResultCode.REQUEST_USERSECOND);
				} else if(countDown == 60) {// 60����ʾ
					Intent intent = new Intent();
					intent.putExtra("countDown", "60");
					intent.putExtra("maxLine", maxLine);
					intent.putExtra("minLine", minLine);
					intent.putExtra("maxPrice", String.valueOf(maxPrice));
					intent.putExtra("minPrice", String.valueOf(minPrice));
					intent.setClass(HomeActivity.this, ClientShowToIndustrial.class);
					finishActivity(AppConstant.RequestResultCode.REQUEST_USERSECOND);
					startActivityForResult(intent, AppConstant.RequestResultCode.REQUEST_USERSECOND);
				} else if(countDown == 90) {// 90����ʾ
					Intent intent = new Intent();
					intent.putExtra("countDown", "90");
					intent.putExtra("economizeFee", economizeFee);
					intent.setClass(HomeActivity.this, ClientShowToIndustrial.class);
					finishActivity(AppConstant.RequestResultCode.REQUEST_USERSECOND);
					startActivity(intent);
					timerThread.setDestory(true);
				}
	    	};
		 };
		 
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(resultCode == AppConstant.RequestResultCode.RESULT_CANCEL) {
			timerThread.setDestory(true);
		}
	}
		 
		 
	private void setTopPicture() throws IOException{
		//-----------------��ȡ�ļ���---------------------
		FileReader file = new FileReader(sdpath+"download/pictureNameFile.txt");
		BufferedReader br = new BufferedReader(file);
		String temp = "";
		StringBuffer sb = new StringBuffer();
        while((temp = br.readLine())!=null){             
        	sb.append(temp);             
        }
        //------------------------------------------------
        String[] fileName = sb.toString().split(",");
		String sdpath = FileUtil.getAppRootPath();// ��ô洢����·��
		String filePath = sdpath+"download/toppicture";
        File wall;// MMͼƬ
        String path;//ͼƬ·��
        RelativeLayout.LayoutParams lp2 = new RelativeLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT);  
        ImageView btn;
        
		for(int i = 0 ; i < fileName.length ; i++){
		    wall = new File(filePath+"/"+ fileName[i].split("\\.")[0]);//��ȡͼƬ�ļ�
	        path = wall.getAbsolutePath();// MMͼƬ·��
		    btn = new ImageView(HomeActivity.this);
			bitmap = BitmapFactory.decodeFile(path);//����bitmapͼƬ
			bitmapDrawable = new BitmapDrawable(bitmap);
		    btn.setBackgroundDrawable(bitmapDrawable);//����ͼƬչ��
		    btn.setLayoutParams(lp2);//����ͼƬ�Ŀ���
		    btn.setScaleType(ScaleType.FIT_CENTER);
		    imageViews.add(btn);//����ť���ӽ���ͷ������
		    btn.destroyDrawingCache();//�ͷ�ͼƬ��ռ�ڴ�
		}
		if(br!=null){
			br.close();
		}
	}
	
	
	/**
	 * �ͷ�ͼƬ�ڴ�ռ�
	 * @param view
	 */
	private void nullViewDrawable(View view){
		try {
			view.setBackgroundDrawable(null);
		} catch(Exception e){
			e.printStackTrace();
		}
		
		try {
			 ImageView imageView = (ImageView)view;
			 imageView.setImageDrawable(null);
			 imageView.setBackgroundDrawable(null);
		} catch(Exception e){
			e.printStackTrace();
		}
	}
	
	/**
	 * �����л�����
	 * 
	 * @author Administrator
	 * 
	 */
	private class ScrollTask implements Runnable {

		public void run() {
			synchronized (viewPager) {
				System.out.println("currentItem: " + currentItem);
				currentItem = (currentItem + 1) % imageViews.size();
				pictureHandler.obtainMessage().sendToTarget(); // ͨ��Handler�л�ͼƬ
			}
		}

	}

	/**
	 * ��ViewPager��ҳ���״̬�����ı�ʱ����
	 * 
	 * @author Administrator
	 * 
	 */
	private class PictureChangeListener implements OnPageChangeListener {
		private int oldPosition = 0;

		/**
		 * This method will be invoked when a new page becomes selected.
		 * position: Position index of the new selected page.
		 */
		public void onPageSelected(int position) {
			currentItem = position;
			ImageView image = (ImageView)(dots.getChildAt(oldPosition));
			image.setImageResource(R.drawable.dot_unselected);
			image = (ImageView)(dots.getChildAt(position));
			image.setImageResource(R.drawable.dot_selected);
			oldPosition = position;
		}

		public void onPageScrollStateChanged(int arg0) {

		}

		public void onPageScrolled(int arg0, float arg1, int arg2) {

		}
	}

	/**
	 * ���ViewPagerҳ���������
	 * 
	 * @author Administrator
	 * 
	 */
	private class TopPictureAdapter extends PagerAdapter {

		@Override
		public int getCount() {
			return imageViews.size();
		}

		@Override
		public Object instantiateItem(View arg0, int arg1) {
			((ViewPager) arg0).addView(imageViews.get(arg1));
			return imageViews.get(arg1);
		}

		@Override
		public void destroyItem(View arg0, int arg1, Object arg2) {
			((ViewPager) arg0).removeView((View) arg2);
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}

		@Override
		public void restoreState(Parcelable arg0, ClassLoader arg1) {

		}

		@Override
		public Parcelable saveState() {
			return null;
		}

		@Override
		public void startUpdate(View arg0) {

		}

		@Override
		public void finishUpdate(View arg0) {

		}
	}
}
