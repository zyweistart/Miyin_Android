package com.freshpower.android.elec.client.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.common.Base64;
import com.freshpower.android.elec.client.common.StringUtil;
import com.freshpower.android.elec.client.domain.PurchaseType;
import com.freshpower.android.elec.client.netapi.PurchaseTypeApi;

import android.opengl.Visibility;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class SearchConditionActivity extends Activity {

	private RoundCornerListView searchConditionListView;
	private TextView topBarTv;
	private ImageView imgV;
	private int currentType;
	private String currentID;
	private String currentName;
	private List<PurchaseType> purchaseTypeList;
	private Intent intent;
	private String[] timeSearchMenuNames;
	private String[] timeSearchCodeValues;
	private RelativeLayout progressRlt = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_search_condition);
		findViews();
		ActivityUtil.addActivity(this);
		progressRlt = (RelativeLayout)findViewById(R.id.progressRlt);
		progressRlt.setVisibility(View.VISIBLE);
		
		new Thread() {
			@Override
			public void run() {
				setAdapter();

				Message msgMessage = new Message();
				SearchConditionActivity.this.mHandler.sendMessage(msgMessage);
			}
		}.start();
	}
	
	private Handler mHandler = new Handler() {
		public void handleMessage(Message msg) {
			progressRlt.setVisibility(View.GONE);
			ScrollView scrollView = (ScrollView) findViewById(R.id.scrollview);
			scrollView.setVisibility(View.VISIBLE);
			
			if((purchaseTypeList==null || purchaseTypeList.size()==0) && currentType!=AppConstant.PurchaseType.TIME){
				searchConditionListView.setVisibility(View.GONE);
				Toast.makeText(SearchConditionActivity.this, R.string.noSearchResult, Toast.LENGTH_LONG).show();
			}
		};
	};

	private void findViews() {
		currentName = getIntent().getStringExtra(AppConstant.ExtraName.EXTRANAME_NAME);
		currentType = getIntent().getIntExtra(AppConstant.ExtraName.EXTRANAME_TYPE,AppConstant.YES_NO_TYPE_NO);
		currentID = String.valueOf(getIntent().getLongExtra(AppConstant.ExtraName.EXTRANAME_ID,0L));
		
		searchConditionListView = (RoundCornerListView) findViewById(R.id.searchConditionListView);
		
		topBarTv = (TextView) findViewById(R.id.topBarTextView);
		if(currentName==null){
			topBarTv.setText(getResources().getString(R.string.search_title_sel)+getIntent().getExtras().getString(AppConstant.ListItemCtlName.MENU_NAME));
		}else{
			topBarTv.setText(currentName);
		}
			
		imgV = (ImageView) findViewById(R.id.nav_left);
		imgV.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				SearchConditionActivity.this.finish();
			}
		});
		
	
	}
	
	private void setAdapter(){
		searchConditionListView.setAdapter(new SimpleAdapter(this, getData(), R.layout.listitem_search_condition, new String[] {AppConstant.ListItemCtlName.MENU_ICO, AppConstant.ListItemCtlName.MENU_NAME}, new int[] { R.id.menuIco,R.id.menuName}));
		setListViewHeightBasedOnChildren(searchConditionListView);
		searchConditionListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				Map<String, Object> listItem = (Map<String, Object>)parent.getItemAtPosition(position);
				if(listItem.get(AppConstant.ListItemCtlName.MENU_ICO)!=null){
					intent = new Intent(SearchConditionActivity.this,SearchConditionActivity.class);
					intent.putExtra(AppConstant.ExtraName.EXTRANAME_NAME,purchaseTypeList.get(position).getName());
					intent.putExtra(AppConstant.ExtraName.EXTRANAME_TYPE, currentType);
					intent.putExtra(AppConstant.ExtraName.EXTRANAME_ID, purchaseTypeList.get(position).getId());
					intent.putExtra(AppConstant.ExtraName.EXTRANAME_CODE, purchaseTypeList.get(position).getCode());
					startActivityForResult(intent,100);
				}else{
					Intent intent=new Intent();  
					if(currentType == AppConstant.PurchaseType.TIME){
						intent.putExtra(AppConstant.ExtraName.EXTRANAME_NAME,timeSearchMenuNames[position]);
						intent.putExtra(AppConstant.ExtraName.EXTRANAME_CODE,timeSearchCodeValues[position]);
						intent.putExtra(AppConstant.ExtraName.EXTRANAME_TYPE, AppConstant.PurchaseType.TIME);
					}else{
						intent.putExtra(AppConstant.ExtraName.EXTRANAME_NAME,purchaseTypeList.get(position).getName());
						intent.putExtra(AppConstant.ExtraName.EXTRANAME_TYPE, currentType);
						intent.putExtra(AppConstant.ExtraName.EXTRANAME_ID, purchaseTypeList.get(position).getId());
						intent.putExtra(AppConstant.ExtraName.EXTRANAME_CODE,purchaseTypeList.get(position).getCode());
					}
			        setResult(20, intent);  
			        finish();
				}
			}
		});
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(20==resultCode)  
        {  
			setResult(20, data);  
			finish();
        }  
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	private  List<Map<String, Object>> getData() {
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		Map<String, Object> listItem = null;
		if(currentType == AppConstant.PurchaseType.TIME){
			timeSearchMenuNames=getResources().getStringArray(R.array.time_search);
			timeSearchCodeValues=getResources().getStringArray(R.array.time_search_code);
			for (int i = 0; i < timeSearchMenuNames.length; i++)
			{
				listItem = new HashMap<String, Object>();
				listItem.put(AppConstant.ListItemCtlName.MENU_NAME, timeSearchMenuNames[i]);
				listItems.add(listItem);
			}
		}else{
			try {
				purchaseTypeList = PurchaseTypeApi.getAppStoreInfo(currentID, currentType);
				
				intent = getIntent();
				PurchaseType purchaseType = new PurchaseType();
				if(!StringUtil.isEmpty(intent.getStringExtra(AppConstant.ExtraName.EXTRANAME_NAME)) && currentType == AppConstant.PurchaseType.AREA){
					purchaseType.setId(intent.getLongExtra(AppConstant.ExtraName.EXTRANAME_ID,0L));
					purchaseType.setName(intent.getStringExtra(AppConstant.ExtraName.EXTRANAME_NAME));
					purchaseType.setCode(intent.getStringExtra(AppConstant.ExtraName.EXTRANAME_CODE));
				}else{
					purchaseType.setId(0L);
					purchaseType.setParentId(0L);
					StringBuffer tempNameSb = new StringBuffer("����");
					if(currentType == AppConstant.PurchaseType.AREA){
						tempNameSb.append("����");
					}else if(currentType == AppConstant.PurchaseType.PURCHASE){
						tempNameSb.append("���");
					}else if(currentType == AppConstant.PurchaseType.TRADE){
						tempNameSb.append("��ҵ");
					}
					purchaseType.setName(tempNameSb.toString());
				}
				purchaseTypeList.add(0, purchaseType);
				
				for (int i = 0; i < purchaseTypeList.size(); i++)
				{
					listItem = new HashMap<String, Object>();
					purchaseType = purchaseTypeList.get(i);
					if(purchaseType.getHasChild()==AppConstant.YES_NO_TYPE_YES)
						listItem.put(AppConstant.ListItemCtlName.MENU_ICO, R.drawable.nav_left);
					listItem.put(AppConstant.ListItemCtlName.MENU_NAME, purchaseType.getName());
					listItems.add(listItem);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		return listItems;
	}
	
	/***
     * ��̬����listview�ĸ߶�
     * 
     * @param listView
     */
    public void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            return;
        }
        int totalHeight = 0;
        for (int i = 0; i < listAdapter.getCount(); i++) {
           View listItem = listAdapter.getView(i, null, listView);
            listItem.measure(0, 0);
            totalHeight += listItem.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight
                + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        listView.setLayoutParams(params);
    }


}
