package com.freshpower.android.elec.client.domain;

import java.util.Date;

public class BidInfo{
    private Long id;

    private String industry;

    private String area;
    
    private String projType;

    private String pubtime;

    private String pubtimeBegin;
    
    private String pubtimeEnd;
    
    private String title;

    private String content;

    private String thumb;

    private String linkMan;

    private String tel;

    private String projNo;

    private String projSrc;

    private Date createDate;
    
    private Integer status;

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}


	public String getProjType() {
		return projType;
	}

	public void setProjType(String projType) {
		this.projType = projType;
	}

	public String getPubtime() {
		return pubtime;
	}

	public void setPubtime(String pubtime) {
		this.pubtime = pubtime;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getThumb() {
		return thumb;
	}

	public void setThumb(String thumb) {
		this.thumb = thumb;
	}

	public String getLinkMan() {
		return linkMan;
	}

	public void setLinkMan(String linkMan) {
		this.linkMan = linkMan;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}


	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getPubtimeBegin() {
		return pubtimeBegin;
	}

	public void setPubtimeBegin(String pubtimeBegin) {
		this.pubtimeBegin = pubtimeBegin;
	}

	public String getPubtimeEnd() {
		return pubtimeEnd;
	}

	public void setPubtimeEnd(String pubtimeEnd) {
		this.pubtimeEnd = pubtimeEnd;
	}

	public String getProjNo() {
		return projNo;
	}

	public void setProjNo(String projNo) {
		this.projNo = projNo;
	}

	public String getProjSrc() {
		return projSrc;
	}

	public void setProjSrc(String projSrc) {
		this.projSrc = projSrc;
	}



}
