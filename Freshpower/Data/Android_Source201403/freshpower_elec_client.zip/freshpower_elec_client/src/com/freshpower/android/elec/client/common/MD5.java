/**   
 * @{#} MD5.java Create on 2013-1-4 ����04:58:18   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.client.common;   

import java.security.MessageDigest;
  
/**   
 * @author <a href="mailto:yangz@freshpower.cn">yangz</a>  
 * @version 1.0   
 */

public class MD5 {
	
	/**
	 * MD5����
	 * @param ��Ҫ���ܵ��ַ���
	 * @return MD5���ܺ���ַ���
	 */
	public static String encrypt(String s){
		try {
			byte[] btInput = s.getBytes();
			MessageDigest mdInst = MessageDigest.getInstance("MD5");
			mdInst.update(btInput);
			byte[] md = mdInst.digest();
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < md.length; i++) {
				int val = ((int) md[i]) & 0xff;
				if (val < 16)
					sb.append("0");
				sb.append(Integer.toHexString(val));

			}
			return sb.toString();
		} catch (Exception e) {
			return null;
		}
	}
}
