package com.freshpower.android.elec.client.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.conn.HttpHostConnectException;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.common.StringUtil;
import com.freshpower.android.elec.client.domain.ChargeDetailCompany;
import com.freshpower.android.elec.client.netapi.ChargeDetailCompanyApi;
import com.freshpower.android.elec.client.widget.PullDownListView;

public class ChargeDetailListCompanyActivity extends FrameActivity implements PullDownListView.OnRefreshListioner{
	private Resources res;
	private List<ChargeDetailCompany> chargeDetailList;
	private PullDownListView mPullDownView;
	private ListView mListView;
	private ChargeDetailCompanyAdapter adapter; 
	private Handler mHandler = new Handler();
	private int pageSize = 10;//ÿҳ��ʾ
	private int currentPage =1;//��ǰҳ
	private int totalCnt=0;//�ܼ�¼��
	private int rs=999;//��ѯ���
	private List<Map<String, Object>> chargeDetailMap;
	private ProgressDialog processProgress;
	private String meterName;
	private String catchNot="yes";
	private String result;
	private EditText lineEdit;
	private Button queryBtn;
	private Dialog noticeDialog;

	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.company_activity_charge_detail_list);
		res = getResources();
		mPullDownView = (PullDownListView) findViewById(R.id.sreach_list);
		mPullDownView.setRefreshListioner(this);
		mListView = mPullDownView.mListView;
		processProgress = ProgressDialog.show(ChargeDetailListCompanyActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(){
			public void run() {
				chargeDetailMap = getGroupOnelistData();
				Message msgMessage = new Message();
				ChargeDetailListCompanyActivity.this.xHandler.sendMessage(msgMessage);
			}
		}.start();
		
		// �����¼�
		ImageView returnButton = (ImageView) findViewById(R.id.chargeDetailReturn);
		returnButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				ChargeDetailListCompanyActivity.this.onBackPressed();
			}
		});
		
		// ��ѯ�¼�
		ImageView findBtn = (ImageView) findViewById(R.id.findBtn);
		findBtn.setOnClickListener(new mapSearchDialogIbClickListener());
	}

	private Handler xHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {

			if(chargeDetailMap!=null){
				adapter = new ChargeDetailCompanyAdapter(chargeDetailMap,ChargeDetailListCompanyActivity.this,R.layout.company_listitem_charge_detail_style);	
				mListView.setAdapter(adapter);
			}else{
				rs=AppConstant.Result.NO_COUNT;
			}
			if(!StringUtil.isEmpty(result)&&result.equals("0")){
				Toast.makeText(ChargeDetailListCompanyActivity.this, R.string.noSearchResultMsg, Toast.LENGTH_SHORT).show();
			}
			if(catchNot.equals("not")&&!StringUtil.isEmpty(result)&&!result.equals("0")){
				Toast.makeText(ChargeDetailListCompanyActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show();
			}
			if(catchNot.equals("not2")&&!StringUtil.isEmpty(result)&&!result.equals("0")){
				Toast.makeText(ChargeDetailListCompanyActivity.this, R.string.msg_abnormal_net2work, Toast.LENGTH_SHORT).show();
			}

			setShow();
			mPullDownView.setVisibility(View.VISIBLE);
			processProgress.dismiss();
		};
	};

	private void setShow() {
		if(rs==AppConstant.Result.NO_COUNT){
			RelativeLayout noResultlayout = (RelativeLayout) findViewById(R.id.noResultlayout);
			noResultlayout.setVisibility(View.VISIBLE);
			mPullDownView.setMore(false);
		}else{
			mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
		}
		if(totalCnt<10){
			mPullDownView.setMore(false);
		}
	}
	private List<Map<String, Object>> getGroupOnelistData(){
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		try {
			Map chargeDetailMap = ChargeDetailCompanyApi.getChargeDetailList(pageSize, currentPage, meterName);
			result = String.valueOf(chargeDetailMap.get("result"));
			totalCnt = Integer.parseInt(String.valueOf(chargeDetailMap.get("totalCount")));
			chargeDetailList = (List<ChargeDetailCompany>) chargeDetailMap.get("chargeDetailList");
			for (ChargeDetailCompany chargeDetail : chargeDetailList)
			{
				Map<String, Object> listItem = new HashMap<String, Object>();
				listItem.put("meterId", chargeDetail.getMeterId());
				listItem.put("meterText", chargeDetail.getMeterName());
				listItem.put("pPowerText",chargeDetail.getpPower());
				listItem.put("swichStatusText", chargeDetail.getSwichStatus());
				listItem.put("factorText", chargeDetail.getFactor());
				listItem.put("currentText", chargeDetail.getCurrent());
				listItems.add(listItem);
			}
		}catch (HttpHostConnectException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return listItems;
	}
	/**
	 * ˢ�£������list������Ȼ�����¼��ظ�������
	 */
	public void onRefresh() {

		mHandler.postDelayed(new Runnable() {

			public void run() {
				chargeDetailMap.clear();
				currentPage =1;
				chargeDetailMap.addAll(getGroupOnelistData());

				mPullDownView.onRefreshComplete();//�����ʾˢ�´�����ɺ������ļ���ˢ�½�������
				mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				if(chargeDetailMap.size()<10){
					mPullDownView.setMore(false);
				}
				adapter.notifyDataSetChanged();	
			}
		}, 1500);


	}

	/**
	 * ���ظ��࣬��ԭ��������������������
	 */
	public void onLoadMore() {

		mHandler.postDelayed(new Runnable() {
			public void run() {
				//addLists(5);//ÿ�μ�������������

				currentPage++;
				chargeDetailMap.addAll(getGroupOnelistData());

				mPullDownView.onLoadMoreComplete();//�����ʾ���ظ��ദ����ɺ������ļ��ظ�����棨���ػ��������������ࣩ
				//if(list.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
				if(chargeDetailMap.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
					mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				else
					mPullDownView.setMore(false);
				adapter.notifyDataSetChanged();	

			}
		}, 1500);
	}
	/***
	 * ��̬����listview�ĸ߶�
	 * 
	 * @param listView
	 */
	public void setListViewHeightBasedOnChildren(ListView listView) {
		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null) {
			return;
		}
		int totalHeight = 0;
		for (int i = 0; i < listAdapter.getCount(); i++) {
			View listItem = listAdapter.getView(i, null, listView);
			listItem.measure(0, 0);
			totalHeight += listItem.getMeasuredHeight();
		}
		ViewGroup.LayoutParams params = listView.getLayoutParams();
		params.height = totalHeight
				+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
		listView.setLayoutParams(params);
	}
	
	private class mapSearchDialogIbClickListener implements
	View.OnClickListener {
		@Override
		public void onClick(View v) {
			LayoutInflater factory = LayoutInflater
					.from(ChargeDetailListCompanyActivity.this);
			final View dialogView = factory.inflate(R.layout.activity_history_search,
					null);
			dialogView.setBackgroundResource(android.R.color.white);
			queryBtn = (Button)dialogView.findViewById(R.id.set_threshold_submit);
			queryBtn.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							processProgress = ProgressDialog.show(ChargeDetailListCompanyActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
							new Thread(){
								public void run() {
									lineEdit = (EditText) dialogView.findViewById(R.id.search_line_edit);
									meterName = lineEdit.getText().toString();
									noticeDialog.cancel();
									chargeDetailMap = getGroupOnelistData();
									Message msgMessage = new Message();
									ChargeDetailListCompanyActivity.this.xHandler.sendMessage(msgMessage);
								}
							}.start();
						}
					});
			// ����Ի���
			AlertDialog alertDialog = new AlertDialog.Builder(ChargeDetailListCompanyActivity.this).create();
			alertDialog.setView(dialogView,0,0,0,0);
			noticeDialog = alertDialog;
			noticeDialog.show();
			
			ImageView closebtn = (ImageView)dialogView.findViewById(R.id.search_close);
			closebtn.setOnClickListener(new OnClickListener(){
				public void onClick(View arg0) {
					noticeDialog.cancel();
				}
			});
		}
	}
}
