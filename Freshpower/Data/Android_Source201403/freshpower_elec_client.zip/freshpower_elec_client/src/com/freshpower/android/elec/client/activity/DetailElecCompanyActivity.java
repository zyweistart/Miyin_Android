package com.freshpower.android.elec.client.activity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.common.LogFactory;
import com.freshpower.android.elec.client.domain.LineDetailInfo;
import com.freshpower.android.elec.client.netapi.ElectricityBillCompanyDataApi;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


@SuppressLint({ "SimpleDateFormat", "HandlerLeak" })
public class DetailElecCompanyActivity extends Activity {
	private LogFactory logger = LogFactory.getLogger(DetailElecCompanyActivity.class);
	
	private TextView lineName;
	private TextView elecTime;
	private TextView electricityTwo;
	private TextView electricityBillTwo;
	private TextView electricityThree;
	private TextView electricityBillThree;
	private TextView electricityFour;
	private TextView electricityBillFour;
	private TextView electricityFive;
	private TextView electricityBillFive;
	private TextView averagePrice;
	private Button searchBtn;
	private String meterId;
	private String meterName;
	Map<String,Object> lineDetailMap;
	private ProgressDialog processProgress;
	private ImageView backBtn;
	private String searchDate;//��������
	private String selType;//�������ͣ�Ĭ��Ϊ�죩
	private RelativeLayout allele;
	private RelativeLayout noResultlayout;
	private LinearLayout elecDetial;
	private SearchThread searchThread = new SearchThread();
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_line_detail_elec);
		ActivityUtil.addActivity(this);
		
		meterId = getIntent().getExtras().getString("meterId");
		meterName = getIntent().getExtras().getString("meterName");
		processProgress = ProgressDialog.show(DetailElecCompanyActivity.this, "", getResources().getString(R.string.msg_operate_processing_alert),true);
		findView();
		//Ĭ�ϲ�ѯ����
		searchDate = "";
		selType = getIntent().getStringExtra("selectType");
		searchThread = new SearchThread();
		searchThread.start();
		searchBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(DetailElecCompanyActivity.this,PowerHistoryActivity.class);
				startActivityForResult(intent, AppConstant.RequestResultCode.REQUEST_LINE);
			}
		});
		backBtn = (ImageView)findViewById(R.id.nav_left);
		backBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				DetailElecCompanyActivity.this.onBackPressed();
			}
		});
		noResultlayout = (RelativeLayout)findViewById(R.id.noResultlayout);
		allele = (RelativeLayout)findViewById(R.id.allele);
		elecDetial = (LinearLayout)findViewById(R.id.elecDetial);
	}
//	//��ȡ��ǰ��ǰһ������
//	private void getYesterDay(){
//		 Date date=new Date();//ȡʱ��
//		 Calendar calendar = new GregorianCalendar();
//		 calendar.setTime(date);
//		 calendar.add(calendar.DATE,-1);//��������ǰ��һ��.����������,������ǰ�ƶ�
//		 date=calendar.getTime(); //���ʱ���������������һ��Ľ�� 
//		 SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
//		 searchDate = formatter.format(date);
//	}
	
	
	class SearchThread extends Thread{
		@Override
		public void run() {
			try {
				lineDetailMap = ElectricityBillCompanyDataApi.getLineDetailInfoList(meterId,searchDate,selType);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				Message msgMessage = new Message();
				DetailElecCompanyActivity.this.handler.sendMessage(msgMessage);
				processProgress.dismiss();
			}
		}
	}
	
	private Handler handler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			List<LineDetailInfo> lineDetailList = (List<LineDetailInfo>) lineDetailMap.get("lineInfoList");
			if(lineDetailList.size() == 0){
				allele.setVisibility(8);
				elecDetial.setVisibility(8);
				noResultlayout.setVisibility(0);
				Toast.makeText(DetailElecCompanyActivity.this, "��ѯ������", Toast.LENGTH_SHORT).show();
				return;
			}else{
				allele.setVisibility(0);
				elecDetial.setVisibility(0);
				noResultlayout.setVisibility(8);
				LineDetailInfo lineDetailInfo = lineDetailList.get(0);
				lineName.setText(meterName);
				elecTime.setText(lineDetailInfo.getDate());
				electricityTwo.setText(lineDetailInfo.getTotalPower());
				electricityBillTwo.setText(lineDetailInfo.getTotalFee());
				electricityThree.setText(lineDetailInfo.getTipPower());
				electricityBillThree.setText(lineDetailInfo.getTipFee());
				electricityFour.setText(lineDetailInfo.getPeakPower());
				electricityBillFour.setText(lineDetailInfo.getPeakFee());
				electricityFive.setText(lineDetailInfo.getValleyPower());
				electricityBillFive.setText(lineDetailInfo.getValleyFee());
				averagePrice.setText(lineDetailInfo.getAvgPrice());
			}
		};
	};
	
	private void findView(){
		lineName = (TextView)findViewById(R.id.line_name);
		elecTime = (TextView)findViewById(R.id.elec_time);
		electricityTwo = (TextView)findViewById(R.id.electricityTwo);
		electricityBillTwo = (TextView)findViewById(R.id.electricityBillTwo);
		electricityThree = (TextView)findViewById(R.id.electricityThree);
		electricityBillThree = (TextView)findViewById(R.id.electricityBillThree);
		electricityFour = (TextView)findViewById(R.id.electricityFour);
		electricityBillFour = (TextView)findViewById(R.id.electricityBillFour);
		electricityFive = (TextView)findViewById(R.id.electricityFive);
		electricityBillFive = (TextView)findViewById(R.id.electricityBillFive);
		averagePrice = (TextView)findViewById(R.id.averagePrice);
		searchBtn = (Button)findViewById(R.id.linesearch_button);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if(resultCode == AppConstant.RequestResultCode.RESULT_LINE){
			if(data.getStringExtra("timeVal")!=null){
				searchDate = data.getStringExtra("timeVal");
				selType = data.getStringExtra("selType");
				processProgress = ProgressDialog.show(DetailElecCompanyActivity.this, "", getResources().getString(R.string.msg_operate_processing_alert),true);
				searchThread = new SearchThread();
				searchThread.start();
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
}
