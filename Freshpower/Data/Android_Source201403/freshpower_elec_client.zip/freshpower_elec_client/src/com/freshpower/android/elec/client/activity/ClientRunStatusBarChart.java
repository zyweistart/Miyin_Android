package com.freshpower.android.elec.client.activity;

import java.util.List;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.BarChart.Type;
import org.achartengine.model.CategorySeries;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.renderer.SimpleSeriesRenderer;
import org.achartengine.renderer.XYMultipleSeriesRenderer;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint.Align;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;

import com.freshpower.android.elec.client.common.MathUtil;

public class ClientRunStatusBarChart extends AbstractChart {
	
	private double[] chargeData = new double[8];// ����
	private List<double[][]> currentList;// ����
	private GraphicalView mChartView;
	
	public double[] getChargeData() {
		return chargeData;
	}

	public void setChargeData(double[] chargeData) {
		this.chargeData = chargeData;
	}

	public List<double[][]> getCurrentList() {
		return currentList;
	}

	public void setCurrentList(List<double[][]> currentList) {
		this.currentList = currentList;
	}

	public String getName() {
		return "";
	}

	public String getDesc() {
		return "";
	}

	/**
	 * ����״̬����
	 */
	public Intent execute(Context context) {
		return ChartFactory.getBarChartIntent(context, getDataSet(),
				getRenderer(), Type.STACKED, "e�繤");
	}
	
	public void exe(Context context, LinearLayout layout) {
		mChartView = ChartFactory.getBarChartView(context, getDataSet(), getRenderer(), Type.DEFAULT);
		layout.removeAllViews();
		layout.addView(mChartView, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)); 
		mChartView.invalidate();
	}

	/**
	 * ��������
	 * 
	 * @return
	 */
	public XYMultipleSeriesDataset getDataSet() {
		XYMultipleSeriesDataset barDataset = new XYMultipleSeriesDataset();
		CategorySeries barSeries;
		barSeries = new CategorySeries("B1");
		barSeries.add(chargeData[0]);
		barDataset.addSeries(barSeries.toXYSeries());
		barSeries = new CategorySeries("B1-1");
		barSeries.add(chargeData[1]);
		barDataset.addSeries(barSeries.toXYSeries());
		barSeries = new CategorySeries("B1-2");
		barSeries.add(chargeData[2]);
		barDataset.addSeries(barSeries.toXYSeries());
		barSeries = new CategorySeries("B1-3");
		barSeries.add(chargeData[3]);
		barDataset.addSeries(barSeries.toXYSeries());
		barSeries = new CategorySeries("B2");
		barSeries.add(chargeData[4]);
		barDataset.addSeries(barSeries.toXYSeries());
		barSeries = new CategorySeries("B2-1");
		barSeries.add(chargeData[5]);
		barDataset.addSeries(barSeries.toXYSeries());
		barSeries = new CategorySeries("B2-2");
		barSeries.add(chargeData[6]);
		barDataset.addSeries(barSeries.toXYSeries());
		barSeries = new CategorySeries("B2-3");
		barSeries.add(chargeData[7]);
		barDataset.addSeries(barSeries.toXYSeries());
		return barDataset;
	}
	
	/**
	 * ������Ⱦ��
	 * 
	 * @return
	 */
	public XYMultipleSeriesRenderer getRenderer() {
		XYMultipleSeriesRenderer renderer = new XYMultipleSeriesRenderer();
		renderer.setYTitle("���ɣ���λ��kW��");
		renderer.setAxisTitleTextSize(16); 
		// ����X�����С���ֺ�������֣��������ǵ������Ǵ�1��ʼ����������Ϊ0.5�Ϳ�����1֮ǰ�ó�һ����
		renderer.setXAxisMin(0.5);
		renderer.setXAxisMax(1.5);
		// ����Y�����С���ֺ��������
		renderer.setYAxisMin(0);
		renderer.setYAxisMax(MathUtil.max(chargeData)*1.3);
		// ������Ⱦ����ʾ���Ű�ť
		renderer.setZoomButtonsVisible(false);
		// ������Ⱦ�������Ŵ���С
		renderer.setZoomEnabled(true);
		// �������
		renderer.setAntialiasing(true);
		// ���ñ�����ɫ
		renderer.setApplyBackgroundColor(true);
		renderer.setBackgroundColor(Color.parseColor("#F5F6F4"));
		renderer.setMarginsColor(Color.parseColor("#F5F6F4"));
		renderer.setXLabelsColor(Color.BLACK);
		renderer.setYLabelsColor(0, Color.BLACK);
		renderer.setAxesColor(Color.BLACK);
		renderer.setLabelsColor(Color.BLACK);
		renderer.setBarWidth(35F);
		// ����ÿ�����ӵ���ɫ
		SimpleSeriesRenderer sr = new SimpleSeriesRenderer();
		sr.setChartValuesTextAlign(Align.RIGHT);
		sr.setColor(Color.parseColor(getColor(currentList.get(0)[0],1443)));
		renderer.addSeriesRenderer(sr);
		
		sr = new SimpleSeriesRenderer();
		sr.setChartValuesTextAlign(Align.RIGHT);
		sr.setColor(Color.parseColor(getColor(currentList.get(0)[1],200)));
	    renderer.addSeriesRenderer(sr);
	    
	    sr = new SimpleSeriesRenderer();
	    sr.setChartValuesTextAlign(Align.RIGHT);
	    sr.setColor(Color.parseColor(getColor(currentList.get(0)[2],500)));
	    renderer.addSeriesRenderer(sr);
	    
	    sr = new SimpleSeriesRenderer();
	    sr.setChartValuesTextAlign(Align.RIGHT);
	    sr.setColor(Color.parseColor(getColor(currentList.get(0)[3],800)));
	    renderer.addSeriesRenderer(sr);
	    
	    sr = new SimpleSeriesRenderer();
	    sr.setChartValuesTextAlign(Align.RIGHT);
	    sr.setColor(Color.parseColor(getColor(currentList.get(1)[0],1443)));
	    renderer.addSeriesRenderer(sr);
	    
	    sr = new SimpleSeriesRenderer();
	    sr.setChartValuesTextAlign(Align.RIGHT);
	    sr.setColor(Color.parseColor(getColor(currentList.get(1)[1],200)));
	    renderer.addSeriesRenderer(sr);
	    
	    sr = new SimpleSeriesRenderer();
	    sr.setChartValuesTextAlign(Align.RIGHT);
	    sr.setColor(Color.parseColor(getColor(currentList.get(1)[2],500)));
	    renderer.addSeriesRenderer(sr);
	    
	    sr = new SimpleSeriesRenderer();
	    sr.setChartValuesTextAlign(Align.RIGHT);
	    sr.setColor(Color.parseColor(getColor(currentList.get(1)[3],800)));
	    renderer.addSeriesRenderer(sr);
		
		
		// ����ÿ���������Ƿ���ʾ��ֵ
	    renderer.setDisplayChartValues(true);
	    
//		renderer.getSeriesRendererAt(0).setDisplayChartValues(true);
		// X��Ľ���������
		renderer.setXLabels(8);
		// Y��Ľ���������
		renderer.setYLabels(5);
		// �̶�����X����������������
		renderer.setXLabelsAlign(Align.CENTER);
		// Y����Y���������������
		renderer.setYLabelsAlign(Align.CENTER);
		// �����������϶�,�����������϶�.
		renderer.setPanEnabled(false, false);
		// ���Ӽ����
		renderer.setBarSpacing(5.5f);
		
		// X�����ֱ�ǩ����
		renderer.setXLabels(0);
		
		return renderer;
	}
	
	/**
	 * ��ȡ����״̬��ɫ
	 * @param line��·
	 * @param max���ֵ
	 * @return
	 */
	private String getColor(double[] line, double max) {
		String color = "#9E9E9E";
			for(int j=0;j<3;j++) {
				if(line[j]>=max*0.9) {
					color = "#FF0000";
					break;
				} else if(line[j]>max*0.5 && line[j]<max*0.9) {
					color = "#FFCC00";
					break;
				} else if(line[j]<=max*0.5) {
					color = "#006600";
					break;
				}
			}
		return color;
	}

}
