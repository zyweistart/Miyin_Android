package com.freshpower.android.elec.client.common;

import java.lang.reflect.Field;

import android.content.DialogInterface;

public class DialogUtil {

	public static void closeCurrent(DialogInterface dialog, boolean isClose) {
		Field field = null;
		try {
			field = dialog.getClass().getSuperclass()
					.getDeclaredField("mShowing");
			field.setAccessible(true);
			field.set(dialog, isClose);
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
