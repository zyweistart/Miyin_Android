package com.freshpower.android.elec.client.activity;

import java.util.ArrayList;
import java.util.List;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint.Align;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;

import com.freshpower.android.elec.client.common.MathUtil;

public class ElectricityCurveChart extends AbstractChart {

	private double[] a = new double[12];
	private double[] b = new double[12];
	private double[] c = new double[12];
	private double[] coefficientList = new double[12];
	private int time;
	public double[] getCoefficientList() {
		return coefficientList;
	}

	public void setCoefficientList(double[] coefficientList) {
		this.coefficientList = coefficientList;
	}

	private GraphicalView mChartView;

	public String getName() {
		return "�����������ͼ";
	}

	public String getDesc() {
		return "չʾ���3�����ڻ�12���㣬ABC����������߼����ֵ�ߣ�y��b*Imax��";
	}

	/**
	 * ��������ͼ
	 */
	public Intent execute(Context context) {
		Intent intent = ChartFactory.getLineChartIntent(context, getDataSet(),
				getRenderer(), "e�繤");
		return intent;
	}
	
	public void exe(Context context, LinearLayout layout) {
		mChartView = ChartFactory.getLineChartView(context, getDataSet(), getRenderer());
		layout.removeAllViews();
		layout.addView(mChartView, new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT)); 
		mChartView.invalidate();
	}

	/**
	 * ��������
	 * 
	 * @return
	 */
	public XYMultipleSeriesDataset getDataSet() {
		String[] titles = new String[] { "A��", "B��", "C��", "���ֵ��" };
		List<double[]> x = new ArrayList<double[]>();
		List<double[]> values = new ArrayList<double[]>();
		if(time <= 12) {
			values.add(MathUtil.change(a, time));
			values.add(MathUtil.change(b, time));
			values.add(MathUtil.change(c, time));
			values.add(MathUtil.change(coefficientList, time));
			for (int i = 0; i < titles.length; i++) {
				switch (time) {
				case 1:
					x.add(new double[] { 1 });
					break;
				case 2:
					x.add(new double[] { 1, 2 });
					break;
				case 3:
					x.add(new double[] { 1, 2, 3 });
					break;
				case 4:
					x.add(new double[] { 1, 2, 3, 4 });
					break;
				case 5:
					x.add(new double[] { 1, 2, 3, 4, 5 });
					break;
				case 6:
					x.add(new double[] { 1, 2, 3, 4, 5, 6 });
					break;
				case 7:
					x.add(new double[] { 1, 2, 3, 4, 5, 6, 7 });
					break;
				case 8:
					x.add(new double[] { 1, 2, 3, 4, 5, 6, 7, 8 });
					break;
				case 9:
					x.add(new double[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 });
					break;
				case 10:
					x.add(new double[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 });
					break;
				case 11:
					x.add(new double[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 });
					break;
				case 12:
					x.add(new double[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 });
					break;
				default:
					break;
				}
			}
		} else {
			values.add(a);
			values.add(b);
			values.add(c);
			values.add(coefficientList);
			for (int i = 0; i < titles.length; i++) {
				x.add(new double[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 });
			}
		}
//		for(int i=0;i<coefficientList.length;i++) {
//			Log.d("elec", "coefficientList="+coefficientList[i]);
//		}
		XYMultipleSeriesDataset dataset = buildDataset(titles, x, values);
		XYSeries series = dataset.getSeriesAt(0);
		series.addAnnotation("", 6, 30);
		return dataset;
	}

	/**
	 * ������Ⱦ��
	 * 
	 * @return
	 */
	public XYMultipleSeriesRenderer getRenderer() {
		int[] colors = new int[] { Color.parseColor("#FBC900"), Color.GREEN, Color.RED, Color.BLUE };
		PointStyle[] styles = new PointStyle[] { PointStyle.CIRCLE,
				PointStyle.DIAMOND, PointStyle.TRIANGLE, PointStyle.POINT };
		XYMultipleSeriesRenderer renderer = buildRenderer(colors, styles);
		int length = renderer.getSeriesRendererCount();
		for (int i = 0; i < length; i++) {
			((XYSeriesRenderer) renderer.getSeriesRendererAt(i))
					.setFillPoints(true);
		}
		setChartSettings(renderer, "", "ʱ�䣨��λ���룩", "�����������λ��A��", 0.5,
				12.5, 0, MathUtil.max(new double[]{ MathUtil.max(a), MathUtil.max(b), MathUtil.max(c), MathUtil.max(coefficientList) })*1.3, Color.BLACK, Color.BLACK);
		renderer.setXLabels(12);
		renderer.setYLabels(10);
		renderer.setAxisTitleTextSize(16); 
		renderer.setShowGrid(true);
		renderer.setXLabelsAlign(Align.RIGHT);
		renderer.setYLabelsAlign(Align.CENTER);
		// ������Ⱦ�������Ŵ���С
		renderer.setZoomButtonsVisible(false);
		renderer.setPanLimits(new double[] { -10, 20, -10, 40 });
		renderer.setZoomLimits(new double[] { -10, 20, -10, 40 });
		// ���ñ�����ɫ
		renderer.setApplyBackgroundColor(true);
		renderer.setBackgroundColor(Color.parseColor("#F5F6F4"));
		renderer.setMarginsColor(Color.parseColor("#F5F6F4"));
		renderer.setXLabelsColor(Color.BLACK);
		renderer.setYLabelsColor(0, Color.BLACK);
		// �����Ƿ��ǿɻ���������
		renderer.setPanEnabled(false, false); 
		// X�����ֱ�ǩ����
		renderer.setXLabels(0);
		if(time <= 12) {
			for(int i=1;i<=12;i++) {
				renderer.addTextLabel(i, String.valueOf(i*5));
			}
		} else {
			for(int i=1;i<=12;i++) {
				renderer.addTextLabel(i, String.valueOf((i*5)+(time-12)*5));
			}
		}
		
		return renderer;
	}

	public double[] getA() {
		return a;
	}

	public void setA(double[] a) {
		this.a = a;
	}

	public double[] getB() {
		return b;
	}

	public void setB(double[] b) {
		this.b = b;
	}

	public double[] getC() {
		return c;
	}

	public void setC(double[] c) {
		this.c = c;
	}
	
	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}
}
