package com.freshpower.android.elec.client.netapi;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.client.common.AppCache;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.conf.AppConfig;
import com.freshpower.android.elec.client.domain.ClientWarnComapny;
import com.freshpower.android.elec.client.domain.LoginInfo;

public class ClientWarnComapnyDataApi extends JsonDataApi {
	private static final String CLIENT_WARN_LIST = "AppAlertInfo.aspx";
	/**
	 * ��������
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getWarnInfoList(int pageSize,int pageNum,String type,String meterName) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("CP_ID", loginInfo.getCpId());
		api.addParam("Type", type);
		api.addParam("PageIndex", String.valueOf(pageNum).trim());
		api.addParam("PageSize", String.valueOf(pageSize).trim());
//		Log.d("BID", loginInfo.getCpId());
//		Log.d("BID", type);
//		Log.d("BID", String.valueOf(pageNum).trim());
//		Log.d("BID", String.valueOf(pageSize).trim());
//		Log.d("BID", AppConfig.getInstance().getFpsWebSite()+File.separator+CLIENT_WARN_LIST);
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getFpsWebSite()+File.separator+CLIENT_WARN_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("AlertList");
		ClientWarnComapny clientWarnComapny = null;
		List<ClientWarnComapny> clientWarnComapnyList = new ArrayList<ClientWarnComapny>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				clientWarnComapny=new ClientWarnComapny();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				clientWarnComapny.setMeterName(table1.getString("METER_NAME")==null?"":table1.getString("METER_NAME"));//--��·����
				clientWarnComapny.setContent(table1.getString("CONTENT")==null?"":table1.getString("CONTENT"));//��������
				clientWarnComapny.setAlertLevel(table1.getString("ALERT_LEVEL")==null?"":table1.getString("ALERT_LEVEL"));//��������
				clientWarnComapny.setAlertDate(table1.getString("ALERT_DATE")==null?"":table1.getString("ALERT_DATE"));//--����ʱ��
				clientWarnComapny.setAlertReply(table1.getString("ALERT_REPLY")==null?"":table1.getString("ALERT_REPLY"));//�������
				clientWarnComapnyList.add(clientWarnComapny);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalCount", rows.getString("TotalCount"));
		map.put("result", rows.getString("result"));
		map.put("clientWarnComapnyList", clientWarnComapnyList);
		return map;
	}
	
}
