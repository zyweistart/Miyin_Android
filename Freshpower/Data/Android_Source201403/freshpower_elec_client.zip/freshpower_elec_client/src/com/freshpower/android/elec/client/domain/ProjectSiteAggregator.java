package com.freshpower.android.elec.client.domain;
/**
 * ���̽�վ�㼯����
 * @author Administrator
 *
 */
public class ProjectSiteAggregator {
	private String serialNo;// ���к�
	private String cpName;// ��ҵ����
	private String convergeKey;// Ψһ��ʶ
	private String subName;// ��緿���
	private String exploTransno;// ��ѹ�����
	private String operationType;// ��ѹ������
	private String msiteId;// վ��ID
	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	public String getCpName() {
		return cpName;
	}
	public void setCpName(String cpName) {
		this.cpName = cpName;
	}
	public String getConvergeKey() {
		return convergeKey;
	}
	public void setConvergeKey(String convergeKey) {
		this.convergeKey = convergeKey;
	}
	public String getSubName() {
		return subName;
	}
	public void setSubName(String subName) {
		this.subName = subName;
	}
	public String getExploTransno() {
		return exploTransno;
	}
	public void setExploTransno(String exploTransno) {
		this.exploTransno = exploTransno;
	}
	public String getOperationType() {
		return operationType;
	}
	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}
	public String getMsiteId() {
		return msiteId;
	}
	public void setMsiteId(String msiteId) {
		this.msiteId = msiteId;
	}
}
