package com.freshpower.android.elec.client.netapi;


import java.net.URLDecoder;

import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

/**
 * 
* @author <a href="mailto:yangz@freshpower.cn">yangz</a>  
* @version 1.0
 */
public class JsonDataApi extends WebDataApi{
	protected static final String GET_DATA_TIME_TAG = "getJsonDataTime";
	private static final String LOG_ERROR_TAG = "JSONError";
	
	public JSONObject postForJsonResult(String url) throws Exception{
		String resposeStr = super.postRequest(url);
		return JSON.parseObject(resposeStr);
	}
	
	public JSONObject postForJsonResult(String url,String charset) throws Exception{
		String resposeStr = super.postRequest(url);
		return JSON.parseObject(URLDecoder.decode(resposeStr,charset));
	}
	
	public JSONObject getForJsonResult(String url) throws Exception{
		String resposeStr = super.getRequest(url);
		return JSON.parseObject(resposeStr);
	}
	
	public JSONObject getForJsonResult(String url,String charset) throws Exception{
		String resposeStr = super.getRequest(url);
		return JSON.parseObject(URLDecoder.decode(resposeStr,charset));
	}
	
	public JSONObject postFileForJsonResult(String url) throws Exception{
		String resposeStr = super.postFileRequest(url);
		return JSON.parseObject(resposeStr);
	}
	
	public static JsonDataApi getInstance(){
		return new JsonDataApi();
	}
	
}
