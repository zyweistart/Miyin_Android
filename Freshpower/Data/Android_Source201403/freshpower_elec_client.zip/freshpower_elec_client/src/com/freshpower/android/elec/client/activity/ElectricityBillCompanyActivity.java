package com.freshpower.android.elec.client.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.domain.ElectricityBillCompany;
import com.freshpower.android.elec.client.netapi.ElectricityBillCompanyDataApi;
import com.freshpower.android.elec.client.widget.PullDownListView;


import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class ElectricityBillCompanyActivity extends FrameActivity implements PullDownListView.OnRefreshListioner{
	private PullDownListView mPullDownView;
	private ListView mListView;
	private Resources res;
	private ImageButton homeBtn;
	private List<ElectricityBillCompany> billCompanyList;
	private Handler mHandler = new Handler();
	private int pageSize = 10;//ÿҳ��ʾ
	private int currentPage =1;//��ǰҳ
	private int totalCnt=0;//�ܼ�¼��
	private int rs=999;//��ѯ���
	private SimpleAdapter adapter;
	private RelativeLayout progressRlt = null;
	List<Map<String, Object>> electricityBillCompanyMap;
	private ProgressDialog processProgress;
	String selectType="";
	private Handler handler = new Handler();
	private EditText eTextUname;
	private String dayMonth;
	private String meterName;
	private Dialog noticeDialog;


	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_electricitybill_company);
		Intent it=getIntent();
		dayMonth =it.getStringExtra("dayMonth");
		meterName=it.getStringExtra("meterName");
		
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				ElectricityBillCompanyActivity.this.onBackPressed();
			}
		});
		Button billbt=(Button)findViewById(R.id.billsearch_button);
		billbt.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				LayoutInflater factory = LayoutInflater.from(ElectricityBillCompanyActivity.this);
				View DialogView = factory.inflate(R.layout.dialog_billcomapny, null);
				AlertDialog builder = new AlertDialog.Builder(ElectricityBillCompanyActivity.this).create();
				builder.setView(DialogView,0,0,0,0);	
				eTextUname = (EditText) DialogView
						.findViewById(R.id.meterName);

				Button billSearchSubBt = (Button)DialogView.findViewById(R.id.billSearchSubBt);
				billSearchSubBt.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						Intent intent = new Intent(ElectricityBillCompanyActivity.this,ElectricityBillCompanyActivity.class);
						intent.putExtra("meterName", eTextUname.getText().toString());
						intent.putExtra("dayMonth",  dayMonth);
						startActivity(intent);
						finish();
					}
				});
				noticeDialog = builder;
				noticeDialog.setCanceledOnTouchOutside(false);
				noticeDialog.show();
				Button billSearchCancelBt = (Button)DialogView.findViewById(R.id.billSearchCancelBt);
				billSearchCancelBt.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						noticeDialog.dismiss();
					}
				});
			}
		});
		processProgress = ProgressDialog.show(ElectricityBillCompanyActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(){
			public void run() {
				electricityBillCompanyMap = getGroupOnelistData(billCompanyList);
				Message msgMessage = new Message();
				ElectricityBillCompanyActivity.this.xHandler.sendMessage(msgMessage);
			}
		}.start();

		mPullDownView = (PullDownListView) findViewById(R.id.sreach_list);
		mPullDownView.setRefreshListioner(this);
		mListView = mPullDownView.mListView;
		mListView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent,
					View view, int position, long id) {
				Intent it = new Intent(ElectricityBillCompanyActivity.this,DetailElecCompanyActivity.class);
				Map map=(Map) electricityBillCompanyMap.get(position-1);
				it.putExtra("meterId",  String.valueOf(map.get("meterId")));
				it.putExtra("selectType", selectType);
				it.putExtra("meterName", map.get("warnOne").toString());
				startActivity(it);
			}	
		});

	}
	private Handler xHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			adapter = new SimpleAdapter(ElectricityBillCompanyActivity.this,electricityBillCompanyMap, 
					R.layout.listitem_electricitybillcompany_style, 
					new String[] { AppConstant.ListItemWarnName.WARN_ONE, 
					AppConstant.ListItemWarnName.WARN_TWO,
					AppConstant.ListItemWarnName.WARN_THREE,
					AppConstant.ListItemWarnName.WARN_FOUR,
					AppConstant.ListItemWarnName.WARN_FIVE,
					AppConstant.ListItemWarnName.WARN_SIX}, 
					new int[] { R.id.billCompanyOne,
					R.id.billCompanyTwo,
					R.id.billCompanyThree,
					R.id.billCompanyFour,
					R.id.TextViewEle,
					R.id.TextViewBill});
			if(electricityBillCompanyMap.size()==0){
				Toast.makeText(ElectricityBillCompanyActivity.this, R.string.noSearchResultMsg,Toast.LENGTH_SHORT).show();
				rs=AppConstant.Result.NO_COUNT;
			}
			mListView.setAdapter(adapter);

			setShow();
			//	    		progressRlt.setVisibility(View.GONE);
			mPullDownView.setVisibility(View.VISIBLE);
			processProgress.dismiss();
		};
	};
	private void setShow() {
		if(rs==AppConstant.Result.NO_COUNT){
			RelativeLayout noResultlayout = (RelativeLayout) findViewById(R.id.noResultlayout);
			noResultlayout.setVisibility(View.VISIBLE);
			mPullDownView.setMore(false);
		}else{
			mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
		}
		if(totalCnt<=pageSize){
			mPullDownView.setMore(false);
		}
	}    
	@Override
	public void onRefresh() {
		// TODO Auto-generated method stub
		mHandler.postDelayed(new Runnable() {

			public void run() {
				electricityBillCompanyMap.clear();
				currentPage =1;
				electricityBillCompanyMap.addAll(getGroupOnelistData(billCompanyList));

				mPullDownView.onRefreshComplete();//�����ʾˢ�´�����ɺ������ļ���ˢ�½�������
				mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				if(totalCnt<=pageSize){
					mPullDownView.setMore(false);
				}
				adapter.notifyDataSetChanged();	
			}
		}, 1500);

	}
	@Override
	public void onLoadMore() {
		mHandler.postDelayed(new Runnable() {
			public void run() {

				currentPage++;
				electricityBillCompanyMap.addAll(getGroupOnelistData(billCompanyList));

				mPullDownView.onLoadMoreComplete();//�����ʾ���ظ��ദ����ɺ������ļ��ظ�����棨���ػ��������������ࣩ
				//if(list.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
				if(electricityBillCompanyMap.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
					mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				else
					mPullDownView.setMore(false);
				adapter.notifyDataSetChanged();	

			}
		}, 1500);

	}
	private List<Map<String, Object>> getGroupOnelistData(List<ElectricityBillCompany> stationDetailList){
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		if(dayMonth.equals("����")){
			selectType="Day";
		}else{
			selectType="Month";
		}
		
		try {
			Map electricityBillCompanyMap=ElectricityBillCompanyDataApi.getElectricityBillCompanyList(pageSize, currentPage,selectType,meterName);
			if(!"0".equals(electricityBillCompanyMap.get("result"))){
				stationDetailList=(List<ElectricityBillCompany>) electricityBillCompanyMap.get("electricityBillList");
				for (ElectricityBillCompany electricityBillCompany:stationDetailList)
				{
					Map<String, Object> listItem = new HashMap<String, Object>();
					listItem.put(AppConstant.ListItemWarnName.WARN_ONE, electricityBillCompany.getMeterName());
					listItem.put(AppConstant.ListItemWarnName.WARN_TWO, electricityBillCompany.getTotalPower());
					listItem.put(AppConstant.ListItemWarnName.WARN_THREE, electricityBillCompany.getTotalFee());
					listItem.put(AppConstant.ListItemWarnName.WARN_FOUR, electricityBillCompany.getAvgPrice());
					listItem.put(AppConstant.ListItemWarnName.WARN_FIVE, "�����ܵ���");
					listItem.put(AppConstant.ListItemWarnName.WARN_SIX, "���յ��");
					if(selectType.equals("Month")){
						listItem.put(AppConstant.ListItemWarnName.WARN_FIVE, "�����ܵ���");
						listItem.put(AppConstant.ListItemWarnName.WARN_SIX, "���µ��");
					}
					
					listItem.put("meterId", electricityBillCompany.getMeterId());
					listItems.add(listItem);
				}
				totalCnt = Integer.parseInt(String.valueOf(electricityBillCompanyMap.get("totalCount")));
				return listItems;
			}else{
				return listItems;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listItems;
	}
}
