package com.freshpower.android.elec.client.common;

import java.math.BigDecimal;
import java.nio.charset.CharacterCodingException;
import java.util.ArrayList;
import java.util.List;

import android.util.Log;

public class EnergeDataParse {
	
	final static int REDUCE_NUMBER = 51;
	final static String MARK_BIT_STRING="68 91";
	final static String MARK_BIT_SERIESNUM_STRING="68 91";
	public static void main(String[] args) throws CharacterCodingException {
//		int index=0;
//		String byteStr="";
//		
//		index =0;//��ѹ
//		byteStr = "FE FE FE FE 68 25 05 12 16 02 02 68 91 0A 33 32 34 35 C5 55 7B 55 B3 56 82 16";
//		System.out.println(processByteToBrizStr(index,byteStr));

//		index =1;//����
//		byteStr = "FE FE FE FE 68 25 05 12 16 02 02 68 91 0D 33 32 35 35 B6 45 33 67 45 33 53 46 33 6C 16";
//		System.out.println(processByteToBrizStr(index,byteStr));
		
//		index =2;//����
//		byteStr = "FE FE FE FE 68 25 05 12 16 02 02 68 91 10 33 32 36 35 C9 34 33 B5 34 33 C9 34 33 C7 34 33 41 16";
//		System.out.println(processByteToBrizStr(index,byteStr));
//	
//		index=3;//��������
//		byteStr = "FE FE FE FE 68 01 00 00 00 00 00 68 91 0C 33 32 33 33 96 34 33 33 65 96 34 33 65 16";
//		System.out.println(processByteToBrizStr(index,byteStr));
//		
//		index=4;//����Ƶ��
//		byteStr = "FE FE FE FE 68 01 00 00 00 00 00 68 91 06 33 32 33 33 96 34 65 16";
//		System.out.println(processByteToBrizStr(index,byteStr));
//		
//		index=5;//����й��ܵ���
//		byteStr = "FE FE FE FE 68 01 00 00 00 00 00 68 91 08 33 32 33 33 96 34 33 33 65 16";
//		System.out.println(processByteToBrizStr(index,byteStr));
//		
//		
//		index=6;//�����޹��ܵ���
//		byteStr = "FE FE FE FE 68 01 00 00 00 00 00 68 91 06 33 32 33 33 96 65 16";
//		System.out.println(processByteToBrizStr(index,byteStr));
//		
//		
//		index=7;//״̬��
//		byteStr = "FE FE FE FE 68 03 00 00 00 00 00 68 91 12 32 38 33 37 33 33 33 33 3B 33 33 33 B3 33 B3 33 33 33 1C 16";
//		System.out.println(processByteToBrizStr(index,byteStr));
		
		System.out.println(reverseOrderByByte(grabSeriesNumString(fillZeroOneChar("FE FE FE FE 68 01 02 03 04 05 06 68 91 0A 34 37 33 37 34 33 33 33 33 33 74 16"))));
		
	}
	
	
	/**
	 * �����������ץȡ
	 * @param str ��������
	 * @return ��Ϊ����Ϊ�Ϸ�����
	 */
	public static String grabEnergeDataString(String str){
		String strTemp="";
		try {
			int markBitIndex = str.indexOf(MARK_BIT_STRING);
			int bizDataLen = Integer.parseInt(str.substring(markBitIndex+6,markBitIndex+8), 16);
			strTemp = str.substring(markBitIndex-33, markBitIndex+9+bizDataLen*2+(bizDataLen-1)+6);
		} catch (Exception e) {
		}
		return strTemp;
	}
	
	/**
	 * ץȡ���к�
	 * @param str
	 * @return
	 */
	public static String grabSeriesNumString(String str){
		String strTemp="";
		try {
			int markBitIndex = str.indexOf(MARK_BIT_SERIESNUM_STRING);
			strTemp = str.substring(markBitIndex-18, markBitIndex-1);
			strTemp = strTemp.replaceAll(" ", "");
		} catch (Exception e) {
		}
		return strTemp;
	}
	
	public static String fillZeroOneChar(String byteStr){
		if(byteStr==null || "".equals(byteStr))return "";
		byteStr = byteStr.trim();
		if(byteStr.indexOf(" ")==-1)return byteStr;
		StringBuffer sb = new StringBuffer();
		String[] byteStrArr = byteStr.split(" ");
		for (int i = 0; i < byteStrArr.length; i++) {
			sb.append(ByteTransHelper.transStandardChar(byteStrArr[i], 2)).append(" ");
		}
		return sb.toString();
	}
	 
	
	public static String processByteToBrizStr(int index,String byteStr){
		StringBuffer strSb=new StringBuffer();
		String responseDataStr;
		BigDecimal aValue;
		BigDecimal bValue;
		BigDecimal cValue;
		BigDecimal rValue;
		
		switch (index) {
		case 0://��ѹ
			responseDataStr = byteStr.substring(byteStr.indexOf(MARK_BIT_STRING)+21,byteStr.length()-5).replaceAll(" ", "");
			responseDataStr = minusByteStr33Reverse(responseDataStr);
			aValue= new BigDecimal(responseDataStr.substring(8,12)).multiply(BigDecimal.valueOf(0.1D));
			bValue = new BigDecimal(responseDataStr.substring(4,8)).multiply(BigDecimal.valueOf(0.1D));
			cValue = new BigDecimal(responseDataStr.substring(0,4)).multiply(BigDecimal.valueOf(0.1D));
			strSb.append("A���ѹΪ")
			.append(aValue)
			.append("v\r\nB���ѹΪ")
			.append(bValue)
			.append("v\r\nC���ѹ:")
			.append(cValue)
			.append("v");
			break;
		case 1://����
			responseDataStr = byteStr.substring(byteStr.indexOf(MARK_BIT_STRING)+21,byteStr.length()-5).replaceAll(" ", "");
			strSb.append("A�����Ϊ")
			.append(parseEnergeSignData(responseDataStr.substring(0,6),"0.001"))
			.append("A\r\nB�����Ϊ"+parseEnergeSignData(responseDataStr.substring(6,12),"0.001"))
			.append("A\r\nC�����:"+parseEnergeSignData(responseDataStr.substring(12,18),"0.001")).append("A");
			break;
		case 2://����
			responseDataStr = byteStr.substring(byteStr.indexOf(MARK_BIT_STRING)+21,byteStr.length()-5).replaceAll(" ", "");
			strSb.append("�ܹ���Ϊ")
			.append(parseEnergeSignData(responseDataStr.substring(0,6),"0.0001"))
			.append("kW\r\nA�๦��Ϊ")
			.append(parseEnergeSignData(responseDataStr.substring(6,12),"0.0001"))
			.append("kW\r\nB�๦��Ϊ")
			.append(parseEnergeSignData(responseDataStr.substring(12,18),"0.0001"))
			.append("kW\r\nC�๦��:")
			.append(parseEnergeSignData(responseDataStr.substring(18,24),"0.0001"))
			.append("kW");
			break;
		case 3://��������
			responseDataStr = byteStr.substring(byteStr.indexOf(MARK_BIT_STRING)+21,byteStr.length()-5).replaceAll(" ", "");
			strSb.append("�ܹ�������Ϊ")
			.append(parseEnergeSignData(responseDataStr.substring(0,4),"0.001"))
			.append("\r\nA�๦������Ϊ")
			.append(parseEnergeSignData(responseDataStr.substring(4,8),"0.001"))
			.append("\r\nB�๦������Ϊ")
			.append(parseEnergeSignData(responseDataStr.substring(8,12),"0.001"))
			.append("\r\nC�๦������Ϊ:")
			.append(parseEnergeSignData(responseDataStr.substring(12,16),"0.001"));
			break;
		case 4://����Ƶ��
			responseDataStr = byteStr.substring(byteStr.indexOf(MARK_BIT_STRING)+21,byteStr.length()-5).replaceAll(" ", "");
			responseDataStr = minusByteStr33Reverse(responseDataStr);
			rValue = new BigDecimal(responseDataStr.substring(0,responseDataStr.length())).multiply(BigDecimal.valueOf(0.01D));
			strSb.append("����Ƶ��Ϊ:").append(rValue).append("Hz");
			break;	
		case 5://����й��ܵ���
			responseDataStr = byteStr.substring(byteStr.indexOf(MARK_BIT_STRING)+21,byteStr.length()-5).replaceAll(" ", "");
			responseDataStr = minusByteStr33Reverse(responseDataStr);
			rValue = new BigDecimal(responseDataStr.substring(0,responseDataStr.length())).multiply(BigDecimal.valueOf(0.01D));
			strSb.append("����й��ܵ���Ϊ").append(rValue).append("kwh");
			break;
		case 6://�����޹��ܵ���
			responseDataStr = byteStr.substring(byteStr.indexOf(MARK_BIT_STRING)+21,byteStr.length()-5).replaceAll(" ", "");
			responseDataStr = minusByteStr33Reverse(responseDataStr);
			rValue = new BigDecimal(responseDataStr.substring(0,responseDataStr.length())).multiply(BigDecimal.valueOf(0.01D));
			strSb.append("�����޹��ܵ���Ϊ").append(rValue).append("kvarh");
			break;
		case 7://״̬��
			responseDataStr = byteStr.substring(byteStr.indexOf(MARK_BIT_STRING)+21,byteStr.length()-5).replaceAll(" ", "");
			responseDataStr = minusByteStr33(responseDataStr);
			
			//״̬��4
			String state = HexTransHelper.hexToBin(responseDataStr.substring(12, 16));// ������
			state = ByteTransHelper.transStandardChar(state, 16);// ��֤Ϊ8λ
			strSb.append("״̬��4(A�����״̬):").append(processStateWord(state));
			strSb.append("\r\n");
			
			//״̬��5
			state = HexTransHelper.hexToBin(responseDataStr.substring(16, 20));// ������
			state = ByteTransHelper.transStandardChar(state, 16);// ��֤Ϊ8λ
			strSb.append("״̬��5(B�����״̬):").append(processStateWord(state));
			strSb.append("\r\n");
			
			//״̬��6
			state = HexTransHelper.hexToBin(responseDataStr.substring(20, 24));// ������
			state = ByteTransHelper.transStandardChar(state, 16);// ��֤Ϊ8λ
			strSb.append("״̬��6(C�����״̬):").append(processStateWord(state));
			strSb.append("\r\n");
			
			break;
		default:
			break;
		}
		return strSb.toString();
	}	
	
	
	/**
	 * ״̬�ִ���
	 * @param state ״̬�ֶ������ַ�
	 * @return
	 */
	public static String processStateWord(String state){
		String[] stateStr = new String[]{"����","��������","����","����","ʧ��","��ѹ","Ƿѹ","ʧѹ","","","","","","","","����"};
		StringBuffer sb = new StringBuffer();
		
		char[] stateCharArr = state.toCharArray();
		for (int i = 0; i < stateCharArr.length; i++) {
			if(stateCharArr[i]=='1')
				sb.append(stateStr[i])
				.append(" ");
		}
		if("".equals(sb.toString())){
			sb.append("��");
		}
		return sb.toString();
	}
	
	/**
	 * ����˳��ת
	 * @param Strr
	 * @return
	 */
	public static String reverseOrderByByte(String strArr){
		StringBuffer sb = new StringBuffer();
		for (int i = strArr.length()/2-1; i >= 0; i--){
			sb.append(strArr.substring(i * 2, i * 2 + 2));
		}
		return sb.toString();
	}
	
	public static String minusByteStr33Reverse(String str){
		StringBuffer sb = new StringBuffer();
		for (int i = str.length()/2-1; i >= 0; i--){
			String strTemp = str.substring(i * 2, i * 2 + 2);
			strTemp = Integer.toHexString(HexTransHelper.hexToOct(strTemp)- REDUCE_NUMBER);
			sb.append(ByteTransHelper.transStandardChar(strTemp, 2));
		}
		return sb.toString();
	}
	
	public static String minusByteStr33(String str){
		StringBuffer sb = new StringBuffer();
		for (int i = 0 ; i < str.length()/2; i++){
			String strTemp = str.substring(i * 2, i * 2 + 2);
			strTemp = Integer.toHexString(HexTransHelper.hexToOct(strTemp)- REDUCE_NUMBER);
			sb.append(ByteTransHelper.transStandardChar(strTemp, 2));
		}
		return sb.toString();
	}
	
	
	/**
	 * �������ܱ��д����ŵ����ݣ���һ�����ݵĸ�λΪ1�Ļ���Ϊ������ȡ����bitλ��ֵ
	 * 
	 * @param data
	 * @param scale
	 * @return
	 */
	public static String parseEnergeSignData(String data, String scale) {
		try {
			String normalData = toNormalData(data);
			int len = normalData.length() / 2;
			String curValue = "";
			int beginIndex = -1;
			StringBuffer buf = new StringBuffer("");
			String signPrefix = "";
			for (int i = 0; i < len; i++) {
				signPrefix = "";
				beginIndex = i * 2;
				curValue = normalData.substring(beginIndex, beginIndex + 2);
				// System.out.println("ԭʼֵ��" + curValue);
				curValue = Integer.toHexString(HexTransHelper
						.hexToOct(curValue)
						- 51);
				curValue = ByteTransHelper.transStandardChar(curValue, 2);// ��֤Ϊ2λ
																			// add
																			// at
																			// 2013-07-12
				// System.out.println("16����ֵ��" + curValue);
				if (i == 0) {
					curValue = HexTransHelper.hexToBin(curValue);// ������
					// ���볤
					curValue = ByteTransHelper.transStandardChar(curValue, 8);// ��֤Ϊ8λ
					// System.out.println("2����ֵ��" + curValue);
					// if (curValue.length() >= 8 && curValue.subSequence(0,
					// 1).equals("1")) {
					if (curValue.substring(0, 1).equals("1")) {
						signPrefix = "-";
					}
					if (curValue.length() == 1) {// ʵ�ʲ���������߼����ڲ���λ��
						// curValue = "0";//���ڳ���Ϊ1�������������תΪ0������Ϊ�������
						curValue = HexTransHelper.binToHex(curValue);
					} else {
						curValue = curValue.substring(1);
						curValue = HexTransHelper.binToHex(curValue);
					}
				}
				buf.append(signPrefix);
				if (curValue.length() < 2) {
					buf.append("0").append(curValue);
				} else {
					buf.append(curValue);
				}
			}
			return new BigDecimal(buf.toString()).multiply(new BigDecimal(scale)).toString();
		} catch (Exception e) {
		}
		return scale;
	}
	
	
	public static String toNormalData(String str) {
		try {
			if ((str.length() % 2) != 0) {
				throw new IllegalArgumentException("���Ȳ���ż��");
			}
			int len = str.length() / 2;
			StringBuffer buf = new StringBuffer("");
			String curValue = "";
			int beginIndex = -1;
			for (int i = len - 1; i >= 0; i--) {
				beginIndex = i * 2;
				curValue = str.substring(beginIndex, beginIndex + 2);
				buf.append(curValue);
			}
			return buf.toString();
		} catch (Exception e) {
		}
		return str;
	}
	
	
	/**
	 * �õ�У����֮��
	 * 
	 * @param str
	 * @return
	 */
	public static String getCS(String str) {
		if (str == null || "".equals(str)) {
			return "00";
		}
		int modResult = str.length() % 2;// modResult=1Ӧ�����д���
		int len = str.length() / 2;

		int beginIndex = 0;
		String curValue = "";
		int strSum = 0;
		for (int i = 0; i < len; i++) {
			beginIndex = i * 2;
			curValue = str.substring(beginIndex, beginIndex + 2);
			// ��16������ת��Ϊ10����
			int value = Integer.valueOf(curValue, 16);
			strSum = strSum + value;
		}
		// ����ȡģ256
		int mod = strSum % 256;
		// ��10����ת��Ϊ16����
		String modHex = Integer.toHexString(mod & 0xFF);
		if (modHex.length() == 1) {
			modHex = '0' + modHex;
		}
		return modHex;
	}

}

