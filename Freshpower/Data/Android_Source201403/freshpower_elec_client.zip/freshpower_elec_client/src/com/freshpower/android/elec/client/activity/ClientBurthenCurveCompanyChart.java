package com.freshpower.android.elec.client.activity;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.CategorySeries;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;

import com.freshpower.android.elec.client.common.MathUtil;
import com.freshpower.android.elec.client.common.StringUtil;

public class ClientBurthenCurveCompanyChart extends AbstractChart {
	
	private double[] sumChargeDoubleList = null;
	private GraphicalView mChartView;
	private String type;
	private String title;
	
	public String getType() {
		return type;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return "";
	}

	public String getDesc() {
		return "";
	}
	
	public double[] getSumChargeDoubleList() {
		return sumChargeDoubleList;
	}

	public void setSumChargeDoubleList(double[] sumChargeDoubleList) {
		this.sumChargeDoubleList = sumChargeDoubleList;
	}

	/**
	 * ��ҵ�ܸ�������ͼ
	 */
	public Intent execute(Context context) {
		return ChartFactory.getCubicLineChartIntent(context, getDataSet(), getRenderer(), 0.5f);
	}
	
	public void exe(Context context, LinearLayout layout) {
		mChartView = ChartFactory.getLineChartView(context, getDataSet(), getRenderer());
		layout.removeAllViews();
		layout.addView(mChartView, new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT)); 
		mChartView.invalidate();
	}
	
	/**
	 * ��������
	 * 
	 * @return
	 */
	public XYMultipleSeriesDataset getDataSet() {
		XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
		CategorySeries series = new CategorySeries("���ո���");
		if(sumChargeDoubleList != null) {
			sumChargeDoubleList = processNullDouble(sumChargeDoubleList);
			int seriesLength = sumChargeDoubleList.length;
		      for (int k = 0; k < seriesLength; k++) {
		        series.add(sumChargeDoubleList[k]);
		      }
		} else {
			series.add(0.0);
		}
		dataset.addSeries(series.toXYSeries());
		return dataset;
	}
	
	private double[] processNullDouble(double[] doubleArr){
		double[] doubleTemp = new double[doubleArr.length];
		if(doubleArr[doubleArr.length-1]==Double.parseDouble("0.0") && doubleArr.length != 1) {
			doubleTemp = new double[doubleArr.length-1];
		}
		for (int i = 0; i <doubleArr.length; i++) {
			if(doubleArr[i]==Double.parseDouble("0.0") && i==doubleArr.length-1) {
				break;
			}
			doubleTemp[i] = doubleArr[i];
		}
		return doubleTemp;
	}
	
	/**
	 * ������Ⱦ��
	 * 
	 * @return
	 */
	public XYMultipleSeriesRenderer getRenderer() {
		int[] colors = new int[] { Color.parseColor("#1E90FF") };
		PointStyle[] styles = new PointStyle[] { PointStyle.POINT };
		XYMultipleSeriesRenderer renderer = buildRenderer(colors, styles);
		if(sumChargeDoubleList != null) {
			setChartSettings(renderer, "",
					"ʱ�䣨��λ��Сʱ��", " ���ɣ���λ��KW��", 0.75, 24.25, 0, MathUtil.max(sumChargeDoubleList)*1.3, Color.BLACK,
					Color.BLACK);
		} else {
			setChartSettings(renderer, "",
					"ʱ�䣨��λ��Сʱ��", " ���ɣ���λ��KW��", 0.75, 24.25, 0, 1000, Color.BLACK,
					Color.BLACK);
		}
		if(!StringUtil.isEmpty(type) && type.equals("chargeDetil")) {
			renderer.setChartTitle(title+"��������");
			renderer.setChartTitleTextSize(50);
		}
		renderer.setXLabels(24);
		renderer.setYLabels(5);
		renderer.setChartTitleTextSize(20);
		renderer.setLabelsTextSize(14f);
		renderer.setAxisTitleTextSize(15);
		renderer.setLegendTextSize(15);
		renderer.setAxisTitleTextSize(16); 
		// ���ñ�����ɫ
		renderer.setApplyBackgroundColor(true);
		renderer.setBackgroundColor(Color.parseColor("#F5F6F4"));
		renderer.setMarginsColor(Color.parseColor("#F5F6F4"));
		renderer.setXLabelsColor(Color.BLACK);
		renderer.setYLabelsColor(0, Color.BLACK);
		// �����Ƿ��ǿɻ���������
		renderer.setPanEnabled(false, false); 
		
		// ������ʽ
		XYSeriesRenderer seriesRenderer = (XYSeriesRenderer) renderer
				.getSeriesRendererAt(0);
		seriesRenderer.setLineWidth(2.5f);
		seriesRenderer.setDisplayChartValues(true);
		seriesRenderer.setChartValuesTextSize(10f);
		
		// X�����ֱ�ǩ����
		renderer.setXLabels(0);
		for(int i=1;i<=24;i++) {
			renderer.addTextLabel(i, String.valueOf(i-1));
		}
		
		return renderer;
	}

}
