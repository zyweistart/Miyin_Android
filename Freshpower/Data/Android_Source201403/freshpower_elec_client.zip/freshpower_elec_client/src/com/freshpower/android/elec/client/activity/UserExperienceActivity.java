package com.freshpower.android.elec.client.activity;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.GetCurrentData;

public class UserExperienceActivity extends Activity {
	public DecimalFormat df =new DecimalFormat("0.00"); //��ȡ��С�������λ
	int time = 1;//ÿ12�μ��㵱ǰ�ܵ���
	UserThread myThread = new UserThread();
	int textViewNumTemp = 1;
	//----------------------
	//�˸����ذ�ť
	ImageButton imgBtn1 = null;
    ImageButton imgBtn2 = null;
    ImageButton imgBtn3 = null;
    ImageButton imgBtn4 = null;
    ImageButton imgBtn5 = null;
    ImageButton imgBtn6 = null;
    ImageButton imgBtn7 = null;
    ImageButton imgBtn8 = null;
    ImageButton imgBtn9 = null;//ĸ�߿���
    //-----------------
    //�˸���ť�Ƿ�������
	//------------------------------
	double[] a = new double[12];//����a
	double[] b = new double[12];//����b
	double[] c = new double[12];//����c
	//�˸���ʾ������TextView
    TextView gameSwitch1 = null;
    TextView gameSwitch2 = null;
    TextView gameSwitch3 = null;
    TextView gameSwitch4 = null;
    TextView gameSwitch5 = null;
    TextView gameSwitch6 = null;
    TextView gameSwitch7 = null;
    TextView gameSwitch8 = null;
	//---------------------------
    //չʾҳ���ܸ��ɡ��ܵ���
    TextView sumCharge = null;
    TextView sumTotalPower = null;
    double[] sumChargeList = new double[24] ;
    Bundle bundle;
    //---------------
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	super.requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_experience);
        ActivityUtil.addActivity(this);
        this.setCurrentTextView();
        //Ϊ������ʹ�õ���list����ֵ����ֹ����ָ�����
		//--------------------------
        myThread.start(); //������������߳�
        //---------------------------------
        bundle = getIntent().getExtras();
//        Log.d("BID", "1234"+String.valueOf(bundle.getDoubleArray("sumCharge")[0]));
//        Log.d("BID",String.valueOf(bundle.getDoubleArray("sumCharge")));
        buttonOnClick();
        gameSwitchOnclick();
        ActivityUtil.addActivity(this);
    }
    
    private Handler  handler = new Handler(){
    	public void handleMessage(android.os.Message msg) {
    		if(msg.what==1){
    			setCurrentTextView();
    		}
    	};
    };
    
    class UserThread extends Thread{
    	
    	private boolean isDestory=false;
    	
    	void setDestory(boolean isDestory){
    		this.isDestory = isDestory;
    	}
    	
    	@Override
    	public void run() {
    		try {
        		while(!isDestory){
					if(isDestory)break;
	            	Message msg  = new Message();
	            	msg.what = 1;
	            	handler.sendMessage(msg);
	            	Thread.sleep(5000);
        		}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
    	}
    }
    
    private void setTextValue(){
    	GetCurrentData.myThread.setDestory(true);
		GetCurrentData.myThread.starts();
		myThread.setDestory(true);
		myThread = new UserThread();
		myThread.start();
    }
    public void setCurrentTextView(){
    	List<TextView> listGame = new ArrayList<TextView>();
        gameSwitch1 = (TextView)findViewById(R.id.game_switch01);
        gameSwitch2 = (TextView)findViewById(R.id.game_switch02);
        gameSwitch3 = (TextView)findViewById(R.id.game_switch03);
        gameSwitch4 = (TextView)findViewById(R.id.game_switch04);
        gameSwitch5 = (TextView)findViewById(R.id.game_switch05);
        gameSwitch6 = (TextView)findViewById(R.id.game_switch06);
        gameSwitch7 = (TextView)findViewById(R.id.game_switch07);
        gameSwitch8 = (TextView)findViewById(R.id.game_switch08);
        sumCharge = (TextView)findViewById(R.id.sumCharge);
        listGame.add(gameSwitch1);
        listGame.add(gameSwitch2);
        listGame.add(gameSwitch3);
        listGame.add(gameSwitch4);
        listGame.add(gameSwitch5);
        listGame.add(gameSwitch6);
        listGame.add(gameSwitch7);
        listGame.add(gameSwitch8);
        double[][] temp = null;
		temp = GetCurrentData.currentList.get(11).get(0);
        for(int x = 0; x < 4 ; x++){
        	StringBuffer current = new StringBuffer();
        	for(char j = 'a'; j < 'd' ;j++){
        		current.append("I"+j+"="+df.format(temp[x][j-97])+";\n");
        	}
        	listGame.get(x).setText(current);
        }
	
		temp = GetCurrentData.currentList.get(11).get(1);
		for(int x = 0; x < 4 ; x++){
			StringBuffer current = new StringBuffer();
        	for(char j = 'a'; j < 'd' ;j++){
        		current.append("I"+j+"="+df.format(temp[x][j-97])+";\n");
        	}
        	listGame.get(x+4).setText(current);
        }
        	
        //--------------------------------------
        sumCharge.setText("��ǰ���ɣ�"+df.format(GetCurrentData.sumChargeDouble)+"kW");
    }
    
   
    
    public static double calculationTime(){//���㵱ǰʱ��ĵ��
    	Date time = new Date();
    	double money = 0 ;
    	int hour = time.getHours();
    	if(hour >= 19 && hour < 21){
    		money = 1.456;
    	}else if ((hour >= 8 && hour< 11)||(hour >= 13&&hour<19)||
    			(hour >= 21 && hour < 22)){
    		money = 1.151;
    	}else {
    		money = 0.628;
    	}
    	return money;
    }
    
    
    public static double businessCalculationTime(){//���㵱ǰʱ�����ҵ���
    	Date time = new Date();
    	double money = 0 ;
    	int hour = time.getHours();
    	if(hour >= 19 && hour < 21){
    		money = 1.406;
    	}else if ((hour >= 8 && hour< 11)||(hour >= 13&&hour<19)||
    			(hour >= 21 && hour < 22)){
    		money = 1.108;
    	}else {
    		money = 0.596;
    	}
    	return money;
    }
    
    public static double calculationIndustrialTime(){//���㵱ǰʱ��Ĺ�ҵ���
    	Date time = new Date();
    	double money = 0 ;
    	int hour = time.getHours();
    	if(hour >= 19 && hour < 21){
    		money = 1.123;
    	}else if ((hour >= 8 && hour< 11)||(hour >= 13&&hour<19)||
    			(hour >= 21 && hour < 22)){
    		money = 0.941;
    	}else {
    		money = 0.457;
    	}
    	return money;
    }
	/*
	 * ��ȡ��������
	 * threePhaseCurrent�洢���ݶ�ά����
	 * size �ڼ�����
	 * j ��������
	 */
	
	public static double getCosRandom(){
		double rnd=Math.random() * 0.1 + 0.9;
		return rnd;
	}
	
	private void openActivity(){
		Intent intent = new Intent(UserExperienceActivity.this,ChargeChartActivity.class);
		intent.putExtras(bundle);
		startActivity(intent);
	}
	
	private void gameSwitchOnclick(){
	    	gameSwitch1.setOnClickListener(new OnClickListener(){
	        	public void onClick(View v) {
	        		GetCurrentData.textViewNum = 1;
	        		GetCurrentData.coefficient = 1;
	        		GetCurrentData.inComingLine = "����1";
	        		openMyThread();
	        		openActivity();
	        	}
	        });
	        gameSwitch2.setOnClickListener(new OnClickListener(){
	        	public void onClick(View v) {
	        		GetCurrentData.textViewNum = 2;
	        		if(GetCurrentData.finalB9){
	        			GetCurrentData.coefficient = 0.15;
	        		}else{
	        			GetCurrentData.coefficient = 0.2;
	        		}
	        		GetCurrentData.inComingLine = "����B1-1";
	        		openMyThread();
	        		openActivity();
	        	}
	        });
	        gameSwitch3.setOnClickListener(new OnClickListener(){
	        	public void onClick(View v) {
	        		GetCurrentData.textViewNum = 3;
	        		if(GetCurrentData.finalB9){
	        			GetCurrentData.coefficient = 0.25;
	        		}else{
	        			GetCurrentData.coefficient = 0.3;
	        		}
	        		GetCurrentData.inComingLine = "����B1-2";
	        		openMyThread();
	        		openActivity();
	        	}
	        });
	        gameSwitch4.setOnClickListener(new OnClickListener(){
	        	public void onClick(View v) {
	        		GetCurrentData.textViewNum = 4;
	        		if(GetCurrentData.finalB9){
	        			GetCurrentData.coefficient = 0.1;
	        		}else{
	        			GetCurrentData.coefficient = 0.5;
	        		}
	        		GetCurrentData.inComingLine = "����B1-3";
	        		openMyThread();
	        		openActivity();
	        	}
	        });
	        gameSwitch5.setOnClickListener(new OnClickListener(){
	        	public void onClick(View v) {
	        		GetCurrentData.textViewNum = 5;
	        		GetCurrentData.coefficient = 1;
	        		GetCurrentData.inComingLine = "����2";
	        		openMyThread();
	        		openActivity();
	        	}
	        });
	        gameSwitch6.setOnClickListener(new OnClickListener(){
	        	public void onClick(View v) {
	        		GetCurrentData.textViewNum = 6;
	        		if(GetCurrentData.finalB9){
	        			GetCurrentData.coefficient = 0.15;
	        		}else{
	        			GetCurrentData.coefficient = 0.3;
	        		}
	        		GetCurrentData.inComingLine = "����B2-1";
	        		openMyThread();
	        		openActivity();
	        	}
	        });
	        gameSwitch7.setOnClickListener(new OnClickListener(){
	        	public void onClick(View v) {
	        		GetCurrentData.textViewNum = 7;
	        		if(GetCurrentData.finalB9){
	        			GetCurrentData.coefficient = 0.25;
	        		}else{
	        			GetCurrentData.coefficient = 0.5;
	        		}
	        		GetCurrentData.inComingLine = "����B2-2";
	        		openMyThread();
	        		openActivity();
	        	}
	        });
	        gameSwitch8.setOnClickListener(new OnClickListener(){
	        	public void onClick(View v) {
	        		GetCurrentData.textViewNum = 8;
	        		if(GetCurrentData.finalB9){
	        			GetCurrentData.coefficient = 0.1;
	        		}else{
	        			GetCurrentData.coefficient = 0.2;
	        		}
	        		GetCurrentData.inComingLine = "����B2-3";
	        		openMyThread();
	        		openActivity();
	        	}
	        });
	    }
	//����������ֵ
//	private void setCoefficientList(){
//		for(int i = 0 ; i< 12 ; i++){
//			GetCurrentData.coefficientList[i] = GetCurrentData.coefficient*1443.4;
//		}
//	}
	//�¿��߳�
	private void openMyThread(){
		myThread.setDestory(true);
		myThread = new UserThread(); 
		myThread.start();
	}

	    //��ť�����¼�
	private void buttonOnClick(){
	        //�˸����ذ�ť
	        imgBtn1 = (ImageButton)findViewById(R.id.game_btn1);
	        imgBtn2 = (ImageButton)findViewById(R.id.game_btn2);
	        imgBtn3 = (ImageButton)findViewById(R.id.game_btn3);
	        imgBtn4 = (ImageButton)findViewById(R.id.game_btn4);
	        imgBtn5 = (ImageButton)findViewById(R.id.game_btn5);
	        imgBtn6 = (ImageButton)findViewById(R.id.game_btn6);
	        imgBtn7 = (ImageButton)findViewById(R.id.game_btn7);
	        imgBtn8 = (ImageButton)findViewById(R.id.game_btn8);
	        imgBtn9 = (ImageButton)findViewById(R.id.game_btn9);
	        List<ImageButton> btnList = new ArrayList<ImageButton>();
	        btnList.add(imgBtn1);
	        btnList.add(imgBtn2);
	        btnList.add(imgBtn3);
	        btnList.add(imgBtn4);
	        btnList.add(imgBtn5);
	        btnList.add(imgBtn6);
	        btnList.add(imgBtn7);
	        btnList.add(imgBtn8);
	        for(int i = 0 ;i < 8 ; i ++){
	        	if(GetCurrentData.finalB[i]){
	        		btnList.get(i).setBackgroundResource(R.drawable.open);
	        	}else{
	        		btnList.get(i).setBackgroundResource(R.drawable.close);
	        	}
	        }
	        if(GetCurrentData.finalB9){
	        	imgBtn9.setBackgroundResource(R.drawable.open);
	        }else{
	        	imgBtn9.setBackgroundResource(R.drawable.close);
	        }
	        //-------------------------------------
	    	imgBtn1.setOnClickListener(new OnClickListener(){
				@SuppressLint("NewApi")
				public void onClick(View v) {
					if(GetCurrentData.finalB9&&GetCurrentData.finalB[4]){
						Toast.makeText(UserExperienceActivity.this, "���ȶϿ�ĸ�����أ��ٺ��Ͻ��߿��ء�", Toast.LENGTH_SHORT).show();
						return;
					}
					if(GetCurrentData.finalB[0]){
						if(!GetCurrentData.finalB[4]){
							Toast.makeText(UserExperienceActivity.this, "���߿���ȫ���Ͽ������ȫվʧ�硣", Toast.LENGTH_SHORT).show();
							return;
						}
						GetCurrentData.finalB[0] = false ;
						imgBtn1.setBackgroundResource(R.drawable.close);
						openMyThread();
						setTextValue();
					}else{
						GetCurrentData.finalB[0] = true ;
						imgBtn1.setBackgroundResource(R.drawable.open);
						openMyThread();
						setTextValue();
					}
				}
	        });
	        imgBtn2.setOnClickListener(new OnClickListener(){
				@SuppressLint("NewApi")
				public void onClick(View v) {
					if(GetCurrentData.finalB[1]){
						GetCurrentData.finalB[1] = false ;
						imgBtn2.setBackgroundResource(R.drawable.close);
						openMyThread();
						setTextValue();
					}else{
						GetCurrentData.finalB[1] = true ;
						imgBtn2.setBackgroundResource(R.drawable.open);
						openMyThread(); 
						setTextValue();
					}
				}
	        });
	        imgBtn3.setOnClickListener(new OnClickListener(){
				@SuppressLint("NewApi")
				public void onClick(View v) {
					if(GetCurrentData.finalB[2]){
						GetCurrentData.finalB[2] = false ;
						imgBtn3.setBackgroundResource(R.drawable.close);					
						openMyThread();
						setTextValue();
					}else{
						GetCurrentData.finalB[2] = true ;
						imgBtn3.setBackgroundResource(R.drawable.open);
						openMyThread();
						setTextValue();
					}
				}
	        });
	        imgBtn4.setOnClickListener(new OnClickListener(){
				@SuppressLint("NewApi")
				public void onClick(View v) {
					if(GetCurrentData.finalB[3]){
						GetCurrentData.finalB[3] = false ;
						imgBtn4.setBackgroundResource(R.drawable.close);
						openMyThread();
						setTextValue();
					}else{
						GetCurrentData.finalB[3] = true ;
						imgBtn4.setBackgroundResource(R.drawable.open);
						openMyThread();
						setTextValue();
					}
				}
	        });
	        imgBtn5.setOnClickListener(new OnClickListener(){
				@SuppressLint("NewApi")
				public void onClick(View v) {
					if(GetCurrentData.finalB9&&GetCurrentData.finalB[0]){
						Toast.makeText(UserExperienceActivity.this, "���ȶϿ�ĸ�����أ��ٺ��Ͻ��߿��ء�", Toast.LENGTH_SHORT).show();
						return;
					}
					if(GetCurrentData.finalB[4]){
						if(!GetCurrentData.finalB[0]){
							Toast.makeText(UserExperienceActivity.this, "���߿���ȫ���Ͽ������ȫվʧ�硣", Toast.LENGTH_SHORT).show();
							return;
						}
						GetCurrentData.finalB[4] = false ;
						imgBtn5.setBackgroundResource(R.drawable.close);
						openMyThread();
						setTextValue();
					}else{
						GetCurrentData.finalB[4] = true ;
						imgBtn5.setBackgroundResource(R.drawable.open);
						openMyThread();
						setTextValue();
					}
				}
	        });
	        imgBtn6.setOnClickListener(new OnClickListener(){
				@SuppressLint("NewApi")
				public void onClick(View v) {
					if(GetCurrentData.finalB[5]){
						GetCurrentData.finalB[5] = false ;
						imgBtn6.setBackgroundResource(R.drawable.close);
						openMyThread();
						setTextValue();
					}else{
						GetCurrentData.finalB[5] = true ;
						imgBtn6.setBackgroundResource(R.drawable.open);
						openMyThread();
						setTextValue();
					}
				}
	        });
	        imgBtn7.setOnClickListener(new OnClickListener(){
				@SuppressLint("NewApi")
				public void onClick(View v) {
					if(GetCurrentData.finalB[6]){
						GetCurrentData.finalB[6] = false ;
						imgBtn7.setBackgroundResource(R.drawable.close);
						openMyThread();
						setTextValue();
					}else{
						GetCurrentData.finalB[6] = true ;
						imgBtn7.setBackgroundResource(R.drawable.open);
						openMyThread();
						setTextValue();
					}
				}
	        });
	        imgBtn8.setOnClickListener(new OnClickListener(){
				@SuppressLint("NewApi")
				public void onClick(View v) {
					if(GetCurrentData.finalB[7]){
						GetCurrentData.finalB[7] = false ;
						imgBtn8.setBackgroundResource(R.drawable.close);
						openMyThread();
						setTextValue();
					}else{
						GetCurrentData.finalB[7]= true ;
						imgBtn8.setBackgroundResource(R.drawable.open);
						openMyThread();
						setTextValue();
					}
				}
	        });
	        imgBtn9.setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					if(GetCurrentData.finalB[0] && GetCurrentData.finalB[4]){
						Toast.makeText(UserExperienceActivity.this, "�ȶϿ�һ�����߿��غ󣬲ſ��ٺ���ĸ�����ء�", Toast.LENGTH_SHORT).show();
						return;
						
					}
					if(GetCurrentData.finalB9){
						GetCurrentData.finalB9 = false ;
						imgBtn9.setBackgroundResource(R.drawable.close);
						openMyThread();
						setTextValue();
					}else{
						GetCurrentData.finalB9 = true ;
						imgBtn9.setBackgroundResource(R.drawable.open);
						openMyThread();
						setTextValue();
					}
				}
			});
	    }
	@Override
	protected void onDestroy() {
			// TODO Auto-generated method stub
			//Log.d("elec", "onDestroy");
			if(myThread != null){
				myThread.setDestory(true);
			}
			super.onDestroy();
		}
	
}