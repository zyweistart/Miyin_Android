package com.freshpower.android.elec.client.activity;

import java.text.DecimalFormat;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class ElecDiagramActivity extends Activity {
	public static DecimalFormat df =new DecimalFormat("#.00"); //��ȡ��С�������λ
	private static int finalB1 = 1;
	static double [] random = new double[3];//���������
	static double [][] ThreePhaseCurrentLeft = new double [3][4];//������������¼
	static double [][] ThreePhaseCurrentRight = new double [3][4];//�Ҳ����������¼
	
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.elec_diagram);
		ActivityUtil.addActivity(this);
		final ImageButton b = (ImageButton)findViewById(R.id.Button_1);
		//b.setBackgroundColor(Color.RED);
		//final TextView t = (TextView)findViewById(R.id.Button_text);
		b.setOnClickListener(new OnClickListener(){
			
			public void onClick(View arg0) {
				if(finalB1 == 1){
					b.setBackgroundResource(R.drawable.left);
					//t.setText(finalB1);
					finalB1 = 2;
				}else if(finalB1 == 2){
					b.setBackgroundResource(R.drawable.right);
					//t.setText(finalB1);
					finalB1 = 1;
				}
				
			}
		});
//		FINAL BUTTON B2 = (BUTTON)FINDVIEWBYID(R.ID.BUTTON_2);
//		FINAL BUTTON B3 = (BUTTON)FINDVIEWBYID(R.ID.BUTTON_3);
	}
	
	public Double Calculate(int i){
		Double rnd = Math.random() ;//����������������
		if(rnd<0.1){
			rnd+=0.1;
		}
		rnd = Double.valueOf(df.format(rnd));
		double electricCurrent = 1443.4 * rnd;
		double [][] ThreePhaseCurrentRight = new double [3][4];
		getRandom();
		ThreePhaseCurrentRight[i][0] = electricCurrent;//I*(���Էֱ����A,B,C)
		ThreePhaseCurrentRight[i][1] = electricCurrent * random[0];//I*1
		ThreePhaseCurrentRight[i][2] = electricCurrent * random[1];//I*2
		ThreePhaseCurrentRight[i][3] = electricCurrent * random[2];//I*3
		return null;
	}
	/*
	 * ����������Ϊ1�������
	 */
	public static void getRandom(){
		double a=Math.random(),b=Math.random();
		String aveprice = df.format(a);
		a = Double.valueOf(aveprice);
		aveprice = df.format(b);
		b = Double.valueOf(aveprice);
		random[0]=Math.min(a, b);
		random[1]=Math.abs(a-b);
		random[2]=1 - Math.max(a,b);
		if(random[0]<0.1||random[1]<0.1||random[2]<0.1){
			getRandom();
		}
	}
}
