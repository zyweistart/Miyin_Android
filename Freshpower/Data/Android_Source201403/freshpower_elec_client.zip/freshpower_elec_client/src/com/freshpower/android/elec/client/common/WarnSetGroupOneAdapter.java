package com.freshpower.android.elec.client.common;

import java.util.List;
import java.util.Map;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.activity.WarnHandleActivity;
import com.freshpower.android.elec.client.domain.CustomerInfo;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;



public class WarnSetGroupOneAdapter extends BaseAdapter {

	List<Map<String, Object>> mData;
	Context mContext;
	int resource;
	private Intent intent;
	private List<CustomerInfo> warnDetailList;
	private String alertId;
	public WarnSetGroupOneAdapter(List<Map<String, Object>> data,
			Context context, int resource,List<CustomerInfo> warnDetailList) {
		this.mData = data;
		this.mContext = context;
		this.resource = resource;
		this.warnDetailList = warnDetailList;
	}

	@Override
	public int getCount() {
		return mData == null ? 0 : mData.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	static class ViewHoder {
		TextView warnOne;
		TextView warnTwo;
		TextView warnThree;
		TextView warnFour;
		Button warnHandle;
		Button warnHistory;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHoder hoder = null;
		if (convertView == null) {
			hoder = new ViewHoder();
			convertView = LayoutInflater.from(mContext).inflate(resource, null);
			hoder.warnOne = (TextView) convertView
					.findViewById(R.id.warnOne);
			hoder.warnTwo = (TextView) convertView
					.findViewById(R.id.warnTwo);
			hoder.warnThree = (TextView) convertView
					.findViewById(R.id.warnThree);
			hoder.warnFour = (TextView) convertView
					.findViewById(R.id.warnFour);
			hoder.warnHandle = (Button) convertView
					.findViewById(R.id.warnHandle);
			convertView.setTag(hoder);
		} else {
			hoder = (ViewHoder) convertView.getTag();
		}
		Map<String, Object> data = mData.get(position);
		hoder.warnOne.setText(String.valueOf(data.get("textView1")));
		hoder.warnTwo.setText(String.valueOf(data.get("textView2")));
		hoder.warnThree.setText(String.valueOf(data.get("textView3")));
		hoder.warnFour.setText(String.valueOf(data.get("textView4")));
		
		
		WarnSetItemOnClickListener WarnSetItemOnClickListener = new WarnSetItemOnClickListener();
		WarnSetItemOnClickListener.setAlertId(String.valueOf(data.get("id")));
		hoder.warnHandle.setOnClickListener(WarnSetItemOnClickListener);
		return convertView;
	}
	
	
	 class WarnSetItemOnClickListener implements View.OnClickListener{
		 
		private String alertId;
		
		public void setAlertId(String alertId) {
			this.alertId = alertId;
		}

		@Override
		public void onClick(View v) {
			Intent intent = new Intent(mContext, WarnHandleActivity.class);
			intent.putExtra("alertId", alertId);
			mContext.startActivity(intent);
		}
	}

}
