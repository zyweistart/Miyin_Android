package com.freshpower.android.elec.client.domain;

public class RunStatus {
	private String meterId;// ��·ID
	private String meterName;// ��·����
	private String color;// ��ɫ
	private String iValue;// ����ֵ
	public String getMeterId() {
		return meterId;
	}
	public void setMeterId(String meterId) {
		this.meterId = meterId;
	}
	public String getMeterName() {
		return meterName;
	}
	public void setMeterName(String meterName) {
		this.meterName = meterName;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getiValue() {
		return iValue;
	}
	public void setiValue(String iValue) {
		this.iValue = iValue;
	}

}
