package com.freshpower.android.elec.client.activity;



import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

public class WarnSearchActivity extends Activity {
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_warnsearch);
		ActivityUtil.addActivity(this);
		Button btn=(Button)findViewById(R.id.warnSub);
		ImageView iv=(ImageView)findViewById(R.id.warnsearchiv);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(WarnSearchActivity.this,WarnActivity.class);
				startActivity(intent);
				finish();
			}
		});
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				EditText edt=(EditText)findViewById(R.id.warnName);
				String  warnName=edt.getText().toString();
				Spinner spn=(Spinner)findViewById(R.id.warnLevel);
				String warnLevel=String.valueOf(spn.getSelectedItemId());
				if(warnName==null||warnName.equals("")){
					Toast.makeText(WarnSearchActivity.this, R.string.warn_search_name, Toast.LENGTH_SHORT).show();
					return;
				}
				if(warnLevel==null||warnLevel.equals("")){
					Toast.makeText(WarnSearchActivity.this, R.string.warn_search_level, Toast.LENGTH_SHORT).show(); 
					return;
				}
				try {
//					Map warnMap = StationInfoDataApi.getWarnSearchInfo(warnName,warnLevel);
					Intent intent = new Intent(WarnSearchActivity.this,WarnActivity.class);
					intent.putExtra("warnSearch", "warnSearch");
					intent.putExtra("warnSearchName", warnName);
					intent.putExtra("warnSearchLevel", warnLevel);
		    		startActivity(intent);
		    		finish();
				}catch (Exception e) {
					Toast.makeText(WarnSearchActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show(); 
					e.printStackTrace();
				}
			}
		});
	}
}
