package com.freshpower.android.elec.client.activity;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.SizeUtil;

import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TabWidget;
import android.widget.TextView;


public class AlarmActivity extends TabActivity {

	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_alarm);
		ActivityUtil.addActivity(this);
		
		TabHost tabHost = getTabHost();

		Intent realTimeShowIntent = new Intent();
		realTimeShowIntent.putExtra("type", "realTime");
		realTimeShowIntent.setClass(this, ClientWarnActivity.class);
		TabHost.TabSpec realTimeShowTS = tabHost.newTabSpec("ʵʱ����");
		Resources res = getResources();
		realTimeShowTS.setIndicator("ʵʱ����");
		realTimeShowTS.setContent(realTimeShowIntent);
		tabHost.addTab(realTimeShowTS);

		Intent historyIntent = new Intent();
		historyIntent.putExtra("type", "history");
		historyIntent.setClass(this, ClientWarnActivity.class);
		TabHost.TabSpec historyTS = tabHost.newTabSpec("��ʷ����");
		historyTS.setIndicator("��ʷ����");
		historyTS.setContent(historyIntent);
		tabHost.addTab(historyTS);
		
		TabWidget tabWidget = tabHost.getTabWidget();
		 for (int i =0; i < tabWidget.getChildCount(); i++) {
			 tabWidget.getChildAt(i).getLayoutParams().height = SizeUtil.dip2px(this, 40F);
			 tabWidget.getChildAt(i).getLayoutParams().width = SizeUtil.dip2px(this, 65F);
			 tabWidget.getChildAt(i).setBackgroundResource(R.color.purple);
			 TextView tv = (TextView) tabWidget.getChildAt(i).findViewById(android.R.id.title);
			 tv.setTextSize(15);
			 tv.setTextColor(this.getResources().getColorStateList(android.R.color.white));
		 }
		
		// �����¼�
		ImageView returnButton = (ImageView) findViewById(R.id.alarm_return);
		returnButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				AlarmActivity.this.onBackPressed();
			}
		});

	}

}
