package com.freshpower.android.elec.client.activity;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.CategorySeries;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;

import com.freshpower.android.elec.client.common.DateUtil;
import com.freshpower.android.elec.client.common.MathUtil;

public class ClientChargeDetailCurveCompanyChart extends AbstractChart {
	
	private double[] sumChargeDoubleList = null;
	private GraphicalView mChartView;
	private String title;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getName() {
		return "";
	}

	public String getDesc() {
		return "";
	}
	
	public double[] getSumChargeDoubleList() {
		return sumChargeDoubleList;
	}

	public void setSumChargeDoubleList(double[] sumChargeDoubleList) {
		this.sumChargeDoubleList = sumChargeDoubleList;
	}

	/**
	 * ��ϸ��������ͼ�����ղ�ѯ��
	 */
	public Intent execute(Context context) {
		return ChartFactory.getCubicLineChartIntent(context, getDataSet(), getRenderer(), 0.5f);
	}
	
	public void exe(Context context, LinearLayout layout) {
		mChartView = ChartFactory.getLineChartView(context, getDataSet(), getRenderer());
		layout.removeAllViews();
		layout.addView(mChartView, new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT)); 
		mChartView.invalidate();
	}
	
	/**
	 * ��������
	 * 
	 * @return
	 */
	public XYMultipleSeriesDataset getDataSet() {
		XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
		CategorySeries series = new CategorySeries("��30��ĸ���");
		if(sumChargeDoubleList != null) {
			int seriesLength = sumChargeDoubleList.length;
		      for (int k = 0; k < seriesLength; k++) {
		        series.add(sumChargeDoubleList[k]);
		      }
		} else {
			series.add(0.0);
		}
		dataset.addSeries(series.toXYSeries());
		return dataset;
	}
	
	/**
	 * ������Ⱦ��
	 * 
	 * @return
	 */
	public XYMultipleSeriesRenderer getRenderer() {
		int[] colors = new int[] { Color.parseColor("#1E90FF") };
		PointStyle[] styles = new PointStyle[] { PointStyle.POINT };
		XYMultipleSeriesRenderer renderer = buildRenderer(colors, styles);
		if(sumChargeDoubleList != null) {
			setChartSettings(renderer, "",
					"ʱ�䣨��λ���գ�", " ���ɣ���λ��KW��", 0.75, 24.25, 0, MathUtil.max(sumChargeDoubleList)*1.3, Color.BLACK,
					Color.BLACK);
		} else {
			setChartSettings(renderer, "",
					"ʱ�䣨��λ���գ�", " ���ɣ���λ��KW��", 0.75, 24.25, 0, 1000, Color.BLACK,
					Color.BLACK);
		}
		renderer.setChartTitle(title+"��������");
		renderer.setChartTitleTextSize(50);
		renderer.setXLabels(24);
		renderer.setYLabels(10);
		renderer.setChartTitleTextSize(20);
		renderer.setLabelsTextSize(14f);
		renderer.setAxisTitleTextSize(15);
		renderer.setLegendTextSize(15);
		renderer.setAxisTitleTextSize(16); 
		// ���ñ�����ɫ
		renderer.setApplyBackgroundColor(true);
		renderer.setBackgroundColor(Color.parseColor("#F5F6F4"));
		renderer.setMarginsColor(Color.parseColor("#F5F6F4"));
		renderer.setXLabelsColor(Color.BLACK);
		renderer.setYLabelsColor(0, Color.BLACK);
		
		// ������ʽ
		XYSeriesRenderer seriesRenderer = (XYSeriesRenderer) renderer
				.getSeriesRendererAt(0);
		seriesRenderer.setLineWidth(2.5f);
		seriesRenderer.setDisplayChartValues(true);
		seriesRenderer.setChartValuesTextSize(10f);
		
		// X�����ֱ�ǩ����
		renderer.setXLabels(0);
		if(sumChargeDoubleList != null) {
			// �����Ƿ��ǿɻ���������
			renderer.setPanEnabled(true, false); 
			renderer.setPanLimits(new double[] { 0, 31, 0, 0 });//���������ķ�Χ
			for(int i=0;i<sumChargeDoubleList.length;i++) {
				renderer.addTextLabel(i+1, DateUtil.getLastMonthDate(-(sumChargeDoubleList.length-i), "dd"));
			}
		} else {
			// �����Ƿ��ǿɻ���������
			renderer.setPanEnabled(false, false); 
			for(int i=1;i<=24;i++) {
				renderer.addTextLabel(i, String.valueOf(i-1));
			}
		}
		
		return renderer;
	}
	
}
