package com.freshpower.android.elec.client.activity;

import java.text.DecimalFormat;
import java.util.Date;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityData;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.GetCurrentData;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ChargeChartActivity extends Activity {
	double[] sumChargeDouble = new double[24];
	public static DecimalFormat df =new DecimalFormat("0.00"); //��ȡ��С�������λ
	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_change_chart);
		ClientBurthenCurveChart clientBurthenCurveChart = new ClientBurthenCurveChart();
		LinearLayout curveChart = (LinearLayout)findViewById(R.id.curveChart);
		ActivityUtil.addActivity(this);
		//sumChargeDouble = ActivityData.getRandomChargeData();// �����ȡ����
		Bundle bundle = getIntent().getExtras();
		sumChargeDouble = bundle.getDoubleArray("sumCharge");
		//Log.d("BID", String.valueOf(sumChargeDouble[0]));
		double b = 0 ;//����ϵ����
		int hour = 0 ;
		if(GetCurrentData.textViewNum > 4){
			//ĸ���ϡ��Ҳ࿪�غϡ��ҽ����Ȳ�Ϊ����1ʱ�����������Ϊ0.525
			if(GetCurrentData.finalB9 && GetCurrentData.finalB[4] && GetCurrentData.textViewNum != 1){
				b = 0.525;
			}else{
				b = 0.475;
			}
		}else{
			//ĸ���ϡ���࿪�غϡ��ҽ����Ȳ�Ϊ����2ʱ�����������Ϊ0.475
			if(GetCurrentData.finalB9 && GetCurrentData.finalB[0] && GetCurrentData.textViewNum != 5){
				b = 0.475;
			}else{
				b = 0.525;
			}
			
		}
		Date date = new Date();
		double max = 0 ;
		double sum = 0 ;
		for(int i = 0 ; i < date.getHours()+1 ; i ++){
			sumChargeDouble[i] =  Double.parseDouble(df.format(sumChargeDouble[i] * GetCurrentData.coefficient * b));
			if(max < sumChargeDouble[i]){
				max = sumChargeDouble[i];
				hour = i;
			}
			sum += sumChargeDouble[i];
		}
		double avg = sum / (date.getHours()+1);//ƽ������
		
		clientBurthenCurveChart.setSumChargeDoubleList(sumChargeDouble);
		clientBurthenCurveChart.exe(ChargeChartActivity.this, curveChart);
		
		TextView charge = (TextView)findViewById(R.id.chargeNowText);
		TextView maxCharge = (TextView)findViewById(R.id.maxChargeText);
		TextView chargeFactor = (TextView)findViewById(R.id.chargeFactorText);
		
		maxCharge.setText(String.valueOf(max)+"kW"+"("+(date.getMonth()+1)+"��"+date.getDate()+"��"+hour+"ʱ)");
		chargeFactor.setText(String.valueOf(df.format(avg/max))+"("+(date.getMonth()+1)+"��"+date.getDate()+"��)");
		charge.setText(String.valueOf(GetCurrentData.chargeDoubleList.get(11)[GetCurrentData.textViewNum-1])+"kW");
		
		ImageView returnButton = (ImageView)findViewById(R.id.scan_back_left);
		returnButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				ChargeChartActivity.this.onBackPressed();
			}
		});
		
	}
}
