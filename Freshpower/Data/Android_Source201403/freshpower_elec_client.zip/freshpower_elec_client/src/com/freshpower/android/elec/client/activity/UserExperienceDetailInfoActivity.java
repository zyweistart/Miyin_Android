package com.freshpower.android.elec.client.activity;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.GetCurrentData;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.TextView;

public class UserExperienceDetailInfoActivity extends Activity {
	public DecimalFormat df =new DecimalFormat("0.00"); //��ȡ��С�������λ
	public OnOffThread myThread = new OnOffThread();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_detail_info);
		ActivityUtil.addActivity(this);
		myThread.start();
	}
    private Handler  handler = new Handler(){
    	public void handleMessage(android.os.Message msg) {
    		if(msg.what==1){
    			setCurrentTextView();
    		}
    	};
    };
    
    class OnOffThread extends Thread{
    	
    	private boolean isDestory=false;
    	
    	void setDestory(boolean isDestory){
    		this.isDestory = isDestory;
    	}
    	
    	@Override
    	public void run() {
    		try {
        		while(!isDestory){
					if(isDestory)break;
	            	Message msg  = new Message();
	            	msg.what = 1;
	            	handler.sendMessage(msg);
	            	Thread.sleep(500);
        		}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
    	}
    }
    private void setCurrentTextView(){
    	//�����ı���
    	TextView lineCharge1 = (TextView)findViewById(R.id.soft_line_charge1);
    	TextView lineCharge2 = (TextView)findViewById(R.id.soft_line_charge2);
    	TextView lineCharge3 = (TextView)findViewById(R.id.soft_line_charge3);
    	TextView lineCharge4 = (TextView)findViewById(R.id.soft_line_charge4);
    	TextView lineCharge5 = (TextView)findViewById(R.id.soft_line_charge5);
    	TextView lineCharge6 = (TextView)findViewById(R.id.soft_line_charge6);
    	TextView lineCharge7 = (TextView)findViewById(R.id.soft_line_charge7);
    	TextView lineCharge8 = (TextView)findViewById(R.id.soft_line_charge8);
    	//�����ı���
    	TextView lineCurrent1 = (TextView)findViewById(R.id.soft_line_current1);
    	TextView lineCurrent2 = (TextView)findViewById(R.id.soft_line_current2);
    	TextView lineCurrent3 = (TextView)findViewById(R.id.soft_line_current3);
    	TextView lineCurrent4 = (TextView)findViewById(R.id.soft_line_current4);
    	TextView lineCurrent5 = (TextView)findViewById(R.id.soft_line_current5);
    	TextView lineCurrent6 = (TextView)findViewById(R.id.soft_line_current6);
    	TextView lineCurrent7 = (TextView)findViewById(R.id.soft_line_current7);
    	TextView lineCurrent8 = (TextView)findViewById(R.id.soft_line_current8);
    	//����״̬
    	TextView lineOpenType1 = (TextView)findViewById(R.id.soft_line_openType1);
    	TextView lineOpenType2 = (TextView)findViewById(R.id.soft_line_openType2);
    	TextView lineOpenType3 = (TextView)findViewById(R.id.soft_line_openType3);
    	TextView lineOpenType4 = (TextView)findViewById(R.id.soft_line_openType4);
    	TextView lineOpenType5 = (TextView)findViewById(R.id.soft_line_openType5);
    	TextView lineOpenType6 = (TextView)findViewById(R.id.soft_line_openType6);
    	TextView lineOpenType7 = (TextView)findViewById(R.id.soft_line_openType7);
    	TextView lineOpenType8 = (TextView)findViewById(R.id.soft_line_openType8);
    	//��������
    	TextView lineFactorPower1 = (TextView)findViewById(R.id.soft_line_factorPower1);
    	TextView lineFactorPower2 = (TextView)findViewById(R.id.soft_line_factorPower2);
    	TextView lineFactorPower3 = (TextView)findViewById(R.id.soft_line_factorPower3);
    	TextView lineFactorPower4 = (TextView)findViewById(R.id.soft_line_factorPower4);
    	TextView lineFactorPower5 = (TextView)findViewById(R.id.soft_line_factorPower5);
    	TextView lineFactorPower6 = (TextView)findViewById(R.id.soft_line_factorPower6);
    	TextView lineFactorPower7 = (TextView)findViewById(R.id.soft_line_factorPower7);
    	TextView lineFactorPower8 = (TextView)findViewById(R.id.soft_line_factorPower8);
    	
    	List<TextView> listCharge = new ArrayList<TextView>();
    	listCharge.add(lineCharge1);
    	listCharge.add(lineCharge2);
    	listCharge.add(lineCharge3);
    	listCharge.add(lineCharge4);
    	listCharge.add(lineCharge5);
    	listCharge.add(lineCharge6);
    	listCharge.add(lineCharge7);
    	listCharge.add(lineCharge8);
    	List<TextView> listCurrent = new ArrayList<TextView>();
    	listCurrent.add(lineCurrent1);
    	listCurrent.add(lineCurrent2);
    	listCurrent.add(lineCurrent3);
    	listCurrent.add(lineCurrent4);
    	listCurrent.add(lineCurrent5);
    	listCurrent.add(lineCurrent6);
    	listCurrent.add(lineCurrent7);
    	listCurrent.add(lineCurrent8);
    	List<TextView> listOpenList = new ArrayList<TextView>();
    	listOpenList.add(lineOpenType1);
    	listOpenList.add(lineOpenType2);
    	listOpenList.add(lineOpenType3);
    	listOpenList.add(lineOpenType4);
    	listOpenList.add(lineOpenType5);
    	listOpenList.add(lineOpenType6);
    	listOpenList.add(lineOpenType7);
    	listOpenList.add(lineOpenType8);
    	List<TextView> listFactorPowerList = new ArrayList<TextView>();
    	listFactorPowerList.add(lineFactorPower1);
    	listFactorPowerList.add(lineFactorPower2);
    	listFactorPowerList.add(lineFactorPower3);
    	listFactorPowerList.add(lineFactorPower4);
    	listFactorPowerList.add(lineFactorPower5);
    	listFactorPowerList.add(lineFactorPower6);
    	listFactorPowerList.add(lineFactorPower7);
    	listFactorPowerList.add(lineFactorPower8);
    	double[] charge = GetCurrentData.chargeDoubleList.get(11);
    	Boolean[] finalB = GetCurrentData.finalB;
    	for(int i = 0 ; i < 8 ; i++){
    		listCharge.get(i).setText(df.format(charge[i]));
    		listFactorPowerList.get(i).setText(df.format(GetCurrentData.powerFactor));
    		if(finalB[i]){
    			listOpenList.get(i).setText("��");
    		}else{
    			listOpenList.get(i).setText("��");
    		}
    	}
    	
    	double[][] temp = null;
		temp = GetCurrentData.currentList.get(11).get(0);
        for(int x = 0; x < 4 ; x++){
        	StringBuffer current = new StringBuffer();
        	for(char j = 'a'; j < 'd' ;j++){
        		current.append("I"+j+"="+df.format(temp[x][j-97])+";");
        	}
        	listCurrent.get(x).setText(current);
        }
	
		temp = GetCurrentData.currentList.get(11).get(1);
		for(int x = 0; x < 4 ; x++){
			StringBuffer current = new StringBuffer();
        	for(char j = 'a'; j < 'd' ;j++){
        		current.append("I"+j+"="+df.format(temp[x][j-97])+";");
        	}
        	listCurrent.get(x+4).setText(current);
        }
    }
    @Override
    protected void onDestroy() {
    	// TODO Auto-generated method stub
    	if(myThread != null){
    		myThread.setDestory(true);
    	}
    	super.onDestroy();
    }
}
