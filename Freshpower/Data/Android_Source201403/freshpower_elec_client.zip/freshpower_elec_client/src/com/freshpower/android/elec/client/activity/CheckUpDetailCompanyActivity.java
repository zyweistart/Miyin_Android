package com.freshpower.android.elec.client.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.conn.HttpHostConnectException;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.common.CheckUpDetailAdapter;
import com.freshpower.android.elec.client.common.LogFactory;
import com.freshpower.android.elec.client.domain.CheckUpDetailInfo;
import com.freshpower.android.elec.client.netapi.CheckUpDetailApi;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;

public class CheckUpDetailCompanyActivity extends Activity {
	private LogFactory logger = LogFactory.getLogger(CheckUpDetailCompanyActivity.class);
	private RoundCornerListView groupOnelistview;
	private List<Map<String, Object>> checkUpList;
	private ProgressDialog processProgress;
	private Handler handler = new Handler();
	private String qttask;
	private String qtkey;
	private RelativeLayout checkupRelayout;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.activity_checkup_detail_company);
		ImageView backBtn = (ImageView)findViewById(R.id.nav_left);
		backBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				CheckUpDetailCompanyActivity.this.onBackPressed();
			}
		});
		Intent intent = getIntent();
		qttask = intent.getStringExtra("taskId");//����id
		qtkey = intent.getStringExtra("equipmentId");//�豸id
		findViews();
		processProgress = ProgressDialog.show(CheckUpDetailCompanyActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(){
			public void run() {
				checkUpList = getGroupOnelistData();
				Message msgMessage = new Message();
				CheckUpDetailCompanyActivity.this.xHandler.sendMessage(msgMessage);
			}
		}.start();
	}
	
	private List<Map<String, Object>> getGroupOnelistData(){
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		try {
			Map checkUpMap = CheckUpDetailApi.getCheckUpInfoList(qttask,qtkey);
			if(checkUpMap.get("result").equals("1")) {
				List<CheckUpDetailInfo> checkUpInfoList=(List<CheckUpDetailInfo>) checkUpMap.get("checkUpInfoList");
				for(CheckUpDetailInfo checkUp : checkUpInfoList){
					Map<String, Object> listItem = new HashMap<String, Object>();
					listItem.put(AppConstant.CheckUpDetail.SCOUTCHECK_CONTENT, checkUp.getScoutcheckContent());//��������
					listItem.put(AppConstant.CheckUpDetail.SCOUTCHECK, checkUp.getScoutcheck());//��д���
					logger.d("elecClient_CheckUpDetailCompanyActivity_BID","SCOUTCHECK_CONTENT:"+ checkUp.getScoutcheckContent() );
					listItems.add(listItem);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listItems;
	}
	
	private Handler xHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			setAdapter();
			processProgress.dismiss();
		}
	};
	
	private void findViews(){
		groupOnelistview = (RoundCornerListView)findViewById(R.id.checkupListView);
		checkupRelayout = (RelativeLayout)findViewById(R.id.checkup_relayout);
	}
	
	
	private void setAdapter(){
		CheckUpDetailAdapter sysOneAdapter = new CheckUpDetailAdapter(checkUpList,CheckUpDetailCompanyActivity.this,R.layout.listitem_checkup_style);
		groupOnelistview.setAdapter(sysOneAdapter);
		setListViewHeightBasedOnChildren(groupOnelistview);
		checkupRelayout.setVisibility(0);
	}
	
	public void setListViewHeightBasedOnChildren(ListView listView) {
		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null) {
			return;
		}
		int totalHeight = 0;
		for (int i = 0; i < listAdapter.getCount(); i++) {
			View listItem = listAdapter.getView(i, null, listView);
			//View listItem = inflater.inflate(android.R.layout.simple_expandable_list_item_1, null);
			listItem.measure(0, 0);
			totalHeight += listItem.getMeasuredHeight();
		}
		ViewGroup.LayoutParams params = listView.getLayoutParams();
		params.height = totalHeight * 2
				+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
		listView.setLayoutParams(params);
	}
}
