package com.freshpower.android.elec.client.activity;

import java.io.File;

import org.apache.http.conn.HttpHostConnectException;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.AppCache;
import com.freshpower.android.elec.client.common.DBOperater;
import com.freshpower.android.elec.client.common.FileUtil;
import com.freshpower.android.elec.client.common.MD5;
import com.freshpower.android.elec.client.domain.LoginInfo;
import com.freshpower.android.elec.client.netapi.LoginInfoDataApi;


public class LoginActivity  extends Activity {
	private LoginInfo loginInfo;
	private ProgressDialog processProgress;
	private Handler handler = new Handler();

	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		ActivityUtil.addActivity(this);
		Button loginSub=(Button)findViewById(R.id.loginSub);
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(LoginActivity.this,HomeLoginTypeActivity.class);
				startActivity(intent);
				finish();
			}
		});
		loginSub.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				EditText loginName_et=(EditText)findViewById(R.id.loginName);
				EditText loginPwd_et=(EditText)findViewById(R.id.loginPwd);
				if(loginName_et.getText().toString().equals(""))
				{
					Toast.makeText(LoginActivity.this, R.string.login_name_msg,Toast.LENGTH_SHORT).show();
					return;
				}else if(loginName_et.getText().toString().indexOf(" ")!=-1){
					Toast.makeText(LoginActivity.this, R.string.login_namepwd_msg,Toast.LENGTH_SHORT).show();
					return;
				}
				if(loginPwd_et.getText().toString().equals(""))
				{
					Toast.makeText(LoginActivity.this, R.string.login_pwd_msg,Toast.LENGTH_SHORT).show();
					return;
				}
				loginInfo=new LoginInfo();
				loginInfo.setLoginName(loginName_et.getText().toString());
				String pwd=loginPwd_et.getText().toString();
				loginInfo.setLoginPwd(MD5.encrypt(pwd.toUpperCase()));
				processProgress = ProgressDialog.show(LoginActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
				new Thread(new Runnable(){
					String msgContent;
					@Override
					public void run() {
						try {
							loginInfo=LoginInfoDataApi.getLoginInfo(loginInfo);
							if(loginInfo.getLoginStatus()==1){
								writeLoginInfoContent(loginInfo);//�û���Ϣ���浽�ļ�
								AppCache.put(AppCache.LOGININFO_OBJ, loginInfo);
								
								//������������㲥
								Intent intent = new Intent();
								intent.setAction(ClientElecWidgetProvider.REFRESH_ACTION);
								sendBroadcast(intent);
								
								msgContent=getResources().getString(R.string.login_success_msg); 
								intent = new Intent(LoginActivity.this, HomeCompanyActivity.class);
								intent.putExtra("isFirst", "isFirst");
								startActivity(intent);
								finish();
							}else if(loginInfo.getLoginStatus()==0){
								msgContent=getResources().getString(R.string.login_lose_msg); 
								Intent intent = new Intent(LoginActivity.this, LoginActivity.class);
								startActivity(intent);
								finish();
							}
						}catch (HttpHostConnectException e) {
							msgContent=getResources().getString(R.string.msg_abnormal_network); 
						}catch (Exception e) {
							msgContent=getResources().getString(R.string.msg_abnormal_net2work); 
						}finally{
							processProgress.dismiss();
							handler.post(new Runnable() {
								@Override
								public void run() {
									Toast.makeText(LoginActivity.this, msgContent, Toast.LENGTH_SHORT).show(); 								
								}
							});
						}
					}
				}).start();
			}

		});
	}
	public void writeLoginInfoContent(LoginInfo loginInfo){
		if(!FileUtil.isFileExist(FileUtil.getDBFilePath())){
			try {
				File dbFile = new File(FileUtil.getDBFilePath());
				FileUtil.createFolder(dbFile.getParent());
				FileUtil.createFile(dbFile);
			} catch (Exception e) {
				Log.e("dberror", e.toString());
				e.printStackTrace();
			}
		}
		String fileContent = FileUtil.read(FileUtil.getDBFilePath());
		fileContent = loginInfo.getLoginName()
				+ "|"
				+ loginInfo.getLoginPwd()
				+ "|"
				+ loginInfo.getCpId()
				+ "|"
				+ loginInfo.getCpName()
				+ "|"
				+ fileContent.substring(fileContent
						.lastIndexOf('|') + 1);
		FileUtil.writeBeforeClearContent(
				FileUtil.getDBFilePath(), fileContent); 
	}
}
