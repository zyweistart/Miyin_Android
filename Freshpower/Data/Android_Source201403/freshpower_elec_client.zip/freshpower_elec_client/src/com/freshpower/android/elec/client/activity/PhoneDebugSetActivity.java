package com.freshpower.android.elec.client.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ScrollView;

public class PhoneDebugSetActivity extends Activity {
	private RoundCornerListView groupOnelistview;
	private RoundCornerListView groupTwolistview;
	private String[] menuNames;
	private int[] menuIcoIds;
	private ScrollView scrollview;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_phone_debug_set);
		ActivityUtil.addActivity(this);
		findViews();
		setAdapter();
		
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
        iv.setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
        		PhoneDebugSetActivity.this.onBackPressed();
			}
		});
		
		scrollview.smoothScrollTo(0, 0);
	}

	private void findViews() {
		groupOnelistview = (RoundCornerListView)findViewById(R.id.setMenulistviewOne);
		groupTwolistview = (RoundCornerListView)findViewById(R.id.setMenulistviewTwo);
		scrollview = (ScrollView)findViewById(R.id.scrollview);
	}

	private void setAdapter() {
		PhoneDebugSetGroupOneAdapter sysOneAdapter = new PhoneDebugSetGroupOneAdapter(getGrouplistData(R.id.setMenulistviewOne),PhoneDebugSetActivity.this,R.layout.listitem_phone_debug);
		groupOnelistview.setAdapter(sysOneAdapter);
		setListViewHeightBasedOnChildren(groupOnelistview);
		
		PhoneDebugSetGroupTwoAdapter sysTwoAdapter = new PhoneDebugSetGroupTwoAdapter(getGrouplistData(R.id.setMenulistviewTwo),PhoneDebugSetActivity.this,R.layout.listitem_phone_two_debug);
		groupTwolistview.setAdapter(sysTwoAdapter);
		setListViewHeightBasedOnChildren(groupTwolistview);
		
		
	}

	private List<Map<String, Object>> getGrouplistData(int groupListId){
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		if(groupListId==R.id.setMenulistviewOne){
			menuNames=getResources().getStringArray(R.array.phoneDebugSet_GroupOne);
			for (int i = 0; i < menuNames.length; i++)
			{
				Map<String, Object> listItem = new HashMap<String, Object>();
				listItem.put("menuNames", menuNames[i]);
				listItems.add(listItem);
			}
		}else if(groupListId==R.id.setMenulistviewTwo){
			menuNames=getResources().getStringArray(R.array.phoneDebugSet_GroupTwo);
			String[] menuNamesRemark = getResources().getStringArray(R.array.phoneDebugSet_GroupTwoRemarkValue);
			
			for (int i = 0; i < menuNames.length; i++)
			{
				Map<String, Object> listItem = new HashMap<String, Object>();
				listItem.put("menuNames", menuNames[i]);
				listItem.put("menuNamesRemark", menuNamesRemark[i]);
				listItems.add(listItem);
			}
		}
		
		return listItems;
	}
	
	/***
     * ��̬����listview�ĸ߶�
     * 
     * @param listView
     */
    public void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            return;
        }
        int totalHeight = 0;
        for (int i = 0; i < listAdapter.getCount(); i++) {
           View listItem = listAdapter.getView(i, null, listView);
        	//View listItem = inflater.inflate(android.R.layout.simple_expandable_list_item_1, null);
            listItem.measure(0, 0);
            totalHeight += listItem.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight
                + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        // params.height += 5;// if without this statement,the listview will be
        // a
        // little short
        // listView.getDividerHeight()��ȡ�����ָ���ռ�õĸ߶�
        // params.height���õ�����ListView������ʾ��Ҫ�ĸ߶�
        listView.setLayoutParams(params);
    }
	
}
