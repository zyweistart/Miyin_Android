package com.freshpower.android.elec.client.activity;

import android.support.v4.app.FragmentActivity;

//
//import java.util.ArrayList;
//import java.util.List;
//
//import com.freshpower.android.elec.client.R;
//import com.freshpower.android.elec.client.common.ActivityUtil;
//import com.freshpower.android.elec.client.common.AppCache;
//import com.freshpower.android.elec.client.common.AppConstant;
//import com.freshpower.android.elec.client.common.SystemServiceUtil;
//import com.freshpower.android.elec.client.domain.GpsDataInfo;
//import com.freshpower.android.elec.client.domain.LoginInfo;
//import com.freshpower.android.elec.client.netapi.GpsDataApi;
//import com.google.android.gms.common.ConnectionResult;
//import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
//import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
//import com.google.android.gms.location.LocationClient;
//import com.google.android.gms.location.LocationListener;
//import com.google.android.gms.location.LocationRequest;
//import com.google.android.gms.maps.CameraUpdateFactory;
//import com.google.android.gms.maps.GoogleMap;
//import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
//import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
//import com.google.android.gms.maps.SupportMapFragment;
//import com.google.android.gms.maps.model.BitmapDescriptorFactory;
//import com.google.android.gms.maps.model.LatLng;
//import com.google.android.gms.maps.model.Marker;
//import com.google.android.gms.maps.model.MarkerOptions;
//
//import android.app.AlertDialog;
//import android.content.DialogInterface;
//import android.content.Intent;
//import android.content.DialogInterface.OnClickListener;
//import android.location.Location;
//import android.net.Uri;
//import android.os.Bundle;
//import android.support.v4.app.FragmentActivity;
//import android.view.Window;
//import android.widget.Toast;
//
public class LookUpElecActivity extends FragmentActivity {
//public class LookUpElecActivity extends FragmentActivity  implements OnMarkerClickListener, OnInfoWindowClickListener,ConnectionCallbacks, OnConnectionFailedListener, LocationListener {
//
//	private GoogleMap mMap;
//	static final int DATE_DIALOG_ID = 0;
//	static final int TIME_DIALOG_ID = 1;
//	private final float mapZoom = 10;
////	private LatLng defaultGpsLatLng = new LatLng(30.287786360161632,
////			120.15082687139511);
//	//����
//	private LatLng defaultGpsLatLng = new LatLng(29.997461006205593,120.6018155523682);
//	private LocationClient mLocationClient;
//	private static final LocationRequest REQUEST = LocationRequest.create()
//		      .setInterval(5000)         // 5 seconds
//		      .setFastestInterval(16)    // 16ms = 60fps
//		      .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
//
//	@Override
//	protected void onCreate(Bundle savedInstanceState) {
//		super.onCreate(savedInstanceState);
//		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
//		setContentView(R.layout.activity_lookup_elec);
//		ActivityUtil.addActivity(this);
//
//		if (!checkSetUpMapEnvir()) {
//			return;
//		}
//		
//		setUpMapIfNeeded();
//	}
//
//
//
//	@Override
//	protected void onResume() {
//		super.onResume();
//		setUpMapIfNeeded();
//		//setUpLocationClientIfNeeded();
//		//mLocationClient.connect();
//	}
//	
//	@Override
//	public void onPause() {
//		super.onPause();
//	    if (mLocationClient != null) {
//	      mLocationClient.disconnect();
//	    }
//	}
//
//	private void setUpMapIfNeeded() {
//		if (mMap == null) {
//			mMap = ((SupportMapFragment) getSupportFragmentManager()
//					.findFragmentById(R.id.map)).getMap();
//			if (mMap != null) {
//				setUpMap();
//			}
//		}
//	}
//
//	private boolean checkReady() {
//        if (mMap == null) {
//            Toast.makeText(this, R.string.map_not_ready, Toast.LENGTH_SHORT).show();
//            return false;
//        }
//        return true;
//    }
//
//	private void setUpMap() {
//
//		mMap.clear();
//
//		addMarkersToMap();
//
//		mMap.setOnMarkerClickListener(this);
//		mMap.setOnInfoWindowClickListener(this);
//		//mMap.setMyLocationEnabled(true);
//		
//		mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultGpsLatLng,
//				mapZoom));
//	}
//
//	private List<LatLng> latLngArr = new ArrayList<LatLng>();
//    private LatLng latLngItem=null;
//	private void addMarkersToMap() {
//		
//		List<GpsDataInfo> gpsDataInfoList =  getFoundEList();
//		
//		if(gpsDataInfoList == null){
//			latLngItem = new LatLng(29.997461006205593, 120.6018155523682);
//			latLngArr.add(latLngItem);
//			
//			latLngItem = new LatLng(29.990250398850474, 120.54001745666507);
//			latLngArr.add(latLngItem);
//			
//			latLngItem = new LatLng(29.936414481847535, 120.57194647277835);
//			latLngArr.add(latLngItem);
//	
//			latLngItem = new LatLng(29.942513384159106, 120.57537970031741);
//			latLngArr.add(latLngItem);
//			
//			latLngItem = new LatLng(29.987425482052284, 120.657433838501);
//			latLngArr.add(latLngItem);
//			
//			latLngItem = new LatLng(29.985715624943672, 120.58688101257327);
//			latLngArr.add(latLngItem);
//			
//			latLngItem = new LatLng(30.168762870400922, 120.65537390197757);
//			latLngArr.add(latLngItem);
//			
//			latLngItem = new LatLng(29.948760652467562, 120.44440206970218);
//			latLngArr.add(latLngItem);
//			
//			latLngItem = new LatLng(29.968950031785944, 120.5882543035889);
//			latLngArr.add(latLngItem);
//			
//			for (int i = 0; i < latLngArr.size(); i++) {
//				// Uses a custom icon.
//		        mMap.addMarker(new MarkerOptions()
//		                .position(latLngArr.get(i))
//		                .title(getResources().getString(R.string.msg_map_marker_title))
//		                .snippet(getResources().getString(R.string.msg_map_marker_snippet))
//		                .icon(BitmapDescriptorFactory.fromResource(R.drawable.map_mark)));
//			}
//		}else{
//			GpsDataInfo gpsDataInfo = null;
//			for (int i = 0; i < gpsDataInfoList.size(); i++) {
//				gpsDataInfo = gpsDataInfoList.get(i);
//				// Uses a custom icon.
//		        mMap.addMarker(new MarkerOptions()
//		                .position(new LatLng(Double.valueOf(gpsDataInfo.getLatitude()), gpsDataInfo.getLongitude()))
//		                .title(gpsDataInfo.getLoginInfo().getUserName())
//		                .snippet(getResources().getString(R.string.msg_map_marker_snippet))
//		                .icon(BitmapDescriptorFactory.fromResource(R.drawable.map_mark)));
//			}
//		}
//        
//	}
//
//
//	private boolean checkSetUpMapEnvir() {
//		boolean isValid = true;
//
//		if (!SystemServiceUtil.isAppsInstalled(this,
//				AppConstant.GooglePlayPackageName.GOOGLE_PLAY_SERVICE)) {
//			builderGooglePlayDialog(
//					AppConstant.GooglePlayPackageName.GOOGLE_PLAY_SERVICE,
//					R.string.msg_google_play_service_Install);
//			isValid = false;
//		} else if (!SystemServiceUtil.isAppsInstalled(this,
//				AppConstant.GooglePlayPackageName.GOOGLE_PLAY_SOTRE)) {
//			builderGooglePlayDialog(
//					AppConstant.GooglePlayPackageName.GOOGLE_PLAY_SOTRE,
//					R.string.msg_google_play_store_Install);
//			isValid = false;
//		}
//
//		return isValid;
//	}
//
//	private void builderGooglePlayDialog(String googlePlayPackageName, int msgId) {
//		AlertDialog.Builder builder = new AlertDialog.Builder(this);
//		builder.setMessage(getResources().getString(msgId));
//		builder.setCancelable(false);
//		builder.setPositiveButton(R.string.soft_btn_continue,
//				getGoogleMapsListener(googlePlayPackageName));
//		builder.setNegativeButton(R.string.soft_btn_cancle,
//				new OnClickListener() {
//					@Override
//					public void onClick(DialogInterface dialog, int which) {
//						dialog.dismiss();
//						LookUpElecActivity.this.finish();
//					}
//				});
//		AlertDialog dialog = builder.create();
//		dialog.setCanceledOnTouchOutside(false);
//		dialog.show();
//	}
//
//	private OnClickListener getGoogleMapsListener(
//			final String googlePlayPackageName) {
//		return new OnClickListener() {
//			@Override
//			public void onClick(DialogInterface dialog, int which) {
//				Intent intent = new Intent(Intent.ACTION_VIEW,
//						Uri.parse("market://details?id="
//								+ googlePlayPackageName));
//				startActivity(intent);
//
//				// Finish the activity so they can't circumvent the check
//				dialog.dismiss();
//				finish();
//			}
//		};
//	}
//	
//	@Override
//	public void onInfoWindowClick(Marker marker) {
//		Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+AppConstant.PHONE_NUM_FRESHPOEWR));  
//		LookUpElecActivity.this.startActivity(intent);
//    }
//
//
//
//	@Override
//	public boolean onMarkerClick(Marker arg0) {
//		// TODO Auto-generated method stub
//		return false;
//	}
//
//
//	boolean flag = false;
//	@Override
//	public void onLocationChanged(Location location) {
//		LatLng latLng = new LatLng(location.getLatitude(),location.getLongitude());
//		if(!flag){
//			mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng,
//					mapZoom));
//			flag = true;
//		}
//	}
//
//
//
//	@Override
//	public void onConnectionFailed(ConnectionResult arg0) {
//		// TODO Auto-generated method stub
//		
//	}
//
//
//
//	@Override
//	public void onConnected(Bundle connectionHint) {
//		mLocationClient.requestLocationUpdates(
//		        REQUEST,
//		        this);
//	}
//
//
//
//	@Override
//	public void onDisconnected() {
//		// TODO Auto-generated method stub
//		
//	}
//	
//	private void setUpLocationClientIfNeeded() {
//	    if (mLocationClient == null) {
//	      mLocationClient = new LocationClient(
//	          getApplicationContext(),
//	          this,  // ConnectionCallbacks
//	          this); // OnConnectionFailedListener
//	    }
//	  }
//
//	/**!
//	 * �ҵ繤��Ϣ
//	 * @return �繤��Ϣ����
//	 */
//	private List<GpsDataInfo> getFoundEList() {
//		List<GpsDataInfo> gpsDataInfoList=null;
//		try {
//			LoginInfo loginInfo = (LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
//			gpsDataInfoList = GpsDataApi.getFoundE(loginInfo.getCpId());
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return gpsDataInfoList;
//	}
}
