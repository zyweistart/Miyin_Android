package com.freshpower.android.elec.client.common;   

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;


public class MathUtil {
	
	/**
	 * ��ȡ�����������ֵ
	 * @param arr
	 * @return
	 */
	public static double max(double[] arr) {
		double maxValue = arr[0];
		for(int i = 1; i < arr.length; i++) {
			maxValue = Math.max(maxValue, arr[i]);
		}
		return maxValue;
    }
	
	/**
	 * ��ȡ��������С��ֵ
	 * @param arr
	 * @return
	 */
	public static double min(double[] arr) {
		double minValue = arr[0];
		for(int i = 1; i < arr.length; i++) {
			minValue = Math.min(minValue, arr[i]);
		}
		return minValue;
    }
	
	/**
	 * ��ȡ������ƽ����ֵ
	 * @param arr
	 * @return
	 */
	public static double avg(double[] arr) {
		double maxSum = 0;
		for(int i = 0; i < arr.length; i++) {
			maxSum += arr[i];
		}
		return maxSum/arr.length;
    }
	
	/**
	 * ����ֵ��������
	 * @param arr
	 * @return
	 */
	public static double[] change(double[] arr, int index) {
		double[] arrReturn = new double[arr.length];
		int length = arr.length;
		for(int i = 0; i < arr.length; i++) {
			arrReturn[length-1-i] = arr[i];
		}
		double[] arrReturnIndex = new double[index];
		for(int i = 0; i < index; i++) {
			arrReturnIndex[index-1-i] = arrReturn[i];
		}
		return arrReturnIndex;
    }
	
	/**
	 * ����ת��Ϊmm:ss��ʽ,��60���Զ�����Ϊ����
	 * @param time
	 * @return
	 */
	public static String changeTime(int time) {
   	 	GregorianCalendar gc = new GregorianCalendar();
	    gc.setTimeInMillis(time * 1000);
	    SimpleDateFormat format = new SimpleDateFormat("mm:ss");
	   	return format.format(gc.getTime());
   }
	
	/**
	 * ��ȡ��ǰʱ��ǰtimeLong���ֵ
	 * @return
	 * @throws Exception
	 */
	public static String getDateByDay(int day){
	        Calendar date = Calendar.getInstance();
	        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	        date.add(Calendar.DATE, -day);
	        return sdf.format(date.getTime());
	}
	
	/**
	 * ��ȡ��ǰʱ��ǰtimeLong���ֵ
	 * @return
	 * @throws Exception
	 */
	public static String getDateByDay(){
        Calendar date = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm");
        return sdf.format(date.getTime());
	}
	
}
  
