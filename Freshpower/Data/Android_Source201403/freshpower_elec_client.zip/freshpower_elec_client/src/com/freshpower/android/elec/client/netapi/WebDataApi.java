package com.freshpower.android.elec.client.netapi;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import android.util.Log;

/**
 * @author yangz
 * 
 */
public class WebDataApi {
	private static final String TAG = "WebDataGetAPI";
	private static final String USER_AGENT = "Mozilla/4.5";
	private static final int HTTP_RES_SUCESS_STATUS = 200;
	private String charset = HTTP.UTF_8;
	private static final int ConnectionTimeoutSec = 5000;
	private static final int SoTimeout = 5000;
	private List<NameValuePair> params = new ArrayList<NameValuePair>();
	private MultipartEntity mulEntity = new MultipartEntity();

	public void addParam(String name, String value) {
		params.add(new BasicNameValuePair(name, value));
	}
	
	public void addParam(String name, File file) {
		mulEntity.addPart(name, new FileBody(file));
	}
	
	

	/**
	 * ��ȡpost������
	 * 
	 * @param url
	 * @return
	 * @throws Exception
	 */
	public String postRequest(String url) throws Exception {
		HttpPost httpPost = new HttpPost(url);
		int statusCode = 0;
		String result = null;
		// Log.d(TAG, "do the postRequest,url=" + url + "");
		try {
			HttpClient client = new DefaultHttpClient();
			client.getParams().setParameter(
					CoreConnectionPNames.CONNECTION_TIMEOUT,
					ConnectionTimeoutSec);
			client.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,
					SoTimeout);

			httpPost.setEntity(new UrlEncodedFormEntity(params, charset));
			HttpResponse httpResponse = client.execute(httpPost);

			statusCode = httpResponse.getStatusLine().getStatusCode();
			//Log.d(TAG, "statuscode = " + statusCode);
			if (statusCode == HTTP_RES_SUCESS_STATUS) {
				result = EntityUtils.toString(httpResponse.getEntity());
			}
			//Log.d("myDebug", result);
		} catch (Exception e) {
			Log.e(TAG, e.getMessage());
			throw e;
		} finally {
			httpPost.abort();
		}
		return result;
	}

	public String getCharset() {
		return charset;
	}

	public void setCharset(String charset) {
		this.charset = charset;
	}

	protected String getRequest(String url) throws Exception {
		//Log.d("sum", url);
		return getRequest(url, new DefaultHttpClient(new BasicHttpParams()));
	}

	/**
	 * ��ȡget������
	 * 
	 * @param url
	 * @param client
	 * @return
	 * @throws Exception
	 */
	protected String getRequest(String url, DefaultHttpClient client)
			throws Exception {
		String result = null;
		int statusCode = 0;
		StringBuffer sb = new StringBuffer(url);
		if (params != null && params.size() > 0) {
			sb.append("?");
			for (NameValuePair nameValuePairItem : params) {
				sb.append(nameValuePairItem.getName()).append("=")
						.append(nameValuePairItem.getValue()).append("&&");
			}
			url = sb.toString().substring(0, sb.toString().lastIndexOf("&&"));
		}
		HttpGet getMethod = new HttpGet(url);
//		Log.d("BID", "do the getRequest,url=" + url + "");
		try {
			getMethod.setHeader("User-Agent", USER_AGENT);
			// HttpParams params = new HttpParams();

			// �����û�������֤��Ϣ
			// client.getCredentialsProvider().setCredentials(
			// new AuthScope(null, -1),
			// new UsernamePasswordCredentials(mUsername, mPassword));

			HttpConnectionParams.setConnectionTimeout(client.getParams(),
					ConnectionTimeoutSec);
			HttpConnectionParams.setSoTimeout(client.getParams(), SoTimeout);

			HttpResponse httpResponse = client.execute(getMethod);
			// statusCode == 200 ����
			statusCode = httpResponse.getStatusLine().getStatusCode();
			//Log.d(TAG, "statuscode = " + statusCode);
			// �������ص�httpResponse��Ϣ
			result = retrieveInputStream(httpResponse.getEntity());
		} catch (Exception e) {
			Log.e(TAG, e.getMessage());
			throw e;
		} finally {
			getMethod.abort();
		}
		return result;
	}

	/**
	 * ����httpResponse��Ϣ,����String
	 * 
	 * @param httpEntity
	 * @return String
	 */
	protected String retrieveInputStream(HttpEntity httpEntity) {
		int length = (int) httpEntity.getContentLength();
		if (length < 0)
			length = 10000;
		StringBuffer stringBuffer = new StringBuffer(length);
		try {
			InputStreamReader inputStreamReader = new InputStreamReader(
					httpEntity.getContent(), charset);
			char buffer[] = new char[length];
			int count;
			while ((count = inputStreamReader.read(buffer, 0, length - 1)) > 0) {
				stringBuffer.append(buffer, 0, count);
			}
		} catch (UnsupportedEncodingException e) {
			Log.e(TAG, e.getMessage());
		} catch (IllegalStateException e) {
			Log.e(TAG, e.getMessage());
		} catch (IOException e) {
			Log.e(TAG, e.getMessage());
		}
		return stringBuffer.toString();
	}
	
	protected String postFileRequest(String url)
			throws Exception {
		HttpPost post = new HttpPost(url);
		HttpClient client = new DefaultHttpClient();
		
		if (params != null && params.size() > 0) {
			for (NameValuePair nameValuePairItem : params) {
				mulEntity.addPart(nameValuePairItem.getName(), new StringBody(nameValuePairItem.getValue()));
			}
		}

		post.setEntity(mulEntity);
		HttpResponse response = client.execute(post);
		int stateCode = response.getStatusLine().getStatusCode();
		StringBuffer sb = new StringBuffer();
		if (stateCode == HttpStatus.SC_OK) {
			HttpEntity result = response.getEntity();
			if (result != null) {
				InputStream is = result.getContent();
				BufferedReader br = new BufferedReader(
						new InputStreamReader(is));
				String tempLine;
				while ((tempLine = br.readLine()) != null) {
					sb.append(tempLine);
				}
			}
		}
		post.abort();
		return sb.toString();
	}
}
