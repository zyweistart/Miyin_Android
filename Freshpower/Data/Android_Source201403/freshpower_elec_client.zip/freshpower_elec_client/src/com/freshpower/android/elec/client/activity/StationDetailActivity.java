package com.freshpower.android.elec.client.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.common.StringUtil;
import com.freshpower.android.elec.client.domain.CustomerInfo;
import com.freshpower.android.elec.client.netapi.StationInfoDataApi;
import com.freshpower.android.elec.client.widget.PullDownListView;

public class StationDetailActivity extends FrameActivity  implements PullDownListView.OnRefreshListioner{
	private PullDownListView mPullDownView;
	private ListView mListView;
	private Resources res;
	private ImageButton homeBtn;
	private List<CustomerInfo> stationDetailList;
	private Handler mHandler = new Handler();
	private int pageSize = 10;//ÿҳ��ʾ
	private int currentPage =1;//��ǰҳ
	private int totalCnt=0;//�ܼ�¼��
	private int rs=999;//��ѯ���
	private SimpleAdapter adapter;
	private RelativeLayout progressRlt = null;
	List<Map<String, Object>> customerInfoMap;
	private ProgressDialog processProgress;
	private Handler handler = new Handler();


	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_stationdetaillv);
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(StationDetailActivity.this,StationActivity.class);
				startActivity(intent);
				finish();	
			}
		});


		mPullDownView = (PullDownListView) findViewById(R.id.sreach_list);
		mPullDownView.setRefreshListioner(this);
		mListView = mPullDownView.mListView;
		mListView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent,
					View view, int position, long id) {
				Intent it = new Intent(StationDetailActivity.this,StationDetailInfoActivity.class);
				Map map=(Map) customerInfoMap.get(position-1);
				it.putExtra("MeterName", String.valueOf(map.get("warnOne")));
				it.putExtra("ReportDate", String.valueOf(map.get("warnThree")));
				it.putExtra("SwitchStatus", String.valueOf(map.get("warnTwo")));
				it.putExtra("DayPower", String.valueOf(map.get("warnFour")));
				it.putExtra("Va",  String.valueOf(map.get("Va")));
				it.putExtra("Vb",  String.valueOf(map.get("Vb")));
				it.putExtra("Vc",  String.valueOf(map.get("Vc")));
				it.putExtra("Ia",  String.valueOf(map.get("Ia")));
				it.putExtra("Ib",  String.valueOf(map.get("Ib")));
				it.putExtra("Ic",  String.valueOf(map.get("Ic")));
				it.putExtra("Power",  String.valueOf(map.get("Power")));
				startActivity(it);
			}	
		});
		processProgress = ProgressDialog.show(StationDetailActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(){
			public void run() {
				customerInfoMap = getGroupOnelistData(stationDetailList);
				Message msgMessage = new Message();
				StationDetailActivity.this.xHandler.sendMessage(msgMessage);
			}
		}.start();

	}
	private Handler xHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			adapter = new SimpleAdapter(StationDetailActivity.this,customerInfoMap, 
					R.layout.listitem_stationdetail_style, 
					new String[] { AppConstant.ListItemWarnName.WARN_ONE, 
					AppConstant.ListItemWarnName.WARN_TWO,
					AppConstant.ListItemWarnName.WARN_THREE,
					AppConstant.ListItemWarnName.WARN_FOUR}, 
					new int[] { R.id.stationdetailOne,
					R.id.stationdetailTwo,
					R.id.stationdetailThree,
					R.id.stationdetailFour});
			mListView.setAdapter(adapter);
			if(customerInfoMap.size()==0){
				Toast.makeText(StationDetailActivity.this, R.string.noSearchResultMsg,Toast.LENGTH_SHORT).show();
				rs=AppConstant.Result.NO_COUNT;
			}
			setShow();
			//	    		progressRlt.setVisibility(View.GONE);
			mPullDownView.setVisibility(View.VISIBLE);
			processProgress.dismiss();
		};
	};
	private void setShow() {
		if(rs==AppConstant.Result.NO_COUNT){
			RelativeLayout noResultlayout = (RelativeLayout) findViewById(R.id.noResultlayout);
			noResultlayout.setVisibility(View.VISIBLE);
			mPullDownView.setMore(false);
		}else{
			mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
		}
		if(customerInfoMap.size()<10){
			mPullDownView.setMore(false);
		}
	}    
	@Override
	public void onRefresh() {
		// TODO Auto-generated method stub
		mHandler.postDelayed(new Runnable() {

			public void run() {
				customerInfoMap.clear();
				currentPage =1;
				customerInfoMap.addAll(getGroupOnelistData(stationDetailList));

				mPullDownView.onRefreshComplete();//�����ʾˢ�´�����ɺ������ļ���ˢ�½�������
				mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				if(customerInfoMap.size()<10){
					mPullDownView.setMore(false);
				}
				adapter.notifyDataSetChanged();	
			}
		}, 1500);

	}
	@Override
	public void onLoadMore() {
		mHandler.postDelayed(new Runnable() {
			public void run() {

				currentPage++;
				customerInfoMap.addAll(getGroupOnelistData(stationDetailList));

				mPullDownView.onLoadMoreComplete();//�����ʾ���ظ��ദ����ɺ������ļ��ظ�����棨���ػ��������������ࣩ
				//if(list.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
				if(customerInfoMap.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
					mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				else
					mPullDownView.setMore(false);
				adapter.notifyDataSetChanged();	

			}
		}, 1500);

	}
	private List<Map<String, Object>> getGroupOnelistData(List<CustomerInfo> stationDetailList){
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		Intent it=getIntent();
		String id =it.getStringExtra("ID");
		try {
			Map customerInfoMap=StationInfoDataApi.getStationDetailInfoList(pageSize,currentPage,id);
			if(!"0".equals(customerInfoMap.get("result"))){
				stationDetailList=(List<CustomerInfo>) customerInfoMap.get("customerDatailList");
				for (CustomerInfo customerInfo:stationDetailList)
				{
					Map<String, Object> listItem = new HashMap<String, Object>();
					listItem.put(AppConstant.ListItemWarnName.WARN_ONE, customerInfo.getMeterName());
					if(!StringUtil.isEmpty(customerInfo.getSwitchStatus())){
						listItem.put(AppConstant.ListItemWarnName.WARN_TWO, customerInfo.getSwitchStatus().equals("0")?"��":"��");
					}else{
						listItem.put(AppConstant.ListItemWarnName.WARN_TWO,"");
					}
					listItem.put(AppConstant.ListItemWarnName.WARN_THREE,customerInfo.getReportDate());
					listItem.put(AppConstant.ListItemWarnName.WARN_FOUR, customerInfo.getDayPower());
					listItem.put("Va", customerInfo.getVa());
					listItem.put("Vb", customerInfo.getVb());
					listItem.put("Vc", customerInfo.getVc());
					listItem.put("Ia", customerInfo.getIa());
					listItem.put("Ib", customerInfo.getIb());
					listItem.put("Ic", customerInfo.getIc());
					listItem.put("Power", customerInfo.getPower());
					listItems.add(listItem);
				}
				totalCnt = Integer.parseInt(String.valueOf(customerInfoMap.get("totalCount")));
				return listItems;
			}else{
				return listItems;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	/***
	 * ��̬����listview�ĸ߶�
	 * 
	 * @param listView
	 */
//	public void setListViewHeightBasedOnChildren(ListView listView) {
//		ListAdapter listAdapter = listView.getAdapter();
//		if (listAdapter == null) {
//			return;
//		}
//		int totalHeight = 0;
//		for (int i = 0; i < listAdapter.getCount(); i++) {
//			View listItem = listAdapter.getView(i, null, listView);
//			//View listItem = inflater.inflate(android.R.layout.simple_expandable_list_item_1, null);
//			listItem.measure(0, 0);
//			totalHeight += listItem.getMeasuredHeight();
//		}
//		ViewGroup.LayoutParams params = listView.getLayoutParams();
//		params.height = totalHeight
//				+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
//		listView.setLayoutParams(params);
//	}
	protected void onResume() {
		homeBtn = (ImageButton) findViewById(R.id.stationDataBtn);
		if(homeBtn!=null){
			homeBtn.setOnClickListener(null);
			homeBtn.setBackgroundResource(R.drawable.databtn_select);
		}

		TextView toolBtnTv = (TextView)findViewById(R.id.stationDataTv);
		toolBtnTv.setTextColor(getResources().getColor(R.color.station));

		super.onResume();
	}
}
