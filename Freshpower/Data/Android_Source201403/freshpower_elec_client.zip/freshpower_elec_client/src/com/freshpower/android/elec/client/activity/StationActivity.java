package com.freshpower.android.elec.client.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.domain.CustomerInfo;
import com.freshpower.android.elec.client.netapi.StationInfoDataApi;
import com.freshpower.android.elec.client.widget.PullDownListView;

public class StationActivity  extends FrameActivity  implements PullDownListView.OnRefreshListioner{
	private RoundCornerListView groupOnelistview;
	private PullDownListView mPullDownView;
	private ListView mListView;
	private Resources res;
	private ImageButton homeBtn;
	private List<CustomerInfo> customerInfoList;
	private Handler mHandler = new Handler();
	private int pageSize = 10;//ÿҳ��ʾ
	private int currentPage =1;//��ǰҳ
	private int totalCnt=0;//�ܼ�¼��
	private int rs=999;//��ѯ���
	private SimpleAdapter adapter;
	private RelativeLayout progressRlt = null;
	List<Map<String, Object>> customerInfoMap;
	private ProgressDialog processProgress;
	private Handler handler = new Handler();

	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_station);
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(StationActivity.this,HomeActivity.class);
				startActivity(intent);
				finish();	
			}
		});


		mPullDownView = (PullDownListView) findViewById(R.id.sreach_list);
		mPullDownView.setRefreshListioner(this);
		mListView = mPullDownView.mListView;
		mListView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent,
					View view, int position, long id) {
				Intent intent = new Intent(StationActivity.this,StationDetailActivity.class);
				Map map=(Map) customerInfoMap.get(position-1);
				intent.putExtra("ID", String.valueOf(map.get("ID")));
				startActivity(intent);
				finish();
			}	
		});
		processProgress = ProgressDialog.show(StationActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(){
			public void run() {
				customerInfoMap = getGroupOnelistData(customerInfoList);
				Message msgMessage = new Message();
				StationActivity.this.xHandler.sendMessage(msgMessage);
			}
		}.start();

	}
	private Handler xHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			adapter = new SimpleAdapter(StationActivity.this,customerInfoMap, 
					R.layout.listitem_station_style, 
					new String[] { AppConstant.ListItemWarnName.WARN_ONE, 
					AppConstant.ListItemWarnName.WARN_TWO,
					AppConstant.ListItemWarnName.WARN_THREE,
					AppConstant.ListItemWarnName.WARN_FOUR
			}, 
			new int[] { 
					R.id.stationOne,
					R.id.stationTwo,
					R.id.stationThree,
					R.id.stationFour});
			mListView.setAdapter(adapter);
			if(customerInfoMap.size()==0){
				rs=AppConstant.Result.NO_COUNT;
			}
			setShow();
			//	    		progressRlt.setVisibility(View.GONE);
			mPullDownView.setVisibility(View.VISIBLE);
			processProgress.dismiss();
		};
	};
	private void setShow() {
		if(rs==AppConstant.Result.NO_COUNT){
			RelativeLayout noResultlayout = (RelativeLayout) findViewById(R.id.noResultlayout);
			noResultlayout.setVisibility(View.VISIBLE);
			mPullDownView.setMore(false);
		}else{
			mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
		}
		if(totalCnt<10){
			mPullDownView.setMore(false);
		}
	}    
	@Override
	public void onRefresh() {
		// TODO Auto-generated method stub
		mHandler.postDelayed(new Runnable() {

			public void run() {
				customerInfoMap.clear();
				currentPage =1;
				customerInfoMap.addAll(getGroupOnelistData(customerInfoList));

				mPullDownView.onRefreshComplete();//�����ʾˢ�´�����ɺ������ļ���ˢ�½�������
				mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				if(customerInfoMap.size()<10){
					mPullDownView.setMore(false);
				}
				adapter.notifyDataSetChanged();	
			}
		}, 1500);

	}
	@Override
	public void onLoadMore() {
		mHandler.postDelayed(new Runnable() {
			public void run() {

				currentPage++;
				customerInfoMap.addAll(getGroupOnelistData(customerInfoList));

				mPullDownView.onLoadMoreComplete();//�����ʾ���ظ��ദ����ɺ������ļ��ظ�����棨���ػ��������������ࣩ
				//if(list.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
				if(customerInfoMap.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
					mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				else
					mPullDownView.setMore(false);
				adapter.notifyDataSetChanged();	

			}
		}, 1500);

	}


	private List<Map<String, Object>> getGroupOnelistData(List<CustomerInfo> customerInfoList){
		res = getResources();
		try {
			Map customerInfoMap=StationInfoDataApi.getStationInfoList(pageSize,currentPage);
			List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
			customerInfoList=(List<CustomerInfo>) customerInfoMap.get("customerInfoList");
			for (CustomerInfo customerInfo:customerInfoList)
			{
				Map<String, Object> listItem = new HashMap<String, Object>();
				listItem.put(AppConstant.ListItemWarnName.WARN_ONE, customerInfo.getCpName());
				listItem.put(AppConstant.ListItemWarnName.WARN_TWO, customerInfo.getTransCount());
				listItem.put(AppConstant.ListItemWarnName.WARN_THREE,customerInfo.getMaxDate());
				listItem.put(AppConstant.ListItemWarnName.WARN_FOUR, customerInfo.getMaxLoad());
				listItem.put("ID", customerInfo.getCpId());
				listItems.add(listItem);
			}
			totalCnt = Integer.parseInt(String.valueOf(customerInfoMap.get("totalCount")));
			return listItems;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	//	/***
	//	 * ��̬����listview�ĸ߶�
	//	 * 
	//	 * @param listView
	//	 */
	//	public void setListViewHeightBasedOnChildren(ListView listView) {
	//		ListAdapter listAdapter = listView.getAdapter();
	//		if (listAdapter == null) {
	//			return;
	//		}
	//		int totalHeight = 0;
	//		for (int i = 0; i < listAdapter.getCount(); i++) {
	//			View listItem = listAdapter.getView(i, null, listView);
	//			//View listItem = inflater.inflate(android.R.layout.simple_expandable_list_item_1, null);
	//			listItem.measure(0, 0);
	//			totalHeight += listItem.getMeasuredHeight();
	//		}
	//		ViewGroup.LayoutParams params = listView.getLayoutParams();
	//		params.height = totalHeight
	//				+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
	//		listView.setLayoutParams(params);
	//	}
	protected void onResume() {
		homeBtn = (ImageButton) findViewById(R.id.stationDataBtn);
		if(homeBtn!=null){
			homeBtn.setOnClickListener(null);
			homeBtn.setBackgroundResource(R.drawable.databtn_select);
		}

		TextView toolBtnTv = (TextView)findViewById(R.id.stationDataTv);
		toolBtnTv.setTextColor(getResources().getColor(R.color.station));

		super.onResume();
	}

}
