package com.freshpower.android.elec.client.activity;

import java.text.DecimalFormat;

import org.apache.http.conn.HttpHostConnectException;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Toast;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.StringUtil;
import com.freshpower.android.elec.client.netapi.AppraiseApi;

public class AppraiseActivity extends Activity {
	private EditText appraiseContent;
	private RatingBar ratingBar;
	private ProgressDialog processProgress;
	private String msgContent;
	private DecimalFormat df = new DecimalFormat("0");
	private Handler handler = new Handler();
	
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_appraise);
		appraiseContent = (EditText)findViewById(R.id.appraiseContent);
		ratingBar = (RatingBar)findViewById(R.id.app_ratingbar);
		
		// �����¼�
		ImageView returnButton = (ImageView)findViewById(R.id.appraise_return);
	 	returnButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				AppraiseActivity.this.onBackPressed();
			}
		});
	 	
 		// �ύ�¼�
 		Button appraiseSubButton = (Button)findViewById(R.id.appraiseSub);
		appraiseSubButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(StringUtil.isEmpty(appraiseContent.getText().toString())) {
					Toast.makeText(AppraiseActivity.this, getResources().getString(R.string.appraise_input), Toast.LENGTH_SHORT).show();
					return;
				} 
				processProgress = ProgressDialog.show(AppraiseActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
				new Thread(new Runnable(){

					@Override
					public void run() {
						String rs = "0";
						msgContent = getResources().getString(R.string.appraise_submit_msg);
						try {
							rs = AppraiseApi.submitAppraise(appraiseContent.getText().toString(), String.valueOf(df.format(ratingBar.getRating())));
						}catch (HttpHostConnectException e) {
							msgContent = getResources().getString(R.string.msg_abnormal_network);
							e.printStackTrace();
						}catch (Exception e) {
							msgContent = getResources().getString(R.string.msg_abnormal_network);
							e.printStackTrace();
						}finally{

							processProgress.dismiss();

							handler.post(new Runnable() {
								@Override
								public void run() {
									Toast.makeText(AppraiseActivity.this, msgContent, Toast.LENGTH_SHORT).show(); 								
								}
							});

							if(rs.equals("1")){
								finish();
							}
						}
					}

				}).start();
			}
		});
		ActivityUtil.addActivity(this);
	}
}