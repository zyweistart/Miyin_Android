package com.freshpower.android.elec.client.activity;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.AdapterView;
import android.widget.ListView;

public class RoundCornerListView extends ListView{

	public RoundCornerListView(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param context
	 * @param attrs
	 * @param defStyle
	 */
	public RoundCornerListView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param context
	 * @param attrs
	 */
	public RoundCornerListView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}

	
	/****
     * ���ش����¼�
     */
	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		// TODO Auto-generated method stub
		 switch (ev.getAction()) {
	        case MotionEvent.ACTION_DOWN:
	                int x = (int) ev.getX();
	                int y = (int) ev.getY();
	                int itemnum = pointToPosition(x, y);

	                if (itemnum == AdapterView.INVALID_POSITION)
	                        break;                 
	                else{
//	                	if(this.getId() ==  R.id.searchListView || this.getId() ==  R.id.setMenulistviewTwo){
//		                	if(itemnum==0){
//		                        if(itemnum==(getAdapter().getCount()-1)){                                    
//		                            setSelector(R.drawable.listview_round_corner_selector);
//		                        }else{
//		                            setSelector(R.drawable.listview_round_corner_top_selector);
//		                        }
//			                }else if(itemnum==(getAdapter().getCount()-1))
//			                        setSelector(R.drawable.listview_round_corner_bottom_selector);
//			                else{                            
//			                    setSelector(R.drawable.listview_round_corner_medium_selector);
//			                }
//	                	}else{
//	                		setSelector(R.drawable.listview_searchcondtion_corner_medium_selector);
//	                	}
	                }

	                break;
	        case MotionEvent.ACTION_UP:
	                break;
	        }
		return super.onInterceptTouchEvent(ev);
	}
	
	
	
	
}
