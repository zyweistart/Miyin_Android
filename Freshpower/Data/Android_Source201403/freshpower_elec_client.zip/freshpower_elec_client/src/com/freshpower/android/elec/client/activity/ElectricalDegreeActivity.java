package com.freshpower.android.elec.client.activity;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.domain.ElectricalDegree;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

public class ElectricalDegreeActivity extends Activity {
	public DecimalFormat df =new DecimalFormat("0.00"); //��ȡ��С�������λ
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.inspection_degree);
		ActivityUtil.addActivity(this);
		double expend = 0;
		double nowRead = 0;//���ζ���
		double lastRead = 0;//�ϴζ���
		double expendTemp = 0;
		double nowReadTemp = 0;
		double lastReadTemp = 0;
		int temp = 0;
		List<TextView> textList = setTextView();
		for(int j = 1 ; j < 3 ; j++){
			if(j == 1){nowRead = 236;temp = 0;}
			if(j == 2){nowRead = 248;temp = 12;}
			expend = Double.parseDouble(df.format(151200*(Math.random()*0.2+0.9)/1000));
			lastRead = nowRead - expend;
			for(int i = 0 ; i < 12 ; i = i + 3){
				if(i == 0 ){
					expendTemp = Double.parseDouble(df.format(expend ));
					nowReadTemp = Double.parseDouble(df.format(nowRead));
					lastReadTemp = Double.parseDouble(df.format(lastRead));
				}
				if(i == 3 ){
					expendTemp = Double.parseDouble(df.format(expend * 0.06));
					nowReadTemp = Double.parseDouble(df.format(nowRead * 0.06));
					lastReadTemp = Double.parseDouble(df.format(lastRead * 0.06));
				}
				if(i == 6 ){
					expendTemp = Double.parseDouble(df.format(expend * 0.6));
					nowReadTemp = Double.parseDouble(df.format(nowRead * 0.6));
					lastReadTemp = Double.parseDouble(df.format(lastRead * 0.6));
				}
				if(i == 9 ){
					expendTemp = Double.parseDouble(df.format(expend * 0.34));
					nowReadTemp = Double.parseDouble(df.format(nowRead * 0.34));
					lastReadTemp = Double.parseDouble(df.format(lastRead * 0.34));
				}
				textList.get(i+(temp+0)).setText(String.valueOf(nowReadTemp));
				textList.get(i+(temp+1)).setText(String.valueOf(lastReadTemp));
				textList.get(i+(temp+2)).setText(String.valueOf(expendTemp));
			}
		}
		ImageView returnBtn = (ImageView)findViewById(R.id.degree_return);
		returnBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				ElectricalDegreeActivity.this.onBackPressed();
			}
		});
		
	}
	private List<TextView> setTextView(){
		TextView textOneA = (TextView)findViewById(R.id.degree_one_a);
		TextView textOneB = (TextView)findViewById(R.id.degree_one_b);
		TextView textOneC = (TextView)findViewById(R.id.degree_one_c);
		TextView textOneD = (TextView)findViewById(R.id.degree_one_d);
		TextView textOneE = (TextView)findViewById(R.id.degree_one_e);
		TextView textOneF = (TextView)findViewById(R.id.degree_one_f);
		TextView textOneG = (TextView)findViewById(R.id.degree_one_g);
		TextView textOneH = (TextView)findViewById(R.id.degree_one_h);
		TextView textOneI = (TextView)findViewById(R.id.degree_one_i);
		TextView textOneJ = (TextView)findViewById(R.id.degree_one_j);
		TextView textOneK = (TextView)findViewById(R.id.degree_one_k);
		TextView textOneL = (TextView)findViewById(R.id.degree_one_l);
		TextView textTwoA = (TextView)findViewById(R.id.degree_two_a);
		TextView textTwoB = (TextView)findViewById(R.id.degree_two_b);
		TextView textTwoC = (TextView)findViewById(R.id.degree_two_c);
		TextView textTwoD = (TextView)findViewById(R.id.degree_two_d);
		TextView textTwoE = (TextView)findViewById(R.id.degree_two_e);
		TextView textTwoF = (TextView)findViewById(R.id.degree_two_f);
		TextView textTwoG = (TextView)findViewById(R.id.degree_two_g);
		TextView textTwoH = (TextView)findViewById(R.id.degree_two_h);
		TextView textTwoI = (TextView)findViewById(R.id.degree_two_i);
		TextView textTwoJ = (TextView)findViewById(R.id.degree_two_j);
		TextView textTwoK = (TextView)findViewById(R.id.degree_two_k);
		TextView textTwoL = (TextView)findViewById(R.id.degree_two_l);
		List<TextView> textList = new ArrayList<TextView>();
		textList.add(textOneA);
		textList.add(textOneB);
		textList.add(textOneC);
		textList.add(textOneD);
		textList.add(textOneE);
		textList.add(textOneF);
		textList.add(textOneG);
		textList.add(textOneH);
		textList.add(textOneI);
		textList.add(textOneJ);
		textList.add(textOneK);
		textList.add(textOneL);
		textList.add(textTwoA);
		textList.add(textTwoB);
		textList.add(textTwoC);
		textList.add(textTwoD);
		textList.add(textTwoE);
		textList.add(textTwoF);
		textList.add(textTwoG);
		textList.add(textTwoH);
		textList.add(textTwoI);
		textList.add(textTwoJ);
		textList.add(textTwoK);
		textList.add(textTwoL);
		return textList;
		
	}
}
