package com.freshpower.android.elec.client.netapi;


import java.io.File;
import android.util.Log;

import java.net.URLDecoder;
import java.net.URLEncoder;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.conf.AppConfig;
import com.freshpower.android.elec.client.domain.LoginInfo;
import com.freshpower.android.elec.client.domain.UserRegisterInfo;

public class LoginInfoDataApi extends JsonDataApi {
	private static final String ACTION_NAME = "checkMobileValid.aspx";
	private static final String REGISTER_TRMS_AUDIT = "elecRegister.aspx";
	private static final String REGISTER_CRM_AUDIT = "checkElecIdent.aspx";
	private static final String LOGIN_TYPE="1";
	
	public static LoginInfo getLoginInfo(LoginInfo login) throws Exception {
		LoginInfo loginInfo=new LoginInfo();
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("imei",login.getLoginName().trim());
		api.addParam("authentication",login.getLoginPwd());
		api.addParam("type",LOGIN_TYPE);
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getFpsWebSite()+File.separator+ACTION_NAME);
		loginInfo.setLoginStatus(Integer.valueOf(jsonResult.getString("result")));
		loginInfo.setCpId(jsonResult.getString("CP_ID"));
		if(jsonResult.getString("NAME")!=null&&!jsonResult.getString("NAME").equals("")){
			loginInfo.setCpName(URLDecoder.decode(jsonResult.getString("NAME"), "GBK"));
		}
		loginInfo.setLoginName(login.getLoginName());
		loginInfo.setLoginPwd(login.getLoginPwd());
		return loginInfo;
	}
	
	public static String testUpload(UserRegisterInfo login,File cardFile,File eleFile) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("name",URLEncoder.encode(login.getLoginRegisterName(),"GBK"));
		api.addParam("telNum",login.getLoginRegisterTel().trim());
		api.addParam("identityNo",login.getLoginRegisterCardNum().trim());
		api.addParam("intentArea",URLEncoder.encode(login.getLoginRegisterAddress(),"GBK"));
		api.addParam("identityImg", cardFile);
		api.addParam("elecImg", eleFile);
		api.addParam("operateType", "1");
		
//		JSONObject jsonResult =api.postFileForJsonResult("http://192.168.0.220:8089/struts2/upload.action");
		JSONObject jsonResult =api.postFileForJsonResult(AppConfig.getInstance().getFpsWebSite()+File.separator+REGISTER_TRMS_AUDIT);
		return jsonResult.getString("rs");
	}
	//��֤�Ϸ� �õ��� ���״̬
	public static String getRegisterInfoAuditTrms(UserRegisterInfo loginInfo) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("telNum", loginInfo.getLoginRegisterTel().trim());
		api.addParam("identityNo", loginInfo.getLoginRegisterCardNum().trim());
		api.addParam("operateType", "2");
//		Log.d("BID", AppConfig.getInstance().getFpsWebSite()+File.separator+REGISTER_TRMS_AUDIT);
		JSONObject jsonResult =api.postForJsonResult(AppConfig.getInstance().getFpsWebSite()+File.separator+REGISTER_TRMS_AUDIT,AppConstant.ETG_INTERFACE_CHARSET);
//		Log.d("BID", jsonResult.getString("rs")+"���״̬");
		return jsonResult.getString("rs");
	}
	//��֤�Ϸ�  crm
		public static String getRegisterInfoCrm(UserRegisterInfo loginInfo) throws Exception {
			JsonDataApi api = JsonDataApi.getInstance();
			api.addParam("telNum", loginInfo.getLoginRegisterTel().trim());
			api.addParam("identityNo", loginInfo.getLoginRegisterCardNum().trim());
			api.addParam("name", URLEncoder.encode(loginInfo.getLoginRegisterName(),"GBK"));
			JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getCrmWebSite()+File.separator+REGISTER_CRM_AUDIT);
			return jsonResult.getString("result");
		}
}
