/**   
 * @{#} SsystemDataApi.java Create on 2012-10-24 ����02:29:07   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.client.netapi;

import java.io.File;

import java.util.HashMap;
import java.util.Map;

import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.conf.AppConfig;
import com.freshpower.android.elec.client.domain.AppStoreInfo;

/**
 * @author <a href="mailto:yangz@freshpower.cn">yangz</a>
 * @version 1.0
 */

public class AppStoreInfoDataApi extends JsonDataApi {
	private static final String ACTION_NAME = "queryMobileVersionInfo.aspx";
	private static final String ACTION_NAME_APPDESKTOP = "AppDeskTop.aspx";

	/**
	 * ��ȡ�����汾��Ϣ
	 * @param key �ֻ�Ψһ��ʶ
	 * @return ����������Ϣ
	 * @throws Exception
	 */
	public static AppStoreInfo getAppStoreInfo(String key) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		String ver=AppConfig.getInstance().getAppVersion();
		api.addParam("key",key);
		api.addParam("wap_filesbag", "wap_filesbag2");
		JSONObject jsonResult =api.postForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+ACTION_NAME,AppConstant.ETG_INTERFACE_CHARSET);
		AppStoreInfo appStoreInfo= new AppStoreInfo();
		appStoreInfo.setVerCode(jsonResult.getString("verCode"));
//		appStoreInfo.setVerFilePah("http://www.fps365.net/SoftwareFile/Electricianc.apk");
		appStoreInfo.setVerFilePah(jsonResult.getString("verFilePah"));
		appStoreInfo.setChangeInfo(jsonResult.getString("changeInfo"));
		appStoreInfo.setFrequency(Long.valueOf(jsonResult.getString("frequency")));
		appStoreInfo.setMust(jsonResult.getString("must"));
		return appStoreInfo;
	}
	
	/**
	 * ��ȡ����С�����Ϣ
	 * @param cpId ��˾ID
	 * @return С�����ϢMap
	 * @throws Exception
	 */
	public static Map<String,String> getAppDeskTopInfo(String cpId,String url) throws Exception{
		Map<String,String> map = new HashMap<String, String>();
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("CP_ID", cpId);
		JSONObject jsonResult = api.getForJsonResult(url+File.separator+ACTION_NAME_APPDESKTOP, AppConstant.ETG_INTERFACE_CHARSET);
//		Log.d("BID", "getAppDeskTopInfo:"+jsonResult.toString());
		JSONObject deskTopJsonObj = jsonResult.getJSONObject("DeskTop");
//		JSONObject deskTopJsonObj = (JSONObject) deskTopJson.get(0);
		map.put("CurrLoad", deskTopJsonObj.getString("CurrLoad"));
		map.put("AvgLoad", deskTopJsonObj.getString("AvgLoad"));
		map.put("PowerFee", deskTopJsonObj.getString("PowerFee"));
		map.put("Price", deskTopJsonObj.getString("Price"));
		map.put("AvgPrice", deskTopJsonObj.getString("AvgPrice"));
		map.put("LoadRate", deskTopJsonObj.getString("LoadRate"));
		
		return map;
	}
	
	
	
}
