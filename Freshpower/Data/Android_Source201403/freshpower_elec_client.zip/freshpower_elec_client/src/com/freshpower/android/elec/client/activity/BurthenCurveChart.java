package com.freshpower.android.elec.client.activity;

import java.util.ArrayList;
import java.util.List;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer.FillOutsideLine;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;

import com.freshpower.android.elec.client.common.MathUtil;

public class BurthenCurveChart extends AbstractChart {
	
	private double[] sumChargeDoubleList = new double[12];
	private GraphicalView mChartView;
	private int time;

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public String getName() {
		return "��������ͼ";
	}

	public String getDesc() {
		return "�������й����ʵ����ߡ�������ʾģ�����ʱ�������3���ӵ����ߡ�";
	}

	/**
	 * ��������ͼ
	 */
	public Intent execute(Context context) {
		return ChartFactory.getCubicLineChartIntent(context, getDataSet(), getRenderer(), 0.5f);
	}
	
	public void exe(Context context, LinearLayout layout) {
		mChartView = ChartFactory.getCubeLineChartView(context, getDataSet(), getRenderer(), 0.5f);
		layout.removeAllViews();
		layout.addView(mChartView, new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT)); 
		mChartView.invalidate();
	}
	
	/**
	 * ��������
	 * 
	 * @return
	 */
	public XYMultipleSeriesDataset getDataSet() {
		String[] titles = new String[] { "", "��ǰ����",
		"" };
		List<double[]> values = new ArrayList<double[]>();
		values.add(sumChargeDoubleList);
		if(time <= 12) {
			values.add(MathUtil.change(sumChargeDoubleList, time));
		} else {
			values.add(sumChargeDoubleList);
		}
		int length = values.get(0).length;
		double[] diff = new double[length];
		for (int i = 0; i < length; i++) {
//			diff[i] = values.get(0)[i] - values.get(1)[i];
		}
		values.add(diff);
		return buildBarDataset(titles, values);
	}
	
	/**
	 * ������Ⱦ��
	 * 
	 * @return
	 */
	public XYMultipleSeriesRenderer getRenderer() {
		int[] colors = new int[] { Color.parseColor("#F5F6F4"), Color.parseColor("#1E90FF"), Color.parseColor("#F5F6F4") };
		PointStyle[] styles = new PointStyle[] { PointStyle.POINT,
				PointStyle.POINT, PointStyle.POINT };
		XYMultipleSeriesRenderer renderer = buildRenderer(colors, styles);
		setChartSettings(renderer, "",
				"ʱ�䣨��λ���룩", " ���ɣ���λ��KW��", 0.75, 12.25, 0, MathUtil.max(sumChargeDoubleList)*1.3, Color.BLACK,
				Color.BLACK);
		renderer.setXLabels(12);
		renderer.setYLabels(10);
		renderer.setChartTitleTextSize(20);
//		renderer.setTextTypeface("sans_serif", Typeface.BOLD);
		renderer.setLabelsTextSize(14f);
		renderer.setAxisTitleTextSize(15);
		renderer.setLegendTextSize(15);
		renderer.setAxisTitleTextSize(16); 
		// ���ñ�����ɫ
		renderer.setApplyBackgroundColor(true);
		renderer.setBackgroundColor(Color.parseColor("#F5F6F4"));
		renderer.setMarginsColor(Color.parseColor("#F5F6F4"));
		renderer.setXLabelsColor(Color.BLACK);
		renderer.setYLabelsColor(0, Color.BLACK);
		// �����Ƿ��ǿɻ���������
		renderer.setPanEnabled(false, false); 
		int length = renderer.getSeriesRendererCount();

		for (int i = 0; i < length; i++) {
			XYSeriesRenderer seriesRenderer = (XYSeriesRenderer) renderer
					.getSeriesRendererAt(i);
			if (i == length - 1) {
				FillOutsideLine fill = new FillOutsideLine(
						FillOutsideLine.Type.BOUNDS_ALL);
				fill.setColor(Color.GREEN);
				seriesRenderer.addFillOutsideLine(fill);
			}
			seriesRenderer.setLineWidth(2.5f);
			seriesRenderer.setDisplayChartValues(true);
			seriesRenderer.setChartValuesTextSize(10f);
		}
		
		// X�����ֱ�ǩ����
		renderer.setXLabels(0);
		if(time <= 12) {
			for(int i=1;i<=12;i++) {
				renderer.addTextLabel(i, String.valueOf(i*5));
			}
		} else {
			for(int i=1;i<=12;i++) {
				renderer.addTextLabel(i, String.valueOf((i*5)+(time-12)*5));
			}
		}
		return renderer;
	}
	
//	/**
//	   * Builds a bar multiple series dataset using the provided values.
//	   * 
//	   * @param titles the series titles
//	   * @param values the values
//	   * @return the XY multiple bar dataset
//	   */
//	  protected XYMultipleSeriesDataset buildBarDataset(String[] titles, List<double[]> values) {
//	    XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
//	    int length = titles.length;
//	    for (int i = 0; i < length; i++) {
//	      CategorySeries series = new CategorySeries(titles[i]);
//	      double[] v = values.get(i);
//	      int seriesLength = v.length;
//	      for (int k = seriesLength-1; k >= 0; k--) {
//	        series.add(v[k]);
//	      }
//	      dataset.addSeries(series.toXYSeries());
//	    }
//	    return dataset;
//	  }

	public double[] getSumChargeDoubleList() {
		return sumChargeDoubleList;
	}

	public void setSumChargeDoubleList(double[] sumChargeDoubleList) {
		this.sumChargeDoubleList = sumChargeDoubleList;
	}
	
}
