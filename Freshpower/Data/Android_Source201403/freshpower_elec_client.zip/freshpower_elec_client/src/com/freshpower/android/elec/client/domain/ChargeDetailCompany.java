package com.freshpower.android.elec.client.domain;

public class ChargeDetailCompany {
	private String meterId;// ��·ID
	private String meterName;// ��·����
	private String pPower;// ����
	private String swichStatus;// ����
	private String factor;// ��������
	private String current;// ABC�����
	public String getMeterId() {
		return meterId;
	}
	public void setMeterId(String meterId) {
		this.meterId = meterId;
	}
	public String getMeterName() {
		return meterName;
	}
	public void setMeterName(String meterName) {
		this.meterName = meterName;
	}
	public String getpPower() {
		return pPower;
	}
	public void setpPower(String pPower) {
		this.pPower = pPower;
	}
	public String getSwichStatus() {
		return swichStatus;
	}
	public void setSwichStatus(String swichStatus) {
		this.swichStatus = swichStatus;
	}
	public String getFactor() {
		return factor;
	}
	public void setFactor(String factor) {
		this.factor = factor;
	}
	public String getCurrent() {
		return current;
	}
	public void setCurrent(String current) {
		this.current = current;
	}
	
}
