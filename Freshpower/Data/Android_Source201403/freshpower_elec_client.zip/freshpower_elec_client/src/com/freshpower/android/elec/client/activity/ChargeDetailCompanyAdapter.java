package com.freshpower.android.elec.client.activity;

import java.util.List;
import java.util.Map;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;

import com.freshpower.android.elec.client.R;



public class ChargeDetailCompanyAdapter extends BaseAdapter {

	List<Map<String, Object>> mData;
	Context mContext;
	int resource;
	public ChargeDetailCompanyAdapter(List<Map<String, Object>> data,
			Context context, int resource) {
		this.mData = data;
		this.mContext = context;
		this.resource = resource;
	}

	@Override
	public int getCount() {
		return mData == null ? 0 : mData.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	static class ViewHoder {
		TextView meterText;
		TextView pPowerText;
		TextView swichStatusText;
		TextView factorText;
		TextView currentText;
		TableLayout chargeDetailTable;
		LinearLayout chargeDetailListitem;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHoder hoder = null;
		if (convertView == null) {
			hoder = new ViewHoder();
			convertView = LayoutInflater.from(mContext).inflate(resource, null);
			hoder.meterText = (TextView) convertView
					.findViewById(R.id.meterText);
			hoder.pPowerText = (TextView) convertView
					.findViewById(R.id.pPowerText);
			hoder.swichStatusText = (TextView) convertView
					.findViewById(R.id.swichStatusText);
			hoder.factorText = (TextView) convertView
					.findViewById(R.id.factorText);
			hoder.currentText = (TextView) convertView
					.findViewById(R.id.currentText);
			hoder.chargeDetailTable = (TableLayout) convertView
					.findViewById(R.id.chargeDetailTable);
			hoder.chargeDetailListitem = (LinearLayout) convertView
					.findViewById(R.id.chargeDetailListitem);
			convertView.setTag(hoder);
		} else {
			hoder = (ViewHoder) convertView.getTag();
		}
		Map<String, Object> data = mData.get(position);
		if(position % 2 ==1){
			hoder.chargeDetailListitem.setBackgroundColor(mContext.getResources().getColor(R.color.bgcolor));
		}else{
			hoder.chargeDetailListitem.setBackgroundColor(mContext.getResources().getColor(R.color.white));
		}
		hoder.meterText.setText(String.valueOf(data.get("meterText")));
		hoder.pPowerText.setText(String.valueOf(data.get("pPowerText")));
		hoder.swichStatusText.setText(String.valueOf(data.get("swichStatusText")));
		if(data.get("swichStatusText").equals("��")) {
			hoder.swichStatusText.setTextColor(Color.parseColor("#009900"));
		} else {
			hoder.swichStatusText.setTextColor(Color.parseColor("#FF0000"));
		}
		hoder.factorText.setText(String.valueOf(data.get("factorText")));
		hoder.currentText.setText(String.valueOf(data.get("currentText")));
		ChargeDetailListener chargeDetailListener = new ChargeDetailListener();
		chargeDetailListener.setMeterId(String.valueOf(data.get("meterId")));
		chargeDetailListener.setMeterName(String.valueOf(data.get("meterText")));
		hoder.chargeDetailTable.setOnClickListener(chargeDetailListener);
		return convertView;
	}
	
	
	 class ChargeDetailListener implements View.OnClickListener{
		 
		private String meterId;
		private String meterName;
		
		public void setMeterId(String meterId) {
			this.meterId = meterId;
		}
		
		public void setMeterName(String meterName) {
			this.meterName = meterName;
		}


		@Override
		public void onClick(View v) {
			Intent intent = new Intent(mContext, ChargeChartCompanyActivity.class);
			intent.putExtra("meterId", meterId);
			intent.putExtra("meterName", meterName);
			mContext.startActivity(intent);
		}
	}

}
