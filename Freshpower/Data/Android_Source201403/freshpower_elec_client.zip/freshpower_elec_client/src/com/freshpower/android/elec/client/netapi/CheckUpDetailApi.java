package com.freshpower.android.elec.client.netapi;

import java.io.File;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.client.common.AppCache;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.conf.AppConfig;
import com.freshpower.android.elec.client.domain.CheckUpDetailInfo;
import com.freshpower.android.elec.client.domain.LoginInfo;

public class CheckUpDetailApi extends JsonDataApi {
	private static final String ACTION_NAME = "AppMonitoringAlarm.aspx";
	/**
	 * ��ȡ�豸��ϸ��Ϣ
	 * @param qttask����id
	 * @param qtkey�豸id
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getCheckUpInfoList(String qttask,String qtkey) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd()); 
//		api.addParam("imei","zhangyy");
//		api.addParam("authentication","4836c90b7d1711efab1f0239d28817d1");
		api.addParam("GNID","RW17");
		api.addParam("QTTASK",qttask);
		api.addParam("QTKEY",qtkey);
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+ACTION_NAME,AppConstant.ETG_INTERFACE_CHARSET);
//		Log.d("BID", "jsonResult:"+jsonResult.toString());
		JSONObject rows = jsonResult.getJSONObject("Rows");
		CheckUpDetailInfo checkUpInfo = null;
		List<CheckUpDetailInfo> checkUpInfoList = new ArrayList<CheckUpDetailInfo>();
		if(Integer.valueOf(rows.getString("result"))>0){
			JSONArray jsonObj = jsonResult.getJSONArray("table1");
			for(int i=0;i<jsonObj.size();i++){
				checkUpInfo=new CheckUpDetailInfo();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				checkUpInfo.setCodeId(table1.getString("CODE_ID")==null?"":table1.getString("CODE_ID"));//����Ӧ��д����
				checkUpInfo.setModelSubId(table1.getString("MODEL_SUB_ID")==null?"":table1.getString("MODEL_SUB_ID"));//�豸����ID
				checkUpInfo.setResultId(table1.getString("RESULT_ID")==null?"":table1.getString("RESULT_ID"));//���ID����������д��32λ����վ�Զ����ɣ�
				checkUpInfo.setScoutcheck(table1.getString("SCOUTCHECK")==null?"":table1.getString("SCOUTCHECK"));//��д���
				checkUpInfo.setScoutcheckContent(table1.getString("SCOUTCHECK_CONTENT")==null?"":table1.getString("SCOUTCHECK_CONTENT"));//��������
				checkUpInfo.setCodeType(table1.getString("code_type")==null?"":table1.getString("code_type"));//�������д����
				checkUpInfoList.add(checkUpInfo);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("checkUpInfoList", checkUpInfoList);
//		map.put("totalCount", rows.getString("TotalCount"));
		map.put("result", rows.getString("result"));
		return map;
	}
}
