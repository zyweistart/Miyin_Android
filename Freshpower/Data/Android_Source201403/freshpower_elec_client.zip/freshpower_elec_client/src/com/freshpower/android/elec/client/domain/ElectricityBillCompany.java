package com.freshpower.android.elec.client.domain;

public class ElectricityBillCompany {
	private String  totalPower;    //�ۼƵ���   
	private String  totalFee;      //�ۼƵ��
	private String  tipPower;      //������
	private String  tipFee;         //�����
	private String  peakPower;     //�߷����
	private String  peakFee;       //�߷���
	private String  valleyPower;   //�͹ȵ���
	private String  valleyFee;     //�͹ȵ��
	private String  avgPrice;     //ƽ�����
	private String meterName;     //��·����
	private String meterId;     //��·Id
	
	public String getMeterId() {
		return meterId;
	}
	public void setMeterId(String meterId) {
		this.meterId = meterId;
	}
	public String getMeterName() {
		return meterName;
	}
	public void setMeterName(String meterName) {
		this.meterName = meterName;
	}
	public String getTotalPower() {
		return totalPower;
	}
	public void setTotalPower(String totalPower) {
		this.totalPower = totalPower;
	}
	public String getTotalFee() {
		return totalFee;
	}
	public void setTotalFee(String totalFee) {
		this.totalFee = totalFee;
	}
	public String getTipPower() {
		return tipPower;
	}
	public void setTipPower(String tipPower) {
		this.tipPower = tipPower;
	}
	public String getTipFee() {
		return tipFee;
	}
	public void setTipFee(String tipFee) {
		this.tipFee = tipFee;
	}
	public String getPeakPower() {
		return peakPower;
	}
	public void setPeakPower(String peakPower) {
		this.peakPower = peakPower;
	}
	public String getPeakFee() {
		return peakFee;
	}
	public void setPeakFee(String peakFee) {
		this.peakFee = peakFee;
	}
	public String getValleyPower() {
		return valleyPower;
	}
	public void setValleyPower(String valleyPower) {
		this.valleyPower = valleyPower;
	}
	public String getValleyFee() {
		return valleyFee;
	}
	public void setValleyFee(String valleyFee) {
		this.valleyFee = valleyFee;
	}
	public String getAvgPrice() {
		return avgPrice;
	}
	public void setAvgPrice(String avgPrice) {
		this.avgPrice = avgPrice;
	}
	

}
