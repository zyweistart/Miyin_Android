package com.freshpower.android.elec.client.netapi;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.client.common.AppCache;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.conf.AppConfig;
import com.freshpower.android.elec.client.domain.LoginInfo;
import com.freshpower.android.elec.client.domain.RunStatus;

public class ChartCompanyApi extends JsonDataApi {
	private static final String CHARGE_CHART_ACTION = "AppComFhReport.aspx";
	private static final String RUNSTATUS_CHART_ACTION = "AppIndexRunStatus.aspx";

	/**
	 * ��ȡ������ҵ�ܸ���
	 * 
	 * @param cpId
	 *            ��ҵID
	 * @return
	 * @throws Exception
	 */
	public static double[] getSumChargeDoubleList() throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo = (LoginInfo) AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("CP_ID", loginInfo.getCpId());
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance()
				.getFpsWebSite() + File.separator + CHARGE_CHART_ACTION,
				AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("ComFhList");
		double[] sumChargeDoubleList = null;
		if(jsonObj != null) {
			sumChargeDoubleList = new double[jsonObj.size()];
			if (Integer.valueOf(rows.getString("result")) > 0) {
				for (int i = 0; i < jsonObj.size(); i++) {
					JSONObject table = (JSONObject) jsonObj.get(i);
					sumChargeDoubleList[i] = Double.parseDouble(table
							.getString("����"));
				}
			}
		}
		return sumChargeDoubleList;
	}

	/**
	 * ��ȡ����״̬
	 * 
	 * @param cpId
	 *            ��ҵID
	 * @return
	 * @throws Exception
	 */
	public static List<RunStatus> getRunStatusList() throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo = (LoginInfo) AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("CP_ID", loginInfo.getCpId());
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance()
				.getFpsWebSite() + File.separator + RUNSTATUS_CHART_ACTION,
				AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("IndexRunStatus");
		RunStatus runStatus = null;
		List<RunStatus> runStatusList = new ArrayList<RunStatus>();
		if (Integer.valueOf(rows.getString("result")) > 0) {
			for (int i = 0; i < jsonObj.size(); i++) {
				runStatus = new RunStatus();
				JSONObject table = (JSONObject) jsonObj.get(i);
				runStatus.setMeterId(table.getString("METER_ID"));
				runStatus.setMeterName(table.getString("METER_NAME"));
				runStatus.setColor(table.getString("COLOR"));
				runStatus.setiValue(table.getString("I_VALUE"));
				runStatusList.add(runStatus);
			}
		}
		return runStatusList;
	}
}
