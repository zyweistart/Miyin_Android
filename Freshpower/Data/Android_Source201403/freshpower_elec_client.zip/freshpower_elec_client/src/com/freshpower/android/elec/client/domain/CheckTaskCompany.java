package com.freshpower.android.elec.client.domain;

public class CheckTaskCompany {
	private String cpId;// ��ҵID
	private String contractId;// ��ͬID
	private String siteId;// վ��ID
	private String taskId;// ����ID
    private String cpName;// ����ͻ�����
    private String siteName;// ����վ������
    private String name;// Ѳ��������
    private String taskDate;// ��������
    private String completeDate;// �������
    private String isComplete;// �Ƿ����
    private String recompleteDate;// Ҫ�����ʱ��
    private String taskUserId;
    private String userId;// ������ԱID
    private String userName;// ������Ա����
    private String modleId;// ģ��ID
    private String modleName;// ģ������
    public String getModleId() {
		return modleId;
	}
	public void setModleId(String modleId) {
		this.modleId = modleId;
	}
	public String getModleName() {
		return modleName;
	}
	public void setModleName(String modleName) {
		this.modleName = modleName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getTaskUserId() {
		return taskUserId;
	}
	public void setTaskUserId(String taskUserId) {
		this.taskUserId = taskUserId;
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getCpName() {
		return cpName;
	}
	public void setCpName(String cpName) {
		this.cpName = cpName;
	}
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTaskDate() {
		return taskDate;
	}
	public void setTaskDate(String taskDate) {
		this.taskDate = taskDate;
	}
	public String getCompleteDate() {
		return completeDate;
	}
	public void setCompleteDate(String completeDate) {
		this.completeDate = completeDate;
	}
	public String getIsComplete() {
		return isComplete;
	}
	public void setIsComplete(String isComplete) {
		this.isComplete = isComplete;
	}
	public String getRecompleteDate() {
		return recompleteDate;
	}
	public void setRecompleteDate(String recompleteDate) {
		this.recompleteDate = recompleteDate;
	}
	public String getCpId() {
		return cpId;
	}
	public void setCpId(String cpId) {
		this.cpId = cpId;
	}
	public String getContractId() {
		return contractId;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	public String getSiteId() {
		return siteId;
	}
	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}
}
