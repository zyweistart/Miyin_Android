package com.freshpower.android.elec.client.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.domain.CompanyInfo;
import com.freshpower.android.elec.client.netapi.ScanInfoDateApi;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class CompanyInfoActivity extends Activity {
	private RoundCornerListView informationlistview;
	private TextView companyName;
	private TextView infoView1;
	private TextView infoView2;
	private TextView infoView3;
	private TextView infoView4;
	private String companyStation[];
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.activity_company_information);
		ImageView returnBtn = (ImageView)findViewById(R.id.company_information_return);
		returnBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				CompanyInfoActivity.this.onBackPressed();
			}
		});
		Intent intent = getIntent();
		String siteId =  intent.getStringExtra("siteId");
		CompanyInfo company = new CompanyInfo();
		try {
			company = ScanInfoDateApi.getCompanyInfo("","",siteId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		companyName = (TextView)findViewById(R.id.company_name);
		infoView1 = (TextView)findViewById(R.id.company_information_view1);
		infoView2 = (TextView)findViewById(R.id.company_information_view2);
		infoView3 = (TextView)findViewById(R.id.company_information_view3);
		infoView4 = (TextView)findViewById(R.id.company_information_view4);
		companyName.setText(company.getName());
		infoView1.setText(company.getAddRess());
		infoView2.setText(company.getSubCount());
		infoView3.setText(company.getTransCount());
		infoView4.setText(company.getTransName());
//		Log.d("BID", "111111111111111");
		if( company.getTransFormNo()!=null){
			companyStation = company.getTransFormNo().split("��");
		}
		if(company.getResult()!=null){
			Toast.makeText(CompanyInfoActivity.this, ScanInfoDateApi.showMsg(company.getResult()), Toast.LENGTH_SHORT).show();
			return;
		}else if(siteId==null){
			Toast.makeText(CompanyInfoActivity.this, "û�д���ҵ��Ϣ��", Toast.LENGTH_SHORT).show();
			return;
		}
		findViews();
		setAdapter();

	}
	private void findViews(){
		informationlistview = (RoundCornerListView)findViewById(R.id.information_list);
	}
	
	private void setAdapter(){
		informationlistview.setAdapter(new SimpleAdapter(this, getInformationlistData(), R.layout.listitem_style_company_info,
				new String[] { AppConstant.ListItemCtlName.COMPANY_STATION}, 
				new int[] { R.id.company_station}));
		setListViewHeightBasedOnChildren(informationlistview);
	}
	
	private List<Map<String, Object>> getInformationlistData(){
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		if(companyStation!=null){
			for (int i = 0; i < companyStation.length; i++)
			{
				//Log.d("elec", String.valueOf(companyStation[i]));
				Map<String, Object> listItem1 = new HashMap<String, Object>();
				listItem1.put(AppConstant.ListItemCtlName.COMPANY_STATION, companyStation[i]);
				listItems.add(listItem1);
			}
		}
		return listItems;
	}
	
	/***
	 * ��̬����listview�ĸ߶�
	 * 
	 * @param listView
	 */
	public void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            return;
        }
        int totalHeight = 0;
        for (int i = 0; i < listAdapter.getCount(); i++) {
           View listItem = listAdapter.getView(i, null, listView);
        	//View listItem = inflater.inflate(android.R.layout.simple_expandable_list_item_1, null);
            listItem.measure(0, 0);
            totalHeight += listItem.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight
                + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        // params.height += 5;// if without this statement,the listview will be
        // a
        // little short
        // listView.getDividerHeight()��ȡ�����ָ���ռ�õĸ߶�
        // params.height���õ�����ListView������ʾ��Ҫ�ĸ߶�
        listView.setLayoutParams(params);
    }
}
