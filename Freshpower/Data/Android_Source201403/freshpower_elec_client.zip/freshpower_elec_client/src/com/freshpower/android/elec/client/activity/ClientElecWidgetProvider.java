package com.freshpower.android.elec.client.activity;

import java.io.File;
import java.math.BigDecimal;
import java.net.ConnectException;
import java.text.DecimalFormat;
import java.util.Map;
import java.util.Random;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.FileUtil;
import com.freshpower.android.elec.client.netapi.AppStoreInfoDataApi;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.Toast;

public class ClientElecWidgetProvider extends AppWidgetProvider {
	private DecimalFormat dfOne = new DecimalFormat("0.00"); // ��ȡ��С�������λ
	private DecimalFormat dfTwo = new DecimalFormat("0.0"); // ��ȡ��С�����һλ
	public static String REFRESH_ACTION = "com.freshpower.android.elec.client.mars.REFRESH_APP_WIDGET";
	private boolean flag = true;
	private RemoteViews remoteViews;
	private String[][] chargeDataStrArr= new String[][]{
			{"1244.13","4.03%","0.63","1"},
			{"1234.83","-0.27%","0.23","0"},
			{"1156.34","0.62%","0.48","1"},
			{"1273.52","2.24%","0.36","1"},
			{"1142.30","-0.89%","0.89","0"},
			{"1293.07","2.34%","0.45","1"},
			{"1332.72","-1.73%","0.75","0"},
			{"1226.96","0.36%","0.34","1"},
			{"1283.67","4.26%","0.65","1"},
			{"1271.54","-3.23%","0.78","0"},
	};
	
	private String[][] billDataStrArr= new String[][]{
			{"8.19","0.63%","1"},
			{"9.02","-0.23%","0"},
			{"8.12","0.48%","1"},
			{"8.89","-0.36%","0"},
			{"9.14","0.89%","1"},
			{"8.94","-0.45%","0"},
			{"8.54","0.75%","1"},
			{"8.87","-0.34%","0"},
			{"9.14","-0.65%","0"},
			{"8.76","0.78%","1"},
	};
	
	BigDecimal totalBill;
	
	private String[] getChargeDataStrArr(){
		int randVal = (new Random()).nextInt(chargeDataStrArr.length);
		return chargeDataStrArr[randVal];
	}
	
	private String[] getBillDataStrArr(){
		Random r = new Random();
		int randVal = r.nextInt(billDataStrArr.length);
		
		
		String currentTimeStr = String.valueOf(System.currentTimeMillis());
		String subCurrentTimeStr =  currentTimeStr.substring(currentTimeStr.length()-8, currentTimeStr.length()-2);
		BigDecimal subCurrentTime = new BigDecimal(subCurrentTimeStr);
		subCurrentTime.divide(BigDecimal.valueOf(100d), 2, BigDecimal.ROUND_HALF_UP);
		totalBill= subCurrentTime.divide(BigDecimal.valueOf(100d), 2, BigDecimal.ROUND_HALF_UP);
		return billDataStrArr[randVal];
	}
	
	@Override
	public void onReceive(Context context, Intent intent) {
		System.out.println("onReceive");
		String action = intent.getAction();
//		Log.d("BID", "flag1111:"+flag); 
		if(REFRESH_ACTION.equals(action)){
			AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
			ComponentName ComponentName = new ComponentName(context, ClientElecWidgetProvider.class);
			remoteViews = new RemoteViews(context.getPackageName(),R.layout.appwidget_elec_info);
			remoteViews.setViewVisibility(R.id.refreshImgV, View.INVISIBLE);
			remoteViews.setViewVisibility(R.id.loadProgressBar, View.VISIBLE);
			appWidgetManager.updateAppWidget(ComponentName, remoteViews);
			
			remoteViews = initRemoteViews(context);
			remoteViews.setViewVisibility(R.id.refreshImgV, View.VISIBLE);
			remoteViews.setViewVisibility(R.id.loadProgressBar, View.INVISIBLE);
			appWidgetManager.updateAppWidget(ComponentName, remoteViews);
		}else {
			super.onReceive(context, intent);
		}
	}
	
	private RemoteViews initRemoteViews(Context context){
		Map<String,String> map = null;
		String[] chargeDataStrArrItem = new String[10];
		String[] billDataStrArrItem = new String[10];
		String url = context.getResources().getString(R.string.fpsWebSite);
		remoteViews = new RemoteViews(context.getPackageName(),R.layout.appwidget_elec_info);
		String fileContent = null;
		try {
			File dbFile = new File(FileUtil.getDBFilePath());
			if(dbFile.exists()){
				fileContent = FileUtil.read(FileUtil.getDBFilePath());
				if(fileContent!=null){
					String[] fileContext = fileContent.split("\\|");
					if(fileContext.length > 3){
						map = AppStoreInfoDataApi.getAppDeskTopInfo(fileContext[2],url);
					}
				}
			}
			if(map!=null){
				double difference = 0;
				double currLoad = Double.parseDouble(map.get("CurrLoad")==null?"0":map.get("CurrLoad").toString());//��ǰ����
				double avgLoad = Double.parseDouble(map.get("AvgLoad")==null?"0":map.get("AvgLoad").toString());//ƽ������
				double powerFee = Double.parseDouble(map.get("PowerFee")==null?"0":map.get("PowerFee").toString());//���յ��
				double price = Double.parseDouble(map.get("Price")==null?"0":map.get("Price").toString());//����ƽ�����
				double avgPrice = Double.parseDouble(map.get("AvgPrice")==null?"0":map.get("AvgPrice").toString());//����ƽ�����
				double loadRate = Double.parseDouble(map.get("LoadRate")==null?"0":map.get("LoadRate").toString());//���ո�����
				if(avgLoad == 0){
					difference = 0;
				}else{
					difference = (currLoad-avgLoad)/avgLoad;//���ɲ�ֵ
				}
				chargeDataStrArrItem[0] = String.valueOf(dfTwo.format(currLoad));
				chargeDataStrArrItem[1] = String.valueOf(dfOne.format(difference*100)+"%");
				chargeDataStrArrItem[2] = String.valueOf(dfOne.format(loadRate));
				if(difference > 0){
					chargeDataStrArrItem[3] = "1";
				}else{
					chargeDataStrArrItem[3] = "0";
				}
				if(avgPrice == 0){
					difference = 0;
				}else{
					difference = (price - avgPrice)/avgPrice;//��۲�ֵ
				}
				totalBill = new BigDecimal(dfOne.format(powerFee));
				billDataStrArrItem[0] = String.valueOf(dfOne.format(avgPrice));
				billDataStrArrItem[1] = String.valueOf(dfOne.format(difference*100)+"%");
				if(difference > 0){
					billDataStrArrItem[2] = "1";
				}else{
					billDataStrArrItem[2] = "0";
				}
			}else{
				chargeDataStrArrItem = getChargeDataStrArr();
				billDataStrArrItem = getBillDataStrArr();
			}
		
			remoteViews.setTextViewText(R.id.realtime_charge_val_tv, chargeDataStrArrItem[0]);
			remoteViews.setTextViewText(R.id.charge_val_info_tv, chargeDataStrArrItem[1]+"    "+chargeDataStrArrItem[2]);
			if("1".equals(chargeDataStrArrItem[3])){
				remoteViews.setImageViewResource(R.id.chargeMarkImgV, R.drawable.red_up);
				remoteViews.setTextColor(R.id.charge_val_info_tv, Color.parseColor("#FF0000"));
			}else{
				remoteViews.setImageViewResource(R.id.chargeMarkImgV, R.drawable.green_down);
				remoteViews.setTextColor(R.id.charge_val_info_tv, Color.parseColor("#33FF00"));
			}
			remoteViews.setTextViewText(R.id.electric_bill_val_tv, String.valueOf(totalBill));
			remoteViews.setTextViewText(R.id.electric_bill_val_info_tv, billDataStrArrItem[0]+"    "+billDataStrArrItem[1]);
			if("1".equals(billDataStrArrItem[2])){
				remoteViews.setImageViewResource(R.id.electricMarkImgV, R.drawable.red_up);
				remoteViews.setTextColor(R.id.electric_bill_val_info_tv, Color.parseColor("#FF0000"));
			}else{
				remoteViews.setImageViewResource(R.id.electricMarkImgV, R.drawable.green_down);
				remoteViews.setTextColor(R.id.electric_bill_val_info_tv, Color.parseColor("#33FF00"));
			}
		}catch(ConnectException e){
			e.printStackTrace();
			if(fileContent!=null){
				flag = false;
				Toast.makeText(context, R.string.msg_abnormal_network,Toast.LENGTH_SHORT).show();
			}
		} catch (Exception e) {
			e.printStackTrace();
			if(fileContent!=null){
				flag = false;
				Toast.makeText(context, R.string.msg_abnormal_net2work,Toast.LENGTH_SHORT).show();
			}
		}
		return remoteViews;
	}

	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager,
			int[] appWidgetIds) {
		System.out.println("onupdate");
		
		Intent intent = new Intent();
		intent.setAction(REFRESH_ACTION);
		PendingIntent pendingIntent = PendingIntent.getBroadcast(context,-1 , intent, 0);
		remoteViews = new RemoteViews(context.getPackageName(),R.layout.appwidget_elec_info);
		remoteViews = initRemoteViews(context);
		remoteViews.setOnClickPendingIntent(R.id.refreshImgV, pendingIntent);
		appWidgetManager.updateAppWidget(appWidgetIds, remoteViews);
		//super.onUpdate(context, appWidgetManager, appWidgetIds);
	}


	@Override
	public void onDeleted(Context context, int[] appWidgetIds) {
		System.out.println("onDeleted");
		super.onDeleted(context, appWidgetIds);
	}

	@Override
	public void onEnabled(Context context) {
		System.out.println("onEnabled");
		super.onEnabled(context);
	}

	@Override
	public void onDisabled(Context context) {
		System.out.println("onDisabled");
		super.onDisabled(context);
	}
	
	

}
