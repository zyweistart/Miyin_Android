package com.freshpower.android.elec.client.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.domain.OperationalAspect;
import com.freshpower.android.elec.client.netapi.OperationalAspectApi;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class OperationalAspectActivity extends Activity {
	private RoundCornerListView groupOnelistview;
	private ListView listView;
	private TextView title;
	private List<OperationalAspect> operationalAspectList;
	private Handler handler = new Handler();
	private ProgressDialog processProgress;
	private Map<String, Object> map;
	private String qtKey;// �豸ID
	private String qtTask;// ����ID
	private String gnid;
	private String recordType;//2Ѳ���¼ 
	private List<Map<String, Object>> OperationalAspectList;
	private RelativeLayout taskoperation_re;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_list_title);
		Intent intent = getIntent();
		ActivityUtil.addActivity(this);
		qtKey = intent.getStringExtra("qtKey");
		qtTask = intent.getStringExtra("qtTask");
		gnid = intent.getStringExtra("gnid");
		recordType=intent.getStringExtra("recordType");
		findViews();
		
		taskoperation_re=(RelativeLayout)findViewById(R.id.taskoperation_re);
		processProgress = ProgressDialog.show(OperationalAspectActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(){
			public void run() {
				OperationalAspectList = getGroupOnelistData();
				Message msgMessage = new Message();
				OperationalAspectActivity.this.xHandler.sendMessage(msgMessage);
			}
		}.start();

		title=(TextView)findViewById(R.id.operationalAspectTitle);
		if(qtKey.equals("3")) {
			title.setText("�豸�¶ȡ���ۼ���¼");// �豸�¶ȡ���ۼ���¼  
			title.setTextSize(15);
		} else if(qtKey.equals("2")) {
			title.setText("�ܹ����ֵ������������¼");// ���ܹ��������
			title.setTextSize(15);
		} else if(qtKey.equals("1")) {
			title.setText("������ȱ���");// վ��������Ϣ
			title.setTextSize(15);
		}

		// �����¼�
		ImageView returnButton = (ImageView)findViewById(R.id.list_title_return);
		returnButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				OperationalAspectActivity.this.onBackPressed();
			}
		});
	}
	private Handler xHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			setAdapter();
			processProgress.dismiss();
			taskoperation_re.setVisibility(View.VISIBLE);
			if(OperationalAspectList.size()==0){
				Toast.makeText(OperationalAspectActivity.this, R.string.noSearchResultMsg,Toast.LENGTH_SHORT).show();
				taskoperation_re.setVisibility(View.GONE);
			}
		}
	};
	private void setAdapter(){
		groupOnelistview.setAdapter(new SimpleAdapter(this,OperationalAspectList,
				R.layout.listitem_operational_aspect,
				new String[]{"title"},
				new int[]{R.id.title}));
		setListViewHeightBasedOnChildren(groupOnelistview);
		groupOnelistview.setOnItemClickListener(new OnItemClickListener() {
			@Override  
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,  
					long arg3) {  
				Intent intentView = new Intent();
				intentView.setClass(OperationalAspectActivity.this, CheckUpDetailCompanyActivity.class);
				intentView.putExtra("taskId", operationalAspectList.get(arg2).getTaskId());// ����ID
				intentView.putExtra("equipmentId", operationalAspectList.get(arg2).getEquipmentId());// �豸ID
				intentView.putExtra("eqType", operationalAspectList.get(arg2).getEqType());// �豸����
				intentView.putExtra("gnid", gnid);
				intentView.putExtra("recordType", recordType);
				startActivity(intentView);
			}  
		});
	}
	private void findViews(){
		groupOnelistview = (RoundCornerListView)findViewById(R.id.listView);
	}
	private List<Map<String, Object>> getGroupOnelistData(){
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		try {
			operationalAspectList= OperationalAspectApi.getOperationalAspectList(qtTask, qtKey);
			for(OperationalAspect operationalAspect : operationalAspectList) {
				map = new HashMap<String, Object>();
				map.put("title", operationalAspect.getName());
				map.put("info", "δ���");
				list.add(map);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	/***
	 * ��̬����listview�ĸ߶�
	 * 
	 * @param listView
	 */
	public void setListViewHeightBasedOnChildren(ListView listView) {
		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null) {
			return;
		}
		int totalHeight = 0;
		for (int i = 0; i < listAdapter.getCount(); i++) {
			View listItem = listAdapter.getView(i, null, listView);
			listItem.measure(0, 0);
			totalHeight += listItem.getMeasuredHeight();
		}
		ViewGroup.LayoutParams params = listView.getLayoutParams();
		params.height = totalHeight
				+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
		listView.setLayoutParams(params);
	}
}