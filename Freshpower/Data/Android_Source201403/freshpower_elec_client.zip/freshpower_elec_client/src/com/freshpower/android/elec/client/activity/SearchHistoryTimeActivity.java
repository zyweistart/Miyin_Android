package com.freshpower.android.elec.client.activity;


import java.util.Calendar;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.common.LogFactory;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.DatePicker.OnDateChangedListener;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

public class SearchHistoryTimeActivity extends Activity {
	private LogFactory logger = LogFactory.getLogger(SearchHistoryTimeActivity.class);
	
	private int year;  
	private int month;  
	private int day;  
	private String selType;
	private String time;
	Calendar c;
	@SuppressLint("NewApi")
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.activity_search_history_time);
		DatePicker datapicker = (DatePicker) findViewById(R.id.datepicker); 
		selType = getIntent().getStringExtra("selType"); 
		c =Calendar.getInstance();  
		year =c.get(Calendar.YEAR);  
		month=c.get(Calendar.MONTH);  
		day=c.get(Calendar.DAY_OF_MONTH); 
		LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(140,LayoutParams.FILL_PARENT);
		((ViewGroup)((ViewGroup) datapicker.getChildAt(0)).getChildAt(0)).getChildAt(1).setLayoutParams(lp2);
		if(selType.equals("Day")){
			showDate(year,month,day);  
		}else{
			showMonth(year,month);
			if(datapicker != null){
				if(android.os.Build.VERSION.SDK_INT > android.os.Build.VERSION_CODES.HONEYCOMB_MR1){
					((ViewGroup)((ViewGroup) datapicker.getChildAt(0)).getChildAt(0)).getChildAt(2).setVisibility(View.GONE);
				}else{
					((ViewGroup) datapicker.getChildAt(0)).getChildAt(2).setVisibility(View.GONE);
				}
			}
		}
		datapicker.init(year, month, day, new OnDateChangedListener() {  
			@Override  
			public void onDateChanged(DatePicker view, int year, int monthOfYear,  
					int dayOfMonth) {  
				SearchHistoryTimeActivity.this.year=year;  
				SearchHistoryTimeActivity.this.month=monthOfYear;  
				SearchHistoryTimeActivity.this.day=dayOfMonth;  
				logger.d("BID", "selType:"+selType);
				if(selType.equals("Day")){
					showDate(year,month,day);  
				}else{
					showMonth(year,month);
				}
			}  
		});
		Button bt = (Button) findViewById(R.id.bt);  
		bt.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				Intent intent=new Intent();
				intent.putExtra("timeValue", time);
				setResult(AppConstant.RequestResultCode.RESULT_LINE_TIME, intent);
				finish();
			}
		});
		Button not_bt = (Button) findViewById(R.id.not_bt); 
		not_bt.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				SearchHistoryTimeActivity.this.onBackPressed();
			}
		});
		
	}  

	private void showDate(int year, int month, int day) {  
		time=year+"-"+(month+1)+"-"+day;
	}
	private void showMonth(int year, int month){
		time = year+"-"+(month+1);
	}
}
