package com.freshpower.android.elec.client.activity;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.freshpower.android.elec.client.R;

public class StationDetailInfoActivity extends FrameActivity {
	private ImageButton homeBtn;
	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_stationdetail);
		Intent it=getIntent();
		TextView textView1=(TextView)findViewById(R.id.stationDeatil_1);
		String meterName =it.getStringExtra("MeterName");
		textView1.setText(meterName);
		TextView textView2=(TextView)findViewById(R.id.stationDeatil_2);
		String reportDate =it.getStringExtra("ReportDate");
		textView2.setText(reportDate);
		TextView textView3=(TextView)findViewById(R.id.stationDeatil_3);
		String switchStatus =it.getStringExtra("SwitchStatus");
		textView3.setText(switchStatus);
		TextView textView4=(TextView)findViewById(R.id.stationDeatil_4);
		String dayPower =it.getStringExtra("DayPower");
		textView4.setText(dayPower);
		TextView textView5=(TextView)findViewById(R.id.stationDeatil_5);
		String va =it.getStringExtra("Va");
		textView5.setText(va);
		TextView textView6=(TextView)findViewById(R.id.stationDeatil_6);
		String vb =it.getStringExtra("Vb");
		textView6.setText(vb);
		TextView textView7=(TextView)findViewById(R.id.stationDeatil_7);
		String vc =it.getStringExtra("Vc");
		textView7.setText(vc);
		TextView textView8=(TextView)findViewById(R.id.stationDeatil_8);
		String ia =it.getStringExtra("Ia");
		textView8.setText(ia);
		TextView textView9=(TextView)findViewById(R.id.stationDeatil_9);
		String ib =it.getStringExtra("Ib");
		textView9.setText(ib);
		TextView textView10=(TextView)findViewById(R.id.stationDeatil_10);
		String ic =it.getStringExtra("Ic");
		textView10.setText(ic);
		TextView textView11=(TextView)findViewById(R.id.stationDeatil_11);
		String totalPower =it.getStringExtra("Power");
		textView11.setText(totalPower);
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
	        iv.setOnClickListener(new OnClickListener() {
	        	@Override
				public void onClick(View v) {
	        		StationDetailInfoActivity.this.onBackPressed();
				}
			});
	}
	protected void onResume() {
		homeBtn = (ImageButton) findViewById(R.id.stationDataBtn);
		if(homeBtn!=null){
			homeBtn.setOnClickListener(null);
			homeBtn.setBackgroundResource(R.drawable.databtn_select);
		}
		
		TextView toolBtnTv = (TextView)findViewById(R.id.stationDataTv);
		toolBtnTv.setTextColor(getResources().getColor(R.color.station));
		
		super.onResume();
	}
	
}
