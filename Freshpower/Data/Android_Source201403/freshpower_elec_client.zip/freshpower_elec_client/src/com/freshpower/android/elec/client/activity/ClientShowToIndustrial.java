package com.freshpower.android.elec.client.activity;

import java.text.DecimalFormat;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.AppConstant;

public class ClientShowToIndustrial extends Activity {
	private DecimalFormat df = new DecimalFormat("0.00");
	private String countDown;
	private String dayPriceElectricity;
	private String monthPriceElectricity;
	private TextView showText;
	private Button commit;
	private Button cancel;
	private Button end;
	private StringBuffer textBuf = new StringBuffer();
	private String maxLine;// ƽ�������ߵ���·
	private String minLine;// ƽ�������͵���·
	private String economizeFee;// ��Լ�ķ���
	private String maxPrice;
	private String minPrice;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		setContentView(R.layout.activity_client_show_to_industrial);
		ActivityUtil.addActivity(this);
		showText = (TextView)findViewById(R.id.show_text);
		commit = (Button)findViewById(R.id.commit);
		cancel = (Button)findViewById(R.id.cancel);
		end = (Button)findViewById(R.id.end);
		Intent intent = getIntent();
		countDown = intent.getStringExtra("countDown");
		dayPriceElectricity = intent.getStringExtra("dayPriceElectricity");
		monthPriceElectricity = intent.getStringExtra("monthPriceElectricity");
		maxLine = intent.getStringExtra("maxLine");
		minLine = intent.getStringExtra("minLine");
		maxPrice = intent.getStringExtra("maxPrice");
		minPrice = intent.getStringExtra("minPrice");
		economizeFee = intent.getStringExtra("economizeFee");
		if(countDown.equals("30")){
			if(dayPriceElectricity.indexOf("-") == -1) {
				textBuf.append("        ����ƽ����۸�������ƽ�����"+df.format(Double.valueOf(dayPriceElectricity))+"Ԫ/kWh ��");
			} else {
				textBuf.append("        ����ƽ����۵�������ƽ�����"+df.format(Double.valueOf(dayPriceElectricity.substring(1)))+"Ԫ/kWh ��");
			}
			if(monthPriceElectricity.indexOf("-") == -1) {
				textBuf.append("���½���֧��"+df.format(Double.valueOf(monthPriceElectricity))+"Ԫ��");
			} else {
				textBuf.append("���½���֧��"+df.format(Double.valueOf(monthPriceElectricity.substring(1)))+"Ԫ��");
			}
			showText.setText(textBuf.toString());
			showText.setTextSize(14);
			showText.setPadding(10, 0, 10, 0);
		} else if(countDown.equals("60")){
			showText.setText("        ����ƽ�������ߵ���·��"+maxLine+"��ƽ�����"+(maxPrice.equals("NaN")?"0.00":maxPrice)+"Ԫ/kWh��ƽ�������͵���·��"+minLine+"��ƽ�����"+(minPrice.equals("NaN")?"0.00":minPrice)+"Ԫ/kWh��");
			showText.setTextSize(14);
			showText.setPadding(10, 0, 10, 0);
		} else if(countDown.equals("90")){
			commit.setVisibility(View.GONE);
			cancel.setVisibility(View.GONE);
			end.setVisibility(View.VISIBLE);
			showText.setText("        ��ҵ�Ĺȵ������ʽϵͣ���������50�����ܹ��ڷ�"+economizeFee+"Ԫ��");
			showText.setTextSize(14);
			showText.setPadding(10, 0, 10, 0);
		}
		commit.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				ClientShowToIndustrial.this.onBackPressed();
			}
		});
		cancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				setResult(AppConstant.RequestResultCode.RESULT_CANCEL,intent);
				ClientShowToIndustrial.this.onBackPressed();
			}
		});
		end.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				ClientShowToIndustrial.this.onBackPressed();
			}
		});
		ImageView close = (ImageView)findViewById(R.id.closeBtn);
		close.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				ClientShowToIndustrial.this.onBackPressed();
			}
		});
	}
}
