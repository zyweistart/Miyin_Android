package com.freshpower.android.elec.client.activity;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;

import org.apache.http.conn.HttpHostConnectException;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.AppCache;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.common.StringUtil;
import com.freshpower.android.elec.client.domain.LoginInfo;
import com.freshpower.android.elec.client.domain.UserRegisterInfo;
import com.freshpower.android.elec.client.netapi.LoginInfoDataApi;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.AlertDialog.Builder;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class PhontoActivity extends Activity {

	private ImageView cardView;
	private ImageView leftView;
	private ImageView eleView;
	private Button photosub;
	private UserRegisterInfo  login;

	private Bitmap photo;
	private Bitmap photo2;

	private File cardFile;
	private File eleFile;

	private TextView cardTv;
	private TextView eleTv;

	private int cardNo;//0Ϊ����֤1Ϊ�繤֤

	private ProgressDialog processProgress;
	private Handler handler = new Handler();

	private String saveDir = Environment.getExternalStorageDirectory()
			.getPath() + "/temp_image";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.photo_activity);
		ActivityUtil.addActivity(this);
		photosub = (Button)findViewById(R.id.photo_sub);
		cardView = (ImageView)findViewById(R.id.iv_image);
		eleView = (ImageView)findViewById(R.id.iv_image2);

		cardTv = (TextView)findViewById(R.id.cardTextView);
		eleTv = (TextView)findViewById(R.id.eleTextView);



		leftView= (ImageView)findViewById(R.id.photo_left);
		leftView.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				PhontoActivity.this.onBackPressed();
			}
		});

		photosub.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {

				if(cardFile==null || StringUtil.isEmpty(cardFile.getAbsolutePath()))
				{
					Toast.makeText(PhontoActivity.this, "����֤��Ƭ����Ϊ�գ����ϴ�",Toast.LENGTH_SHORT).show();
					return;
				}
				if(eleFile==null || StringUtil.isEmpty(eleFile.getAbsolutePath()))
				{
					Toast.makeText(PhontoActivity.this, "�繤֤��Ƭ����Ϊ�գ����ϴ�",Toast.LENGTH_SHORT).show();
					return;
				}
				Intent it=getIntent();
				login=new UserRegisterInfo();
				login.setLoginRegisterCardNum(it.getStringExtra("registerCardNum"));
				login.setLoginRegisterName(it.getStringExtra("registerName"));
				login.setLoginRegisterTel(it.getStringExtra("registerTel"));
				login.setLoginRegisterAddress(it.getStringExtra("registerAddress"));
				processProgress = ProgressDialog.show(PhontoActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
				new Thread(new Runnable(){
					String msgContent;
					@Override
					public void run() {
						String rs = "0";
						msgContent=getResources().getString(R.string.msg_registeryes); 
						try {
							rs=LoginInfoDataApi.testUpload(login, cardFile,eleFile);
						}catch (HttpHostConnectException e) {
							msgContent=getResources().getString(R.string.msg_abnormal_network); 
						}catch (Exception e) {
							msgContent=getResources().getString(R.string.msg_abnormal_network); 
						}finally{
							processProgress.dismiss();
							handler.post(new Runnable() {
								@Override
								public void run() {
									Toast.makeText(PhontoActivity.this, msgContent, Toast.LENGTH_SHORT).show(); 								
								}
							});
							if(rs.equals("1")){
								Intent intent = new Intent(PhontoActivity.this, HomeActivity.class);
								startActivity(intent);
								finish();
							}
						}
					}

				}).start();
			}
		});
		cardView.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {

				AlertDialog.Builder builder = new Builder(PhontoActivity.this);
				builder.setTitle(R.string.photo_title);
				cardNo = 0;
				builder.setItems(R.array.photos, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface paramDialogInterface,
							int paramInt) {
						if (paramInt == 0) {
							// ��ʾ���ضԻ���
							//destoryImage();
							String state = Environment.getExternalStorageState();
							if (state.equals(Environment.MEDIA_MOUNTED)) {
								cardFile = new File(saveDir, "temp_1.jpg");
								cardFile.delete();
								if (!cardFile.exists()) {
									try {
										cardFile.createNewFile();
									} catch (IOException e) {
										e.printStackTrace();
										Toast.makeText(PhontoActivity.this, "��Ƭ����ʧ��!",
												Toast.LENGTH_LONG).show();
										return;
									}
								}
								Intent intent = new Intent(
										"android.media.action.IMAGE_CAPTURE");
								intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(cardFile));
								startActivityForResult(intent, 1);
							} else {
								Toast.makeText(PhontoActivity.this, "sdcard��Ч��û�в���!",
										Toast.LENGTH_SHORT).show();
							}
						} else if (paramInt == 1) {
							Intent getAlbum = new Intent(Intent.ACTION_GET_CONTENT);
							getAlbum.setType("image/*");
							startActivityForResult(getAlbum, 3);
						}
					}
				});
				Dialog noticeDialog = builder.create();
				noticeDialog.show();
			}
		});
		eleView.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {

				AlertDialog.Builder builder = new Builder(PhontoActivity.this);
				builder.setTitle(R.string.photo_title);
				cardNo = 1;
				builder.setItems(R.array.photos, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface paramDialogInterface,
							int paramInt) {
						if (paramInt == 0) {
							// ��ʾ���ضԻ���
							//destoryImage();
							String state = Environment.getExternalStorageState();
							if (state.equals(Environment.MEDIA_MOUNTED)) {
								eleFile = new File(saveDir, "temp_2.jpg");
								eleFile.delete();
								if (!eleFile.exists()) {
									try {
										eleFile.createNewFile();
									} catch (IOException e) {
										e.printStackTrace();
										Toast.makeText(PhontoActivity.this, "��Ƭ����ʧ��!",
												Toast.LENGTH_LONG).show();
										return;
									}
								}
								Intent intent = new Intent(
										"android.media.action.IMAGE_CAPTURE");
								intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(eleFile));
								startActivityForResult(intent, 1);
							} else {
								Toast.makeText(PhontoActivity.this, "sdcard��Ч��û�в���!",
										Toast.LENGTH_SHORT).show();
							}
						} else if (paramInt == 1) {
							Intent getAlbum = new Intent(Intent.ACTION_GET_CONTENT);
							getAlbum.setType("image/*");
							startActivityForResult(getAlbum, 4);
						}
					}
				});
				Dialog noticeDialog = builder.create();
				noticeDialog.setCanceledOnTouchOutside(false);
				noticeDialog.show();
			}
		});

		File savePath = new File(saveDir);
		if (!savePath.exists()) {
			savePath.mkdirs();
		}

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == 1 && resultCode == RESULT_OK) {
			if (cardFile != null && cardFile.exists() && cardNo == 0) {
				BitmapFactory.Options option = new BitmapFactory.Options();
				option.inSampleSize = 8;

				photo = BitmapFactory.decodeFile(cardFile.getPath(), option);
				cardView.setImageBitmap(photo);
			}else	if (eleFile != null && eleFile.exists() && cardNo == 1) {
				BitmapFactory.Options option = new BitmapFactory.Options();
				option.inSampleSize = 8;

				photo2 = BitmapFactory.decodeFile(eleFile.getPath(), option);
				eleView.setImageBitmap(photo2);
			}
		}
		else if (requestCode == 2 && resultCode == RESULT_OK) {// ����ȡ
			//Log.d("trmsDebug", "2222");
			Bitmap cameraBitmap = (Bitmap) data.getExtras().get("data");
			photo = cameraBitmap;
			if(cardNo == 0){
				cardView.setImageBitmap(photo);
			}else{
				eleView.setImageBitmap(photo);
			}
		} else if ((requestCode == 3 ||requestCode == 4)&& resultCode == RESULT_OK) {// ������ȡ
			// ���ĳ������ContentProvider���ṩ���� ����ͨ��ContentResolver�ӿ�

			ContentResolver resolver = getContentResolver();

			// �˴��������жϽ��յ�Activity�ǲ�������Ҫ���Ǹ�

			Uri originalUri = data.getData(); // ���ͼƬ��uri
			String selectedImagePath2 = getPath(originalUri);

			Bitmap bm = null;
			// �Եõ�bitmapͼƬ
			if(cardNo == 0){
				cardView.setImageBitmap(PhontoActivity.lessenUriImage(selectedImagePath2)); 
			}else{
				eleView.setImageBitmap(PhontoActivity.lessenUriImage(selectedImagePath2)); 
			}

			// ���￪ʼ�ĵڶ����֣���ȡͼƬ��·����

			String[] proj = { MediaStore.Images.Media.DATA };

			// ������android��ý�����ݿ�ķ�װ�ӿڣ�����Ŀ�Android�ĵ�
			Cursor cursor = managedQuery(originalUri, proj, null, null, null);

			// ���Ҹ������� ����ǻ���û�ѡ���ͼƬ������ֵ

			int column_index = cursor
					.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);

			// �����������ͷ ���������Ҫ����С�ĺ���������Խ��

			cursor.moveToFirst();

			// ����������ֵ��ȡͼƬ·��

			String path = cursor.getString(column_index);
			if(requestCode==3)
				cardFile = new File(path);
			else
				eleFile = new File(path);
		}
	}

	@Override
	protected void onDestroy() {
		Log.d("BID", "onDestroy....");
		destoryImage();
		super.onDestroy();
	}

	private void destoryImage() {
		if (photo != null) {
			photo.recycle();
			photo = null;
		}
		if(photo2!=null){
			photo2.recycle();
			photo2 = null;
		}
	}
	public String getPath(Uri uri)  
    {    
       String[] projection = {MediaStore.Images.Media.DATA };    
       Cursor cursor = managedQuery(uri, projection, null, null, null);    
       int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);    
       cursor.moveToFirst();    
       return cursor.getString(column_index);    
    } 
	  public final static Bitmap lessenUriImage(String path)
	  { 
	   BitmapFactory.Options options = new BitmapFactory.Options(); 
	   options.inJustDecodeBounds = true; 
	   Bitmap bitmap = BitmapFactory.decodeFile(path, options); //��ʱ���� bm Ϊ�� 
	   options.inJustDecodeBounds = false; //���űȡ������ǹ̶��������ţ�ֻ�ø߻��߿�����һ�����ݽ��м��㼴��
	   int be = (int)(options.outHeight / (float)320); 
	   if (be <= 0) 
	    be = 1;
	   options.inSampleSize = be; //���¶���ͼƬ��ע���ʱ�Ѿ��� options.inJustDecodeBounds ��� false �� 
	   bitmap=BitmapFactory.decodeFile(path,options); 
	   int w = bitmap.getWidth(); 
	   int h = bitmap.getHeight(); 
	   System.out.println(w+" "+h); //after zoom
	   return bitmap;
	  }

}
