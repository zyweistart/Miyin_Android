package com.freshpower.android.elec.client.activity;

import org.apache.http.conn.HttpHostConnectException;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.StringUtil;
import com.freshpower.android.elec.client.domain.AggregatorInfo;
import com.freshpower.android.elec.client.domain.CompanyInfo;
import com.freshpower.android.elec.client.netapi.ScanInfoDateApi;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ScanAggregatorActivity extends Activity {
	private String siteId;
	private AggregatorInfo agg = new AggregatorInfo();
	String serialNo;
	private ProgressDialog processProgress;
	private Handler handler = new Handler();
	
	TextView textView1;
	TextView textView2;
	TextView textView3;
	TextView textView4;
	TextView textView5;
	TextView textView6;
	TextView textView7;
	TextView textView8;
	TextView textView9;
	TextView textView10;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.activity_scan_aggregator);
		 textView1 =  (TextView)findViewById(R.id.scan_aggregator_view1);
		 textView2 =  (TextView)findViewById(R.id.scan_aggregator_view2);
		 textView3 =  (TextView)findViewById(R.id.scan_aggregator_view3);
		 textView4 =  (TextView)findViewById(R.id.scan_aggregator_view4);
		 textView5 =  (TextView)findViewById(R.id.scan_aggregator_view5);
		 textView6 =  (TextView)findViewById(R.id.scan_aggregator_view6);
		 textView7 =  (TextView)findViewById(R.id.scan_aggregator_view7);
		 textView8 =  (TextView)findViewById(R.id.scan_aggregator_view8);
		 textView9 =  (TextView)findViewById(R.id.scan_aggregator_view9);
		 textView10 =  (TextView)findViewById(R.id.scan_aggregator_view10);
		
		Button informationView = (Button)findViewById(R.id.scan_aggregator_btn);
		informationView.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				//Log.d("sum", "begin");
				Intent it = new Intent();
				it.putExtra("siteId", siteId);
				it.setClass(ScanAggregatorActivity.this, CompanyInfoActivity.class);
				startActivity(it);
			}
		});
		ImageView returnBtn = (ImageView)findViewById(R.id.scan_aggregator_return);
		returnBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				ScanAggregatorActivity.this.onBackPressed();
			}
		});
		Intent intent = getIntent();
		serialNo = intent.getStringExtra("serialNo");
		processProgress = ProgressDialog.show(ScanAggregatorActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(new Runnable(){
			String content;
			@Override
			public void run() {
				try {
					agg = ScanInfoDateApi.getAggregatorInfo("","",serialNo);
				} catch (HttpHostConnectException e) {
					content =  "�������粻�ȶ������Ժ����ԣ�";
					e.printStackTrace();
				} catch (Exception e) {
					content =  "�������粻�ȶ������Ժ����ԣ�";
					e.printStackTrace();
				}finally{
					if(agg.getResult()!=null){
						content = ScanInfoDateApi.showMsg(agg.getResult());
					}else if(agg.getSerialNo()==null){
						content =  "û�д˻㼯����Ϣ��";
					}
					processProgress.dismiss();
					handler.post(new Runnable() {
						@Override
						public void run() {
							if(!StringUtil.isEmpty(content)){
								Toast.makeText(ScanAggregatorActivity.this, content, Toast.LENGTH_SHORT).show();
							}
							textView1.setText(agg.getSerialNo());
							textView2.setText(agg.getProductNo());
							textView3.setText(agg.getCommuType());
							if(agg.getIsOnLine()!=null){
								if(agg.getIsOnLine().equals("1")){
									textView4.setText("����");
								}else{
									textView4.setText("������");
								}
							}else{
								textView4.setText("");
							}
							textView5.setText(agg.getCpName());
							textView6.setText(agg.getConvergeKey());
							textView7.setText(agg.getLinesCount());
							textView8.setText(agg.getMetersCount());
							textView9.setText(agg.getAlarmCount());
							textView10.setText(agg.getErrCount());
							siteId = agg.getSiteId();
						}
					});
				}
			}
		}).start();

		/*

		if(agg.getResult()!=null){
			Toast.makeText(ScanAggregatorActivity.this, ScanInfoDateApi.showMsg(agg.getResult()), Toast.LENGTH_SHORT).show();
			return;
		}else if(agg.getSerialNo()==null){
			Toast.makeText(ScanAggregatorActivity.this, "û�д˻㼯����Ϣ��", Toast.LENGTH_SHORT).show();
			return;
		}*/
		
	}
}
