package com.freshpower.android.elec.client.common;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class GetCurrentData {
	DecimalFormat df =new DecimalFormat("0.00"); //��ȡ��С�������λ
	double [][] threePhaseCurrentLeft = new double [4][3];//������������¼
	double [][] threePhaseCurrentRight = new double [4][3];//�Ҳ����������¼
	//public Timer timer = new Timer();
	Intent intent = null;
	int textViewNumTemp = 1;
	//����������һ�ν����Ƿ�ͱ��ν�����ͬһ���ߣ��Ƿ�����ֵ������䣩
	//����ͼ�ε���·
	public static String inComingLine = "";
	//----------------------

    double sumChargeLeft = 0;
    double sumChargeRight = 0;
    double sumTotalPowerDouble = 0;
    double[] nowMinutes = new double[8];//��ǰ����ӵĵ���
    double[] lastMinutes = new double[8];//��һ���ӵĵ�����
    double lastMintesSum = 0;//��һ���������ߵ��ܵ���
    double lastMintesLeft = 0;
    double lastMintesRight = 0;
    double[] sumTotalPowerDoubleList = new double[12];//�ܵ���list(���ڵ�ǰչʾ��12���������)
    double[] totalPowerDouble = new double[8];//ͬһʱ�������߲�ͬ�ĵ���ֵ
    
    double[] sumChargeDoubleList = new double[12];//�ܸ���List������չʾ��12���㣩
    double[] sumTotalPowerMoneyList = new double[12];//�ܵ��list
	//�˸����ذ�ť
    //-----------------
	public static Boolean[] finalB = new Boolean[8];
	public static Boolean finalB9 = false;//�м俪�أ�Ĭ��Ϊ��բ״̬
	//------------------------------
	double[] a = new double[12];//����a
	double[] b = new double[12];//����b
	double[] c = new double[12];//����c
    ArrayList<double[]> totalPowerDoubleList = new ArrayList<double[]>();
    public static ArrayList<double[]> chargeDoubleList = new ArrayList<double[]>();//�����ܸ���
    public static double sumChargeDouble = 0 ; //�ܸ���
	public static int time = 1;//ÿ12�μ��㵱ǰ�ܵ���
	public static ArrayList<List<double[][]>> currentList = new ArrayList<List<double[][]>>();
	public static OnOffThread myThread = null;
	double[] coefficientList = new double[12];//���ֵlist
	public static double coefficient = 0;//ϵ��B
	public static int textViewNum = 1;
    double chargeSumList[] = new double[8];//���ߵ�������(��Ž���list����ͬһʱ��İ����߲�ֵͬ)
    
    double electriCurrentTemp = 0 ;//��¼�������ĵ���ֵ������ÿ����ǰ������Ĳ���
    //---------------
	private double maxCurrent = 0;
	double minCurrent = 0;
	double max = 0;
	double min = 0;
	public static double powerFactor = 0 ;
	/**
	 * @param args
	 */
	public void start(){
		//Ϊ������ʹ�õ���list����ֵ����ֹ����ָ�����
		for(int i = 0 ;i < 12 ; i++){
			List temp = new ArrayList<double[][]>();
			for(int j = 0 ; j < 2 ; j++){
				temp.add(new double[4][3]);
			}
			chargeDoubleList.add(new double[8]);//�����ܸ��ɳ�ʼ��
			totalPowerDoubleList.add(new double[8]);//�����ܵ�����ʼ��
			currentList.add(temp);
		}
		for(int i = 0 ; i < 8 ; i ++){
			finalB[i] = true ; 
		}
		//---------------------------------
		myThread = new OnOffThread();
        myThread.start(); //������������߳�
        //---------------------------------
	 	//������Ϣ
		Date date = new Date();
		int hour = date.getHours();
		if(hour >= 8 && hour <= 18){
			maxCurrent = 866 * 1.2;
			minCurrent = 866 * 0.8;
			max = 94.5;
			min = 76.9;
		}else{
			maxCurrent = 866 * 1.12;
			minCurrent = 866 * 0.88;
			max = 99.232;
			min = 84.67;
		}
		powerFactor = Math.random()*0.1+0.9;
	}

    private Handler  handler = new Handler(){
    	public void handleMessage(android.os.Message msg) {
    		if(msg.what==1){
    			List<double[][]> Current = new ArrayList<double[][]>();
    			Current = setCurrentTextView();
    			currentList.remove(0);
				currentList.add(11,Current);
				chargeDoubleList.remove(0);
				chargeDoubleList.add(11,chargeSumList);
    		}
    		double[][] temp = null;
    		for(int i = 0; i < 12 ; i++) {
	        	if(textViewNum >= 5){//ÿ��list��ǰ�ĸ�Ϊ�Ҳ�
	        		temp = currentList.get(i).get(1);
	            	a[i] = temp[textViewNum-5][0];//ÿ����һ��ĵ���ֵ
	            	b[i] = temp[textViewNum-5][1];
	            	c[i] = temp[textViewNum-5][2];
	            	sumChargeDoubleList[i] = chargeDoubleList.get(i)[textViewNum-1];//ÿ����һ��ĸ���ֵ
	        	}else{//ÿ��list�к��ĸ�Ϊ���
	        		temp = currentList.get(i).get(0);
	            	a[i] = temp[textViewNum-1][0];//ÿ����һ��ĵ���ֵ
	            	b[i] = temp[textViewNum-1][1];
	            	c[i] = temp[textViewNum-1][2];
	            	sumChargeDoubleList[i] = chargeDoubleList.get(i)[textViewNum-1];//ÿ����һ��ĸ���ֵ
	        	}
    		}
    		textViewNumTemp = textViewNum;//���˴ν������·��ż�¼����
			if(time%12 == 0){//������·����һ����ʱ�����²��õ���ͼ
				totalPowerDoubleList.remove(0);
				totalPowerDoubleList.add(11,totalPowerDouble);
//				Log.d("BID","totalPowerDoubleList��"+totalPowerDoubleList.get(11)[4]);
			}
			for(int i = 0; i < 12 ; i++){
				sumTotalPowerDoubleList[i] = Double.valueOf(df.format(totalPowerDoubleList.get(i)[textViewNum-1]));
				sumTotalPowerMoneyList[i] = Double.valueOf(df.format(totalPowerDoubleList.get(i)[textViewNum-1] * calculationTime()));
			}
    	};
    };
    
    public class OnOffThread extends Thread{
    	
    	public boolean isDestory=false;
    	
    	public void setDestory(boolean isDestory){
    		this.isDestory = isDestory;
    	}
    	public void starts(){
    		myThread = new OnOffThread();
    		myThread.start();
    	}
    	
    	@Override
    	public void run() {
    		try {
        		while(!isDestory){
					if(isDestory)break;
	            	Message msg  = new Message();
	            	msg.what = 1;
	            	handler.sendMessage(msg);
	            	Thread.sleep(5000);
        		}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
    	}
    }
    
    public List<double[][]> setCurrentTextView(){
		chargeSumList = new double[8];//���½�����ʵ����,��ֹ��β���ͬһ�ڴ��ַ
        threePhaseCurrentLeft = new double[4][3];
        threePhaseCurrentRight = new double[4][3];
		Double rnd = Math.random()+0.2 ;//����������������
		if(rnd<0.8){
			rnd = 0.8;
		}
		
		rnd = Double.valueOf(df.format(rnd));
		double electricCurrentLeft = 0 ;
		//��¼�������ĵ���ֵ������ÿ����ǰ������Ĳ���������5%
		if(time == 1){
			electricCurrentLeft = 866 * rnd;
			electriCurrentTemp = electricCurrentLeft ; 
		}else{
			if(rnd>0.5){
				electricCurrentLeft = electriCurrentTemp * 1.05;
			}else{
				electricCurrentLeft = electriCurrentTemp * 0.95;
			}
		}
		if(electricCurrentLeft >=maxCurrent){electricCurrentLeft = maxCurrent-max;}
		if(electricCurrentLeft < minCurrent){electricCurrentLeft = minCurrent + min;}
		electriCurrentTemp = electricCurrentLeft ;
		//---------------------------------------------------
		//��������������·�ĵ����˴�֮��������5%
		rnd = Math.random() ;//����������������
		double electricCurrentRight = 0 ;
		if(rnd>0.5){
			electricCurrentRight = electricCurrentLeft * 1.05;
		}else{
			electricCurrentRight = electricCurrentLeft * 0.95;
		}
		if(electricCurrentRight >=1345){electricCurrentRight = 1443-108.2;}
		//--------------------------------------------------
		//����Ia��Ib��Ic�������֮��ķ��Ȳ�����5%
		int sign = -1;
		double scope = 0.025;
		if(finalB9){
	        for(int i = 0 ;i < 3;i++){
	        	rnd = Math.random() ;
	        	if(rnd> 0.5){
	        		sign = -1;
	        	}else{
	        		sign = 1;
	        	}
		        if(finalB[0]){
		        	consolidated(i,electricCurrentLeft*(1 + scope * i * sign ));
		        }else if(finalB[4]){
		        	consolidated(i,electricCurrentRight*(1 + scope * i * sign ));
		        }
			}
		}else{
	        for(int i = 0 ;i < 3;i++){
	        	rnd = Math.random() ;
	        	if(rnd> 0.5){
	        		sign = -1;
	        	}else{
	        		sign = 1;
	        	}
	        	calculate(threePhaseCurrentLeft,i,0,electricCurrentRight*(1 + scope * i * sign ));//���
	        	calculate(threePhaseCurrentRight,i,1,electricCurrentLeft*(1 + scope * i * sign ));//�ұ�
	        }
		}
        //----------------------------------------------
        //ҳ����ʾ������Ϣ
        for(int i = 0; i < 4 ; i++){
        	double currentSum = 0;
        	StringBuffer current = new StringBuffer();
        	for(char j = 'a'; j < 'd' ;j++){
        		current.append("I"+j+"="+df.format(threePhaseCurrentLeft[i][j-97])+";\n");
        		currentSum+=threePhaseCurrentLeft[i][j-97];
        	}
        	chargeSumList[i]= Double.parseDouble(df.format(220 * currentSum * powerFactor / 1000));
        }
        for(int i = 0; i < 4 ; i++){
        	double currentSum = 0;
        	StringBuffer current = new StringBuffer();
        	for(char j = 'a'; j < 'd' ;j++){
        		current.append("I"+j+"="+df.format(threePhaseCurrentRight[i][j-97])+";\n");
        		currentSum+=threePhaseCurrentRight[i][j-97];
        	}
        	chargeSumList[i+4]= Double.parseDouble(df.format(220 * currentSum * powerFactor / 1000));
        } 
        //--------------------------------------
        //���ɣ��ܵ���
        //------------------------
        double lefta = 220 * threePhaseCurrentLeft[0][0] *powerFactor ; 
        double leftb = 220 * threePhaseCurrentLeft[0][1] *powerFactor ; 
        double leftc = 220 * threePhaseCurrentLeft[0][2] *powerFactor ; 
        double righta = 220 * threePhaseCurrentRight[0][0] *powerFactor ; 
        double rightb = 220 * threePhaseCurrentRight[0][1] *powerFactor ;
        double rightc = 220 * threePhaseCurrentRight[0][2] *powerFactor ;
        //Log.d("elec", String.valueOf(threePhaseCurrentLeft[0][0]));
        sumChargeLeft = lefta + leftb + leftc;
        sumChargeRight = righta + rightb +rightc;
        sumChargeDouble = (sumChargeLeft + sumChargeRight)/1000;
        
        if(time==1){
        	for(int i = 0 ; i < 4 ; i++){//��¼ÿ�������ʼ�ĵ���
        		lastMinutes[i] = 220 * threePhaseCurrentLeft[i][0] * powerFactor 
        				+ 220 * threePhaseCurrentLeft[i][1] * powerFactor 
        				+ 220 * threePhaseCurrentLeft[i][2] * powerFactor;
        	}
        	for(int i = 0 ; i < 4 ; i++){
        		lastMinutes[i+4] = 220 * threePhaseCurrentRight[i][0] * powerFactor 
        				+ 220 * threePhaseCurrentRight[i][1] * powerFactor 
        				+ 220 * threePhaseCurrentRight[i][2] * powerFactor; 
        	}
        }
        time++;//ÿ�����ۼ�һ��
        if(time%12==0){
        	totalPowerDouble = new double[8];
        	if(!finalB[1] && !finalB[5]){
        		sumTotalPowerDouble =  sumTotalPowerDouble ;
        	}else if(!finalB[2] && !finalB[3] && !finalB[4] && !finalB[6] && !finalB[7] && !finalB[8]){
        		sumTotalPowerDouble =  sumTotalPowerDouble ;
        	}else{
        		if(finalB[1]){
        			lastMintesSum = lastMintesSum + lastMinutes[0];
        		}
        		if(finalB[5]){
        			lastMintesSum = lastMintesSum + lastMinutes[4];
        		}
        		lastMintesSum = lastMintesSum / 1000;
//        		Log.d("BID","sumTotalPowerDouble1��"+sumTotalPowerDouble);
        		sumTotalPowerDouble =  sumTotalPowerDouble +(lastMintesSum + sumChargeDouble)/2/60;
//        		Log.d("BID","sumTotalPowerDouble2��"+(lastMintesSum + sumChargeDouble)/2/60);
//        		Log.d("BID","sumTotalPowerDouble3��"+sumTotalPowerDouble);
        		lastMintesSum = 0;
        	}
        	for(int i = 0 ; i < 4 ; i++){//��¼ÿ�������ʼ�ĵ���
        		nowMinutes[i] = 220 * threePhaseCurrentLeft[i][0] * powerFactor 
        						+ 220 * threePhaseCurrentLeft[i][1] * powerFactor 
        						+ 220 * threePhaseCurrentLeft[i][2] * powerFactor;
        	}
        	for(int i = 0 ; i < 4 ; i++){
        		nowMinutes[i+4] = 220 * threePhaseCurrentRight[i][0] * powerFactor 
        						+ 220 * threePhaseCurrentRight[i][1] * powerFactor 
        						+ 220 * threePhaseCurrentRight[i][2] * powerFactor; 
        	}
        	setTotalPower();
        }
        //Log.d("elec", String.valueOf(sumTotalPowerDouble));
        List<double[][]> Current = new ArrayList<double[][]>();
        Current.add(threePhaseCurrentLeft);
        Current.add(threePhaseCurrentRight);
        sumTotalPowerDouble = Double.parseDouble(df.format(sumTotalPowerDouble));
        sumChargeDouble = Double.parseDouble(df.format(sumChargeDouble));
//        Log.d("elec", String.valueOf(sumChargeDouble));
        return Current;
    }
    
    private void setTotalPower(){
    	for(int i = 0 ; i < 8 ; i ++){
        	if(!finalB[i]){
        		totalPowerDouble[i] =  0;
        		lastMinutes[i] = 0;
        	}else{
        		totalPowerDouble[i] =  Double.parseDouble(df.format((nowMinutes[i] + lastMinutes[i])/2/60/1000));
        		lastMinutes[i] = nowMinutes[0];
        	}
    	}
    }
    
    public static double calculationTime(){//���㵱ǰʱ��ĵ��
    	Date time = new Date();
    	double money = 0 ;
    	int hour = time.getHours();
    	if(hour >= 19 && hour < 21){
    		money = 1.456;
    	}else if ((hour >= 8 && hour< 11)||(hour >= 13&&hour<19)||
    			(hour >= 21 && hour < 22)){
    		money = 1.151;
    	}else {
    		money = 0.628;
    	}
    	return money;
    }
    
    
    public static double businessCalculationTime(){//���㵱ǰʱ�����ҵ���
    	Date time = new Date();
    	double money = 0 ;
    	int hour = time.getHours();
    	if(hour >= 19 && hour < 21){
    		money = 1.406;
    	}else if ((hour >= 8 && hour< 11)||(hour >= 13&&hour<19)||
    			(hour >= 21 && hour < 22)){
    		money = 1.108;
    	}else {
    		money = 0.596;
    	}
    	return money;
    }
    
    public static double calculationIndustrialTime(){//���㵱ǰʱ��Ĺ�ҵ���
    	Date time = new Date();
    	double money = 0 ;
    	int hour = time.getHours();
    	if(hour >= 19 && hour < 21){
    		money = 1.123;
    	}else if ((hour >= 8 && hour< 11)||(hour >= 13&&hour<19)||
    			(hour >= 21 && hour < 22)){
    		money = 0.941;
    	}else {
    		money = 0.457;
    	}
    	return money;
    }
	/*
	 * ��ȡ��������
	 * threePhaseCurrent�洢���ݶ�ά����
	 * size �ڼ�����
	 * j ��������
	 */
	public void calculate(double [][] threePhaseCurrent,int size,int j,double electricCurrent){
		if( !finalB[0] && j == 0){//�ұ�
			threePhaseCurrent[0][size] = 0.0;//I*(���Էֱ����A,B,C)
			threePhaseCurrent[1][size] = 0.0;//I*1
			threePhaseCurrent[2][size] = 0.0;//I*2
			threePhaseCurrent[3][size] = 0.0;//I*3			
		}else if( !finalB[4] && j == 1){//���
			threePhaseCurrent[0][size] = 0.0;//I*(���Էֱ����A,B,C)
			threePhaseCurrent[1][size] = 0.0;//I*1
			threePhaseCurrent[2][size] = 0.0;//I*2
			threePhaseCurrent[3][size] = 0.0;//I*3
		}else{
			//getRandom();
			threePhaseCurrent[0][size] = Double.valueOf(df.format(electricCurrent));//I*(���Էֱ����A,B,C)
			if(j == 0){
				threePhaseCurrent[1][size] = electricCurrent * 0.2;//I*1
				threePhaseCurrent[2][size] = electricCurrent * 0.3;//I*2
				threePhaseCurrent[3][size] = electricCurrent * 0.5;//I*3
				if(!finalB[1]){
					threePhaseCurrent[0][size]= threePhaseCurrent[0][size] - threePhaseCurrent[1][size];
					threePhaseCurrent[1][size] = 0.0;
				}
				if(!finalB[2]){
					threePhaseCurrent[0][size]= threePhaseCurrent[0][size] - threePhaseCurrent[2][size];
					threePhaseCurrent[2][size] = 0.0;
				}
				if(!finalB[3]){
					threePhaseCurrent[0][size]= threePhaseCurrent[0][size] - threePhaseCurrent[3][size];
					threePhaseCurrent[3][size] = 0.0;
				}
				if(threePhaseCurrent[0][size] < 5)threePhaseCurrent[0][size] = 0.0;
			}else if(j == 1){
				threePhaseCurrent[1][size] = electricCurrent * 0.3;//I*1
				threePhaseCurrent[2][size] = electricCurrent * 0.5;//I*2
				threePhaseCurrent[3][size] = electricCurrent * 0.2;//I*3
				if(!finalB[5]){
					threePhaseCurrent[0][size]= threePhaseCurrent[0][size] - threePhaseCurrent[1][size];
					threePhaseCurrent[1][size] = 0.0;
				}
				if(!finalB[6]){
					threePhaseCurrent[0][size]= threePhaseCurrent[0][size] - threePhaseCurrent[2][size];
					threePhaseCurrent[2][size] = 0.0;
				}
				if(!finalB[7]){
					threePhaseCurrent[0][size]= threePhaseCurrent[0][size] - threePhaseCurrent[3][size];
					threePhaseCurrent[3][size] = 0.0 ;
				}
				if(threePhaseCurrent[0][size] < 5)threePhaseCurrent[0][size] = 0.0;
			}
		}
	}
	
	public void consolidated(int size,double electricCurrent){//�м�ϲ�ʱ�ļ��㷽��
		if( !finalB[0] && !finalB[4]){
			threePhaseCurrentRight[0][size] = 0.0;//I*(���Էֱ����A,B,C)
			threePhaseCurrentRight[1][size] = 0.0;//I*1
			threePhaseCurrentRight[2][size] = 0.0;//I*2
			threePhaseCurrentRight[3][size] = 0.0;//I*3
			threePhaseCurrentLeft[0][size] = 0.0;//I*1
			threePhaseCurrentLeft[1][size] = 0.0;//I*1
			threePhaseCurrentLeft[2][size] = 0.0;//I*2
			threePhaseCurrentLeft[3][size] = 0.0;//I*3
		}else{
			threePhaseCurrentRight[1][size] = electricCurrent*0.15;//I*1
			threePhaseCurrentRight[2][size] = electricCurrent*0.25;//I*2
			threePhaseCurrentRight[3][size] = electricCurrent*0.1;//I*3
			threePhaseCurrentLeft[1][size] = electricCurrent*0.15;//I*1
			threePhaseCurrentLeft[2][size] = electricCurrent*0.25;//I*2
			threePhaseCurrentLeft[3][size] = electricCurrent*0.1;//I*3
			if(!finalB[1]){
				electricCurrent = electricCurrent - threePhaseCurrentLeft[1][size];
				threePhaseCurrentLeft[1][size] = 0.0;
			}
			if(!finalB[2]){
				electricCurrent = electricCurrent - threePhaseCurrentLeft[2][size];
				threePhaseCurrentLeft[2][size] = 0.0;
			}
			if(!finalB[3]){
				electricCurrent = electricCurrent - threePhaseCurrentLeft[3][size];
				threePhaseCurrentLeft[3][size] = 0.0;
			}
			if(!finalB[5]){
				electricCurrent = electricCurrent - threePhaseCurrentRight[1][size];
				threePhaseCurrentRight[1][size] = 0.0;
			}
			if(!finalB[6]){
				electricCurrent = electricCurrent - threePhaseCurrentRight[2][size];
				threePhaseCurrentRight[2][size] = 0.0;
			}
			if(!finalB[7]){
				electricCurrent = electricCurrent - threePhaseCurrentRight[3][size];
				threePhaseCurrentRight[3][size] = 0.0 ;
			}
			if(finalB[0]){
				threePhaseCurrentRight[0][size] = 0.0;
				if(electricCurrent < 5)
					threePhaseCurrentLeft[0][size] = 0.0;
				else
					threePhaseCurrentLeft[0][size] = electricCurrent;
			}
			if(finalB[4]){
				threePhaseCurrentLeft[0][size] = 0.0;
				if(electricCurrent < 5)
					threePhaseCurrentRight[0][size] = 0.0;
				else
					threePhaseCurrentRight[0][size] = electricCurrent;
			}
		}
	}
	/*
	 * ���������cosֵ
	 */
	public static double getCosRandom(){
		double rnd=Math.random() * 0.1 + 0.9;
		return rnd;
	}
	
	
	//�¿��߳�
	private void openMyThread(){
		myThread.setDestory(true);
		myThread = new OnOffThread(); 
		myThread.start();
	}
}
