package com.freshpower.android.elec.client.netapi;

import java.io.File;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.protocol.HTTP;

import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.client.common.AppCache;
import com.freshpower.android.elec.client.common.AppConstant;
import com.freshpower.android.elec.client.common.MD5;
import com.freshpower.android.elec.client.common.StringUtil;
import com.freshpower.android.elec.client.conf.AppConfig;
import com.freshpower.android.elec.client.domain.CustomerInfo;
import com.freshpower.android.elec.client.domain.LoginInfo;


public class StationInfoDataApi extends JsonDataApi {
	private static final String STATION_NAME_LIST = "AppMonitoringAlarm.aspx";
	/**
	 * �ͻ��б�
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getStationInfoList(int pageSize,int pageNum) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "SJ10");
		api.addParam("QTPINDEX", String.valueOf(pageNum).trim());
		api.addParam("QTPSIZE", String.valueOf(pageSize).trim());
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		CustomerInfo customerInfo = null;
		List<CustomerInfo> customerInfoList = new ArrayList<CustomerInfo>();
		Map<String, Object> map = new HashMap<String, Object>();
		if(Integer.valueOf(rows.getString("result"))>0){
			JSONArray jsonObj = jsonResult.getJSONArray("table1");
			for(int i=0;i<jsonObj.size();i++){
				customerInfo=new CustomerInfo();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				customerInfo.setCpId(table1.getString("CP_ID"));;
				customerInfo.setCpName(table1.getString("CP_NAME")==null?"":table1.getString("CP_NAME"));
				customerInfo.setMaxDate(table1.getString("MAX_DATE")==null?"":table1.getString("MAX_DATE"));
				customerInfo.setMaxLoad(table1.getString("MAX_LOAD")==null?"":table1.getString("MAX_LOAD"));
				customerInfo.setTransCount(table1.getString("TRANS_COUNT")==null?"":table1.getString("TRANS_COUNT"));
				customerInfoList.add(customerInfo);
			}
			map.put("customerInfoList", customerInfoList);
		}
		map.put("totalCount", rows.getString("TotalCount"));
		map.put("result", rows.getString("result"));
		return map;
	}
	/**
	 * ��·�б�
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getStationDetailInfoList(int pageSize,int pageNum,String id) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "SJ20");
		api.addParam("QTCP", id);
		api.addParam("QTPINDEX", String.valueOf(pageNum).trim());
		api.addParam("QTPSIZE", String.valueOf(pageSize).trim());
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("table1");
		CustomerInfo customerInfo = null;
		List<CustomerInfo> customerInfoList = new ArrayList<CustomerInfo>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				customerInfo=new CustomerInfo();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				customerInfo.setCpId(table1.getString("CP_ID"));
				customerInfo.setMeterId(table1.getString("METER_ID"));
				customerInfo.setMeterNo(table1.getString("METER_NO"));
				customerInfo.setMeterName(table1.getString("METER_NAME")==null?"":table1.getString("METER_NAME"));//"����1-��·1",--��·����
				customerInfo.setSwitchStatus(table1.getString("SWITCH_STATUS")==null?"":table1.getString("SWITCH_STATUS"));//--����״̬1�պ�0��
				customerInfo.setDataId(table1.getString("DATA_ID"));
				customerInfo.setVa(table1.getString("V_A")==null?"":table1.getString("V_A"));//--��ѹA��
				customerInfo.setVb(table1.getString("V_B")==null?"":table1.getString("V_B"));
				customerInfo.setVc(table1.getString("V_C")==null?"":table1.getString("V_C"));
				customerInfo.setIa(table1.getString("I_A")==null?"":table1.getString("I_A"));//--����A��
				customerInfo.setIb(table1.getString("I_B")==null?"":table1.getString("I_B"));
				customerInfo.setIc(table1.getString("I_C")==null?"":table1.getString("I_C"));
				customerInfo.setTotalPower(table1.getString("TOTAL_POWER"));//--����й�����
				customerInfo.setPower(table1.getString("P_POWER")==null?"":table1.getString("P_POWER"));//--���й�����
				customerInfo.setDayPower(table1.getString("DAY_POWER")==null?"":table1.getString("DAY_POWER"));//�պ���
				customerInfo.setReportDate(table1.getString("REPORT_DATE")==null?"":table1.getString("REPORT_DATE"));//����ʱ��
				customerInfoList.add(customerInfo);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("customerDatailList", customerInfoList);
		map.put("totalCount", rows.getString("TotalCount"));
		map.put("result", rows.getString("result"));
		return map;
	}
	/**
	 * ��������
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getWarnInfoList(int pageSize,int pageNum,String warnName,String warnLevel) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "SJ30");
		api.addParam("QTPINDEX", String.valueOf(pageNum).trim());
		api.addParam("QTPSIZE", String.valueOf(pageSize).trim());
		if(!StringUtil.isEmpty(warnName)){
			api.addParam("QTKEY1", URLEncoder.encode(warnName,"GBK").trim());
		}
		if(!StringUtil.isEmpty(warnLevel)){
			api.addParam("QTKEY", warnLevel.trim());
		}
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("table1");
		CustomerInfo customerInfo = null;
		List<CustomerInfo> customerInfoList = new ArrayList<CustomerInfo>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				customerInfo=new CustomerInfo();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				customerInfo.setAlertId(table1.getString("ALERT_ID"));//--����ΨһID,����ʱʹ��
				customerInfo.setCpId(table1.getString("CP_ID"));
				customerInfo.setSiteId(table1.getString("SITE_ID"));
				customerInfo.setMeterId(table1.getString("METER_ID"));//--��·ID,�����д�ֵʱ,���鿴��ʷ���ݡ��ſ���
				customerInfo.setSiteName(table1.getString("SITE_NAME")==null?"":table1.getString("SITE_NAME"));//
				customerInfo.setMeterName(table1.getString("METER_NAME"));
				customerInfo.setAlertCode(table1.getString("ALERT_CODE"));//--"������ѹ"
				customerInfo.setCataLog(table1.getString("CATA_LOG")==null?"":table1.getString("CATA_LOG"));//--������������
				customerInfo.setAlertLevel(table1.getString("ALERT_LEVEL")==null?"":table1.getString("ALERT_LEVEL"));//"��Ҫ����"
				customerInfo.setContent(table1.getString("CONTENT")==null?"":table1.getString("CONTENT"));//----��������
				customerInfo.setAlertDate(table1.getString("ALERT_DATE")==null?"":table1.getString("ALERT_DATE"));//--��������
				customerInfo.setStatus(table1.getString("STATUS"));
				customerInfoList.add(customerInfo);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalCount", rows.getString("TotalCount"));
		map.put("warnInfoList", customerInfoList);
		return map;
	}
	/**
	 * ��������
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws Exception
	 */
	public static String getWarnDetailInfo(String alertId,String spinnerId) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "SJ31");
		api.addParam("QTALARM", alertId.trim());
		api.addParam("QTVAL", spinnerId.trim());
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		/*JSONArray jsonObj = jsonResult.getJSONArray("table1");
		CustomerInfo customerInfo = null;
		List<CustomerInfo> customerInfoList = new ArrayList<CustomerInfo>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				customerInfo=new CustomerInfo();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				customerInfo.setAlertId(table1.getString("ALERT_ID"));//--����ΨһID,����ʱʹ��
				customerInfo.setCpId(table1.getString("CP_ID"));
				customerInfo.setSiteId(table1.getString("SITE_ID"));
				customerInfo.setMeterId(table1.getString("METER_ID"));//--��·ID,�����д�ֵʱ,���鿴��ʷ���ݡ��ſ���
				customerInfo.setSiteName(table1.getString("SITE_NAME"));//
				customerInfo.setMeterName(table1.getString("METER_NAME"));
				customerInfo.setAlertCode(table1.getString("ALERT_CODE"));//--"������ѹ"
				customerInfo.setCataLog(table1.getString("CATA_LOG"));//--������������
				customerInfo.setAlertLevel(table1.getString("ALERT_LEVEL"));//"��Ҫ����"
				customerInfo.setContent(table1.getString("CONTENT"));//----��������
				customerInfo.setAlertDate(table1.getString("ALERT_DATE"));//--��������
				customerInfo.setStatus(table1.getString("STATUS"));
				customerInfoList.add(customerInfo);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("warnInfoList", customerInfoList);*/
		return rows.getString("result");
	}
	/**
	 * ������ѯ
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getWarnSearchInfo(String warnName,String warnLevel) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",URLEncoder.encode(loginInfo.getLoginName(),"GBK"));
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "SJ30");
		api.addParam("QTKEY1", URLEncoder.encode(warnName,"GBK").trim());
		api.addParam("QTKEY", warnLevel.trim());
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("table1");
		CustomerInfo customerInfo = null;
		List<CustomerInfo> customerInfoList = new ArrayList<CustomerInfo>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				customerInfo=new CustomerInfo();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				customerInfo.setAlertId(table1.getString("ALERT_ID"));//--����ΨһID,����ʱʹ��
				customerInfo.setCpId(table1.getString("CP_ID"));
				customerInfo.setSiteId(table1.getString("SITE_ID"));
				customerInfo.setMeterId(table1.getString("METER_ID"));//--��·ID,�����д�ֵʱ,���鿴��ʷ���ݡ��ſ���
				customerInfo.setSiteName(table1.getString("SITE_NAME"));//
				customerInfo.setMeterName(table1.getString("METER_NAME"));
				customerInfo.setAlertCode(table1.getString("ALERT_CODE"));//--"������ѹ"
				customerInfo.setCataLog(table1.getString("CATA_LOG"));//--������������
				customerInfo.setAlertLevel(table1.getString("ALERT_LEVEL"));//"��Ҫ����"
				customerInfo.setContent(table1.getString("CONTENT"));//----��������
				customerInfo.setAlertDate(table1.getString("ALERT_DATE"));//--��������
				customerInfo.setStatus(table1.getString("STATUS"));
				customerInfoList.add(customerInfo);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("warnInfoList", customerInfoList);
		return map;
	}
}
