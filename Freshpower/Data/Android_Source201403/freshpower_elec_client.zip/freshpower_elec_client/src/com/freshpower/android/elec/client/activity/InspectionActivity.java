package com.freshpower.android.elec.client.activity;

import java.util.Calendar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.MathUtil;

public class InspectionActivity extends Activity {
	ImageView inspection_left;
	TextView inspection_degree;
	TextView inspection_tmp;
	TextView inspection_ele;
	TextView degree_time;
	Button appraise_button;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.inspection_project);
		inspection_left=(ImageView)findViewById(R.id.inspection_left);
		inspection_left.setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
        		InspectionActivity.this.onBackPressed();
			}
		});
		inspection_degree=(TextView)findViewById(R.id.inspection_degree);
		inspection_degree.setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
        		Intent intent = new Intent(InspectionActivity.this,ElectricalDegreeActivity.class);
	    		startActivity(intent);
			}
		});
		inspection_tmp=(TextView)findViewById(R.id.inspection_tmp);
		inspection_tmp.setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
        		Intent intent = new Intent(InspectionActivity.this,InspectionTemperatureActivity.class);
	    		startActivity(intent);
			}
		});
		inspection_ele=(TextView)findViewById(R.id.inspection_ele);
		inspection_ele.setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
        		Intent intent = new Intent(InspectionActivity.this,InspectionElectricActivity.class);
	    		startActivity(intent);
			}
		});
		appraise_button=(Button)findViewById(R.id.appraise_button);
		appraise_button.setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
        		Intent intent = new Intent(InspectionActivity.this,AppraiseActivity.class);
	    		startActivity(intent);
			}
		});
		degree_time=(TextView)findViewById(R.id.degree_time);
		degree_time.setText(MathUtil.getDateByDay(1));
	}

}
