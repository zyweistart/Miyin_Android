package com.freshpower.android.elec.client.domain;
/**
 * �û�ע��
 * @author Administrator
 *
 */
public class UserRegisterInfo {
	private String loginRegisterTel;
	private String loginRegisterName;
	private String loginRegisterCardNum;
	private String  loginRegisterStruts;
	private String loginRegisterAddress;
	
	
	public String getLoginRegisterAddress() {
		return loginRegisterAddress;
	}
	public void setLoginRegisterAddress(String loginRegisterAddress) {
		this.loginRegisterAddress = loginRegisterAddress;
	}
	public String getLoginRegisterStruts() {
		return loginRegisterStruts;
	}
	public void setLoginRegisterStruts(String loginRegisterStruts) {
		this.loginRegisterStruts = loginRegisterStruts;
	}
	public String getLoginRegisterTel() {
		return loginRegisterTel;
	}
	public void setLoginRegisterTel(String loginRegisterTel) {
		this.loginRegisterTel = loginRegisterTel;
	}
	public String getLoginRegisterName() {
		return loginRegisterName;
	}
	public void setLoginRegisterName(String loginRegisterName) {
		this.loginRegisterName = loginRegisterName;
	}
	public String getLoginRegisterCardNum() {
		return loginRegisterCardNum;
	}
	public void setLoginRegisterCardNum(String loginRegisterCardNum) {
		this.loginRegisterCardNum = loginRegisterCardNum;
	}
	
}
