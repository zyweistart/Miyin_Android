package com.freshpower.android.elec.client.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;


public class InspectionRecordCompanyActivity extends Activity {
	private ImageView inspection_left;
	private RelativeLayout inspection_degree;
	private RelativeLayout inspection_tmp;
	private RelativeLayout inspection_ele;
	private String taskId;
	private Intent intent;
	private Button appraise_button;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.company_activity_inspection_record);
		inspection_left=(ImageView)findViewById(R.id.inspection_left);
		inspection_left.setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
        		InspectionRecordCompanyActivity.this.onBackPressed();
			}
		});
		Intent ite=getIntent();
		taskId=ite.getStringExtra("taskId");
		inspection_degree=(RelativeLayout)findViewById(R.id.inspection_degree);
		inspection_degree.setOnClickListener(new OnClickListener() {// վ��������Ϣ
        	@Override
			public void onClick(View v) {
        		startPutIntent(intent,"1","RW16",taskId);
			}
		});
		inspection_tmp=(RelativeLayout)findViewById(R.id.inspection_tmp);
		inspection_tmp.setOnClickListener(new OnClickListener() {// �����豸��ۡ��¶ȼ��
        	@Override
			public void onClick(View v) {
        		startPutIntent(intent,"3","RW17",taskId);
			}
		});
		inspection_ele=(RelativeLayout)findViewById(R.id.inspection_ele);
		inspection_ele.setOnClickListener(new OnClickListener() {// ���ܹ��������
        	@Override
			public void onClick(View v) {
        		startPutIntent(intent,"2","RW15",taskId);
			}
		});
		appraise_button=(Button)findViewById(R.id.appraise_button);
		appraise_button.setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
        		Intent intent = new Intent(InspectionRecordCompanyActivity.this,AppraiseActivity.class);
	    		startActivity(intent);
			}
		});
	}
	public void startPutIntent(Intent intent,String qtKey,String gnid,String qtTask){
		intent = new Intent(InspectionRecordCompanyActivity.this,OperationalAspectActivity.class);
		intent.putExtra("qtKey",qtKey);
		intent.putExtra("gnid", gnid);
		intent.putExtra("qtTask", qtTask);
		startActivity(intent);
	};

}
