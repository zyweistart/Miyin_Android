package com.freshpower.android.elec.client.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;


public class RealTimeActivity extends Activity {

	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_real_time_alarm);
		ActivityUtil.addActivity(this);
	}
	
}
