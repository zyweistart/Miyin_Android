package com.freshpower.android.elec.client.activity;

import java.text.DecimalFormat;
import java.util.Calendar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityData;
import com.freshpower.android.elec.client.common.ActivityUtil;

public class ElectricityBillActivity extends Activity {
	Double totalElectricity;
	Double totalElectriBillcity;
	Double averagePrice;
	Double hourElectricity;//ÿСʱ����
	int hour=0;
	int day=0;
	private double[] outScaleArr;// ����������ߵ�ϵ������
	private double[] inScaleArr;// ����������е�ϵ������
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.activity_electricitybill);
		Intent it=getIntent();
		hourElectricity=it.getDoubleExtra("hourElectricity",0.0);
		String str=it.getStringExtra("dayMonth");
		DecimalFormat df = new DecimalFormat("0.00");
		averagePrice=0.06*1.406+0.6*1.108+0.34*0.596;
		Calendar c=Calendar.getInstance();
		day=c.get(Calendar.DAY_OF_MONTH);
		ImageView elebill_left=(ImageView)findViewById(R.id.elebill_left);
		elebill_left.setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
				ElectricityBillActivity.this.onBackPressed();
			}
		});
		
		TextView TextViewEle1=(TextView)findViewById(R.id.TextViewEle1);
		TextView TextViewBill1=(TextView)findViewById(R.id.TextViewBill1);
		TextView TextViewEle2=(TextView)findViewById(R.id.TextViewEle2);
		TextView TextViewBill2=(TextView)findViewById(R.id.TextViewBill2);
		TextView TextViewEle3=(TextView)findViewById(R.id.TextViewEle3);
		TextView TextViewBill3=(TextView)findViewById(R.id.TextViewBill3);
		TextView TextViewEle4=(TextView)findViewById(R.id.TextViewEle4);
		TextView TextViewBill4=(TextView)findViewById(R.id.TextViewBill4);
		TextView TextViewEle5=(TextView)findViewById(R.id.TextViewEle5);
		TextView TextViewBill5=(TextView)findViewById(R.id.TextViewBill5);
		TextView TextViewEle6=(TextView)findViewById(R.id.TextViewEle6);
		TextView TextViewBill6=(TextView)findViewById(R.id.TextViewBill6);
		TextView TextViewEle7=(TextView)findViewById(R.id.TextViewEle7);
		TextView TextViewBill7=(TextView)findViewById(R.id.TextViewBill7);
		TextView TextViewEle8=(TextView)findViewById(R.id.TextViewEle8);
		TextView TextViewBill8=(TextView)findViewById(R.id.TextViewBill8);
		if(str.equals("����")){
			hour=c.get(Calendar.HOUR_OF_DAY);
		}else{
			hour=(day-1)*24;
			TextViewEle1.setText(R.string.dayMonth_ele);
			TextViewBill1.setText(R.string.dayMonth_bill);
			TextViewEle2.setText(R.string.dayMonth_ele);
			TextViewBill2.setText(R.string.dayMonth_bill);
			TextViewEle3.setText(R.string.dayMonth_ele);
			TextViewBill3.setText(R.string.dayMonth_bill);
			TextViewEle4.setText(R.string.dayMonth_ele);
			TextViewBill4.setText(R.string.dayMonth_bill);
			TextViewEle5.setText(R.string.dayMonth_ele);
			TextViewBill5.setText(R.string.dayMonth_bill);
			TextViewEle6.setText(R.string.dayMonth_ele);
			TextViewBill6.setText(R.string.dayMonth_bill);
			TextViewEle7.setText(R.string.dayMonth_ele);
			TextViewBill7.setText(R.string.dayMonth_bill);
			TextViewEle8.setText(R.string.dayMonth_ele);
			TextViewBill8.setText(R.string.dayMonth_bill);
		}
		
		outScaleArr = it.getDoubleArrayExtra("outScaleArr");
		inScaleArr = it.getDoubleArrayExtra("inScaleArr");
		
		totalElectricity=hour*hourElectricity;
		totalElectriBillcity=totalElectricity*averagePrice;
		Double totalElectricityFirst=totalElectricity*inScaleArr[0];
		Double totalElectricityBillFirst=totalElectriBillcity*inScaleArr[0];
		Double totalElectricitySecond=totalElectricity*inScaleArr[1];
		Double totalElectricityBillSecond=totalElectriBillcity*inScaleArr[1];
		//����B1
		TextView dayMonthone=(TextView)findViewById(R.id.dayMonthone);
		dayMonthone.setText(String.valueOf(df.format(totalElectricityFirst))+"kWh");
		TextView dayMonthBillone=(TextView)findViewById(R.id.dayMonthBillone);
		dayMonthBillone.setText(String.valueOf(df.format(totalElectricityBillFirst))+"Ԫ");
		TextView dayMonthaveragePrice=(TextView)findViewById(R.id.dayMonthaveragePrice);
		averagePrice = totalElectricityBillFirst/totalElectricityFirst;
		dayMonthaveragePrice.setText((String.valueOf(df.format(averagePrice)).equals("NaN")?"0.00":String.valueOf(df.format(averagePrice)))+"Ԫ/kWh");
		
		//����B1-1
		TextView dayMonthTwo=(TextView)findViewById(R.id.dayMonthTwo);
		dayMonthTwo.setText(String.valueOf(df.format(totalElectricityFirst*0.2))+"kWh");
		TextView dayMonthBillTwo=(TextView)findViewById(R.id.dayMonthBillTwo);
		dayMonthBillTwo.setText(String.valueOf(df.format(totalElectricityBillFirst*outScaleArr[0]))+"Ԫ");
		TextView dayMonthaveragePriceTwo=(TextView)findViewById(R.id.dayMonthaveragePriceTwo);
		averagePrice = (totalElectricityBillFirst*outScaleArr[0])/(totalElectricityFirst*0.2);
		dayMonthaveragePriceTwo.setText((String.valueOf(df.format(averagePrice)).equals("NaN")?"0.00":String.valueOf(df.format(averagePrice)))+"Ԫ/kWh");
		//����B1-2
		TextView dayMonthThree=(TextView)findViewById(R.id.dayMonthThree);
		dayMonthThree.setText(String.valueOf(df.format(totalElectricityFirst*0.3))+"kWh");
		TextView dayMonthBillThree=(TextView)findViewById(R.id.dayMonthBillThree);
		dayMonthBillThree.setText(String.valueOf(df.format(totalElectricityBillFirst*outScaleArr[1]))+"Ԫ");
		TextView dayMonthaveragePriceThree=(TextView)findViewById(R.id.dayMonthaveragePriceThree);
		averagePrice = (totalElectricityBillFirst*outScaleArr[1])/(totalElectricityFirst*0.3);
		dayMonthaveragePriceThree.setText((String.valueOf(df.format(averagePrice)).equals("NaN")?"0.00":String.valueOf(df.format(averagePrice)))+"Ԫ/kWh");
		//����B1-3
		TextView dayMonthFour=(TextView)findViewById(R.id.dayMonthFour);
		dayMonthFour.setText(String.valueOf(df.format(totalElectricityFirst*0.5))+"kWh");
		TextView dayMonthBillFour=(TextView)findViewById(R.id.dayMonthBillFour);
		dayMonthBillFour.setText(String.valueOf(df.format(totalElectricityBillFirst*outScaleArr[2]))+"Ԫ");
		TextView dayMonthaveragePriceFour=(TextView)findViewById(R.id.dayMonthaveragePriceFour);
		averagePrice = (totalElectricityBillFirst*outScaleArr[2])/(totalElectricityFirst*0.5);
		dayMonthaveragePriceFour.setText((String.valueOf(df.format(averagePrice)).equals("NaN")?"0.00":String.valueOf(df.format(averagePrice)))+"Ԫ/kWh");
		//����B2
		TextView dayMonthFive=(TextView)findViewById(R.id.dayMonthFive);
		dayMonthFive.setText(String.valueOf(df.format(totalElectricitySecond))+"kWh");
		TextView dayMonthBillFive=(TextView)findViewById(R.id.dayMonthBillFive);
		dayMonthBillFive.setText(String.valueOf(df.format(totalElectricityBillSecond))+"Ԫ");
		TextView dayMonthaveragePriceFive=(TextView)findViewById(R.id.dayMonthaveragePriceFive);
		averagePrice = totalElectricityBillSecond/totalElectricitySecond;
		dayMonthaveragePriceFive.setText((String.valueOf(df.format(averagePrice)).equals("NaN")?"0.00":String.valueOf(df.format(averagePrice)))+"Ԫ/kWh");
		//����B2-1
		TextView dayMonthSix=(TextView)findViewById(R.id.dayMonthSix);
		dayMonthSix.setText(String.valueOf(df.format(totalElectricitySecond*0.2))+"kWh");
		TextView dayMonthBillSix=(TextView)findViewById(R.id.dayMonthBillSix);
		dayMonthBillSix.setText(String.valueOf(df.format(totalElectricityBillSecond*outScaleArr[3]))+"Ԫ");
		TextView dayMonthaveragePriceSix=(TextView)findViewById(R.id.dayMonthaveragePriceSix);
		averagePrice = (totalElectricityBillSecond*outScaleArr[3])/(totalElectricitySecond*0.2);
		dayMonthaveragePriceSix.setText((String.valueOf(df.format(averagePrice)).equals("NaN")?"0.00":String.valueOf(df.format(averagePrice)))+"Ԫ/kWh");
		//����B2-2
		TextView dayMonthSeven=(TextView)findViewById(R.id.dayMonthSeven);
		dayMonthSeven.setText(String.valueOf(df.format(totalElectricitySecond*0.3))+"kWh");
		TextView dayMonthBillSeven=(TextView)findViewById(R.id.dayMonthBillSeven);
		dayMonthBillSeven.setText(String.valueOf(df.format(totalElectricityBillSecond*outScaleArr[4]))+"Ԫ");
		TextView dayMonthaveragePriceSeven=(TextView)findViewById(R.id.dayMonthaveragePriceSeven);
		averagePrice = (totalElectricityBillSecond*outScaleArr[4])/(totalElectricitySecond*0.3);
		dayMonthaveragePriceSeven.setText((String.valueOf(df.format(averagePrice)).equals("NaN")?"0.00":String.valueOf(df.format(averagePrice)))+"Ԫ/kWh");
		//����B2-3
		TextView dayMonthEight=(TextView)findViewById(R.id.dayMonthEight);
		dayMonthEight.setText(String.valueOf(df.format(totalElectricitySecond*0.5))+"kWh");
		TextView dayMonthBillEight=(TextView)findViewById(R.id.dayMonthBillEight);
		dayMonthBillEight.setText(String.valueOf(df.format(totalElectricityBillSecond*outScaleArr[5]))+"Ԫ");
		TextView dayMonthaveragePriceEight=(TextView)findViewById(R.id.dayMonthaveragePriceEight);
		averagePrice = (totalElectricityBillSecond*outScaleArr[5])/(totalElectricitySecond*0.5);
		dayMonthaveragePriceEight.setText((String.valueOf(df.format(averagePrice)).equals("NaN")?"0.00":String.valueOf(df.format(averagePrice)))+"Ԫ/kWh");
	}

}
