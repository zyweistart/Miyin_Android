package com.freshpower.android.elec.client.activity;

import com.freshpower.android.elec.client.R;
import com.freshpower.android.elec.client.common.ActivityUtil;
import com.freshpower.android.elec.client.common.AppConstant;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;

public class PowerHistoryActivity extends Activity {
	private ImageView closeButton;  
	private EditText year;
	private String selType;
	private RadioGroup radioGroup;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		setContentView(R.layout.activity_power_history_search);
		ActivityUtil.addActivity(this);
		selType = "Day";
		findView();
		
		radioGroup.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				// TODO Auto-generated method stub
				switch(checkedId){
				case R.id.search_day:
					selType = "Day";
					break;
				case R.id.search_month:
					selType = "Month";
					break;
				}
			}
		});
		closeButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				PowerHistoryActivity.this.onBackPressed();
			}
		});
		year.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(PowerHistoryActivity.this,SearchHistoryTimeActivity.class);
				intent.putExtra("selType", selType);
				startActivityForResult(intent, AppConstant.RequestResultCode.REQUEST_LINE_TIME);
			}
		});
		Button searchBtn = (Button)findViewById(R.id.search_submit);
		searchBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.putExtra("timeVal", year.getText().toString());
				intent.putExtra("selType", selType);
				setResult(AppConstant.RequestResultCode.RESULT_LINE, intent);
				finish();
			}
		});
	}
	
	private void findView(){
		year = (EditText)findViewById(R.id.year);
		radioGroup = (RadioGroup)findViewById(R.id.radioGroup);
		closeButton = (ImageView)findViewById(R.id.search_close);
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if(resultCode == AppConstant.RequestResultCode.RESULT_LINE_TIME){
			String timeVal = data.getStringExtra("timeValue");
//			Log.d("BID", "timeVal:"+timeVal);
			year.setText(timeVal);
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
}
