package com.freshpower.android.elec.netapi;

import java.io.File;
import java.net.URLEncoder;

import android.util.Log;

import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.conf.AppConfig;
import com.freshpower.android.elec.domain.FeedBackInfo;
/**
 * 
 * @author chenjl
 * ��������ӿ�
 *
 */
public class FeedBackDateApi extends JsonDataApi {
	private static final String ACTION_NAME= "addSuggest.aspx";
	public static String postFeedBackDate(FeedBackInfo feedBack)  throws Exception {
		try{
			JsonDataApi api = JsonDataApi.getInstance();
			api.addParam("content",URLEncoder.encode(feedBack.getFeedBackInfo().trim(),"GBK"));
			api.addParam("phone",feedBack.getFeedBackTel().trim());
			api.addParam("mail",feedBack.getFeedBackMail().trim());
			api.addParam("msgType","2");
			JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getFpsWebSite()+File.separator+ACTION_NAME);
			return jsonResult.getString("rs");
		}catch (Exception e) {
			throw e;
		}
	}

}
