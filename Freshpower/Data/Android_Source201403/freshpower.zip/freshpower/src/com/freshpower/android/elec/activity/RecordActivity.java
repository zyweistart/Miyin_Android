package com.freshpower.android.elec.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.freshpower.android.elec.R;

public class RecordActivity extends Activity {

		private ListView listView;
		private TextView title;
	
		@Override
		public void onCreate(Bundle savedInstanceState) {
			super.requestWindowFeature(Window.FEATURE_NO_TITLE);
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_list_title);
			listView = (ListView) findViewById(R.id.listView);  
			title = (TextView) findViewById(R.id.operationalAspectTitle);  
			SimpleAdapter adapter = new SimpleAdapter(this,getData(),R.layout.listitem_operational_aspect,
					new String[]{"title"},
					new int[]{R.id.title});
			
			// ��̬����ListView�߶�
			ViewGroup.LayoutParams params = listView.getLayoutParams();
			params.height = 104;
			listView.setLayoutParams(params);
	        listView.setAdapter(adapter);  
	        title.setVisibility(View.GONE);
		}

		private List<Map<String, Object>> getData() {
			List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

			Map<String, Object> map = new HashMap<String, Object>();
			map.put("title", "��ѹ��1");
			map.put("info", "���");
			list.add(map);

			map = new HashMap<String, Object>();
			map.put("title", "��ѹ��2");
			map.put("info", "δ���");
			list.add(map);

			return list;
		}
	}