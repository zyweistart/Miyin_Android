package com.freshpower.android.elec.dao.impl;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.freshpower.android.elec.common.AppCache;
import com.freshpower.android.elec.common.DBException;
import com.freshpower.android.elec.dao.LoginPurviewDao;
import com.freshpower.android.elec.domain.LoginInfo;

public class LoginPurviewDaoImpl extends BaseDaoImpl implements LoginPurviewDao {

	public LoginPurviewDaoImpl(Context context) {
		this.context = context;
	}

	@Override
	public void insertLoginPurview(LoginInfo loginInfo) throws DBException {
		StringBuffer sb = new StringBuffer();
		sb.append("INSERT INTO APP_T_PRIV_FUNCTION(BP_CODE,BP_NAME,LOGIN_NAME) VALUES(");
		sb.append("'").append(loginInfo.getBpCode()).append("',");
		sb.append("'").append(loginInfo.getBpName()).append("',");
		sb.append("'").append(loginInfo.getLoginName()).append("')");
		this.getDBOperater(context).execQuery(sb.toString());
	}

	@Override
	public void deleteLoginPurview(LoginInfo loginInfo) throws DBException {
		StringBuffer sb = new StringBuffer();
		sb.append("delete from APP_T_PRIV_FUNCTION ");
		this.getDBOperater(context).execQuery(sb.toString());
	}

	@Override
	public Boolean selectLoginPurview(LoginInfo loginInfo) throws DBException {
		boolean results=false;
		String sb =("select * from  APP_T_PRIV_FUNCTION where LOGIN_NAME=? and BP_CODE=?");
		String[] args=new String[]{loginInfo.getLoginName(),loginInfo.getBpCode()};
		Cursor cursor=this.getDBOperater(context).openQuery(sb, args);
		while (cursor.moveToNext()) {
			results=true;
		}
		return results;
	}

	@Override
	public void insertLoginInfo(LoginInfo loginInfo) throws DBException {
		StringBuffer sb = new StringBuffer();
		sb.append("INSERT INTO APP_T_USER(LOGIN_NAME,LOGIN_PWD) VALUES(");
		sb.append("'").append(loginInfo.getLoginName()).append("',");
		sb.append("'").append(loginInfo.getLoginPwd()).append("')");
		this.getDBOperater(context).execQuery(sb.toString());
	}

	@Override
	public void deleteLoginInfo(LoginInfo loginInfo) throws DBException {
		StringBuffer sb = new StringBuffer();
		sb.append("delete from  APP_T_USER ");
		this.getDBOperater(context).execQuery(sb.toString());
		
	}

	@Override
	public Boolean selectLoginInfo(String bpCode) throws DBException {
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		boolean results=false;
		String sb =("select b.BP_CODE from  APP_T_USER as a,APP_T_PRIV_FUNCTION as b where a.LOGIN_NAME=b.LOGIN_NAME and b.LOGIN_NAME=? and b.BP_CODE=? ");
		String[] args=new String[]{loginInfo.getLoginName(),bpCode};
		Cursor cursor=this.getDBOperater(context).openQuery(sb, args);
		cursor.moveToFirst();
		for (cursor.moveToFirst(); !cursor.isAfterLast();cursor.moveToNext()) {  
				results=true;
		}
		return results;
	}

}
