package com.freshpower.android.elec.activity;


import java.util.Calendar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.DatePicker.OnDateChangedListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TimePicker;
import android.widget.TimePicker.OnTimeChangedListener;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;

public class TaskTimeActivity extends Activity {
	private int year;  
	private int month;  
	private int day;  
	private int hour;  
	private int minute; 
	private String time;
	private int selIndex;
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.activity_task_time);
		DatePicker datapicker = (DatePicker) findViewById(R.id.datepicker);  
		TimePicker timepicker =(TimePicker) findViewById(R.id.timepicker);
		timepicker.setIs24HourView(true);
		selIndex = getIntent().getIntExtra("selIndex", 0);
		Calendar c =Calendar.getInstance();  
		year =c.get(Calendar.YEAR);  
		month=c.get(Calendar.MONTH);  
		day=c.get(Calendar.DAY_OF_MONTH);  
		hour = c.get(Calendar.HOUR_OF_DAY);  
		minute =c.get(Calendar.MINUTE);  
		showDate(year,month,day,hour,minute);  
		datapicker.init(year, month, day, new OnDateChangedListener() {  
			@Override  
			public void onDateChanged(DatePicker view, int year, int monthOfYear,  
					int dayOfMonth) {  
				TaskTimeActivity.this.year=year;  
				TaskTimeActivity.this.month=monthOfYear;  
				TaskTimeActivity.this.day=dayOfMonth;  
				showDate(year,month,day,hour,minute);  
			}  
		});
		timepicker.setCurrentHour(hour);
		timepicker.setCurrentMinute(minute);
		timepicker.setOnTimeChangedListener(new OnTimeChangedListener() {  
			@Override  
			public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {  
				// TODO Auto-generated method stub  
				TaskTimeActivity.this.hour=hourOfDay;  
				TaskTimeActivity.this.minute=minute;  
				showDate(year,month,day,hour,minute);  
			}  
		});  
		Button bt = (Button) findViewById(R.id.bt);  
		bt.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				Intent intent=new Intent();
				intent.putExtra("timeValue", time);
				intent.putExtra("selIndex", selIndex);
				setResult(20, intent);
				finish();
			}
		});
		Button not_bt = (Button) findViewById(R.id.not_bt); 
		not_bt.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				TaskTimeActivity.this.onBackPressed();
				finish();
			}
		});
		
	}  
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(20==resultCode)  
		{  
			setResult(20, data);  
			finish();
		}  
		super.onActivityResult(requestCode, resultCode, data);
	}
	private void showDate(int year, int month, int day, int hour,int minute) {  
		time=year+"/"+(month+1)+"/"+day+" "+hour+":"+minute;
	}  
}
