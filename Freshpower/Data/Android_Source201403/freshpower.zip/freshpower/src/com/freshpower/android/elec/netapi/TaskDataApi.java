package com.freshpower.android.elec.netapi;

import java.io.File;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.common.AppCache;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.conf.AppConfig;
import com.freshpower.android.elec.domain.CheckTaskInfo;
import com.freshpower.android.elec.domain.LoginInfo;
import com.freshpower.android.elec.domain.Task;

public class TaskDataApi extends JsonDataApi {
	private static final String STATION_NAME_LIST = "AppMonitoringAlarm.aspx";
	/**
	 * �ͻ��б�
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getTaskInfoList(int pageSize,int pageNum) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("gnid", "RW10");
		api.addParam("QTPINDEX", String.valueOf(pageNum).trim());
		api.addParam("QTPSIZE", String.valueOf(pageSize).trim());
		
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
//		Log.d("BID", "rows:"+rows.toJSONString());
		Task taskInfo = null;
		List<Task> taskInfoList = new ArrayList<Task>();
		if(Integer.valueOf(rows.getString("result"))>0){
			JSONArray jsonObj = jsonResult.getJSONArray("table1");
			for(int i=0;i<jsonObj.size();i++){
				taskInfo=new Task();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				taskInfo.setTaskId(table1.getString("TASK_ID")==null?"":table1.getString("TASK_ID"));;
				taskInfo.setTaskDate(table1.getString("TASK_DATE")==null?"":table1.getString("TASK_DATE"));
				taskInfo.setCpName(table1.getString("CP_NAME")==null?"":table1.getString("CP_NAME"));
				taskInfo.setIsComplete(table1.getString("IS_COMPLETE")==null?"":table1.getString("IS_COMPLETE"));
				taskInfo.setSiteName(table1.getString("SITE_NAME")==null?"":URLDecoder.decode(table1.getString("SITE_NAME"),"UTF-8"));
				taskInfo.setName(table1.getString("NAME")==null?"":URLDecoder.decode(table1.getString("NAME"),"UTF-8"));
				taskInfo.setRecompleteDate(table1.getString("RECOMPLETE_DATE")==null?"":table1.getString("RECOMPLETE_DATE"));
				taskInfoList.add(taskInfo);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("taskInfoList", taskInfoList);
		map.put("totalCount", rows.getString("TotalCount")==null?"0":rows.getString("TotalCount"));
		map.put("result", rows.getString("result"));
		return map;
	}
	
	/**
	 * ��ȡ�豸��ϸ��Ϣ
	 * @param gnid����
	 * @param qrtask����id
	 * @param qtkey
	 * @return
	 * @throws Exception
	 */
	
	public static Map<String,Object> getCheckInfoList(String gnid,String qrtask,String qtkey,String qtkey1) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("gnid", gnid);
		api.addParam("QTTASK", qrtask);
		api.addParam("QTKEY", qtkey);
		if(!StringUtil.isEmpty(qtkey1)) {
			api.addParam("QTKEY1", qtkey1);
		}
		
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		Task checkInfo = null;
		List<Task> taskInfoList = new ArrayList<Task>();
		Map<String, Object> map = new HashMap<String, Object>();
		if(Integer.valueOf(rows.getString("result"))>0){
			JSONArray jsonObj = jsonResult.getJSONArray("table1");
			for(int i=0;i<jsonObj.size();i++){
				checkInfo=new Task();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				checkInfo.setCodeId(table1.getString("CODE_ID")==null?"":table1.getString("CODE_ID"));//����Ӧ��д����
				checkInfo.setCpId(table1.getString("CP_ID")==null?"":table1.getString("CP_ID"));
				checkInfo.setIsComplete(table1.getString("IS_COMPLETE")==null?"":table1.getString("IS_COMPLETE"));
				checkInfo.setModelSubId(table1.getString("MODEL_SUB_ID")==null?"":table1.getString("MODEL_SUB_ID"));//�豸����ID
				checkInfo.setRemark(table1.getString("REMARK")==null?"":table1.getString("REMARK"));
				checkInfo.setName(table1.getString("NAME")==null?"":table1.getString("NAME"));
				checkInfo.setResultId(table1.getString("RESULT_ID")==null?"":table1.getString("RESULT_ID"));//���ID����������д��32λ����վ�Զ����ɣ�
				checkInfo.setScoutcheck(table1.getString("SCOUTCHECK")==null?"":table1.getString("SCOUTCHECK"));//��д���
				checkInfo.setScoutcheckContent(table1.getString("SCOUTCHECK_CONTENT")==null?"":table1.getString("SCOUTCHECK_CONTENT"));//��������
				checkInfo.setType(table1.getString("code_type")==null?"":table1.getString("code_type"));//�������д����
				taskInfoList.add(checkInfo);
			}
			map.put("taskInfoList", taskInfoList);
		}
		map.put("totalCount", rows.getString("TotalCount"));
		map.put("result", rows.getString("result"));
		map.put("remark", rows.getString("remark"));
		return map;
	}
	/**
	 * ��ȡ�����豸�б�
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getTaskTypeList(String taskId,String taskType) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "RW12");
		api.addParam("QTTASK", taskId);
		api.addParam("QTKEY", taskType);
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		Map<String, Object> map = new HashMap<String, Object>();
		List<Task> taskInfoList = new ArrayList<Task>();
	    JSONArray jsonObj = jsonResult.getJSONArray("table1");
	    if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				Task taskInfo=new Task();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				taskInfo.setTaskId(table1.getString("TASK_ID"));
				taskInfo.setEquipmentId(table1.getString("EQUIPMENT_ID"));
				taskInfo.setEquipmentName(table1.getString("NAME"));
				taskInfoList.add(taskInfo);
			}
	    }
	    map.put("taskInfoList", taskInfoList);
		map.put("result", rows.getString("result"));
		return map;
	}
	
	public static Map<String,Object> saveTask(String taskId,String qtkey,String qtkey2,String qtval) throws Exception{
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "RW13");
		api.addParam("QTTASK", taskId);
		api.addParam("QTKEY", qtkey);
		api.addParam("QTKEY2", qtkey2);
		api.addParam("QTVAL", qtval);
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		String result = rows.get("result").toString();
		String remark = rows.getString("remark");
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("result", result);
		map.put("remark", remark);
		return map;
	}
	
	public static Map<String,Object> subTask(String taskId) throws Exception{
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "RW14");
		api.addParam("QTTASK", taskId);
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		String result = rows.get("result").toString();
		String remark = rows.getString("remark");
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("result", result);
		map.put("remark", remark);
		return map;
	}
}
