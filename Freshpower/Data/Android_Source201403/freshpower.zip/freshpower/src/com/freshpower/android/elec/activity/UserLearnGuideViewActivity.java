package com.freshpower.android.elec.activity;

import java.util.ArrayList;

import com.freshpower.android.elec.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;


public class UserLearnGuideViewActivity extends Activity {
	private ViewPager viewPager;  
	private ArrayList<View> pageViews;  
	private ImageView imageView;  
	private ImageView[] imageViews; 
	// ��������ͼƬLinearLayout
	private ViewGroup main;
	// ����СԲ���LinearLayout
	private ViewGroup group;
	Button userExperienceButton;
	ImageView userexperienceTypeoneImageName;
	ImageView userexperienceTypetwoImageName;
	ImageView userExperience_iv;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// �����ޱ��ⴰ��
		requestWindowFeature(Window.FEATURE_NO_TITLE);

		LayoutInflater inflater = getLayoutInflater();  
		pageViews = new ArrayList<View>();  
		pageViews.add(inflater.inflate(R.layout.activity_learn_user, null));
		pageViews.add(inflater.inflate(R.layout.activity_learn_type, null));

		imageViews = new ImageView[pageViews.size()];  
		main = (ViewGroup)inflater.inflate(R.layout.activity_learn_entrance, null);  

		group = (ViewGroup)main.findViewById(R.id.viewGroup);  
		viewPager = (ViewPager)main.findViewById(R.id.guidePages);  

		for (int i = 0; i < pageViews.size(); i++) { 
			imageView = new ImageView(UserLearnGuideViewActivity.this);  
			imageViews[i] = imageView;  

			if (i == 0) {  
				//Ĭ��ѡ�е�һ��ͼƬ
				imageViews[i].setBackgroundResource(R.drawable.dot_selected);  
			} else {  
				imageViews[i].setBackgroundResource(R.drawable.dot_unselected);  
			}  

			group.addView(imageViews[i]);  
		}  
		setContentView(main);
		userExperience_iv=(ImageView)findViewById(R.id.nav_left);
		userExperience_iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				UserLearnGuideViewActivity.this.onBackPressed();
			}
		});
		viewPager.setAdapter(new GuidePageAdapter());  
		viewPager.setOnPageChangeListener(new GuidePageChangeListener());  
	}

	// ָ��ҳ������������
	class GuidePageAdapter extends PagerAdapter {  

		@Override  
		public int getCount() {  
			return pageViews.size();  
		}  

		@Override  
		public boolean isViewFromObject(View arg0, Object arg1) {  
			return arg0 == arg1;  
		}  

		@Override  
		public int getItemPosition(Object object) {  
			// TODO Auto-generated method stub  
			return super.getItemPosition(object);  
		}  

		@Override  
		public void destroyItem(View arg0, int arg1, Object arg2) {  
			// TODO Auto-generated method stub  
			((ViewPager) arg0).removeView(pageViews.get(arg1));  
		}  

		@Override  
		public Object instantiateItem(View arg0, int arg1) {  
			// TODO Auto-generated method stub  
			((ViewPager) arg0).addView(pageViews.get(arg1));  
			if(arg1 == 0) {
				userExperienceButton=(Button)pageViews.get(arg1).findViewById(R.id.userExperienceButton);
				userExperienceButton.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						Intent intent = new Intent(UserLearnGuideViewActivity.this, UserExperienceActivity.class);
						startActivity(intent);
					}
				});
			}else if(arg1 == 1) {
				userexperienceTypeoneImageName=(ImageView)pageViews.get(arg1).findViewById(R.id.userexperienceTypeoneImageName);
				userexperienceTypeoneImageName.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						Intent intent = new Intent(UserLearnGuideViewActivity.this, UserExperienceSecondActivity.class);
						intent.putExtra("userType", "1");
						startActivity(intent);//��ҵ
					}
				});
				userexperienceTypetwoImageName=(ImageView)pageViews.get(arg1).findViewById(R.id.userexperienceTypetwoImageName);
				userexperienceTypetwoImageName.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						Intent intent = new Intent(UserLearnGuideViewActivity.this, UserExperienceSecondActivity.class);
						intent.putExtra("userType", "0");
						startActivity(intent);//��ҵ
					}
				});
			}

			return pageViews.get(arg1);  
		}  

		@Override  
		public void restoreState(Parcelable arg0, ClassLoader arg1) {  
			// TODO Auto-generated method stub  

		}  

		@Override  
		public Parcelable saveState() {  
			// TODO Auto-generated method stub  
			return null;  
		}  

		@Override  
		public void startUpdate(View arg0) {  
			// TODO Auto-generated method stub  

		}  

		@Override  
		public void finishUpdate(View arg0) {  
			// TODO Auto-generated method stub  

		}  
	} 

	// ָ��ҳ������¼�������
	class GuidePageChangeListener implements OnPageChangeListener {  

		@Override  
		public void onPageScrollStateChanged(int arg0) {  
			// TODO Auto-generated method stub  

		}  

		@Override  
		public void onPageScrolled(int arg0, float arg1, int arg2) {  

		}  

		@Override  
		public void onPageSelected(int arg0) {  
			for (int i = 0; i < imageViews.length; i++) {  
				imageViews[arg0].setBackgroundResource(R.drawable.dot_selected);

				if (arg0 != i) {  
					imageViews[i].setBackgroundResource(R.drawable.dot_unselected);  
				}  
			}
		}  
	}  

}
