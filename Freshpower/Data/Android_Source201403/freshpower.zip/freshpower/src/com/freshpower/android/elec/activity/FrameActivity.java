package com.freshpower.android.elec.activity;

import java.io.File;

import org.androidpn.client.ServiceManager;
import org.apache.http.conn.HttpHostConnectException;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.AppCache;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.CommunicationManager;
import com.freshpower.android.elec.common.DBException;
import com.freshpower.android.elec.common.FileUtil;
import com.freshpower.android.elec.common.LogFactory;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.conf.AppConfig;
import com.freshpower.android.elec.dao.DaoFactory;
import com.freshpower.android.elec.dao.LoginPurviewDao;
import com.freshpower.android.elec.domain.UserRegisterInfo;
import com.freshpower.android.elec.netapi.LoginInfoDataApi;

public abstract class FrameActivity extends Activity implements OnClickListener {
	private ImageButton homeBtn;
	private ImageButton toolbtn;
	private ImageButton learnBtn;
	private ImageButton phoneBtn;
	private ImageButton recommendBtn;
	private ImageButton stationDataBtn;
	private ImageButton stationWarnBtn;
	private ImageButton stationTaskbtn;
	private ImageButton stationCheckBtn;
	private LoginPurviewDao loginPurviewDao;
	private Resources res;
	

	public LoginPurviewDao getLoginPurviewDao() {
		return loginPurviewDao;
	}

	public void setLoginPurviewDao(LoginPurviewDao loginPurviewDao) {
		this.loginPurviewDao = loginPurviewDao;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		ActivityUtil.addActivity(this);
		init(savedInstanceState);
		res = getResources();
		loginPurviewDao=DaoFactory.getLoginPurviewDao(FrameActivity.this);

		homeBtn = (ImageButton) findViewById(R.id.homeBtn);
		if(homeBtn!=null)
			homeBtn.setOnClickListener(this);

		learnBtn = (ImageButton) findViewById(R.id.learnBtn);
		if(learnBtn!=null)
			learnBtn.setOnClickListener(this);

		toolbtn = (ImageButton) findViewById(R.id.toolbtn);
		if(toolbtn!=null)
			toolbtn.setOnClickListener(this);

		recommendBtn = (ImageButton) findViewById(R.id.recommendBtn);
		if(recommendBtn!=null)
			recommendBtn.setOnClickListener(this);

		phoneBtn = (ImageButton) findViewById(R.id.phoneBtn);
		if(phoneBtn!=null)
			phoneBtn.setOnClickListener(this);

		stationDataBtn = (ImageButton) findViewById(R.id.stationDataBtn);
		if(stationDataBtn!=null)
			stationDataBtn.setOnClickListener(this);

		stationWarnBtn = (ImageButton) findViewById(R.id.stationWarnBtn);
		if(stationWarnBtn!=null)
			stationWarnBtn.setOnClickListener(this);

		stationTaskbtn = (ImageButton) findViewById(R.id.stationTaskbtn);
		if(stationTaskbtn!=null)
			stationTaskbtn.setOnClickListener(this);

		stationCheckBtn = (ImageButton) findViewById(R.id.stationCheckBtn);
		if(stationCheckBtn!=null)
			stationCheckBtn.setOnClickListener(this);
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	public void onClick(View v) {
		Intent intent = null;
		switch (v.getId()) {
		case R.id.homeBtn:
			intent = new Intent(this, HomeActivity.class);
			startActivity(intent);
			overridePendingTransition(android.R.anim.fade_in,
					android.R.anim.fade_out);
			this.finish();
			break;
		case R.id.learnBtn:
			if(!FileUtil.isFileExist(FileUtil.getElecFilePath())){
				LayoutInflater factory = LayoutInflater.from(FrameActivity.this);
				View DialogView = factory.inflate(R.layout.dialog_login, null);
				AlertDialog.Builder builder = new Builder(FrameActivity.this);
				builder.setView(DialogView);

				final EditText eTextUname = (EditText) DialogView
						.findViewById(R.id.loginTel);
				builder.setPositiveButton(R.string.soft_validate_validatebtn,
						new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						String logtel=eTextUname.getText().toString();
						if(StringUtil.isEmpty(logtel)){
							Toast.makeText(FrameActivity.this, R.string.user_register_tel, Toast.LENGTH_SHORT).show();
							return;
						}else if(logtel.length()!=11){
							Toast.makeText(FrameActivity.this, R.string.user_register_telNot,Toast.LENGTH_SHORT).show();
							return;
						}else{
							UserRegisterInfo registerInfo=new UserRegisterInfo();
							registerInfo.setLoginRegisterTel(eTextUname.getText().toString());
							registerInfo.setLoginRegisterCardNum("");
							String rs;
							try {
								rs = LoginInfoDataApi.getRegisterInfoAuditTrms(registerInfo);
								//���״̬�ӿ�
								if("1".equals(rs)){//���ͨ��
									File dbFile = new File(FileUtil.getElecFilePath());
									FileUtil.createFolder(dbFile.getParent());
									FileUtil.createFile(dbFile);
									String fileContent = FileUtil.read(FileUtil.getElecFilePath());
									fileContent = registerInfo.getLoginRegisterTel();
									FileUtil.writeBeforeClearContent(
											FileUtil.getElecFilePath(), fileContent); 
									Intent intent = new Intent(FrameActivity.this,LearnActivity.class);
									startActivity(intent);
								}else if("0".equals(rs)){//��˲�ͨ��
									Toast.makeText(FrameActivity.this, R.string.msg_auditnot_network,Toast.LENGTH_SHORT).show();
									return;
								}else if("2".equals(rs)){//�����
									Toast.makeText(FrameActivity.this, R.string.msg_audit_network,Toast.LENGTH_SHORT).show();
									return;
								}else{
									Intent intent = new Intent(FrameActivity.this, UserRegisterActivity.class);
									startActivity(intent);
								}
							}catch (HttpHostConnectException e) {
								Toast.makeText(FrameActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show();
								e.printStackTrace();
							}catch (Exception e) {
								Toast.makeText(FrameActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show(); 
								e.printStackTrace();
							}
						}
					}
				});
				builder.setNegativeButton(R.string.soft_validate_cancle,
						new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});
				builder.setCancelable(false);
				Dialog noticeDialog = builder.create();
				noticeDialog.setCanceledOnTouchOutside(false);
				noticeDialog.show();
				break;
			}else{
				Intent	inte = new Intent(FrameActivity.this, LearnActivity.class);
				startActivity(inte);
				overridePendingTransition(android.R.anim.fade_in,
						android.R.anim.fade_out);
				this.finish();
				break;
			}
		case R.id.toolbtn:
			intent = new Intent(FrameActivity.this, ToolActivity.class);
			startActivity(intent);
			overridePendingTransition(android.R.anim.fade_in,
					android.R.anim.fade_out);
			this.finish();
			break;
		case R.id.recommendBtn:
			intent = new Intent(Intent.ACTION_SEND); // �����������͵�����
			intent.setType("text/plain");
			intent.putExtra(Intent.EXTRA_SUBJECT, "subject");
			intent.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.msg_share_msg)); // ����������
			this.startActivity(Intent.createChooser(intent, getResources().getString(R.string.menu_share)));// Ŀ��Ӧ��ѡ��Ի���ı���
			break;
		case R.id.phoneBtn:

			// ����Ի���
			AlertDialog.Builder builder = new Builder(FrameActivity.this);
			builder.setTitle(R.string.soft_call_freshpower_title);
			builder.setPositiveButton(R.string.soft_validate_validatebtn,
					new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+AppConstant.PHONE_NUM_FRESHPOEWR));  
					FrameActivity.this.startActivity(intent);
				}
			});
			builder.setNegativeButton(R.string.soft_validate_cancle,
					new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
			builder.setCancelable(false);
			Dialog noticeDialog = builder.create();
			noticeDialog.setCanceledOnTouchOutside(false);
			noticeDialog.show();
			break;
		case R.id.stationDataBtn:
				intent = new Intent(FrameActivity.this, StationActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in,
						android.R.anim.fade_out);
				this.finish();
				break;
			case R.id.stationWarnBtn:
				intent = new Intent(FrameActivity.this, WarnActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in,
						android.R.anim.fade_out);
				this.finish();
				break;
			case R.id.stationTaskbtn:
				intent = new Intent(FrameActivity.this, TaskActivity.class);
				startActivity(intent);
				overridePendingTransition(android.R.anim.fade_in,
						android.R.anim.fade_out);
				this.finish();
				break;
			case R.id.stationCheckBtn:
				try {
					boolean result=loginPurviewDao.selectLoginInfo(res.getString(R.string.stationTaskbtn_bpcode));
					if(result){
						intent = new Intent(FrameActivity.this, CheckActivity.class);
						startActivity(intent);
						overridePendingTransition(android.R.anim.fade_in,
								android.R.anim.fade_out);
						this.finish();
					}else{
						Toast.makeText(FrameActivity.this, R.string.login_purview_bpcode,
								Toast.LENGTH_LONG).show();
					}
				}catch (Exception e) {
					Toast.makeText(FrameActivity.this, R.string.login_purview_bpcode,
							Toast.LENGTH_LONG).show();
					e.printStackTrace();
				}
				break;
			default:
				break;
			}
		}

		protected abstract void init(Bundle savedInstanceState);

		@Override
		public boolean onCreateOptionsMenu(Menu menu) {
			menu.add(0, AppConstant.OptionsMenuBtn.OPTIONS_MENU_BTN_CHANGE_ACCOUNT, 1, R.string.optionsMenu_changeAccount).setIcon(android.R.drawable.ic_menu_share);
			menu.add(0, AppConstant.OptionsMenuBtn.OPTIONS_MENU_BTN_ABOUT, 2, R.string.optionsMenu_about).setIcon(android.R.drawable.ic_menu_info_details);
			menu.add(0, AppConstant.OptionsMenuBtn.OPTIONS_MENU_BTN_EXISTS, 3, R.string.optionsMenu_exists).setIcon(android.R.drawable.ic_lock_power_off);
			return super.onCreateOptionsMenu(menu);
		}

		@Override
		public boolean onOptionsItemSelected(MenuItem item) {
			if (item.getItemId() == AppConstant.OptionsMenuBtn.OPTIONS_MENU_BTN_EXISTS) {
				ActivityUtil.exit();
				AppCache.remove(AppCache.LOGININFO_OBJ);
				this.finish();
			} else if (item.getItemId() == AppConstant.OptionsMenuBtn.OPTIONS_MENU_BTN_ABOUT) {
				Toast.makeText(this, this.getString(R.string.company_appName)+AppConfig.getInstance().getAppVersion(), Toast.LENGTH_LONG).show();
				return true;
			} else if (item.getItemId() == AppConstant.OptionsMenuBtn.OPTIONS_MENU_BTN_CHANGE_ACCOUNT){
				FileUtil.deleteFile(FileUtil.getDBFilePath());
				AppCache.remove(AppCache.LOGININFO_OBJ);
				
				Intent intent = new Intent();
				intent.setAction(AppConstant.ReceiverAction.ACTION_GPSSERVICE_STOP);
				this.sendBroadcast(intent);

				//ֹͣʵʱ��Ϣ����
				ServiceManager serviceManager = new ServiceManager(this);
				serviceManager.stopService();

				intent = new Intent(this, LoginActivity.class);
				startActivity(intent);
			}
			return super.onOptionsItemSelected(item);
		}

		@Override
		public boolean onKeyDown(int keyCode, KeyEvent event) {
			String className = this.getClass().getName().substring(this.getClass().getName().lastIndexOf(".")+1);
			if("HomeActivity".equals(className) || "LearnActivity".equals(className) || "ToolActivity".equals(className)){
				if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
					AlertDialog.Builder builder = new Builder(this);
					builder.setPositiveButton(R.string.soft_btn_ok,
							new android.content.DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							ActivityUtil.exit();
							dialog.dismiss();
							finish();
						}
					});
					builder.setNegativeButton(R.string.soft_btn_cancle,
							new android.content.DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							dialog.dismiss();
						}
					});
					builder.setIcon(android.R.drawable.ic_dialog_info);
					builder.setMessage(R.string.soft_exists);
					builder.show();
					return true;
				}
			}else{
				ImageView iv=(ImageView)findViewById(R.id.nav_left);
				if(iv!=null){
					iv.performClick();
				}
			}
			return super.onKeyDown(keyCode, event);
		}

		@Override
		protected void onDestroy() {
			super.onDestroy();
		}
	}
