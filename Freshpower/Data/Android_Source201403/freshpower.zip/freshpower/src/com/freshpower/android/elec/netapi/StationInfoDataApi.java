package com.freshpower.android.elec.netapi;

import java.io.File;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.common.AppCache;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.conf.AppConfig;
import com.freshpower.android.elec.domain.CustomerInfo;
import com.freshpower.android.elec.domain.LoginInfo;


public class StationInfoDataApi extends JsonDataApi {
	private static final String STATION_NAME_LIST = "AppMonitoringAlarm.aspx";
	/**
	 * �ͻ��б�
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getStationInfoList(int pageSize,int pageNum, String cpName) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "SJ10");
		api.addParam("QTKEY", URLEncoder.encode(cpName, AppConstant.ETG_INTERFACE_CHARSET));
		api.addParam("QTPINDEX", String.valueOf(pageNum).trim());
		api.addParam("QTPSIZE", String.valueOf(pageSize).trim());
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		CustomerInfo customerInfo = null;
		List<CustomerInfo> customerInfoList = new ArrayList<CustomerInfo>();
		Map<String, Object> map = new HashMap<String, Object>();
		if(Integer.valueOf(rows.getString("result"))>0){
			JSONArray jsonObj = jsonResult.getJSONArray("table1");
			for(int i=0;i<jsonObj.size();i++){
				customerInfo=new CustomerInfo();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				customerInfo.setCpId(table1.getString("CP_ID"));;
				customerInfo.setCpName(table1.getString("CP_NAME")==null?"":table1.getString("CP_NAME"));
				customerInfo.setMaxDate(table1.getString("MAX_DATE")==null?"":table1.getString("MAX_DATE"));
				customerInfo.setMaxLoad(table1.getString("MAX_LOAD")==null?"":table1.getString("MAX_LOAD"));
				customerInfo.setTransCount(table1.getString("TRANS_COUNT")==null?"":table1.getString("TRANS_COUNT"));
				customerInfoList.add(customerInfo);
			}
			map.put("customerInfoList", customerInfoList);
		}
		map.put("totalCount", rows.getString("TotalCount"));
		map.put("result", rows.getString("result"));
		return map;
	}
	/**
	 * ��·�б�
	 * @param pageSize
	 * @param pageNum
	 * @param id �ͻ�ID
	 * @param transNo ��ѹ�����
	 * @param meterName ��·����
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getStationDetailInfoList(int pageSize,int pageNum,String id,String transNo,String meterName) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "SJ20");
		api.addParam("QTCP", id);
		api.addParam("QTKEY", URLEncoder.encode(transNo, AppConstant.ETG_INTERFACE_CHARSET));
		api.addParam("QTKEY1", URLEncoder.encode(meterName, AppConstant.ETG_INTERFACE_CHARSET));
		api.addParam("QTPINDEX", String.valueOf(pageNum).trim());
		api.addParam("QTPSIZE", String.valueOf(pageSize).trim());
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("table1");
		CustomerInfo customerInfo = null;
		List<CustomerInfo> customerInfoList = new ArrayList<CustomerInfo>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				customerInfo=new CustomerInfo();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				customerInfo.setCpId(table1.getString("CP_ID"));
				customerInfo.setMeterId(table1.getString("METER_ID"));
				customerInfo.setMeterNo(table1.getString("METER_NO"));
				customerInfo.setMeterName(table1.getString("METER_NAME")==null?"":table1.getString("METER_NAME"));//"����1-��·1",--��·����
				customerInfo.setSwitchStatus(table1.getString("SWITCH_STATUS")==null?"":table1.getString("SWITCH_STATUS"));//--����״̬1�պ�0��
				customerInfo.setDataId(table1.getString("DATA_ID"));
				customerInfo.setVa(table1.getString("V_A")==null?"":table1.getString("V_A"));//--��ѹA��
				customerInfo.setVb(table1.getString("V_B")==null?"":table1.getString("V_B"));
				customerInfo.setVc(table1.getString("V_C")==null?"":table1.getString("V_C"));
				customerInfo.setIa(table1.getString("I_A")==null?"":table1.getString("I_A"));//--����A��
				customerInfo.setIb(table1.getString("I_B")==null?"":table1.getString("I_B"));
				customerInfo.setIc(table1.getString("I_C")==null?"":table1.getString("I_C"));
				customerInfo.setTotalPower(table1.getString("TOTAL_POWER"));//--����й�����
				customerInfo.setPower(table1.getString("P_POWER")==null?"":table1.getString("P_POWER"));//--���й�����
				customerInfo.setDayPower(table1.getString("DAY_POWER")==null?"":table1.getString("DAY_POWER"));//�պ���
				customerInfo.setReportDate(table1.getString("REPORT_DATE")==null?"":table1.getString("REPORT_DATE"));//����ʱ��
				customerInfo.setFactor(table1.getString("FACTOR")==null?"":table1.getString("FACTOR"));//����ʱ��
				customerInfoList.add(customerInfo);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("customerDatailList", customerInfoList);
		map.put("totalCount", rows.getString("TotalCount"));
		map.put("result", rows.getString("result"));
		return map;
	}
	/**
	 * ��������
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getWarnInfoList(int pageSize,int pageNum,String warnName,String warnLevel,String warnSort) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "SJ30");
		api.addParam("QTPINDEX", String.valueOf(pageNum).trim());
		api.addParam("QTPSIZE", String.valueOf(pageSize).trim());
		if(!StringUtil.isEmpty(warnName)){
			api.addParam("QTKEY1", URLEncoder.encode(warnName,"GBK").trim());
		}
		if(!StringUtil.isEmpty(warnLevel)){
			api.addParam("QTKEY", warnLevel.trim());
		}
		if(!StringUtil.isEmpty(warnSort)){
			api.addParam("QTKEY2", warnSort.trim());
		}
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("table1");
		CustomerInfo customerInfo = null;
		List<CustomerInfo> customerInfoList = new ArrayList<CustomerInfo>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				customerInfo=new CustomerInfo();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				customerInfo.setAlertId(table1.getString("ALERT_ID"));//--����ΨһID,����ʱʹ��
				customerInfo.setCpId(table1.getString("CP_ID"));
				customerInfo.setSiteId(table1.getString("SITE_ID"));
				customerInfo.setMeterId(table1.getString("METER_ID"));//--��·ID,�����д�ֵʱ,���鿴��ʷ���ݡ��ſ���
				customerInfo.setSiteName(table1.getString("SITE_NAME")==null?"":table1.getString("SITE_NAME"));//
				customerInfo.setMeterName(table1.getString("METER_NAME"));
				customerInfo.setAlertCode(table1.getString("ALERT_CODE"));//--"������ѹ"
				customerInfo.setCataLog(table1.getString("CATA_LOG")==null?"":table1.getString("CATA_LOG"));//--������������
				customerInfo.setAlertLevel(table1.getString("ALERT_LEVEL")==null?"":table1.getString("ALERT_LEVEL"));//"��Ҫ����"
				customerInfo.setContent(table1.getString("CONTENT")==null?"":table1.getString("CONTENT"));//----��������
				customerInfo.setAlertDate(table1.getString("ALERT_DATE")==null?"":table1.getString("ALERT_DATE"));//--��������
				customerInfo.setStatus(table1.getString("STATUS"));
				customerInfoList.add(customerInfo);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalCount", rows.getString("TotalCount"));
		map.put("warnInfoList", customerInfoList);
		map.put("result", rows.getString("result"));
		return map;
	}
	/**
	 * ��������
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws Exception
	 */
	public static String getWarnDetailInfo(String alertId,String spinnerId) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		if(alertId.indexOf(",")!=-1){
			api.addParam("GNID", "SJ32");
			api.addParam("QTKEY", alertId.trim());
		}else{
			api.addParam("GNID", "SJ31");
			api.addParam("QTALARM", alertId.trim());
		}
		api.addParam("QTVAL", spinnerId.trim());
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		Log.d("BID", "BID:"+rows.toJSONString());
		/*JSONArray jsonObj = jsonResult.getJSONArray("table1");
		CustomerInfo customerInfo = null;
		List<CustomerInfo> customerInfoList = new ArrayList<CustomerInfo>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				customerInfo=new CustomerInfo();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				customerInfo.setAlertId(table1.getString("ALERT_ID"));//--����ΨһID,����ʱʹ��
				customerInfo.setCpId(table1.getString("CP_ID"));
				customerInfo.setSiteId(table1.getString("SITE_ID"));
				customerInfo.setMeterId(table1.getString("METER_ID"));//--��·ID,�����д�ֵʱ,���鿴��ʷ���ݡ��ſ���
				customerInfo.setSiteName(table1.getString("SITE_NAME"));//
				customerInfo.setMeterName(table1.getString("METER_NAME"));
				customerInfo.setAlertCode(table1.getString("ALERT_CODE"));//--"������ѹ"
				customerInfo.setCataLog(table1.getString("CATA_LOG"));//--������������
				customerInfo.setAlertLevel(table1.getString("ALERT_LEVEL"));//"��Ҫ����"
				customerInfo.setContent(table1.getString("CONTENT"));//----��������
				customerInfo.setAlertDate(table1.getString("ALERT_DATE"));//--��������
				customerInfo.setStatus(table1.getString("STATUS"));
				customerInfoList.add(customerInfo);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("warnInfoList", customerInfoList);*/
		return rows.getString("result");
	}
	/**
	 * ������ѯ
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getWarnSearchInfo(String warnName,String warnLevel) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",URLEncoder.encode(loginInfo.getLoginName(),"GBK"));
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "SJ30");
		api.addParam("QTKEY1", URLEncoder.encode(warnName,"GBK").trim());
		api.addParam("QTKEY", warnLevel.trim());
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("table1");
		CustomerInfo customerInfo = null;
		List<CustomerInfo> customerInfoList = new ArrayList<CustomerInfo>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				customerInfo=new CustomerInfo();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				customerInfo.setAlertId(table1.getString("ALERT_ID"));//--����ΨһID,����ʱʹ��
				customerInfo.setCpId(table1.getString("CP_ID"));
				customerInfo.setSiteId(table1.getString("SITE_ID"));
				customerInfo.setMeterId(table1.getString("METER_ID"));//--��·ID,�����д�ֵʱ,���鿴��ʷ���ݡ��ſ���
				customerInfo.setSiteName(table1.getString("SITE_NAME"));//
				customerInfo.setMeterName(table1.getString("METER_NAME"));
				customerInfo.setAlertCode(table1.getString("ALERT_CODE"));//--"������ѹ"
				customerInfo.setCataLog(table1.getString("CATA_LOG"));//--������������
				customerInfo.setAlertLevel(table1.getString("ALERT_LEVEL"));//"��Ҫ����"
				customerInfo.setContent(table1.getString("CONTENT"));//----��������
				customerInfo.setAlertDate(table1.getString("ALERT_DATE"));//--��������
				customerInfo.setStatus(table1.getString("STATUS"));
				customerInfoList.add(customerInfo);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("warnInfoList", customerInfoList);
		return map;
	}
	/**
	 * ��·��ʷ����
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getStationDetailHistoryDataList(int pageSize,int pageNum,String meterId,String cpId,String StartDate,String EndDate) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "SJ22");
		api.addParam("QTCP", cpId);
		api.addParam("QTLN",meterId);
		api.addParam("QTPINDEX", String.valueOf(pageNum).trim());
		api.addParam("QTPSIZE", String.valueOf(pageSize).trim());
		api.addParam("QTD1",URLEncoder.encode(StartDate));
		api.addParam("QTD2",URLEncoder.encode(EndDate));
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("table1");
		CustomerInfo customerInfo = null;
		List<CustomerInfo> customerInfoList = new ArrayList<CustomerInfo>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				customerInfo=new CustomerInfo();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				customerInfo.setCpId(table1.getString("CP_ID"));
				customerInfo.setMeterId(table1.getString("METER_ID"));
				customerInfo.setMeterNo(table1.getString("METER_NO"));
				customerInfo.setMeterName(table1.getString("METER_NAME")==null?"":table1.getString("METER_NAME"));//"����1-��·1",--��·����
				customerInfo.setSwitchStatus(table1.getString("SWITCH_STATUS")==null?"":table1.getString("SWITCH_STATUS"));//--����״̬1�պ�0��
				customerInfo.setDataId(table1.getString("DATA_ID"));
				customerInfo.setVa(table1.getString("V_A")==null?"":table1.getString("V_A"));//--��ѹA��
				customerInfo.setVb(table1.getString("V_B")==null?"":table1.getString("V_B"));
				customerInfo.setVc(table1.getString("V_C")==null?"":table1.getString("V_C"));
				customerInfo.setIa(table1.getString("I_A")==null?"":table1.getString("I_A"));//--����A��
				customerInfo.setIb(table1.getString("I_B")==null?"":table1.getString("I_B"));
				customerInfo.setIc(table1.getString("I_C")==null?"":table1.getString("I_C"));
				customerInfo.setTotalPower(table1.getString("TOTAL_POWER"));//--����й�����
				customerInfo.setPower(table1.getString("P_POWER")==null?"":table1.getString("P_POWER"));//--���й�����
				customerInfo.setDayPower(table1.getString("DAY_POWER")==null?"":table1.getString("DAY_POWER"));//�պ���
				customerInfo.setReportDate(table1.getString("REPORT_DATE")==null?"":table1.getString("REPORT_DATE"));//����ʱ��
				customerInfo.setFactor(table1.getString("FACTOR")==null?"":table1.getString("FACTOR"));//�ܹ�������
				customerInfo.setHz(table1.getString("HZ")==null?"":table1.getString("HZ"));//��������
				customerInfo.setChannel(table1.getString("CHANNEL")==null?"":table1.getString("CHANNEL"));//��������
				customerInfoList.add(customerInfo);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("customerDatailList", customerInfoList);
		map.put("totalCount", rows.getString("TotalCount"));
		map.put("result", rows.getString("result"));
		return map;
	}
	/**
	 * ��·��ʷ����
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getStationDetailHistoryConsumptionList(int pageSize,int pageNum,String meterId,String cpId) throws Exception {
		Calendar date=Calendar.getInstance();
		int year=date.get(Calendar.YEAR);
		int month=date.get(Calendar.MONTH)+1;
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "SJ21");
		api.addParam("QTCP", cpId);
		api.addParam("QTLN",meterId);
//		api.addParam("QTCP", "149");
//		api.addParam("QTLN","588");
		api.addParam("QTD1",year+"-"+month+"-"+"1");
		api.addParam("QTPINDEX", String.valueOf(pageNum).trim());
		api.addParam("QTPSIZE", String.valueOf(pageSize).trim());
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("table1");
		CustomerInfo customerInfo = null;
		List<CustomerInfo> customerInfoList = new ArrayList<CustomerInfo>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				customerInfo=new CustomerInfo();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				customerInfo.setMeterId(table1.getString("METER_ID"));
				customerInfo.setReportYear(table1.getString("REPORT_YEAR"));//��
				customerInfo.setReportMonth(table1.getString("REPORT_MONTH"));//��
				customerInfo.setTotalPower(table1.getString("TOTAL_POWER"));//�պ���
				customerInfo.setReportDay(table1.getString("REPORT_DAY"));//��
				customerInfoList.add(customerInfo);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("customerDatailList", customerInfoList);
		map.put("totalCount", rows.getString("TotalCount"));
		map.put("result", rows.getString("result"));
		return map;
	}
	
	/**
	 * ��ȡ��ѹ����Ϣ
	 * @param cpId
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getTransList(String cpId) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "ZY21");
		api.addParam("QTCP", cpId);
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+STATION_NAME_LIST,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("table1");
		CustomerInfo customerInfo = null;
		List<CustomerInfo> customerInfoList = new ArrayList<CustomerInfo>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				if(!StringUtil.isEmpty(table1.getString("TRANS_NAME"))) {
					customerInfo = new CustomerInfo();
					customerInfo.setTransNo(table1.getString("TRANS_NO"));
					customerInfo.setTransName(table1.getString("TRANS_NAME"));
					customerInfoList.add(customerInfo);
				}
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("remark", rows.getString("remark"));
		map.put("customerInfoList", customerInfoList);
		map.put("result", rows.getString("result"));
		return map;
	}
}
