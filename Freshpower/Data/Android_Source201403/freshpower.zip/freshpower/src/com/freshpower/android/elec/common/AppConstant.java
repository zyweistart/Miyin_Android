/**   
 * @{#} AppConstant.java Create on 2012-11-20 ����11:00:13   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.common;

import java.util.HashMap;
import java.util.Map;

import com.freshpower.android.elec.R;


/**
 * @author <a href="mailto:yangz@freshpower.cn">yangz</a>
 * @version 1.0
 */

public class AppConstant {
	
	public static final int YES_NO_TYPE_NO = 0;// ��
	public static final int YES_NO_TYPE_YES = 1;// ��
	
	public static class FlashLightState {
		public static final int OPEN = 1;
		public static final int CLOSE = 0;
	}

	public static class AuthenticationInfo {
		public static final int TIME_OUT = -1;
		public static final int INVALID = 0;
	}

	public static class OptionsMenuBtn {
		public static final int OPTIONS_MENU_BTN_EXISTS = 1;
		public static final int OPTIONS_MENU_BTN_ABOUT = 2;
		public static final int OPTIONS_MENU_BTN_CHANGE_ACCOUNT = 3;
	}
	
	public static class EnBottomBtnType {
		public static final int OTHER_BTN = 0;// ����
		public static final int INDEXPAGE_BTN = 1;
		public static final int ELECTRICPAGE_BTN = 2;
		public static final int EFFICIENCYPAGE_BTN = 3;
		public static final int RUNMANAGER_BTN = 4;
		public static final int MYCENTER_BTN = 5;
	}

	public static class SharedPreferencesKey {
		public static final String FREQUENCY = "FREQUENCY";
		public static final String LIGHT_SET = "LIGHT_SET";
		public static final String GPS_SET = "GPS_SET";
		public static final String VIBRATION_SET = "VIBRATION_SET";
		public static final String TIP_SET = "TIP_SET";
		

	    public static final String KEY_PREF_BAUDRATE = "pref_BaudRate";
	    public static final String KEY_PREF_DATABIT = "pref_DataBit";
	    public static final String KEY_PREF_STOPBIT = "pref_StopBit";
	    public static final String KEY_PREF_PARITY = "pref_Parity";
	    public static final String KEY_BAUDRATE_INDEX = "baudRateIndex";
	    public static final String KEY_DATABIT_INDEX = "dataBitIndex";
	    public static final String KEY_STOPBIT_INDEX = "stopBitIndex";
	    public static final String KEY_PARITY_INDEX = "parityIndex";
	    public static final String KEY_PREF_FLOW = "pref_Flow";
	    public static final String KEY_PREF_INBUFFERSIZE = "pref_InBufferSize";
	    public static final String KEY_PREF_OUTBUFFERSIZE = "pref_OutBufferSize";
	    public static final String KEY_PREF_CLEARSENDEDIT = "pref_ClearSendEdit";
	    public static final String KEY_PREF_IOMODE = "pref_IOMode";
	    public static final String KEY_PREF_CHARSET = "pref_Charset";
	    public static final String KEY_PREF_AUTOWRAP = "pref_AutoWrap";
	    public static final String KEY_PREF_ECHO = "pref_Echo";
	    public static final String KEY_PREF_ECHOPREFIX = "pref_EchoPrefix";
	    public static final String KEY_PREF_LT = "pref_LT";
	}

	public static final String SHARED_PREFERENCE_NAME = "elec_preferences";
	public static final String PHONE_NUM_FRESHPOEWR = "4008263365";
	public static final String ETG_INTERFACE_CHARSET = "GBK";

	public static class GpsDataApiResult {
		public static final int RESULT_ERROR = 0;
		public static final int RESULT_SUCCESS = 1;
		public static final int RESULT_PERMISSION_NOT = 2;
		public static final int RESULT_PHONENUM_NOTEXIST = 3;
	}
	
	public static class ListItemCtlName{
		public static final String MENU_ICO = "menuIco";
		public static final String MENU_NAME = "menuName";
		public static final String MENU_SIZE = "menuSize";
		public static final String CONDITION_VALUE = "conditionValue";
		public static final String COMPANY_STATION = "company_station";
		public static final String COMPANY_CURRENT = "company_current";
	}
	
	public static class ListItemTask{
		public static final String MODEL_SUB_ID="modelSubId";
		public static final String SCOUTCHECK_CONTENT="scoutcheckContent";
		public static final String RESULT_ID="resultId";
		public static final String SCOUTCHECK="scoutcheck";
		public static final String CODE_ID="codeId";
		public static final String CODE_TYPE="codeType";
		public static final String RECORD_TYPE="recordType";
	}
	
	public static class ListItemWarnName{
		public static final String WARN_ONE = "warnOne";
		public static final String WARN_TWO = "warnTwo";
		public static final String WARN_THREE = "warnThree";
		public static final String WARN_FOUR = "warnFour";
		public static final String WARN_FIVE = "warnFive";
		public static final String WARN_SIX = "warnSix";
		public static final String WARN_SEVEN = "warnSeven";
		public static final String WARN_EIGHT = "warnEight";
		public static final String WARN_NINE = "nine";
		public static final String WARN_TEN = "ten";
		public static final String WARN_ELEVEN = "eleven";
		public static final String WARN_TWELVE = "twelve";
	}
	
	public static class PurchaseType{
		public static final int PURCHASE = 1;//�ɹ�����
		public static final int AREA = 2;//����
		public static final int TRADE = 3;//��ҵ
		public static final int TIME = 4;//ʱ��
	}
	
	public static class ExtraName{
		public static final String EXTRANAME_NAME="name";
		public static final String EXTRANAME_TYPE="type";
		public static final String EXTRANAME_ID="id";
		public static final String EXTRANAME_KEYWORDS="keyWords";
		public static final String EXTRANAME_CODE="code";
	}
	
	public static class Result{
		public static final int SUCCESS=1;
		public static final int NO_COUNT=0;
		public static final int ERROR=999;
	}
	
	/*
	 * some constants
	 */
	public static interface IOMode{
		public static final int text = 0;
		public static final int binary = 1;
	}
	public static interface LineTerminator{
		public static final int crlf = 0;
		public static final int cr = 1;
		public static final int lf = 2;
	}
	/*
	 * some constants end.
	 */
	
	/**
	 * ��ȡ����
	 * @author yzsunlight
	 *
	 */
	public static class ReadParam{
		public static final String CONFIGED="configed";
		public static final String SHAREDP_NAME_VOLTAGE="voltage";
		public static final String SHAREDP_NAME_ELECTRICITY="electricity";
		public static final String SHAREDP_NAME_POWER="power";
		public static final String SHAREDP_NAME_POWER_FACTOR="power_factor";
		public static final String SHAREDP_NAME_RATE="rate";
		public static final String SHAREDP_NAME_GROUP_ELECTRIC="group_electric";
		public static final String SHAREDP_NAME_POSITIVE_ELECTRIC="positive_electric";
		public static final String SHAREDP_NAME_STATUS_WORD="status_word";
		
		public static final int voltage=0;
		public static final int electricity=1;
		public static final int power=2;
		public static final int power_factor=3;
		public static final int rate=4;
		public static final int group_electric=5;
		public static final int positive_electric=6;
		public static final int status_word=7;
		
		public static Map<Integer,String> readParamMap = new HashMap<Integer,String>();
		static{
			readParamMap.put(voltage, SHAREDP_NAME_VOLTAGE);
			readParamMap.put(electricity, SHAREDP_NAME_ELECTRICITY);
			readParamMap.put(power, SHAREDP_NAME_POWER);
			readParamMap.put(power_factor, SHAREDP_NAME_POWER_FACTOR);
			readParamMap.put(rate, SHAREDP_NAME_RATE);
			readParamMap.put(group_electric, SHAREDP_NAME_GROUP_ELECTRIC);
			readParamMap.put(positive_electric, SHAREDP_NAME_POSITIVE_ELECTRIC);
			readParamMap.put(status_word, SHAREDP_NAME_STATUS_WORD);
		}
		
	}
	
	public static class RequestResultCode{
		public static final int REQUEST_PHONEDEBUGACTIVITY=120;//�ֻ�����ҳ������
		public static final int RESULT_PHONEDEBUGACTIVITY=120;//�ֻ�����ҳ������
		public static final int REQUEST_SCANACTIVITY = 300;//ɨ���������
		public static final int RESULT_SCANACTIVITY = 300;//ɨ���������
		public static final int REQUEST_SCANPROJECTACTIVITY=110;// ���̽�վɨ��㼯��
		public static final int RESULT_SCANPROJECTACTIVITY=110;// ���̽�վɨ��㼯��
		public static final int REQUEST_SCANCOLLECTORACTIVITY=100;// ���̽�վɨ��ɼ���
		public static final int RESULT_SCANCOLLECTORACTIVITY=100;// ���̽�վɨ��ɼ���
		public static final int REQUEST_USERSECOND=200;// �ر�ָ��activity(������dialig)
		public static final int REQUEST_OPEATERCOMMIT=10;//�趨������Ϊ�˳�����
		public static final int REQUEST_OPEATERCANCEL=11;//�趨������Ϊ��������
		public static final int REQUEST_BUY_CLOSETHREAD=400;// ���߹���ҳ������ر��߳�
		public static final int REQUEST_BUY_OPENTHREAD=401;// ���߹���ҳ��������߳�
		public static final int REQUEST_USEREXPERIENCESECOND=403;// �ڶ��׶�ҳ������
		public static final int REQUEST_ASSESS = 500;//����
		public static final int REQUEST_LOAD_REPORT = 700;//�����ɱ���
		public static final int RESULT_LOAD_REPORT = 700;//�����ɱ���
		public static final int REQUEST_OPERATIONALSCAN=120;// ɨ�����ܹ�
		public static final int RESULT_OPERATIONALSCAN=120;// ɨ�����ܹ�
		public static final int RESULT_TASKTIME=20;//Ѳ��ʱ�� 
		public static final int REQUEST_WARNINGSET = 800;//��������
	}
	
	/**
	 * GPS���ݻ�ȡ����
	 * @author yzsunlight
	 *
	 */
	public static class GpsRequestQueryRtype{
		public static final int SEARCH_DEFAULT = 0;//Ĭ�ϲ�ѯ��ʽһ�׶�ԭ�з�ʽ����
		public static final int SEARCH_DAY = 1;//�����ѯ
		public static final int SEARCH_MONTH = 2;//���²�ѯ
	}
	
	public static class GooglePlayPackageName {
		public static final String GOOGLE_PLAY_SERVICE = "com.google.android.gms";
		public static final String GOOGLE_PLAY_SOTRE = "com.android.vending";
	}
	
	public static class ResultCode{
		public static final int RESULT_CODE_SUCCESS = 20;
		public static final int RESULT_CODE_RESULT_NULL = 30;
		public static final int RESULT_CODE_REQUEST = 100;
	}
	
	public static class ReceiverAction {
		public static final String ACTION_GPSSERVICE_START = "com.freshpower.elec.action.GPSSERVICE_START";
		public static final String ACTION_GPSSERVICE_STOP = "com.freshpower.elec.action.GPSSERVICE_STOP";
	}
}
