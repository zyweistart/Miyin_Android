package com.freshpower.android.elec.netapi;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.common.AppCache;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.conf.AppConfig;
import com.freshpower.android.elec.domain.LoginInfo;
import com.freshpower.android.elec.domain.OperationalAspect;
import com.freshpower.android.elec.domain.Task;

public class OperationalAspectApi extends JsonDataApi {
	private static final String ACTION_NAME = "AppMonitoringAlarm.aspx";
	/**
	 * ��ȡ�豸�б�
	 * @param qtTask ����ID
	 * @param qtKey �豸���� 1-������豸2-�����豸3-�����豸4-TRMS�豸
	 * @return
	 * @throws Exception
	 */
	public static List<OperationalAspect> getOperationalAspectList(String qtTask, String qtKey) throws Exception {
		LoginInfo loginInfo = (LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("imei", loginInfo.getLoginName().trim());
		api.addParam("authentication", loginInfo.getLoginPwd());
		api.addParam("GNID", "RW12");
		api.addParam("QTTASK", qtTask);
		api.addParam("QTKEY", qtKey);
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getEtgWebsite() + File.separator + ACTION_NAME, AppConstant.ETG_INTERFACE_CHARSET);
		JSONArray json = jsonResult.getJSONArray("table1");
		ArrayList<OperationalAspect> operationalAspectList = new ArrayList<OperationalAspect>();
		OperationalAspect operationalAspect = null;
		for(int i=0;i<json.size();i++){
			JSONObject rows = (JSONObject)json.get(i);
			operationalAspect = new OperationalAspect();
			operationalAspect.setTaskId(rows.getString("TASK_ID"));
			operationalAspect.setEqType(rows.getString("EQ_TYPE"));
			operationalAspect.setName(rows.getString("NAME"));
			operationalAspect.setEquipmentId(rows.getString("EQUIPMENT_ID"));
			operationalAspect.setRemark(rows.getString("REMARK"));
			operationalAspectList.add(operationalAspect);
		}
		return operationalAspectList;
	}
	
	/**
	 * ɨ�����ܹ�
	 * @param gnId
	 * @param qtTask
	 * @param qtKey
	 * @return
	 * @throws Exception
	 */
	public static List<Task> scanOperationalAspect(String gnId, String qtTask, String qtKey, String qtKey1) throws Exception {
		LoginInfo loginInfo = (LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("imei", loginInfo.getLoginName().trim());
		api.addParam("authentication", loginInfo.getLoginPwd());
		api.addParam("GNID", gnId);
		api.addParam("QTTASK", qtTask);
		api.addParam("QTKEY", qtKey);
		if(!StringUtil.isEmpty(qtKey1)) {
			api.addParam("QTKEY1", qtKey1);
		}
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getEtgWebsite() + File.separator + ACTION_NAME, AppConstant.ETG_INTERFACE_CHARSET);
		JSONArray json = jsonResult.getJSONArray("table1");
		Task task = null;
		ArrayList<Task> taskList = new ArrayList<Task>();
		for(int i=0;i<json.size();i++){
			JSONObject rows = (JSONObject)json.get(i);
			task = new Task();
			task.setResultId(rows.getString("RESULT_ID"));
			task.setModelSubId(rows.getString("MODEL_SUB_ID"));
			task.setName(rows.getString("NAME"));
			task.setIsComplete(rows.getString("IS_COMPLETE"));
			task.setScoutcheckContent(rows.getString("SCOUTCHECK_CONTENT"));
			task.setCodeId(rows.getString("CODE_ID"));
			task.setScoutcheck(rows.getString("SCOUTCHECK"));
			task.setCpId(rows.getString("CP_ID"));
			task.setRemark(rows.getString("REMARK"));
			taskList.add(task);
		}
		return taskList;
	}
	
}
