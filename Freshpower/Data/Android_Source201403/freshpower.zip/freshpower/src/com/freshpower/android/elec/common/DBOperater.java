package com.freshpower.android.elec.common;

import java.io.File;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.util.Log;

/**
 * @author yangz
 *
 */
public class DBOperater extends  SQLiteOpenHelper{
	
	private static final int DATABASE_VERSION = 1;
	private static String fileName;
	private static LogFactory logger = LogFactory.getLogger(DBOperater.class);

	public DBOperater(Context context, String name, CursorFactory factory,
			int version) {
		//����ͨ��super���ø��൱�еĹ��캯��
		super(context, name, factory, version);
	}
	public DBOperater(Context context,String name){
		this(context,name,DATABASE_VERSION);
	}
	public DBOperater(Context context,String name,int version){
		this(context, name,null,version);
	}
	
	
	public static DBOperater getInstance(Context context,String fileName){
		DBOperater.fileName = fileName;
		File file = new File(fileName);
		File parent = new File(file.getParent());
		if(!parent.exists()){
			parent.mkdirs();
		}
		return new DBOperater(context,fileName);
	}
	
	/**
	 * �����ݿ�
	 * @return
	 * @throws DBException 
	 */
	public SQLiteDatabase openDB() throws DBException{
		try{
			return this.getWritableDatabase();
		}catch(Exception e){
			throw new DBException(e);
		}
	}
	
	/**
	 * �ر����ݿ�
	 * @param db
	 * @throws DBException 
	 */
	public void closeDB(SQLiteDatabase db) throws DBException{
		try{
			db.close();
		}catch(Exception e){
			throw new DBException(e);
		}
	}
	
	/**
	 * ɾ�����ݿ�
	 * @return
	 * @throws DBException 
	 */
	public boolean deleteDB() throws DBException{
		try{
			File file = new File(fileName);
			if(file.exists()){
				return file.delete();
			}
			return true;
		}catch(Exception e){
			throw new DBException(e);
		}
	}
	
	/**
	 * ִ��SQL���
	 * @param sql
	 * @throws DBException 
	 */
	public void execQuery(String sql) throws DBException{
		try{
			SQLiteDatabase db = openDB();
			db.execSQL(sql);
			closeDB(db);
		}catch(Exception e){
			throw new DBException(e);
		}
	}
	
	/**
	 * ִ��SQL���
	 * @param sql
	 * @throws DBException 
	 */
	public void execQuery(String sql,String[] args) throws DBException{
		try{
			SQLiteDatabase db = openDB();
			db.execSQL(sql,args);
			closeDB(db);
		}catch(Exception e){
			throw new DBException(e);
		}
	}
	
	/**
	 * �򿪲�ѯ����ȡ�α���
	 * @param tableName
	 * @param condStr
	 * @return
	 * @throws DBException 
	 */
	public Cursor openQuery(String sql,String[] args) throws DBException{
		try{
			Log.d("BID", sql);
			SQLiteDatabase db = openDB();
			Cursor cursor =db.rawQuery(sql, args);
			cursor.moveToFirst();
			closeDB(db);
			return cursor;
		}catch(Exception e){
			throw new DBException(e);
		}
	}
	
	/**
	 * �ж����ݿ���Ƿ����
	 * @param tableName
	 * @return
	 * @throws DBException 
	 */
	public boolean isTableExists(String tableName) throws DBException{
		try{
			Cursor cursor = openQuery("select sqlist_master where tbl_name='"+tableName+"'",null);
			int count = cursor.getCount();
			cursor.close();
			return count>0;
		}catch(Exception e){
			throw new DBException(e);
		}
	}
	


	@Override
	public void onCreate(SQLiteDatabase db) {
		logger.d("BID", "onCreate...");
		 try {
			createTable1(db);
			createTable2(db);
		} catch (DBException e) {
			e.printStackTrace();
		}
	}
	
	private void createTable1(SQLiteDatabase db) throws DBException{
		StringBuffer sb = new StringBuffer();
		sb.append("CREATE TABLE APP_T_PRIV_FUNCTION(BP_CODE TEXT,");
		sb.append("BP_NAME TEXT,");
		sb.append("LOGIN_NAME TEXT");
		sb.append(")");
		db.execSQL(sb.toString());
		
	}
	private void createTable2(SQLiteDatabase db) throws DBException{
		StringBuffer bf = new StringBuffer();
		bf.append("CREATE TABLE APP_T_USER(LOGIN_NAME TEXT,");
		bf.append("LOGIN_PWD TEXT");
		bf.append(")");
		db.execSQL(bf.toString());
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		logger.d("BID", "onUpgrade...");
	}
	
}
