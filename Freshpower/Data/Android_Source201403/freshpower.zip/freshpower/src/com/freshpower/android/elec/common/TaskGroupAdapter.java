package com.freshpower.android.elec.common;

import java.util.List;
import java.util.Map;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.activity.OperationalAspectActivity;
import com.freshpower.android.elec.activity.TaskConsumptionActivity;
import com.freshpower.android.elec.domain.Task;
import com.freshpower.android.elec.netapi.TaskDataApi;
import com.freshpower.android.elec.activity.TaskActivity;

public class TaskGroupAdapter extends BaseAdapter {
	
	List<Map<String, Object>> mData;
	Context mContext;
	int resource;
	private Intent intent;
	private List<Task> taskDetailList;
	private String taskId;
	private TaskActivity taskActivity;
	public TaskGroupAdapter(List<Map<String, Object>> data,
			Context context, int resource,List<Task> taskDetailList){
		this.mData = data;
		this.mContext = context;
		this.resource = resource;
		this.taskDetailList = taskDetailList;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mData == null ? 0 : mData.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}
	class ViewTask{
		RelativeLayout taskListItem;
		TextView taskName;
		TextView taskDate;
		Button taskSubBtn;
		ImageButton taskOpenBtn;
		LinearLayout fristLyt;
		LinearLayout secondLyt;
		LinearLayout thridLyt;
		LinearLayout fouthLyt;
		LinearLayout taskTypeLyt;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewTask viewTask=null;
		if(convertView == null){
			Log.d("BID", "1");
			viewTask = new ViewTask();
			convertView = LayoutInflater.from(mContext).inflate(resource, null);
			viewTask.taskListItem = (RelativeLayout)convertView.findViewById(R.id.taskListItem);
			viewTask.taskName = (TextView)convertView.findViewById(R.id.taskName);
			viewTask.taskDate = (TextView)convertView.findViewById(R.id.taskDate);
			viewTask.taskOpenBtn = (ImageButton)convertView.findViewById(R.id.taskOpenBtn);
			viewTask.taskSubBtn = (Button)convertView.findViewById(R.id.taskSubmitBtn);
			viewTask.fristLyt = (LinearLayout)convertView.findViewById(R.id.fristLyt);
			viewTask.secondLyt = (LinearLayout)convertView.findViewById(R.id.secondLyt);
			viewTask.thridLyt = (LinearLayout)convertView.findViewById(R.id.thridLyt);
			viewTask.fouthLyt = (LinearLayout)convertView.findViewById(R.id.fouthLyt);
			viewTask.taskTypeLyt = (LinearLayout)convertView.findViewById(R.id.taskTypeLyt);
			
			convertView.setTag(viewTask);//View�е�setTag(Onbect)��ʾ��View����һ����������ݣ��Ժ������getTag()���������ȡ������

		}else{
			viewTask = (ViewTask)convertView.getTag();
		}
		Map<String, Object> data = mData.get(position);
		taskId = String.valueOf(data.get("id"));
		viewTask.taskName.setText(String.valueOf(data.get("taskName")));
		
		
		viewTask.taskDate.setText(String.valueOf(data.get("taskDate")));
		if(position % 2 ==1){
			viewTask.taskListItem.setBackgroundColor(mContext.getResources().getColor(R.color.bgcolor));
		}else{
			viewTask.taskListItem.setBackgroundColor(mContext.getResources().getColor(R.color.white));
		}
		TaskItemOnClickListener frist = new TaskItemOnClickListener();
		frist.setTaskId(String.valueOf(data.get("id")));
		frist.setType("frist");
		TaskItemOnClickListener second = new TaskItemOnClickListener();
		second.setTaskId(String.valueOf(data.get("id")));
		second.setType("second");
		TaskItemOnClickListener thrid = new TaskItemOnClickListener();
		thrid.setTaskId(String.valueOf(data.get("id")));
		thrid.setType("thrid");
		TaskItemOnClickListener fouth = new TaskItemOnClickListener();
		fouth.setTaskId(String.valueOf(data.get("id")));
		fouth.setType("fouth");
		viewTask.fristLyt.setOnClickListener(frist);
		viewTask.secondLyt.setOnClickListener(second);
		viewTask.thridLyt.setOnClickListener(thrid);
		viewTask.fouthLyt.setOnClickListener(fouth);
		viewTask.taskOpenBtn.setOnClickListener(new TaskOpenBtnOnClickListener(viewTask));
		viewTask.taskTypeLyt.setVisibility(View.GONE);
		viewTask.taskSubBtn.setOnClickListener(new TaskSubBtnOnclickListener(data.get("id").toString()));
		return convertView;
	}
	
	
	class TaskSubBtnOnclickListener implements View.OnClickListener{
		private String taskId;
		
		public TaskSubBtnOnclickListener(String taskId) {
			this.taskId = taskId; 
		}

		Map<String,Object> map ;
		@Override
		public void onClick(View arg0) {
				taskActivity = (TaskActivity)mContext;
				taskActivity.processProgress = ProgressDialog.show(mContext, "", mContext.getResources().getString(R.string.msg_operate_processing_alert),true);
				
				new Thread(new Runnable() {
					@Override
					public void run() {
						try {
							map= TaskDataApi.subTask(taskId);
						} catch (Exception e) {
							e.printStackTrace();
						}finally{
							taskActivity.processProgress.dismiss();
							taskActivity.mHandler.post(new Runnable() {
								public void run() {
									int result = Integer.parseInt(map.get("result").toString());
									String remark = map.get("remark").toString();
									Toast.makeText(mContext, remark.split(",")[1], Toast.LENGTH_SHORT).show();
									taskActivity.onRefresh();
								}
							});
						}
					}
				}).start();
			}
		}
	
	class TaskOpenBtnOnClickListener implements View.OnClickListener{
		private ViewTask viewTask;
		
		
		public TaskOpenBtnOnClickListener(ViewTask viewTask) {
			this.viewTask = viewTask; 
		}

		@Override
		public void onClick(View v) {
//			Log.d("BID", "viewTask:"+viewTask);
			if(viewTask.taskTypeLyt.getVisibility()==View.GONE){
				viewTask.taskTypeLyt.setVisibility(View.VISIBLE);
				viewTask.taskOpenBtn.setBackgroundResource(R.drawable.down);
			}else{
				viewTask.taskTypeLyt.setVisibility(View.GONE);
				viewTask.taskOpenBtn.setBackgroundResource(R.drawable.up);
			}
		}
	}
	
	 class TaskItemOnClickListener implements View.OnClickListener{
		 
		private String taskId;
		private String type;
		
		public void setTaskId(String taskId) {
			this.taskId = taskId;
		}

		public void setType(String type) {
			this.type = type;
		}

		@Override
		public void onClick(View v) {
			Intent intent = null;
			if(type.equals("frist")){// վ��������Ϣ
				intent = new Intent(mContext, OperationalAspectActivity.class);
				intent.putExtra("qtKey", "1");
				intent.putExtra("gnid", "RW16");
			}else if(type.equals("second")){// �����豸��ۡ��¶ȼ��
				intent = new Intent(mContext, OperationalAspectActivity.class);
				intent.putExtra("qtKey", "3");
				intent.putExtra("gnid", "RW17");
			}else if(type.equals("thrid")){// ���ܹ��������
				intent = new Intent(mContext, OperationalAspectActivity.class);
				intent.putExtra("qtKey", "2");
				intent.putExtra("gnid", "RW15");
			}else if(type.equals("fouth")){// TRMSϵͳѲ�Ӽ��
				intent = new Intent(mContext, OperationalAspectActivity.class);
				intent.putExtra("qtKey", "4");
				intent.putExtra("gnid", "RW17");
			}
			intent.putExtra("qtTask", taskId);
			mContext.startActivity(intent);
		}
	}
}
