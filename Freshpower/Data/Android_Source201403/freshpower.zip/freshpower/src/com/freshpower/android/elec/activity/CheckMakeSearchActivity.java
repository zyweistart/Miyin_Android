package com.freshpower.android.elec.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;

public class CheckMakeSearchActivity extends Activity {
	private EditText cpNameText;
	private EditText siteNameText;
	private String searchCpName;
	private String searchSiteName;
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_check_make_search);
		ActivityUtil.addActivity(this);
		Button btn = (Button)findViewById(R.id.checkMakeSearchSub);
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(CheckMakeSearchActivity.this,CheckMakeListActivity.class);
				cpNameText = (EditText)findViewById(R.id.searchCpName);
				searchCpName = cpNameText.getText().toString();
				siteNameText = (EditText)findViewById(R.id.searchSiteName);
				searchSiteName = siteNameText.getText().toString();
				intent.putExtra("searchCpName", searchCpName);
				intent.putExtra("searchSiteName", searchSiteName);
				startActivity(intent);
			}
		});
	}
	
}
