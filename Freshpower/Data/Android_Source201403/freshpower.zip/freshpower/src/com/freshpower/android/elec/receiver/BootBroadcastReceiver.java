/**   
 * @{#} BootBroadcastReceiver.java Create on 2013-4-17 ����09:46:36   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.receiver;   


import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.LogFactory;
import com.freshpower.android.elec.common.SystemServiceUtil;
import com.freshpower.android.elec.service.GpsService;

import android.app.Application;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.util.Log;
  
/**   
 * @author <a href="mailto:yangz@freshpower.cn">yangz</a>  
 * @version 1.0   
 */

public class BootBroadcastReceiver extends BroadcastReceiver {
	private LogFactory logger = LogFactory.getLogger(BootBroadcastReceiver.class);
	private Intent serviceIntent;
	
	@Override
	public void onReceive(Context context, Intent intent) {
		logger.d("BootBroadcastReceiver", "BootBroadcastReceiver....onReceive");
		serviceIntent = new Intent(context,GpsService.class);
		if(intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED)){
			if(context.getSharedPreferences(AppConstant.SHARED_PREFERENCE_NAME, context.MODE_PRIVATE).getBoolean(AppConstant.SharedPreferencesKey.GPS_SET, false)){
				if(!SystemServiceUtil.isGpsOpen(context)){
					notification(context);
				}
				logger.d("trmsDebug", "BootBroadcastReceiver...BOOT");
				serviceIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				context.startService(serviceIntent);
			}
		}else if(intent.getAction().equals(AppConstant.ReceiverAction.ACTION_GPSSERVICE_START)){
			if(!SystemServiceUtil.isGpsOpen(context)){
				notification(context);
			}
			logger.d("trmsDebug", "BootBroadcastReceiver...START");
			if(!SystemServiceUtil.isServiceRunning(context, GpsService.class.getName())){
				logger.d("trmsDebug", "BootBroadcastReceiver..services...START");
				serviceIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				context.startService(serviceIntent);
			}
		}else if(intent.getAction().equals(AppConstant.ReceiverAction.ACTION_GPSSERVICE_STOP)){
			logger.d("trmsDebug", "BootBroadcastReceiver...STOP");
			context.stopService(serviceIntent);
		}
	}
	
	private void notification(Context context){
		Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
		PendingIntent pi = PendingIntent.getActivity(context, 0, myIntent, 0);
		Notification notify = new Notification();
		notify.icon = context.getApplicationContext().getApplicationInfo().icon;
		notify.tickerText = context.getString(R.string.msg_statusBar_gps_openAlert_ticker);
		notify.when = System.currentTimeMillis();
		notify.defaults = Notification.DEFAULT_ALL;
		notify.setLatestEventInfo(context,context.getString(R.string.msg_statusBar_gps_openAlert_ContentTitle), context.getString(R.string.msg_statusBar_gps_openAlert_ContentText), pi);  
		notify.flags = Notification.FLAG_AUTO_CANCEL;
		NotificationManager notificationManager = (NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);
		notificationManager.notify(0x1123, notify);
//		notificationManager.cancel(0x1123);
	}

}
  
