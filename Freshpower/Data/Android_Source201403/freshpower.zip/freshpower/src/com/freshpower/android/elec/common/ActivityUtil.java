/**   
 * @{#} BaseActivity.java Create on 2012-12-12 ����04:34:55   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.common;   

import java.util.LinkedList;

import android.app.Activity;
  
/**   
 * @author <a href="mailto:yangz@freshpower.cn">yangz</a>  
 * @version 1.0   
 */

public class ActivityUtil {
	private static final LinkedList<Activity> sActivityList = new LinkedList<Activity>();   
    
    private static boolean sProcessKilled = true;   
       
    public static boolean isProcessKilled() {   
        return sProcessKilled;   
    }   
  
    public static void setProcessStarted() {   
        sProcessKilled = false;   
    }   
       
    /***  
     * ��ÿ��Activity��onCreate�е��ã�������¼���˵�activity  
     */  
    public static void addActivity(Activity act) {   
        sActivityList.add(act);   
    }   
       
    /***  
     * ��ÿ��Activity��onDestroy�е���  
     */  
    public static void removeActivity(Activity act) {   
        sActivityList.remove(act);   
    }   
       
    /***  
     * �������е�activity�����رճ���Ľ���  
     */  
    public static void exit() {   
        finishAll();
    }   
       
    /***  1
     * �������е�activity��������رճ���Ľ���  
     */  
    public static void finishAll() {   
        for (Activity act : sActivityList) {   
            act.finish();   
        }      
        sActivityList.clear();   
    }   
       
    private ActivityUtil() {} // no instance   
}
  
