package com.freshpower.android.elec.netapi;

import java.io.File;

import android.annotation.SuppressLint;
import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppCache;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.MD5;
import com.freshpower.android.elec.conf.AppConfig;
import com.freshpower.android.elec.domain.AggregatorInfo;
import com.freshpower.android.elec.domain.CollectorInfo;
import com.freshpower.android.elec.domain.CompanyInfo;
import com.freshpower.android.elec.domain.LoginInfo;

public class ScanInfoDateApi extends JsonDataApi {
	private static final String ACTION_NAME = "AppScanNumber.aspx";
	/**
	 * �㼯�����
	 * @param SerialNo ɨ��㼯��������
	 * @return
	 * @throws Exception
	 */
	@SuppressLint("DefaultLocale")
	public static AggregatorInfo getAggregatorInfo(String name,String password,String SerialNo) throws Exception {//
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei", loginInfo.getLoginName());
		api.addParam("authentication", loginInfo.getLoginPwd().toUpperCase());
		api.addParam("OpWap", "1");
		api.addParam("OpType", "2");
		api.addParam("SerialNo", SerialNo.trim());
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+ACTION_NAME,AppConstant.ETG_INTERFACE_CHARSET);
		JSONArray json = jsonResult.getJSONArray("Rows");
		AggregatorInfo agg = new AggregatorInfo();
		JSONObject rs=(JSONObject) json.get(0);
		if(rs.getString("result")!=null){
			agg.setResult(rs.getString("result"));
			return agg;
		}else{
			for(int i=0;i<json.size();i++){
				JSONObject rows=(JSONObject) json.get(i);
				agg = new AggregatorInfo();
				agg.setSerialNo(rows.getString("SERIAL_NO"));//���к�
				agg.setProductNo(rows.getString("PRODUCT_NO"));//�ͺ�
				agg.setCommuType(rows.getString("COMMU_TYPE"));//��վͨѶ
				agg.setIsOnLine(rows.getString("IS_ONLINE"));//����վ����
				agg.setStatus(rows.getString("STATUS"));
				agg.setRegId(rows.getString("REG_ID"));
				agg.setConvergeId(rows.getString("CONVERGE_ID"));
				agg.setSiteId(rows.getString("SITE_ID"));
				agg.setCpId(rows.getString("CP_ID"));
				agg.setConvergeKey(rows.getString("CONVERGE_KEY"));//Ψһ��ʶ
				agg.setCpName(rows.getString("CP_NAME"));//ʹ�õ�λ
				agg.setSiteName(rows.getString("SITE_NAME"));
				agg.setTel(rows.getString("TEL"));
				agg.setTelName(rows.getString("TELMAN"));
				agg.setLinesCount(rows.getString("LINES_COUNT"));//�ɼ�·��
				agg.setMetersCount(rows.getString("METERS_COUNT"));//�ɼ���·��
				agg.setAlarmCount(rows.getString("ALARM_COUNT"));//������Ϣ
				agg.setErrCount(rows.getString("ERR_COUNT"));//�쳣·��
			}
			return agg;
		}
	}
	//��ȡ��ҵ��Ϣ
	@SuppressLint("DefaultLocale")
	public static CompanyInfo getCompanyInfo(String name,String password,String SiteId) throws Exception{
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei", loginInfo.getLoginName());
		api.addParam("authentication", loginInfo.getLoginPwd().toUpperCase());
		api.addParam("SiteId", SiteId);
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+ACTION_NAME,AppConstant.ETG_INTERFACE_CHARSET);
		JSONArray json = jsonResult.getJSONArray("Rows");
		CompanyInfo company = new CompanyInfo();
		JSONObject rs=(JSONObject) json.get(0);
		if(rs.getString("result")!=null){
			company.setResult(rs.getString("result"));
			return company;
		}else{
			for(int i=0;i<json.size();i++){
				JSONObject rows=(JSONObject) json.get(i);
				company = new CompanyInfo();
				company.setName(rows.getString("NAME"));
				company.setTelMan(rows.getString("TELMAN"));
				company.setAddRess(rows.getString("ADDRESS"));
				company.setSubCount(rows.getString("SUB_COUNT"));
				company.setTransCount(rows.getString("TRANS_COUNT"));
				company.setTransName(rows.getString("TRANS_NAME"));
				company.setTransFormNo(rows.getString("TRANSFORM_NO"));
			}
			return company;
		}
	}
	//��ȡ��·��Ϣ
	@SuppressLint("DefaultLocale")
	public static CollectorInfo getCollectorInfo(String name,String password,String serialNo,String chanel) throws Exception{
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei", loginInfo.getLoginName());
		api.addParam("authentication", loginInfo.getLoginPwd().toUpperCase());
		api.addParam("OpWap", "1");
		api.addParam("OpType","1");
		api.addParam("SerialNo",serialNo.trim());
		api.addParam("Channel",chanel.trim());
		
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+ACTION_NAME,AppConstant.ETG_INTERFACE_CHARSET);
		JSONArray json = jsonResult.getJSONArray("Rows");
		CollectorInfo collectorInfo = new CollectorInfo();
		JSONObject rs=(JSONObject) json.get(0);
		if(rs.getString("result")!=null){
			collectorInfo.setResult(rs.getString("result"));
			return collectorInfo;
		}else{
			for(int i=0;i<json.size();i++){
				JSONObject rows=(JSONObject) json.get(i);
				collectorInfo = new CollectorInfo();
				collectorInfo.setMeterName(rows.getString("METER_NAME"));
				collectorInfo.setMeterNo(rows.getString("METER_NO"));
				collectorInfo.setRatio(rows.getString("RATIO"));
				collectorInfo.setLoadGrade(rows.getString("LOAD_GRADE"));
				collectorInfo.setSwitchNo(rows.getString("SWITCH_NO"));
				collectorInfo.setFixValue(rows.getString("FIX_VALUE"));
				collectorInfo.setStatus2(rows.getString("STATUS2"));
				collectorInfo.setReportDate(rows.getString("REPORT_DATE"));
				collectorInfo.setAllHour(rows.getString("all_hour"));
				collectorInfo.setTotalPower(rows.getString("TOTAL_POWER"));
				collectorInfo.setvA(rows.getString("V_A"));
				collectorInfo.setvB(rows.getString("V_B"));
				collectorInfo.setvC(rows.getString("V_C"));
				collectorInfo.setpA(rows.getString("P_A"));
				collectorInfo.setpB(rows.getString("P_B"));
				collectorInfo.setpC(rows.getString("P_C"));
				collectorInfo.setiA(rows.getString("I_A"));
				collectorInfo.setiB(rows.getString("I_B"));
				collectorInfo.setiC(rows.getString("I_C"));
				collectorInfo.setfA(rows.getString("F_A"));
				collectorInfo.setfB(rows.getString("F_B"));
				collectorInfo.setfC(rows.getString("F_C"));
				collectorInfo.setHz(rows.getString("HZ"));
			}
			return collectorInfo;
		}
	}
	//�����ɼ���
	public static String changeMeter(String name,String password,String oldSerialNo,String newSerialNo,String ChangeReason) throws Exception{
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei", loginInfo.getLoginName());
		api.addParam("authentication", loginInfo.getLoginPwd().toUpperCase());
		api.addParam("OpWap", "0");
		api.addParam("OpType","1");
		api.addParam("SerialNo", oldSerialNo.trim());
		api.addParam("NewserialNo", newSerialNo.trim());
		api.addParam("ChangeReason", ChangeReason.trim());
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+ACTION_NAME,AppConstant.ETG_INTERFACE_CHARSET);
		JSONArray json = jsonResult.getJSONArray("Rows");
		JSONObject result = (JSONObject) json.get(0);
		String rs = result.getString("result");
		return rs;
	}
	public static int showMsg(String num){
		int msg = 0;
		if(num.equals("0")){
			msg = R.string.no_user;
		}else if(num.equals("-1")){
			msg = R.string.charge_fail;
		}else if(num.equals("-2")){
			msg = R.string.collector_cannot_opeater;
		}else if(num.equals("-4")){
			msg = R.string.cannt_user_ckcollector;
		}else if(num.equals("-5")){
			msg = R.string.type_error;
		}else if(num.equals("-6")){
			msg = R.string.cannt_opeater;
		}else if(num.equals("-7")){
			msg = R.string.not_find_line_name;
		}else if(num.equals("-8")){
			msg = R.string.no_opeater_power;
		}else if(num.equals("-9")){
			msg = R.string.no_find_id_connect_manager;
		}else if(num.equals("-10")){
			msg = R.string.no_find_only_key;
		}else if(num.equals("-11")){
			msg = R.string.no_confirm_no_opeater;
		}else if(num.equals("-12")){
			msg = R.string.connect_fail_check_network;
		}else if(num.equals("-13")){
			msg = R.string.connect_down;
		}else if(num.equals("-14")){
			msg = R.string.no_twelve;
		}else if(num.equals("-15")){
			msg = R.string.no_telnet;
		}
		return msg;
	}
	
}
