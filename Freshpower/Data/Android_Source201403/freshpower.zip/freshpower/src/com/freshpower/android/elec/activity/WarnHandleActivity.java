package com.freshpower.android.elec.activity;

import org.apache.http.conn.HttpHostConnectException;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.netapi.StationInfoDataApi;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

public class WarnHandleActivity extends Activity {
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		ActivityUtil.addActivity(this);
		getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		setContentView(R.layout.activity_warnhandle);
		Button btn=(Button)findViewById(R.id.set_warnhandle_submit);


		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Spinner spinner=(Spinner)findViewById(R.id.warnhandle_spinner);
				spinner.getSelectedItem().toString();
				//�ύ ���ݽӿ�
				Intent it=getIntent();
				if(spinner.getSelectedItemId()==0){
					Toast.makeText(WarnHandleActivity.this, "��ѡ����ѡ�", Toast.LENGTH_SHORT).show();
					return;
				}
				try {
					String result=StationInfoDataApi.getWarnDetailInfo(it.getStringExtra("alertId"),String.valueOf(spinner.getSelectedItemId()));
					if(null!=result&&!"".equals(result)){
						Toast.makeText(WarnHandleActivity.this, R.string.warn_handle_msg, Toast.LENGTH_SHORT).show();
						Intent intent = new Intent(WarnHandleActivity.this,WarnActivity.class);
						startActivity(intent);
						finish();
					}
				}catch (HttpHostConnectException e) {
					Toast.makeText(WarnHandleActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show();
					e.printStackTrace();
				}catch (Exception e) {
					Toast.makeText(WarnHandleActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show(); 
					e.printStackTrace();
				}
			}
		});
		ImageView closebtn = (ImageView)findViewById(R.id.set_warnhandle_close);
		closebtn.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				WarnHandleActivity.this.onBackPressed();
				finish();
			}
		});

	}
}
