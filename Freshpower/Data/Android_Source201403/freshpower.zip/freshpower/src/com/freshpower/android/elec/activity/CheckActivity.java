package com.freshpower.android.elec.activity;

import android.annotation.SuppressLint;
import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabWidget;
import android.widget.TextView;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.SizeUtil;


@SuppressWarnings("deprecation")
@SuppressLint("ResourceAsColor")
public class CheckActivity extends TabActivity implements OnClickListener {
	private ImageButton homeBtn;
	private ImageButton stationDataBtn;
	private ImageButton stationWarnBtn;
	private ImageButton stationTaskbtn;
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_check);
		final TabHost tabHost = getTabHost();

		Intent checkMakeIntent = new Intent();
		checkMakeIntent.setClass(this, CheckMakeSearchActivity.class);
		TabHost.TabSpec checkMakeTS = tabHost.newTabSpec(getResources().getString(R.string.check_make_title));
		checkMakeTS.setIndicator(getResources().getString(R.string.check_make_title));
		checkMakeTS.setContent(checkMakeIntent);
		tabHost.addTab(checkMakeTS);

		Intent checkRecordIntent = new Intent();
		checkRecordIntent.setClass(this, CheckRecordSearchActivity.class);
		TabHost.TabSpec checkRecordTS = tabHost.newTabSpec(getResources().getString(R.string.check_record_title));
		checkRecordTS.setIndicator(getResources().getString(R.string.check_record_title));
		checkRecordTS.setContent(checkRecordIntent);
		tabHost.addTab(checkRecordTS);

		Intent workerIntent = new Intent();
		workerIntent.setClass(this, LocationMapActivity.class);
		TabHost.TabSpec workerTS = tabHost.newTabSpec(getResources().getString(R.string.check_worker_title));
		workerTS.setIndicator(getResources().getString(R.string.check_worker_title));
		workerTS.setContent(workerIntent);
		tabHost.addTab(workerTS);

		tabHost.setCurrentTab(0);

		//��ʼ������һ�α�ǩ����
		updateTabBackground(tabHost);
		


		//ѡ��ʱ�������ġ�
		tabHost.setOnTabChangedListener(new OnTabChangeListener() {
			public void onTabChanged(String tabId) {
				updateTabBackground(tabHost);
			}
		});

		TabWidget tabWidget = tabHost.getTabWidget();
		for (int i =0; i < tabWidget.getChildCount(); i++) {
			tabWidget.getChildAt(i).getLayoutParams().height = SizeUtil.dip2px(this, 40F);
			tabWidget.getChildAt(i).getLayoutParams().width = SizeUtil.dip2px(this, 65F);
			tabWidget.getChildAt(i).setBackgroundResource(R.color.bgcolor);
			 View vvv = tabHost.getTabWidget().getChildAt(i);
			TextView tv = (TextView) tabWidget.getChildAt(i).findViewById(android.R.id.title);
			if(i==0){
				tv.setTextColor(getResources().getColor(R.color.orange));
            	vvv.setBackgroundResource(R.drawable.tab_select);
            	tv.setTextSize(15);
			}else{
				vvv.setBackgroundResource(R.drawable.tab);
				tv.setTextColor(this.getResources().getColorStateList(android.R.color.black));
			}
			
		}

		 tabWidget.getChildAt(2).setOnClickListener(new OnClickListener() {
				
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(CheckActivity.this, LocationMapActivity.class);
				startActivity(intent);
			}
		});
		 
		 
		// �����¼�
		ImageView returnButton = (ImageView) findViewById(R.id.nav_left);
		returnButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				CheckActivity.this.onBackPressed();
			}
		});

		stationDataBtn = (ImageButton) findViewById(R.id.stationDataBtn);
		if(stationDataBtn!=null)
			stationDataBtn.setOnClickListener(this);

		stationWarnBtn = (ImageButton) findViewById(R.id.stationWarnBtn);
		if(stationWarnBtn!=null)
			stationWarnBtn.setOnClickListener(this);

		stationTaskbtn = (ImageButton) findViewById(R.id.stationTaskbtn);
		if(stationTaskbtn!=null)
			stationTaskbtn.setOnClickListener(this);

	}

	protected void onResume() {
		homeBtn = (ImageButton) findViewById(R.id.stationCheckBtn);
		if(homeBtn!=null){
			homeBtn.setOnClickListener(null);
			homeBtn.setBackgroundResource(R.drawable.checkbtn_select);
		}

		TextView toolBtnTv = (TextView)findViewById(R.id.stationCheckTv);
		toolBtnTv.setTextColor(getResources().getColor(R.color.orange));

		super.onResume();
	}

	public void onClick(View v) {
		Intent intent = null;
		switch (v.getId()) {
		case R.id.stationDataBtn:
			intent = new Intent(CheckActivity.this, StationActivity.class);
			startActivity(intent);
			overridePendingTransition(android.R.anim.fade_in,
					android.R.anim.fade_out);
			this.finish();
			break;
		case R.id.stationWarnBtn:
			intent = new Intent(CheckActivity.this, WarnActivity.class);
			startActivity(intent);
			overridePendingTransition(android.R.anim.fade_in,
					android.R.anim.fade_out);
			this.finish();
			break;
		case R.id.stationTaskbtn:
			intent = new Intent(CheckActivity.this, TaskActivity.class);
			startActivity(intent);
			overridePendingTransition(android.R.anim.fade_in,
					android.R.anim.fade_out);
			this.finish();
			break;
		default:
			break;
		}
	}
	
	/**
     * ����Tab��ǩ�ı���ͼ
     * @param tabHost
     */
    @SuppressLint("ResourceAsColor")
	private void updateTabBackground(final TabHost tabHost) {
        for (int i = 0; i < tabHost.getTabWidget().getChildCount(); i++) {
        	TabWidget tab = tabHost.getTabWidget();
        	TextView tv = (TextView) tab.getChildAt(i).findViewById(android.R.id.title);
            View view = tabHost.getTabWidget().getChildAt(i);
            if (tabHost.getCurrentTab() == i) {
                //ѡ�к�ı���
            	tv.setTextColor(getResources().getColor(R.color.orange));
            	view.setBackgroundResource(R.drawable.tab_select);
            } else {
                //��ѡ��ı���
            	tv.setTextColor(R.color.balck);
            	view.setBackgroundResource(R.drawable.tab);
            }
        }
    }
    
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
    	 if (event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0 && event.getAction() == KeyEvent.ACTION_DOWN){
    		 Intent intent = new Intent(this,HomeActivity.class);
    		 startActivity(intent);
    		 finish();
             return false;
         }
         else
         {
             return super.dispatchKeyEvent(event);
         }
    }
    
}
