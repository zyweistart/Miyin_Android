/**   
 * @{#} AppCache.java Create on 2012-10-23 ����02:34:25   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.common;   
  

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import android.app.Application;

/**   
 * @author <a href="mailto:yangz@freshpower.cn">yangz</a>  
 * @version 1.0   
 */
public class AppCache extends Application{
	private static Map<String, Object> maincache = null;
	
	static {
		maincache = Collections.synchronizedMap(new HashMap<String, Object>());
	}
	public static void put(String key,Object value){
		maincache.put(key, value);
	}
	
	public static Object get(String key){
		return maincache.get(key);
	}
	
	public static void remove(String key){
		maincache.remove(key);
	}
	
	public static int getSize(){
		return maincache.size();
	}
	
	public final static String LOGIN_AUTH_INFO = "LOGIN_AUTH_INFO";
	public final static String LOCATION_key = "LOCATION";
	public final static String APP_RUNMODEL_KEY = "RUN_MODEL";
	public final static String CURRENT_MEDIA_PLAYER = "CURRENT_MEDIA_PLAYER";
	public final static String IS_UPDATE_NEXT = "IS_UPDATE_NEXT";
	public final static String LOGININFO_OBJ = "LOGININFO_OBJ";
}
