/**   
 * @{#} SsystemDataApi.java Create on 2012-10-24 ����02:29:07   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.netapi;

import java.io.File;

import android.content.pm.PackageManager;
import android.util.Log;

import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.conf.AppConfig;
import com.freshpower.android.elec.domain.AppStoreInfo;

/**
 * @author <a href="mailto:yangz@freshpower.cn">yangz</a>
 * @version 1.0
 */

public class AppStoreInfoDataApi extends JsonDataApi {
	private static final String ACTION_NAME = "queryMobileVersionInfo.aspx";

	public static AppStoreInfo getAppStoreInfo(String key) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		String ver=AppConfig.getInstance().getAppVersion();
		api.addParam("key",key);
		api.addParam("wap_filesbag", "wap_filesbag1");
		JSONObject jsonResult =api.postForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+ACTION_NAME,AppConstant.ETG_INTERFACE_CHARSET);
		AppStoreInfo appStoreInfo= new AppStoreInfo();
		if(jsonResult.getString("verCode")==null || "".equals(jsonResult.getString("verCode"))){
			appStoreInfo.setVerCode("3.0");
		}else{
			appStoreInfo.setVerCode(jsonResult.getString("verCode"));
		}
		appStoreInfo.setVerFilePah("http://www.fps365.net/SoftwareFile/Electrician.apk");
//		appStoreInfo.setVerFilePah(jsonResult.getString("verFilePath"));
		appStoreInfo.setChangeInfo(jsonResult.getString("changeInfo"));
		appStoreInfo.setMust(jsonResult.getString("must"));
		appStoreInfo.setFrequency(Long.valueOf(jsonResult.getString("frequency")));
		return appStoreInfo;
	}
}
