package com.freshpower.android.elec.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.conn.HttpHostConnectException;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.CheckTaskAdapter;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.domain.CheckTask;
import com.freshpower.android.elec.netapi.CheckTaskApi;
import com.freshpower.android.elec.widget.PullDownListView;

public class CheckMakeListActivity extends FrameActivity implements PullDownListView.OnRefreshListioner{
	private Resources res;
	private ImageButton homeBtn;
	private List<CheckTask> checkTaskList;
	private PullDownListView mPullDownView;
	private ListView mListView;
	private CheckTaskAdapter adapter; 
	private Handler mHandler = new Handler();
	private int pageSize = 10;//ÿҳ��ʾ
	private int currentPage =1;//��ǰҳ
	private int totalCnt=0;//�ܼ�¼��
	private int rs=999;//��ѯ���
	List<Map<String, Object>> checkTaskMap;
	private ProgressDialog processProgress;
	private String cpName;
	private String siteName;
	private String catchNot="yes";
	private String result;

	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_check_make_list);
		res = getResources();

		cpName = getIntent().getStringExtra("searchCpName");
		siteName = getIntent().getStringExtra("searchSiteName");

		mPullDownView = (PullDownListView) findViewById(R.id.sreach_list);
		mPullDownView.setRefreshListioner(this);
		mListView = mPullDownView.mListView;
		processProgress = ProgressDialog.show(CheckMakeListActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(){
			public void run() {
				checkTaskMap = getGroupOnelistData();
				Message msgMessage = new Message();
				CheckMakeListActivity.this.xHandler.sendMessage(msgMessage);
			}
		}.start();
		
		// �����¼�
		ImageView returnButton = (ImageView) findViewById(R.id.nav_left);
		returnButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				CheckMakeListActivity.this.onBackPressed();
			}
		});
		
	}

	private Handler xHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			adapter = new CheckTaskAdapter(checkTaskMap,CheckMakeListActivity.this,R.layout.listitem_check_make_style);	
			if(checkTaskMap.size()==0){
				Toast.makeText(CheckMakeListActivity.this, R.string.noSearchResultMsg,Toast.LENGTH_SHORT).show();
				rs=AppConstant.Result.NO_COUNT;
			}else{
				rs=AppConstant.Result.SUCCESS;
			}
			mListView.setAdapter(adapter);
			setShow();
			mPullDownView.setVisibility(View.VISIBLE);
			processProgress.dismiss();
		};
	};

	private void setShow() {
		RelativeLayout noResultlayout = (RelativeLayout) findViewById(R.id.noResultlayout);
		if(rs==AppConstant.Result.NO_COUNT){
			noResultlayout.setVisibility(View.VISIBLE);
			mPullDownView.setMore(false);
		}else{
			noResultlayout.setVisibility(View.GONE);
			mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
		}
		if(totalCnt<10){
			mPullDownView.setMore(false);
		}
	}
	private List<Map<String, Object>> getGroupOnelistData(){
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		try {
			Map checkTaskMap = CheckTaskApi.getCheckMakeList(pageSize,currentPage,cpName,siteName);
			result = String.valueOf(checkTaskMap.get("result"));
			totalCnt = Integer.parseInt(String.valueOf(checkTaskMap.get("totalCount")));
			checkTaskList = (List<CheckTask>) checkTaskMap.get("checkTaskList");
			for (CheckTask checkTask:checkTaskList)
			{
				Map<String, Object> listItem = new HashMap<String, Object>();
				listItem.put("cpNameText",checkTask.getCpName());
				listItem.put("siteNameText",checkTask.getSiteName());
				listItem.put("cpId", checkTask.getCpId());
				listItem.put("contractId", checkTask.getContractId());
				listItem.put("siteId", checkTask.getSiteId());
				listItems.add(listItem);
			}
		}catch (HttpHostConnectException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return listItems;
	}
	/**
	 * ˢ�£������list������Ȼ�����¼��ظ�������
	 */
	public void onRefresh() {

		mHandler.postDelayed(new Runnable() {

			public void run() {
				checkTaskMap.clear();
				currentPage =1;
				checkTaskMap.addAll(getGroupOnelistData());

				mPullDownView.onRefreshComplete();//�����ʾˢ�´�����ɺ������ļ���ˢ�½�������
				mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				if(checkTaskMap.size()<10){
					mPullDownView.setMore(false);
				}
				adapter.notifyDataSetChanged();	
			}
		}, 1500);


	}

	/**
	 * ���ظ��࣬��ԭ��������������������
	 */
	public void onLoadMore() {

		mHandler.postDelayed(new Runnable() {
			public void run() {
				//addLists(5);//ÿ�μ�������������

				currentPage++;
				checkTaskMap.addAll(getGroupOnelistData());

				mPullDownView.onLoadMoreComplete();//�����ʾ���ظ��ദ����ɺ������ļ��ظ�����棨���ػ��������������ࣩ
				//if(list.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
				if(checkTaskMap.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
					mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				else
					mPullDownView.setMore(false);
				adapter.notifyDataSetChanged();	

			}
		}, 1500);
	}
	/***
	 * ��̬����listview�ĸ߶�
	 * 
	 * @param listView
	 */
	public void setListViewHeightBasedOnChildren(ListView listView) {
		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null) {
			return;
		}
		int totalHeight = 0;
		for (int i = 0; i < listAdapter.getCount(); i++) {
			View listItem = listAdapter.getView(i, null, listView);
			listItem.measure(0, 0);
			totalHeight += listItem.getMeasuredHeight();
		}
		ViewGroup.LayoutParams params = listView.getLayoutParams();
		params.height = totalHeight
				+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
		listView.setLayoutParams(params);
	}
	protected void onResume() {
		homeBtn = (ImageButton) findViewById(R.id.stationWarnBtn);
		if(homeBtn!=null){
			homeBtn.setOnClickListener(null);
			homeBtn.setBackgroundResource(R.drawable.warnbtn_select);
		}

		super.onResume();
	}
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		if(checkTaskMap!=null){
			checkTaskMap.clear();
		}
		super.onDestroy();
	}
	
}
