package com.freshpower.android.elec.netapi;

import java.io.File;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.common.AppCache;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.conf.AppConfig;
import com.freshpower.android.elec.domain.LoginInfo;
import com.freshpower.android.elec.domain.ProjectSiteAggregator;
import com.freshpower.android.elec.domain.ProjectSiteCollector;

public class ProjectSiteDateApi extends JsonDataApi {
	private static final String ACTION_NAME = "AppProductInfoBySerial.aspx";
	/**
	 * ɨ��㼯���ӿ�
	 * @param SerialNo �㼯�����к�
	 * @return
	 * @throws Exception
	 */
	public static ProjectSiteAggregator getProjectSiteAggregator(String serialNo) throws Exception {
		LoginInfo loginInfo = (LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("imei", loginInfo.getLoginName().trim());
		api.addParam("authentication", loginInfo.getLoginPwd());
		api.addParam("OpWap", "0");
		api.addParam("SerialNo", serialNo.replace(" ", ""));
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getEtgWebsite() + File.separator + ACTION_NAME, AppConstant.ETG_INTERFACE_CHARSET);
		JSONArray json = jsonResult.getJSONArray("Rows");
		ProjectSiteAggregator projectSiteAggregator = null;
		for(int i=0;i<json.size();i++){
			JSONObject rows = (JSONObject)json.get(i);
			projectSiteAggregator = new ProjectSiteAggregator();
			projectSiteAggregator.setSerialNo(rows.getString("SERIAL_NO"));//���к�
			projectSiteAggregator.setCpName(rows.getString("CP_NAME"));// ��ҵ����
			projectSiteAggregator.setConvergeKey(rows.getString("CONVERGEKEY"));// Ψһ��ʶ
			projectSiteAggregator.setSubName(rows.getString("SUB_NAME"));// ��緿���
			projectSiteAggregator.setExploTransno(rows.getString("EXPLO_TRANSNO"));// ��ѹ�����
			projectSiteAggregator.setOperationType(rows.getString("OPERATION_TYPE"));// ��ѹ������
			projectSiteAggregator.setMsiteId(rows.getString("MSITE_ID"));// վ��ID
		}
		return projectSiteAggregator;
	}
	
	/**
	 * ɨ��ɼ����ӿ�
	 * @param SerialNo �ɼ������к�
	 * @return
	 * @throws Exception
	 */
	public static ProjectSiteCollector getProjectSiteCollector(String serialNo, String channel) throws Exception {
		LoginInfo loginInfo = (LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("imei", loginInfo.getLoginName());
		api.addParam("authentication", loginInfo.getLoginPwd());
		api.addParam("OpWap", "0");
		api.addParam("SerialNo", serialNo.replace(" ", ""));
		api.addParam("Channel", channel.trim());
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getEtgWebsite() + File.separator + ACTION_NAME, AppConstant.ETG_INTERFACE_CHARSET);
		JSONArray json = jsonResult.getJSONArray("Rows");
		ProjectSiteCollector projectSiteCollector = null;
		for(int i=0;i<json.size();i++){
			JSONObject rows = (JSONObject)json.get(i);
			projectSiteCollector = new ProjectSiteCollector();
			projectSiteCollector.setSerialNo(rows.getString("SERIAL_NO"));// ���к�
			projectSiteCollector.setLineName(rows.getString("LINE_NAME"));// ��·����
			projectSiteCollector.setRatio(rows.getString("RATIO"));// ���
			projectSiteCollector.setLineCrrent(rows.getString("LINE_CURRENT"));// �����
			projectSiteCollector.setTransType1(rows.getString("TRANS_TYPE1"));// ������
			projectSiteCollector.setOperationType(rows.getString("OPERATION_TYPE"));// �ɼ�����
			projectSiteCollector.setMeterId(rows.getString("METER_ID"));// �ɼ���ID
		}
		return projectSiteCollector;
	}
	
	/**
	 * ��վ
	 * @param SerialNo �㼯�����к�
	 * @return
	 * @throws Exception
	 */
	public static String createProjectSite(String serialNo) throws Exception {
		LoginInfo loginInfo = (LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("imei", loginInfo.getLoginName());
		api.addParam("authentication", loginInfo.getLoginPwd());
		api.addParam("OpWap", "2");
		api.addParam("SerialNo", serialNo.replace(" ", ""));
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getEtgWebsite() + File.separator + ACTION_NAME, AppConstant.ETG_INTERFACE_CHARSET);
		JSONArray json = jsonResult.getJSONArray("Rows");
		JSONObject rows = (JSONObject)json.get(0);
		return rows.getString("result");
	}
	
	/**
	 * ������·
	 * @param projectSiteCollector �ɼ�������
	 * @return
	 * @throws Exception
	 */
	public static String addLine(ProjectSiteCollector projectSiteCollector) throws Exception {
		LoginInfo loginInfo = (LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("imei", loginInfo.getLoginName());
		api.addParam("authentication", loginInfo.getLoginPwd());
		api.addParam("OpWap", "1");
		api.addParam("SerialNo", projectSiteCollector.getSerialNo().replace(" ", ""));
		api.addParam("MsiteId", projectSiteCollector.getMsiteId().trim());
		api.addParam("Channel", projectSiteCollector.getChannel().trim());
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getEtgWebsite() + File.separator + ACTION_NAME, AppConstant.ETG_INTERFACE_CHARSET);
		JSONArray json = jsonResult.getJSONArray("Rows");
		JSONObject rows = (JSONObject)json.get(0);
		return rows.getString("result");
	}
	
}
