package com.freshpower.android.elec.dao;


import com.freshpower.android.elec.common.DBException;
import com.freshpower.android.elec.domain.LoginInfo;

public interface LoginPurviewDao {
	public void insertLoginPurview(LoginInfo loginInfo)throws DBException;
	public void deleteLoginPurview(LoginInfo loginInfo)throws DBException;
	public Boolean selectLoginPurview(LoginInfo loginInfo)throws DBException;
	public void insertLoginInfo(LoginInfo loginInfo)throws DBException;
	public void deleteLoginInfo(LoginInfo loginInfo)throws DBException;
	public Boolean selectLoginInfo(String bpCode)throws DBException;

}
