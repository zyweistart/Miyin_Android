package com.freshpower.android.elec.common;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


/**
 * 
 * @author yzsunlight
 *
 */
public class DateUtil {

	private static Calendar calendar;
	private static final DateFormat DATETIME_FORMAT = new SimpleDateFormat(
			"MM/dd/yyyy HH:mm:ss");
	private static final DateFormat DEFAULT_DATEFORMAT = new SimpleDateFormat(
			"mm/dd/yyyy");

	private static final DateFormat TIME__DATEFORMAT = new SimpleDateFormat(
			"hh:mm:ss");

	private static final DateFormat WEEK_FORMAT = new SimpleDateFormat("E");
	
	private static final Map<String, DateFormat> DATE_FORMAT_MAP = new HashMap<String, DateFormat>();
	static {
		DATE_FORMAT_MAP.put("mm/dd/yyyy", DEFAULT_DATEFORMAT);
		DATE_FORMAT_MAP.put("HH:mm:ss", TIME__DATEFORMAT);
		DATE_FORMAT_MAP.put("mm/dd/yyyy HH:mm:ss", DATETIME_FORMAT);
		DATE_FORMAT_MAP.put("E", WEEK_FORMAT);
	}
	
	/**
	 * ��ȡ��ǰ�µĵ�һ�������ַ���
	 * @return
	 */
	public static String getCurrentFirstDayOfMonth(){
		calendar = Calendar.getInstance();
		calendar.set(Calendar.DAY_OF_MONTH, 1); 
		return new SimpleDateFormat("yyyy-MM-dd 00:00").format(calendar.getTime());
	}
	
	/**
	 * ��ȡ��ǰ�µ����һ�������ַ���
	 * @return
	 */
	public static String getCurrentLastDayOfMonth(){
		calendar = Calendar.getInstance(); 
		calendar.set(Calendar.DAY_OF_MONTH, 1); 
		calendar.roll(Calendar.DAY_OF_MONTH, -1);  
		return new SimpleDateFormat("yyyy-MM-dd 23:59").format(calendar.getTime());
	}
	
	/**
	 * ��������ʽת�����ַ�����ʽ����ʽΪָ����ʽ
	 * 
	 * @param aDate
	 * @return ���ظ�ʽΪָ����ʽ���ַ���
	 */
	public static final String convertDateToString(Date aDate, String aMask) {
		if (aDate == null)
			return null;
		if (aMask == null || aMask.equals(""))
			return null;
		return getDateTime(aDate, aMask);
	}
	
	/**
	 * ȡ���ض�ʱ���Ӧ���ַ���,��ʽ��Ϊָ����ʽ
	 * 
	 * @param aMask
	 *            �������ڸ�ʽ���ַ���
	 * @param Date
	 * @return ���ظ�ʽΪָ����ʽ���ַ���
	 * 
	 * @see java.text.SimpleDateFormat
	 */
	public static final String getDateTime(Date aDate, String aMask) {
		if (aDate == null)
			return null;

		DateFormat format = (DateFormat) DATE_FORMAT_MAP.get(aMask);
		if (format == null) {
			format = new SimpleDateFormat(aMask);
			DATE_FORMAT_MAP.put(aMask, format);
		}
		return format.format(aDate);
	}
	
	/**
	 * ��ȡ��ֵ����
	 * @param field �����ֶ�
	 * @param amount Ϊ�ֶ����ӵ����ڻ�ʱ����
	 * @return
	 */
	public static String amountDateStr(int field,int amount){
		calendar = Calendar.getInstance();
		calendar.add(field, amount);
		return new SimpleDateFormat("yyyy-MM-dd 00:00").format(calendar.getTime());
	}
	
	/**
	 * ���ڼ�һ��
	 * @param dateStr ����
	 * @return
	 * @throws ParseException  
	 */
	public static String andOneDay(String dateStr) throws ParseException {
		Date date = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
	    calendar = Calendar.getInstance();
        calendar.setTime(date); 
        calendar.add(calendar.DATE,1);
		return new SimpleDateFormat("yyyy-MM-dd").format(calendar.getTime());
	}
	
	/**
	 * ��ȡ����ʱ��
	 * @return
	 * @throws ParseException  
	 */
	public static String getNowDate() {
		return new SimpleDateFormat("yyyy-MM-dd").format(new Date());
	}
	
	/**
	 * ��ʽ����ָ����ʽ
	 * @param dateStr ʱ��
	 * @param format ָ����ʽ
	 * @return
	 * @throws ParseException  
	 */
	public static String dateFormat(String dateStr, String format) throws ParseException {
		SimpleDateFormat fmt = new SimpleDateFormat(format);
		Date date = fmt.parse(dateStr);
		return new SimpleDateFormat(format).format(date);
	}
	
	public static void main(String[] args) {
		System.out.println(DateUtil.getCurrentFirstDayOfMonth());
		System.out.println(DateUtil.getCurrentLastDayOfMonth());
	}
}
