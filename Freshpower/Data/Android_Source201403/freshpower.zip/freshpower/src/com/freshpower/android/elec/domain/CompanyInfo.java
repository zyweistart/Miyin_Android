package com.freshpower.android.elec.domain;

public class CompanyInfo {//��˾��Ϣ
	private String name;//��ҵ����
	private String telMan;//��ϵ��
	private String addRess;//��ַ
	private String subCount;//��緿��
	private String transCount;//��ѹ����
	private String transName;//��ǰ�㼯������
	private String transFormNo;//��ѹ����Ϣ
	private String result;//����ʱ���صĽ��
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTelMan() {
		return telMan;
	}
	public void setTelMan(String telMan) {
		this.telMan = telMan;
	}
	public String getAddRess() {
		return addRess;
	}
	public void setAddRess(String addRess) {
		this.addRess = addRess;
	}
	public String getSubCount() {
		return subCount;
	}
	public void setSubCount(String subCount) {
		this.subCount = subCount;
	}
	public String getTransCount() {
		return transCount;
	}
	public void setTransCount(String transCount) {
		this.transCount = transCount;
	}
	public String getTransName() {
		return transName;
	}
	public void setTransName(String transName) {
		this.transName = transName;
	}
	public String getTransFormNo() {
		return transFormNo;
	}
	public void setTransFormNo(String transFormNo) {
		this.transFormNo = transFormNo;
	}
}
