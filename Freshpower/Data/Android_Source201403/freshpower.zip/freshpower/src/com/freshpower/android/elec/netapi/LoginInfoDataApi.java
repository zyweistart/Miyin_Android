package com.freshpower.android.elec.netapi;


import java.io.File;

import android.R;
import android.content.Context;
import android.util.Log;
import java.net.URLEncoder;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.conf.AppConfig;
import com.freshpower.android.elec.dao.DaoFactory;
import com.freshpower.android.elec.dao.LoginPurviewDao;
import com.freshpower.android.elec.dao.impl.LoginPurviewDaoImpl;
import com.freshpower.android.elec.domain.LoginInfo;
import com.freshpower.android.elec.domain.UserRegisterInfo;

public class LoginInfoDataApi extends JsonDataApi {
	private static final String ACTION_NAME = "checkMobileValid.aspx";
	private static final String REGISTER_TRMS_AUDIT = "elecRegister.aspx";
	private static final String REGISTER_CRM_AUDIT = "checkElecIdent.aspx";
	private static final String LOGIN_TYPE="2";
	private static  LoginPurviewDao loginPurviewDao;
	
	public LoginPurviewDao getLoginPurviewDao() {
		return loginPurviewDao;
	}

	public void setLoginPurviewDao(LoginPurviewDao loginPurviewDao) {
		this.loginPurviewDao = loginPurviewDao;
	}

	public static LoginInfo getLoginInfo(LoginInfo login,Context context) throws Exception {
		LoginInfo loginInfo=new LoginInfo();
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("imei",login.getLoginName().trim());
		api.addParam("authentication",login.getLoginPwd());
		api.addParam("type",LOGIN_TYPE);
		api.addParam("IsEncode","2");
		JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getFpsWebSite()+File.separator+ACTION_NAME,AppConstant.ETG_INTERFACE_CHARSET);
		loginInfo.setLoginStatus(Integer.valueOf(jsonResult.getString("result")));
		loginInfo.setLoginName(login.getLoginName());
		loginInfo.setLoginPwd(login.getLoginPwd());
		if(Integer.parseInt(jsonResult.getString("result"))==2){
			JSONArray jsonObj = jsonResult.getJSONArray("Perm");
			if(jsonObj!=null && jsonObj.size()>0){
				loginPurviewDao=DaoFactory.getLoginPurviewDao(context);
				loginPurviewDao.deleteLoginInfo(loginInfo);
				loginPurviewDao.insertLoginInfo(loginInfo);
				loginPurviewDao.deleteLoginPurview(loginInfo);
				for(int i=0;i<jsonObj.size();i++){
					LoginInfo loginPurview=new LoginInfo();
					JSONObject table1 = (JSONObject) jsonObj.get(i);
					loginPurview.setBpCode(table1.getString("BP_CODE"));
					loginPurview.setBpName(table1.getString("BP_NAME"));
					loginPurview.setLoginName(login.getLoginName());
					loginPurviewDao.insertLoginPurview(loginPurview);
				}
			}
		}
		return loginInfo;
	}
	
	public static String testUpload(UserRegisterInfo login,File cardFile,File eleFile) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("name",URLEncoder.encode(login.getLoginRegisterName(),"GBK"));
		api.addParam("telNum",login.getLoginRegisterTel().trim());
		api.addParam("identityNo",login.getLoginRegisterCardNum().trim());
		api.addParam("intentArea",URLEncoder.encode(login.getLoginRegisterAddress(),"GBK"));
		api.addParam("identityImg", cardFile);
		api.addParam("elecImg", eleFile);
		api.addParam("operateType", "1");
		api.addParam("province",URLEncoder.encode(login.getProvince(),"GBK"));
		api.addParam("city", URLEncoder.encode(login.getCity(),"GBK"));
		api.addParam("area", URLEncoder.encode(login.getCounty(),"GBK"));
		JSONObject jsonResult =api.postFileForJsonResult(AppConfig.getInstance().getFpsWebSite()+File.separator+REGISTER_TRMS_AUDIT);
		return jsonResult.getString("rs");
	}
	//��֤�Ϸ� �õ��� ���״̬
	public static String getRegisterInfoAuditTrms(UserRegisterInfo loginInfo) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("telNum", loginInfo.getLoginRegisterTel().trim());
		api.addParam("identityNo", loginInfo.getLoginRegisterCardNum().trim());
		api.addParam("operateType", "2");
		JSONObject jsonResult =api.postForJsonResult(AppConfig.getInstance().getFpsWebSite()+File.separator+REGISTER_TRMS_AUDIT,AppConstant.ETG_INTERFACE_CHARSET);
		return jsonResult.getString("rs");
	}
	//��֤�Ϸ�  crm
		public static String getRegisterInfoCrm(UserRegisterInfo loginInfo) throws Exception {
			JsonDataApi api = JsonDataApi.getInstance();
			api.addParam("telNum", loginInfo.getLoginRegisterTel().trim());
			api.addParam("identityNo", loginInfo.getLoginRegisterCardNum().trim());
			api.addParam("name", URLEncoder.encode(loginInfo.getLoginRegisterName(),"GBK"));
			JSONObject jsonResult =api.getForJsonResult(AppConfig.getInstance().getCrmWebSite()+File.separator+REGISTER_CRM_AUDIT);
			return jsonResult.getString("result");
		}
}
