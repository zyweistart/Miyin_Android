package com.freshpower.android.elec.activity;

import org.apache.http.conn.HttpHostConnectException;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.camera.CaptureActivity;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.domain.ProjectSiteAggregator;
import com.freshpower.android.elec.domain.ProjectSiteCollector;
import com.freshpower.android.elec.netapi.ProjectSiteDateApi;

public class ProjectSiteActivity extends Activity {

	// �㼯��
	private EditText serialNoAggregator;
	private EditText cpName;
	private EditText convergeKey;
	private EditText subName;
	
	// �ɼ���
	private TextView serialNoCollector;
	private TextView transType1;
	private TextView bus;
	private TextView lineName;
	private TextView lineCrrent;
	private TextView ratio;
	
	private String msiteId;// վ��ID
	
	private static ProjectSiteAggregator projectSiteAggregator = null;// �㼯��
	private static ProjectSiteCollector projectSiteCollector = null;// �ɼ���
	
	private static String aggregatorSerialNo;
	private static String aggregatorCpName;
	private static String aggregatorConvergeKey;
	private static String aggregatorSubName;

	private ProgressDialog processProgress;
	private Handler handler = new Handler();
	
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.activity_project_site);
		
		serialNoAggregator = (EditText)findViewById(R.id.testEt);
		serialNoAggregator.setText(aggregatorSerialNo);
		cpName = (EditText)findViewById(R.id.cp_name_text);
		cpName.setText(aggregatorCpName);
		convergeKey = (EditText)findViewById(R.id.converge_key_text);
		convergeKey.setText(aggregatorConvergeKey);
		subName = (EditText)findViewById(R.id.sub_name_text);
		subName.setText(aggregatorSubName);

		// �����¼�
		ImageView returnButton = (ImageView) findViewById(R.id.nav_left);
		returnButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				aggregatorSerialNo = "";
				aggregatorCpName = "";
				aggregatorConvergeKey = "";
				aggregatorSubName = "";
				projectSiteAggregator = null;
				ProjectSiteActivity.this.onBackPressed();
			}
		});

		// ɨ��㼯��
		ImageView scanAggregatorInfoButton = (ImageView) findViewById(R.id.scan_project_site);
		scanAggregatorInfoButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.putExtra("operateType", "scanProjectSiteAggregator");
				intent.setClass(ProjectSiteActivity.this, CaptureActivity.class);
				startActivityForResult(intent,AppConstant.RequestResultCode.REQUEST_SCANPROJECTACTIVITY);
			}
		});
		
		// ɨ��ɼ���/������·
		Button scanCollectorButton = (Button) findViewById(R.id.add_line);
		scanCollectorButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				//Log.d("sum",String.valueOf(projectSiteAggregator.getMsiteId()));
				if(projectSiteAggregator != null) {
					if(Integer.parseInt(projectSiteAggregator.getMsiteId()) > 0) {
						Intent intent = new Intent();
						intent.putExtra("operateType", "scanProjectSiteCollector");
						intent.setClass(ProjectSiteActivity.this, CaptureActivity.class);
						startActivityForResult(intent,AppConstant.RequestResultCode.REQUEST_SCANCOLLECTORACTIVITY);
					} else {
						Toast.makeText(ProjectSiteActivity.this, R.string.alert_msg_create_site, Toast.LENGTH_SHORT).show();
					}
				} else {
					Toast.makeText(ProjectSiteActivity.this, R.string.alert_msg_scan_aggregator, Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		// ��վ
		Button createProjectSiteButton = (Button) findViewById(R.id.create_project_site);
		createProjectSiteButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				processProgress = ProgressDialog.show(ProjectSiteActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
				new Thread(new Runnable(){
					String content ;
					@Override
					public void run() {
						try {
							if(projectSiteAggregator != null) {
								if(Integer.parseInt(projectSiteAggregator.getMsiteId()) == 0) {
									String result = ProjectSiteDateApi.createProjectSite(projectSiteAggregator.getSerialNo());
									projectSiteAggregator.setMsiteId(result);
									//Log.d("elec", "result="+result);
									if(result != null && Integer.parseInt(result) > 0) {
										//Log.d("elec", "��վ�ɹ���");
										content = getResources().getString(R.string.alert_msg_craete_success);
									} else if(result != null && Integer.parseInt(result) == -10) {
										content = getResources().getString(R.string.alert_msg_serialNo_not_null);
									} else if(result != null && Integer.parseInt(result) == -9) {
										content = getResources().getString(R.string.alert_msg_serialNo_not_found);
									} else if(result != null && Integer.parseInt(result) == -8) {
										content = getResources().getString(R.string.alert_msg_serialNo_cannot_use);
									} else if(result != null && Integer.parseInt(result) == -5) {
										content = getResources().getString(R.string.alert_msg_select);
									} else if(result != null && Integer.parseInt(result) == -4) {
										content = getResources().getString(R.string.alert_msg_exist);
									} else if(result != null && Integer.parseInt(result) == -2) {
										content = getResources().getString(R.string.alert_msg_operation);
									} else if(result != null && Integer.parseInt(result) == 0) {
										content = getResources().getString(R.string.alert_msg_unreasonable);
									}
								} else {
									content = getResources().getString(R.string.alert_msg_exist);
								}
							} else {
								content = getResources().getString(R.string.alert_msg_scan_aggregator);
							}
						} catch (Exception e) {
							e.printStackTrace();
							content = getResources().getString(R.string.msg_abnormal_network);
						}finally{
							processProgress.dismiss();
							handler.post(new Runnable() {
								@Override
								public void run() {
									Toast.makeText(ProjectSiteActivity.this, content, Toast.LENGTH_SHORT).show(); 								
								}
							});
						}
					}
				}).start();
				
			}	
		});
		
		ActivityUtil.addActivity(this);
	}

	/**
	 * ɨ�践��ֵ
	 */
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		try {
			// ɨ��㼯��
			if(AppConstant.RequestResultCode.REQUEST_SCANPROJECTACTIVITY == requestCode && AppConstant.RequestResultCode.RESULT_SCANPROJECTACTIVITY == resultCode) {
				if(!StringUtil.isEmpty(data.getStringExtra("twoDimCode")) && data.getStringExtra("twoDimCode").replaceAll(" ", "").length() == 12) {
					try {
						projectSiteAggregator = ProjectSiteDateApi.getProjectSiteAggregator(data.getStringExtra("twoDimCode"));
					} catch(HttpHostConnectException e) {
						Toast.makeText(ProjectSiteActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show();
					}
					serialNoAggregator = (EditText)findViewById(R.id.testEt);
					serialNoAggregator.setText(projectSiteAggregator.getSerialNo());
					aggregatorSerialNo = projectSiteAggregator.getSerialNo();
					cpName = (EditText)findViewById(R.id.cp_name_text);
					cpName.setText(projectSiteAggregator.getCpName());
					aggregatorCpName = projectSiteAggregator.getCpName();
					convergeKey = (EditText)findViewById(R.id.converge_key_text);
					convergeKey.setText(projectSiteAggregator.getConvergeKey());
					aggregatorConvergeKey = projectSiteAggregator.getConvergeKey();
					subName = (EditText)findViewById(R.id.sub_name_text);
					subName.setText(projectSiteAggregator.getSubName());
					aggregatorSubName = projectSiteAggregator.getSubName();
				} else {
					Toast.makeText(ProjectSiteActivity.this, R.string.alert_msg_is_true_aggregator, Toast.LENGTH_SHORT).show();
				}
			// ɨ��ɼ���
			} else if(AppConstant.RequestResultCode.REQUEST_SCANCOLLECTORACTIVITY == requestCode && AppConstant.RequestResultCode.RESULT_SCANCOLLECTORACTIVITY == resultCode) {
				if(StringUtil.isEmpty(data.getStringExtra("twoDimCode")) || data.getStringExtra("twoDimCode").replaceAll(" ", "").length() != 14) {
					Toast.makeText(ProjectSiteActivity.this, R.string.alert_msg_is_true_collector, Toast.LENGTH_SHORT).show();
					return;
				}
				try {
					projectSiteCollector = ProjectSiteDateApi.getProjectSiteCollector(data.getStringExtra("twoDimCode").substring(0, 12), data.getStringExtra("twoDimCode").substring(12));
				} catch(HttpHostConnectException e) {
					Toast.makeText(ProjectSiteActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show();
				}
				if(projectSiteAggregator != null) {
					projectSiteCollector.setMsiteId(projectSiteAggregator.getMsiteId());
				} else {
					Toast.makeText(ProjectSiteActivity.this, getResources().getString(R.string.alert_msg_scan_aggregator), Toast.LENGTH_SHORT).show();
					super.onActivityResult(requestCode, resultCode, data);
				}
				setContentView(R.layout.activity_line_new_info);
				projectSiteCollector.setChannel(data.getStringExtra("twoDimCode").substring(12));
				serialNoCollector = (TextView)findViewById(R.id.line_serial_no_text);
				serialNoCollector.setText(projectSiteCollector.getSerialNo());
				transType1 = (TextView)findViewById(R.id.trans_type1_text);
				transType1.setText(projectSiteCollector.getTransType1());
				bus = (TextView)findViewById(R.id.bus_text);
				bus.setText(data.getStringExtra("twoDimCode").substring(12));
				lineName = (TextView)findViewById(R.id.line_name_text);
				lineName.setText(projectSiteCollector.getLineName());
				lineCrrent = (TextView)findViewById(R.id.line_crrent_text);
				lineCrrent.setText(projectSiteCollector.getLineCrrent());
				ratio = (TextView)findViewById(R.id.ratio_text);
				ratio.setText(projectSiteCollector.getRatio());
				
				// ������·/���
				Button addLineButton = (Button) findViewById(R.id.add_line_button);
				addLineButton.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						processProgress = ProgressDialog.show(ProjectSiteActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
						new Thread(new Runnable(){
									String content;
									@Override
									public void run() {
										try {
											if(projectSiteCollector !=null && Integer.parseInt(projectSiteCollector.getMeterId()) == 0) {
												String result = ProjectSiteDateApi.addLine(projectSiteCollector);
												projectSiteCollector.setMeterId(result);
												if(result != null && Integer.parseInt(result) > 0) {
													projectSiteCollector = null;
													content = getResources().getString(R.string.add_line_success);
												} else if(result != null && Integer.parseInt(result) == -10) {
													projectSiteCollector = null;
													content = getResources().getString(R.string.alert_msg_serialNo_not_null);
												} else if(result != null && Integer.parseInt(result) == -9) {
													projectSiteCollector = null;
													content = getResources().getString(R.string.alert_msg_serialNo_not_found);
												} else if(result != null && Integer.parseInt(result) == -8) {
													projectSiteCollector = null;
													content = getResources().getString(R.string.alert_msg_serialNo_cannot_use);
												} else if(result != null && Integer.parseInt(result) == -5) {
													projectSiteCollector = null;
													content = getResources().getString(R.string.add_line_true_select);
												} else if(result != null && Integer.parseInt(result) == -4) {
													projectSiteCollector = null;
													content = getResources().getString(R.string.add_line_exist);
												} else if(result != null && Integer.parseInt(result) == -2) {
													projectSiteCollector = null;
													content = getResources().getString(R.string.alert_msg_operation);
													setContentView(R.layout.activity_project_site);
												} else if(result != null && Integer.parseInt(result) == 0) {
													projectSiteCollector = null;
													content = getResources().getString(R.string.alert_msg_unreasonable);
												}
											} else {
												projectSiteCollector = null;
												content = getResources().getString(R.string.add_line_exist);
											}
										} catch(Exception e) {
											e.printStackTrace();
											content = getResources().getString(R.string.msg_abnormal_network);
										}finally{
											processProgress.dismiss();
											
											handler.post(new Runnable() {
												@Override
												public void run() {
													Toast.makeText(ProjectSiteActivity.this, content, Toast.LENGTH_SHORT).show(); 
													setTextView();
												}
											});
										}
									}
								}).start();
					}
				});
				
				// �����¼�
				ImageView returnButton = (ImageView) findViewById(R.id.nav_left);
				returnButton.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						projectSiteCollector = null;
						setTextView();
					}
				});
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	private void setTextView(){
		setContentView(R.layout.activity_project_site);
		if(projectSiteAggregator != null){
			serialNoAggregator = (EditText)findViewById(R.id.testEt);
			serialNoAggregator.setText(projectSiteAggregator.getSerialNo());
			aggregatorSerialNo = projectSiteAggregator.getSerialNo();
			cpName = (EditText)findViewById(R.id.cp_name_text);
			cpName.setText(projectSiteAggregator.getCpName());
			aggregatorCpName = projectSiteAggregator.getCpName();
			convergeKey = (EditText)findViewById(R.id.converge_key_text);
			convergeKey.setText(projectSiteAggregator.getConvergeKey());
			aggregatorConvergeKey = projectSiteAggregator.getConvergeKey();
			subName = (EditText)findViewById(R.id.sub_name_text);
			subName.setText(projectSiteAggregator.getSubName());
			aggregatorSubName = projectSiteAggregator.getSubName();
		}
		
		// �����¼�
		ImageView returnButton = (ImageView) findViewById(R.id.nav_left);
		returnButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				aggregatorSerialNo = "";
				aggregatorCpName = "";
				aggregatorConvergeKey = "";
				aggregatorSubName = "";
				projectSiteAggregator = null;
				ProjectSiteActivity.this.onBackPressed();
			}
		});
		
		// ɨ��ɼ���/������·
		Button scanCollectorButton = (Button) findViewById(R.id.add_line);
		scanCollectorButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(projectSiteAggregator != null) {
					if(Integer.parseInt(projectSiteAggregator.getMsiteId()) > 0) {
						Intent intent = new Intent();
						intent.putExtra("operateType", "scanProjectSiteCollector");
						intent.setClass(ProjectSiteActivity.this, CaptureActivity.class);
						startActivityForResult(intent,AppConstant.RequestResultCode.REQUEST_SCANCOLLECTORACTIVITY);
					} else {
						Toast.makeText(ProjectSiteActivity.this, getResources().getString(R.string.alert_msg_create_site), Toast.LENGTH_SHORT).show();
					}
				} else {
					Toast.makeText(ProjectSiteActivity.this, getResources().getString(R.string.alert_msg_scan_aggregator), Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		ImageView scanAggregatorInfoButton = (ImageView) findViewById(R.id.scan_project_site);
		scanAggregatorInfoButton.setVisibility(4);
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		projectSiteAggregator = null;// �㼯��
		projectSiteCollector = null;// �ɼ���
		
		aggregatorSerialNo="";
		aggregatorCpName="";
		aggregatorConvergeKey="";
		aggregatorSubName="";
		super.onDestroy();
	}
	
	
}