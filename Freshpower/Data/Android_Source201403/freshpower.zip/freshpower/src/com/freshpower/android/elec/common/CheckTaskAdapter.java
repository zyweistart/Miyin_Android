package com.freshpower.android.elec.common;

import java.util.List;
import java.util.Map;

import android.content.Context;
import android.content.Intent;
import android.text.TextPaint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.activity.CheckMakeEditActivity;



public class CheckTaskAdapter extends BaseAdapter {

	List<Map<String, Object>> mData;
	Context mContext;
	int resource;
	public CheckTaskAdapter(List<Map<String, Object>> data,
			Context context, int resource) {
		this.mData = data;
		this.mContext = context;
		this.resource = resource;
	}

	@Override
	public int getCount() {
		return mData == null ? 0 : mData.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	static class ViewHoder {
		TextView cpNameText;
		TextView siteNameText;
		Button makeCheckTaskBtn;
		LinearLayout checkMakeListitem;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHoder hoder = null;
		if (convertView == null) {
			hoder = new ViewHoder();
			convertView = LayoutInflater.from(mContext).inflate(resource, null);
			hoder.cpNameText = (TextView) convertView
					.findViewById(R.id.cpNameText);
			hoder.siteNameText = (TextView) convertView
					.findViewById(R.id.siteNameText);
			hoder.makeCheckTaskBtn = (Button) convertView
					.findViewById(R.id.checkMakeHandle);
			hoder.checkMakeListitem = (LinearLayout) convertView
					.findViewById(R.id.checkMakeListitem);
			convertView.setTag(hoder);
		} else {
			hoder = (ViewHoder) convertView.getTag();
		}
		Map<String, Object> data = mData.get(position);
		if(position % 2 ==1){
			hoder.checkMakeListitem.setBackgroundColor(mContext.getResources().getColor(R.color.bgcolor));
		}else{
			hoder.checkMakeListitem.setBackgroundColor(mContext.getResources().getColor(R.color.white));
		}
		hoder.cpNameText.setText(String.valueOf(data.get("cpNameText")));
		hoder.siteNameText.setText(String.valueOf(data.get("siteNameText")));
		
		
		MakeCheckTaskListener makeCheckTaskListener = new MakeCheckTaskListener();
		makeCheckTaskListener.setCpId(String.valueOf(data.get("cpId")));
		makeCheckTaskListener.setContractId(String.valueOf(data.get("contractId")));
		makeCheckTaskListener.setSiteId(String.valueOf(data.get("siteId")));
		hoder.makeCheckTaskBtn.setOnClickListener(makeCheckTaskListener);
		return convertView;
	}
	
	
	 class MakeCheckTaskListener implements View.OnClickListener{
		 
		private String cpId;
		private String contractId;
		private String siteId;
		
		public void setCpId(String cpId) {
			this.cpId = cpId;
		}

		public void setContractId(String contractId) {
			this.contractId = contractId;
		}

		public void setSiteId(String siteId) {
			this.siteId = siteId;
		}

		@Override
		public void onClick(View v) {
			Intent intent = new Intent(mContext, CheckMakeEditActivity.class);
			intent.putExtra("cpId", cpId);
			intent.putExtra("contractId", contractId);
			intent.putExtra("siteId", siteId);
			mContext.startActivity(intent);
		}
	}
	 
}
