package com.freshpower.android.elec.activity;

import org.apache.http.conn.HttpHostConnectException;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.domain.CollectorInfo;
import com.freshpower.android.elec.netapi.ScanInfoDateApi;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class LineInfoActivity extends Activity {
	private ProgressDialog processProgress;
	private Handler handler = new Handler();
	private String serialNo;
	private String chanel;
	private CollectorInfo collectorInfo = new CollectorInfo();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_line_info);
		ImageView returnBtn = (ImageView)findViewById(R.id.nav_left);
		returnBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				LineInfoActivity.this.onBackPressed();
			}
		});
		Intent intent = getIntent();
		serialNo = intent.getStringExtra("serialNo");
		chanel = intent.getStringExtra("chanel");
		
		processProgress = ProgressDialog.show(LineInfoActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(new Runnable(){
			int content = 0;
			@Override
			public void run() {
				try {
					Log.d("BID","serialNo:"+serialNo);
					collectorInfo = ScanInfoDateApi.getCollectorInfo("","",serialNo, chanel);
				} catch (HttpHostConnectException e) {
					Toast.makeText(LineInfoActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show();
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					processProgress.dismiss();
					handler.post(new Runnable() {
						@Override
						public void run() {
							TextView lineInfoNo = (TextView)findViewById(R.id.line_info_no);
							TextView lineView1 = (TextView)findViewById(R.id.line_view1);
							TextView lineView2 = (TextView)findViewById(R.id.line_view2);
							TextView lineView3 = (TextView)findViewById(R.id.line_view3);
							TextView lineView4 = (TextView)findViewById(R.id.line_view4);
							TextView lineView5 = (TextView)findViewById(R.id.line_view5);
							TextView lineView6 = (TextView)findViewById(R.id.line_view6);
							TextView lineView7 = (TextView)findViewById(R.id.line_view7);
							TextView lineView8 = (TextView)findViewById(R.id.line_view8);
							TextView lineView9 = (TextView)findViewById(R.id.line_view9);
							TextView lineView10 = (TextView)findViewById(R.id.line_view10);
							TextView lineView11 = (TextView)findViewById(R.id.line_view11);
							TextView lineView12 = (TextView)findViewById(R.id.line_view12);
							TextView lineView13 = (TextView)findViewById(R.id.line_view13);
							TextView lineView14 = (TextView)findViewById(R.id.line_view14);
							TextView lineView15 = (TextView)findViewById(R.id.line_view15);
							TextView lineView16 = (TextView)findViewById(R.id.line_view16);
							TextView lineView17 = (TextView)findViewById(R.id.line_view17);
							TextView lineView18 = (TextView)findViewById(R.id.line_view18);
							TextView lineView19 = (TextView)findViewById(R.id.line_view19);
							TextView lineView20 = (TextView)findViewById(R.id.line_view20);
							TextView lineView21 = (TextView)findViewById(R.id.line_view21);
							TextView lineView22 = (TextView)findViewById(R.id.line_view22);
							TextView lineView23 = (TextView)findViewById(R.id.line_view23);
							lineInfoNo.setText(serialNo.substring(0,4)+" "+serialNo.substring(4,8)+" "+serialNo.substring(8,12) +" | "+chanel);
							lineView1.setText(collectorInfo.getMeterName());
							lineView2.setText(collectorInfo.getMeterNo());
							lineView3.setText(collectorInfo.getSwitchNo());
							lineView4.setText(collectorInfo.getLoadGrade());
							lineView5.setText(collectorInfo.getFixValue());
							lineView6.setText(collectorInfo.getRatio());
							lineView7.setText(collectorInfo.getStatus2());
							lineView8.setText(collectorInfo.getReportDate());
							lineView9.setText(collectorInfo.getTotalPower());
							lineView10.setText(collectorInfo.getAllHour());
							lineView11.setText(collectorInfo.getvA());
							lineView12.setText(collectorInfo.getvB());
							lineView13.setText(collectorInfo.getvC());
							lineView14.setText(collectorInfo.getiA());
							lineView15.setText(collectorInfo.getiB());
							lineView16.setText(collectorInfo.getiC());
							lineView17.setText(collectorInfo.getpA());
							lineView18.setText(collectorInfo.getpB());
							lineView19.setText(collectorInfo.getpC());
							lineView20.setText(collectorInfo.getfA());
							lineView21.setText(collectorInfo.getfB());
							lineView22.setText(collectorInfo.getfC());
							lineView23.setText(collectorInfo.getHz());
							if(collectorInfo.getResult()!=null){
								Toast.makeText(LineInfoActivity.this, ScanInfoDateApi.showMsg(collectorInfo.getResult()), Toast.LENGTH_SHORT).show();
							}
						}
					});
				}
			}
		}).start();
		
		
		

//		lineView1.setText(agg.get)
	}
}
