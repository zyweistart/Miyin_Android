package com.freshpower.android.elec.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.domain.CustomerInfo;
import com.freshpower.android.elec.netapi.StationInfoDataApi;
import com.freshpower.android.elec.widget.PullDownListView;

public class StationHistoryDataActivity extends FrameActivity  implements PullDownListView.OnRefreshListioner{
	private PullDownListView mPullDownView;
	private ListView mListView;
	private Resources res;
	private ImageButton homeBtn;
	private List<CustomerInfo> stationDetailList;
	private Handler mHandler = new Handler();
	private int pageSize = 10;//ÿҳ��ʾ
	private int currentPage =1;//��ǰҳ
	private int totalCnt=0;//�ܼ�¼��
	private int rs=999;//��ѯ���
	private SimpleAdapter adapter;
	private RelativeLayout progressRlt = null;
	List<Map<String, Object>> customerInfoMap;
	private ProgressDialog processProgress;
	private Handler handler = new Handler();


	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_station_historydata);
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				StationHistoryDataActivity.this.onBackPressed();
			}
		});
		mPullDownView = (PullDownListView) findViewById(R.id.sreach_list);
		mPullDownView.setRefreshListioner(this);
		mListView = mPullDownView.mListView;
		processProgress = ProgressDialog.show(StationHistoryDataActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(){
			public void run() {
				customerInfoMap = getGroupOnelistData(stationDetailList);
				Message msgMessage = new Message();
				StationHistoryDataActivity.this.xHandler.sendMessage(msgMessage);
			}
		}.start();

	}
	private Handler xHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			adapter = new SimpleAdapter(StationHistoryDataActivity.this,customerInfoMap, 
					R.layout.listitem_stationhistorydata, 
					new String[] { AppConstant.ListItemWarnName.WARN_ONE, 
					AppConstant.ListItemWarnName.WARN_TWO,
					AppConstant.ListItemWarnName.WARN_THREE,
					AppConstant.ListItemWarnName.WARN_FOUR,
					AppConstant.ListItemWarnName.WARN_FIVE,
					AppConstant.ListItemWarnName.WARN_SIX,
					AppConstant.ListItemWarnName.WARN_SEVEN,
					AppConstant.ListItemWarnName.WARN_EIGHT,
					AppConstant.ListItemWarnName.WARN_NINE,
					AppConstant.ListItemWarnName.WARN_TEN,
					AppConstant.ListItemWarnName.WARN_ELEVEN,
					AppConstant.ListItemWarnName.WARN_TWELVE
					}, 
					new int[] { R.id.stationhistoryData_1,
					R.id.stationhistoryData_2,
					R.id.stationhistoryData_3,
					R.id.stationhistoryData_4,
					R.id.stationhistoryData_5,
					R.id.stationhistoryData_6,
					R.id.stationhistoryData_7,
					R.id.stationhistoryData_8,
					R.id.stationhistoryData_9,
					R.id.stationhistoryData_10,
					R.id.stationhistoryData_11,
					R.id.stationhistoryData_12
					});

			if(customerInfoMap.size()==0){
				Toast.makeText(StationHistoryDataActivity.this, R.string.noSearchResultMsg,Toast.LENGTH_SHORT).show();
				rs=AppConstant.Result.NO_COUNT;
			}
			mListView.setAdapter(adapter);
		
			setShow();
			//	    		progressRlt.setVisibility(View.GONE);
			mPullDownView.setVisibility(View.VISIBLE);
			processProgress.dismiss();
		};
	};
	private void setShow() {
		if(rs==AppConstant.Result.NO_COUNT){
			RelativeLayout noResultlayout = (RelativeLayout) findViewById(R.id.noResultlayout);
			noResultlayout.setVisibility(View.VISIBLE);
			mPullDownView.setMore(false);
		}else{
			mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
		}
		if(customerInfoMap.size()<10){
			mPullDownView.setMore(false);
		}
	}    
	@Override
	public void onRefresh() {
		// TODO Auto-generated method stub
		mHandler.postDelayed(new Runnable() {

			public void run() {
				customerInfoMap.clear();
				currentPage =1;
				customerInfoMap.addAll(getGroupOnelistData(stationDetailList));

				mPullDownView.onRefreshComplete();//�����ʾˢ�´�����ɺ������ļ���ˢ�½�������
				mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				if(customerInfoMap.size()<10){
					mPullDownView.setMore(false);
				}
				adapter.notifyDataSetChanged();	
			}
		}, 1500);

	}
	@Override
	public void onLoadMore() {
		mHandler.postDelayed(new Runnable() {
			public void run() {

				currentPage++;
				customerInfoMap.addAll(getGroupOnelistData(stationDetailList));

				mPullDownView.onLoadMoreComplete();//�����ʾ���ظ��ദ����ɺ������ļ��ظ�����棨���ػ��������������ࣩ
				//if(list.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
				if(customerInfoMap.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
					mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				else
					mPullDownView.setMore(false);
				adapter.notifyDataSetChanged();	

			}
		}, 1500);

	}
	private List<Map<String, Object>> getGroupOnelistData(List<CustomerInfo> stationDetailList){
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		Intent it=getIntent();
		String meterId =it.getStringExtra("MeterId");
		String cpId =it.getStringExtra("CpId");
		String startDate =it.getStringExtra("startDate");
		String endDate =it.getStringExtra("endDate");
		try {
			Map customerInfoMap=StationInfoDataApi.getStationDetailHistoryDataList(pageSize,currentPage,meterId,cpId,startDate,endDate);
			if(!"0".equals(customerInfoMap.get("result"))){
				stationDetailList=(List<CustomerInfo>) customerInfoMap.get("customerDatailList");
				for (CustomerInfo customerInfo:stationDetailList)
				{
					Map<String, Object> listItem = new HashMap<String, Object>();
					listItem.put(AppConstant.ListItemWarnName.WARN_ONE, customerInfo.getMeterName());
					listItem.put(AppConstant.ListItemWarnName.WARN_TWO, customerInfo.getReportDate());
					listItem.put(AppConstant.ListItemWarnName.WARN_THREE,customerInfo.getChannel());
					listItem.put(AppConstant.ListItemWarnName.WARN_FOUR, customerInfo.getHz());
					listItem.put(AppConstant.ListItemWarnName.WARN_FIVE, customerInfo.getVa());
					listItem.put(AppConstant.ListItemWarnName.WARN_SIX, customerInfo.getIa());
					listItem.put(AppConstant.ListItemWarnName.WARN_SEVEN, customerInfo.getVb());
					listItem.put(AppConstant.ListItemWarnName.WARN_EIGHT, customerInfo.getIb());
					listItem.put(AppConstant.ListItemWarnName.WARN_NINE, customerInfo.getVc());
					listItem.put(AppConstant.ListItemWarnName.WARN_TEN, customerInfo.getIc());
					listItem.put(AppConstant.ListItemWarnName.WARN_ELEVEN, customerInfo.getPower());
					listItem.put(AppConstant.ListItemWarnName.WARN_TWELVE, customerInfo.getFactor());
					listItems.add(listItem);
				}
					totalCnt = Integer.parseInt(String.valueOf(customerInfoMap.get("totalCount")));
				return listItems;
			}else{
				return listItems;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listItems;
	}
	protected void onResume() {
		homeBtn = (ImageButton) findViewById(R.id.stationDataBtn);
		if(homeBtn!=null){
			homeBtn.setOnClickListener(null);
			homeBtn.setBackgroundResource(R.drawable.databtn_select);
		}

		TextView toolBtnTv = (TextView)findViewById(R.id.stationDataTv);
		toolBtnTv.setTextColor(getResources().getColor(R.color.orange));

		super.onResume();
	}
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		if(customerInfoMap!=null){
			customerInfoMap.clear();
		}
		super.onDestroy();
	}
}
