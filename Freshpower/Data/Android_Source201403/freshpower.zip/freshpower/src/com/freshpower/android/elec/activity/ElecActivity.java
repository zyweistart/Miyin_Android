package com.freshpower.android.elec.activity;

import java.io.File;

import org.androidpn.client.Constants;
import org.androidpn.client.NotificationTxtMsgListener;
import org.androidpn.client.ServiceManager;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.AppCache;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.CommunicationManager;
import com.freshpower.android.elec.common.FileUtil;
import com.freshpower.android.elec.common.LogFactory;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.conf.AppConfig;
import com.freshpower.android.elec.domain.LoginInfo;
import com.freshpower.android.elec.netapi.DownLoadPictureApi;
import com.freshpower.android.elec.netapi.LoginInfoDataApi;

public class ElecActivity extends Activity {

	private LogFactory logger = LogFactory.getLogger(ElecActivity.class);
	private static final int NETWORKFINISH = 0x100;
	private static final int APKFINISH = 0x115;
	private static final int FINISH = 0x108;
	private static final int DBFINISH = 0x111;
	private static final int CONNECTTIMEOUT = 0x112;
	private static final int IMAGELOAD = 0x113;
	private ProgressBar progressBar;
	private TextView textView;
	private Message msgMessage;
	private SharedPreferences trmsSharedPreferences;
	private String versionStr ="Version ";

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.initwait);
		ActivityUtil.addActivity(this);
		FileUtil.appFilesDir = this.getFilesDir().getPath();
		progressBar = (ProgressBar) findViewById(R.id.circleProgressBar);
		progressBar.setIndeterminate(false);
		progressBar.setVisibility(View.VISIBLE);
		textView = (TextView) findViewById(R.id.statusText);
		TextView verCodeTv = (TextView)findViewById(R.id.verCodeTv);
		verCodeTv.setText(versionStr + getResources().getString(R.string.appVersion));
		trmsSharedPreferences = getSharedPreferences(
				AppConstant.SHARED_PREFERENCE_NAME, MODE_PRIVATE);
		/*if (!SystemServiceUtil.isNetworkConnected(ElecActivity.this)) {
			setNetworkMethod(ElecActivity.this);
			return;
		}*/
		new Thread() {
			public void run() {
				try {
					msgMessage = new Message();
					msgMessage.what = NETWORKFINISH;
					ElecActivity.this.xHandler.sendMessage(msgMessage);
					Thread.sleep(500);
					// logger.d("BID", "openInternet...");
					// openInternet();
					// logger.d("BID", "openInternet finish...");
					if (!FileUtil.isFileExist(FileUtil.getDBFilePath())) {
						initDB(FileUtil.getDBFilePath());
						msgMessage = new Message();
						msgMessage.what = DBFINISH;
						ElecActivity.this.xHandler.sendMessage(msgMessage);
						Thread.sleep(500);
					}
					
					//logger.d("BID", "initAppConfig...");
					initAppConfig();

					isLoginInfo();
					
					if (AppCache.get(AppCache.LOGIN_AUTH_INFO)!=null && (Integer) AppCache.get(AppCache.LOGIN_AUTH_INFO) == AppConstant.AuthenticationInfo.TIME_OUT) {
						msgMessage = new Message();
						msgMessage.what = CONNECTTIMEOUT;
						ElecActivity.this.xHandler.sendMessage(msgMessage);
						return;
					}

					/*
					 * ����ͷ��ͼƬ
					 */
					try {
						if (android.os.Environment.getExternalStorageState().equals(
								android.os.Environment.MEDIA_MOUNTED)) {
							msgMessage = new Message();
							msgMessage.what = IMAGELOAD;
							ElecActivity.this.xHandler.sendMessage(msgMessage);
							DownLoadPictureApi.downLoadPicture();//ʵʱ������վ���µ���ҳͼƬ
							DownLoadPictureApi.downLoadHtml();
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					
					/*
					 * msgMessage = new Message(); msgMessage.what = APKFINISH;
					 * ElecActivity.this.xHandler.sendMessage(msgMessage);
					 * Thread.sleep(500);
					 */
					startRealTimeService();
					
					msgMessage = new Message();
					msgMessage.what = FINISH;
					ElecActivity.this.xHandler.sendMessage(msgMessage);

				} catch (Exception e) {
					e.printStackTrace();
				}
			};
		}.start();
	}

	private Handler xHandler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case FINISH:
				textView.setText("�ɹ�...");
				openBrowserActivity();
				break;
			case APKFINISH:
				textView.setText("���������...");
				break;
			case NETWORKFINISH:
				textView.setText("������������...");
				break;
			case IMAGELOAD:
				textView.setText("���ݳ�ʼ��...");
				break;
			case DBFINISH:
				textView.setText("���ݳ�ʼ�����...");
				break;
			case CONNECTTIMEOUT:
				builderTimeOutDialog();
				break;
			default:
				break;
			}
		};
	};

	public void initDB(String filePath) {
		//DBOperater.openOrCreateDB(FileUtil.getDBFilePath());
		try {
			File dbFile = new File(filePath);
			FileUtil.createFolder(dbFile.getParent());
			FileUtil.createFile(dbFile);
		} catch (Exception e) {
			logger.e("dberror", e.toString());
			e.printStackTrace();
		}
	}

	/**
	 * ��ʼ��Ӧ������
	 */
	private void initAppConfig() {
		AppConfig appConfig = AppConfig.getInstance();
		appConfig.setAppVersion(getResources().getString(R.string.appVersion));
		appConfig.setEtgWebsite(getResources().getString(R.string.etgWebSite));
		appConfig.setFpsWebSite(getResources().getString(R.string.fpsWebSite));
		appConfig.setCrmWebSite(getResources().getString(R.string.crmWebSite));
		AppCache.put(AppCache.LOGIN_AUTH_INFO,
				AppConstant.AuthenticationInfo.INVALID);
	}

	private void openBrowserActivity() {
		
		Intent intent = getIntent();
		
		if(intent!=null && !StringUtil.isEmpty(intent.getStringExtra(Constants.NOTIFICATION_MESSAGE))){
			
			if(NotificationTxtMsgListener.MSG_TYPE_SWITCH.equals(intent.getStringExtra(Constants.NOTIFICATION_TYPE)) || NotificationTxtMsgListener.MSG_TYPE_ALARM.equals(intent.getStringExtra(Constants.NOTIFICATION_TYPE))){
				intent.setClass(ElecActivity.this, WarnActivity.class);
				intent.putExtra(Constants.NOTIFICATION_MESSAGE, intent.getStringExtra(Constants.NOTIFICATION_MESSAGE));
			}else{
				intent.setClass(ElecActivity.this, MessageInfoActivity.class);
			}
			startActivity(intent);
		}else{
			intent = new Intent();
			intent.putExtra("isFirst", "isFirst");
			intent.setClass(ElecActivity.this, HomeActivity.class);
			startActivity(intent);
		}
		ElecActivity.this.finish();
	}

	/*
	 * �������������
	 */
	private void setNetworkMethod(final Context context) {
		AlertDialog.Builder builder = new Builder(context);
		builder.setTitle("����������ʾ")
		.setMessage("�������Ӳ�����,�Ƿ��������?")
		.setPositiveButton("����", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				Intent intent = new Intent(
						android.provider.Settings.ACTION_WIRELESS_SETTINGS);
				context.startActivity(intent);
			}
		})
		.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				ElecActivity thisActivity = (ElecActivity) context;
				thisActivity.finish();
			}
		});
		builder.setCancelable(false);
		Dialog noticeDialog = builder.create();
		noticeDialog.setCanceledOnTouchOutside(false);
		noticeDialog.show();
	}

	private void builderTimeOutDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(ElecActivity.this);
		builder.setMessage(R.string.msg_abnormal_network);
		builder.setCancelable(false);
		builder.setPositiveButton(R.string.soft_btn_ok, new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				ElecActivity.this.finish();
			}
		});
		AlertDialog dialog = builder.create();
		dialog.setCanceledOnTouchOutside(false);
		dialog.show();
	}
	private void isLoginInfo() {
		String fileContent = FileUtil.read(FileUtil.getDBFilePath());
		if (!StringUtil.isEmpty(fileContent)){
			String str[]=fileContent.split("\\|");
			LoginInfo loginInfo=new LoginInfo();
			loginInfo.setLoginName(str[0].toString());
			loginInfo.setLoginPwd(str[1].toString());
			try {
				loginInfo=LoginInfoDataApi.getLoginInfo(loginInfo,ElecActivity.this);
				if(loginInfo.getLoginStatus()==2){
					AppCache.put(AppCache.LOGININFO_OBJ, loginInfo);
				}else{
					AppCache.remove(AppCache.LOGININFO_OBJ);
				}
			} catch (Exception e) {
				AppCache.remove(AppCache.LOGININFO_OBJ);
				e.printStackTrace();
			}
			
		}
	}
	
	/**
	 * ��ʼʵʱ֪ͨ
	 */
	private void startRealTimeService(){
		try {
			logger.d("trmsDebug", "startRealTimeService.....");
			LoginInfo loginInfo = (LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
			if(loginInfo!=null){
				initService();//GPS����
				
		        ServiceManager serviceManager = new ServiceManager(this);
		        serviceManager.setNotificationIcon(R.drawable.notification);
		        logger.d("trmsDebug", "loginCmd:"+CommunicationManager.getLogincmd(loginInfo.getLoginName(), loginInfo.getLoginPwd()));
		        serviceManager.setLoginCmd(CommunicationManager.getLogincmd(loginInfo.getLoginName(), loginInfo.getLoginPwd()));
		        serviceManager.startService();
			}
		} catch (Exception e) {
			logger.d("trmsDebug", "startRealTimeService error.....");
			e.printStackTrace();
		}
	}
	
	/**
	 * ��ʼ������
	 */
	private void initService() {
		if (trmsSharedPreferences.getBoolean(
				AppConstant.SharedPreferencesKey.GPS_SET, false)) {
			logger.d("trmsDebug", "initService...");
			Intent intent = new Intent();
			intent.setAction(AppConstant.ReceiverAction.ACTION_GPSSERVICE_START);
			sendBroadcast(intent);
		}
	}


}