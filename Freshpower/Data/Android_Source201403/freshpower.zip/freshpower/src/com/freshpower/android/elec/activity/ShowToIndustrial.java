package com.freshpower.android.elec.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppConstant;

public class ShowToIndustrial extends Activity {
	private int time = 30;
	TextView showTime;
	TextView showTimeText;
	TextView title;
	MyThread thread = new MyThread();
	private Intent privateIntent;
	String userType = "";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		setContentView(R.layout.activity_show_to_industrial);
		showTimeText = (TextView)findViewById(R.id.show_time_text);
		showTime = (TextView)findViewById(R.id.show_time);
		title = (TextView)findViewById(R.id.title);
		Intent intent = getIntent();
		String type = intent.getStringExtra("type");
		String charge = intent.getStringExtra("charge");
		String money = intent.getStringExtra("money");
		userType = intent.getStringExtra("userType");
		Button commit = (Button)findViewById(R.id.commit);
		Button cancel = (Button)findViewById(R.id.cancel);
		Log.d("BID",userType);
		if(userType.equals("0")){
			title.setText(R.string.industry_title);
			if(type.equals("1")){
				showTime.setVisibility(4);//�������鵹��ʱ��������
				showTimeText.setText(getResources().getString(R.string.industry_prompt_before)+charge+getResources().getString(R.string.industry_prompt_after));
				showTimeText.setTextSize(14);
				showTimeText.setPadding(10, 0, 10, 0);
			}else if(type.equals("2")){
				showTime.setVisibility(4);
				showTimeText.setText(getResources().getString(R.string.industry_prompt_before) + charge + getResources().getString(R.string.industry_prompt_center) + money + getResources().getString(R.string.yuan));
				showTimeText.setTextSize(14);
				showTimeText.setPadding(10, 0, 10, 0);
				commit.setVisibility(4);
				cancel.setVisibility(4);
			}
		}else if(userType.equals("1")){
			title.setText(R.string.business_title);
			if(type.equals("1")){
				showTime.setVisibility(4);
				showTimeText.setText(getResources().getString(R.string.business_prompt_before) + money + getResources().getString(R.string.yuan));
				showTimeText.setTextSize(14);
				showTimeText.setPadding(10, 0, 10, 0);
			}else if(type.equals("2")){
				showTime.setVisibility(4);
				showTimeText.setText(getResources().getString(R.string.charge_opater) + money + getResources().getString(R.string.yuan));
				showTimeText.setTextSize(14);
				showTimeText.setPadding(10, 0, 10, 0);
				commit.setVisibility(4);
				cancel.setVisibility(4);
			}
		}
		commit.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				privateIntent = new Intent();
				setResult(AppConstant.RequestResultCode.REQUEST_OPEATERCOMMIT, privateIntent);
				Log.d("elec", String.valueOf(AppConstant.RequestResultCode.REQUEST_OPEATERCOMMIT));
				ShowToIndustrial.this.onBackPressed();
			}
		});
		cancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				privateIntent = new Intent();
				setResult(AppConstant.RequestResultCode.REQUEST_OPEATERCANCEL, privateIntent);
				Log.d("elec", String.valueOf(AppConstant.RequestResultCode.REQUEST_OPEATERCANCEL));
				finish();
			}
		});
		ImageView close = (ImageView)findViewById(R.id.closeBtn);
		close.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				privateIntent = new Intent();
				setResult(AppConstant.RequestResultCode.REQUEST_OPEATERCANCEL, privateIntent);
				finish();
			}
		});
	}
	private Handler  handler = new Handler(){
    	public void handleMessage(android.os.Message msg) {
    		showTime.setText("00:"+time);
    	};
    };
    class MyThread extends Thread{
    	private boolean flag = true;
    	
    	public void setFlag(boolean flag) {
			this.flag = flag;
		}
		@Override
    	public void run() {
    		try {
        		while(time > 0 && flag){
	            	Message msg  = new Message();
	            	handler.sendMessage(msg);
	            	Thread.sleep(1000);
	            	time--;
        		}
        		finish();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
    	}
    }
    @Override
    protected void onDestroy() {
    	// TODO Auto-generated method stub
    	if(thread != null){
    		thread.setFlag(false);
    	}
    	super.onDestroy();
    }
}
