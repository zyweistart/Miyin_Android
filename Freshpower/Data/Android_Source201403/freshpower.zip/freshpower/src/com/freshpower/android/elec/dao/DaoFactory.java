package com.freshpower.android.elec.dao;

import android.content.Context;

import com.freshpower.android.elec.dao.impl.AppStoreDaoImpl;
import com.freshpower.android.elec.dao.impl.LoginPurviewDaoImpl;

public class DaoFactory {
	private static AppStoreDao appStoreDao;
	private static LoginPurviewDao loginPurviewDao;
	
	public static AppStoreDao getAppStoreDao(Context context){
		if(null == appStoreDao){
			appStoreDao = new AppStoreDaoImpl(context);
		}
		return appStoreDao;
	}
	public static LoginPurviewDao getLoginPurviewDao(Context context){
		if(null == loginPurviewDao){
			loginPurviewDao = new LoginPurviewDaoImpl(context);
		}
		return loginPurviewDao;
	}
}
