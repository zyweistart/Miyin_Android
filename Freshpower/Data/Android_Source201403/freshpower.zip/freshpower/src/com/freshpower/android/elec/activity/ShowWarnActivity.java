package com.freshpower.android.elec.activity;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

public class ShowWarnActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		setContentView(R.layout.warn);
		ActivityUtil.addActivity(this);
		ImageView close = (ImageView)findViewById(R.id.warn_closebtn);
		TextView warnText = (TextView)findViewById(R.id.warn_text);
		Intent it = getIntent();
		Bundle bnd = it.getExtras();
		String type = bnd.getString("type");
		if(type.equals("current")){
			if(UserExperienceActivity.textViewNum >= 5){
				if(UserExperienceActivity.textViewNum ==5){
					warnText.setText(R.string.in_line_current_two);
				}else{
					warnText.setText(getResources().getString(R.string.out_line_two)+(UserExperienceActivity.textViewNum-5)+getResources().getString(R.string.over_current));
				}
			}else{
				if(UserExperienceActivity.textViewNum ==1){
					warnText.setText(R.string.in_line_current_one);
				}else{
					warnText.setText(getResources().getString(R.string.out_line_one)+(UserExperienceActivity.textViewNum-1)+getResources().getString(R.string.over_current));
				}
			}
		}else if (type.equals("voltage")){
			if(UserExperienceActivity.textViewNum >= 5){
				if(UserExperienceActivity.textViewNum ==5){
					warnText.setText(R.string.in_line_voltage_two);
				}else{
					warnText.setText(getResources().getString(R.string.out_line_two)+(UserExperienceActivity.textViewNum-5)+getResources().getString(R.string.over_voltage));
				}
			}else{
				if(UserExperienceActivity.textViewNum ==1){
					warnText.setText(R.string.in_line_voltage_one);
				}else{
					warnText.setText(getResources().getString(R.string.out_line_one)+(UserExperienceActivity.textViewNum-1)+getResources().getString(R.string.over_voltage));
				}
			}
		}else if(type.equals("switch")){
			StringBuffer str = new StringBuffer();
			if(!UserExperienceActivity.finalB[0]){
				str.append(getResources().getString(R.string.in_line_one));
			}
			if(!UserExperienceActivity.finalB[1]){
				str.append(getResources().getString(R.string.out_line_one_frist));
			}
			if(!UserExperienceActivity.finalB[2]){
				str.append(getResources().getString(R.string.out_line_one_second));
			}
			if(!UserExperienceActivity.finalB[3]){
				str.append(getResources().getString(R.string.out_line_one_thrid));
			}
			if(!UserExperienceActivity.finalB[4]){
				str.append(getResources().getString(R.string.in_line_two));
			}
			if(!UserExperienceActivity.finalB[5]){
				str.append(getResources().getString(R.string.out_line_two_frist));
			}
			if(!UserExperienceActivity.finalB[6]){
				str.append(getResources().getString(R.string.out_line_two_second));
			}
			if(!UserExperienceActivity.finalB[7]){
				str.append(getResources().getString(R.string.out_line_two_thrid));
			}
			//Log.d("elec",str.toString());
			if(!UserExperienceActivity.finalB[0]||!UserExperienceActivity.finalB[1]||!UserExperienceActivity.finalB[2]||
					!UserExperienceActivity.finalB[3]||!UserExperienceActivity.finalB[4]||!UserExperienceActivity.finalB[5]||
					!UserExperienceActivity.finalB[6]||!UserExperienceActivity.finalB[7])
			warnText.setText(str.toString()+getResources().getString(R.string.switch_operation));
			
		}else if (type.equals("load")){
			warnText.setText(R.string.company_load_over_range);
		}
		close.setOnClickListener(new OnClickListener(){
			public void onClick(View v) {
				finish();
			}
		});
	}
}
