/**   
 * @{#} SysSetGroupOneAdapter.java Create on 2012-11-5 ����11:00:47   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.common;

import java.util.List;
import java.util.Map;
import com.freshpower.android.elec.R;
import com.freshpower.android.elec.domain.LoginInfo;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;



public class SysSetGroupOneAdapter extends BaseAdapter {

	List<Map<String, Object>> mData;
	Context mContext;
	int resource;
	private SharedPreferences trmsSharedPreferences;
	private Editor editor;
	private Intent intent;

	public SysSetGroupOneAdapter(List<Map<String, Object>> data,
			Context context, int resource) {
		this.mData = data;
		this.mContext = context;
		this.resource = resource;
	}

	@Override
	public int getCount() {
		return mData == null ? 0 : mData.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHoder hoder = null;
		if (convertView == null) {
			hoder = new ViewHoder();
			convertView = LayoutInflater.from(mContext).inflate(resource, null);
			hoder.ImageView = (ImageView) convertView
					.findViewById(R.id.sysSetImageName);
			hoder.textView = (TextView) convertView
					.findViewById(R.id.sysSetMenuName);
			hoder.checkBox = (CheckBox) convertView
					.findViewById(R.id.sysSetCkBox);
			convertView.setTag(hoder);
		} else {
			hoder = (ViewHoder) convertView.getTag();
		}

		Map<String, Object> data = mData.get(position);
		int menuIcoId = Integer.parseInt(data.get("menuIcoId").toString());
		hoder.ImageView.setImageResource(menuIcoId);
		hoder.textView.setText(String.valueOf(data.get("menuNames")));
		binkCheckBoxListener(hoder,menuIcoId);
		return convertView;
	}
	
	private void binkCheckBoxListener(ViewHoder hoder,int menuIcoId){
		trmsSharedPreferences = mContext.getSharedPreferences(AppConstant.SHARED_PREFERENCE_NAME, mContext.MODE_PRIVATE);
		editor = trmsSharedPreferences.edit();
		
		if(menuIcoId == R.drawable.tip){
			hoder.checkBox.setChecked(trmsSharedPreferences.getBoolean(AppConstant.SharedPreferencesKey.TIP_SET, false));
			hoder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(
						CompoundButton paramCompoundButton, boolean paramBoolean) {
					modifyTipState(paramBoolean);
				}
			});
		}else if(menuIcoId == R.drawable.vibration){
			hoder.checkBox.setChecked(trmsSharedPreferences.getBoolean(AppConstant.SharedPreferencesKey.VIBRATION_SET, false));
			hoder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(
						CompoundButton paramCompoundButton, boolean paramBoolean) {
					modifyVibrationState(paramBoolean);
				}
			});
		}else if(menuIcoId == R.drawable.gps){
			hoder.checkBox.setChecked(trmsSharedPreferences.getBoolean(AppConstant.SharedPreferencesKey.GPS_SET, false));
			hoder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(
						CompoundButton paramCompoundButton, boolean paramBoolean) {
					if(paramBoolean && !SystemServiceUtil.openGPSSettings(mContext)){
						CheckBox ck = (CheckBox)paramCompoundButton;
						ck.setChecked(false);
						return;
					}
					modifyGpsState(paramBoolean);
				}
			});
		}
	}
	
	private void modifyTipState(boolean paramBoolean){
		String msg = paramBoolean?"֪ͨ��ʾ��":"�ر���ʾ��";
		Toast.makeText(mContext, msg,Toast.LENGTH_SHORT).show();
		editor.putBoolean(AppConstant.SharedPreferencesKey.TIP_SET, paramBoolean);
		editor.commit();
	}
	
	private void modifyVibrationState(boolean paramBoolean){
		String msg = paramBoolean?"֪ͨʱ��":"֪ͨʱ����";
		Toast.makeText(mContext,msg,Toast.LENGTH_SHORT).show();
		editor.putBoolean(AppConstant.SharedPreferencesKey.VIBRATION_SET, paramBoolean);
		editor.commit();
	}
	
	/**
	 * �޸�GPS״̬
	 * @param paramBoolean
	 */
	private void modifyGpsState(boolean paramBoolean){
		String msg = paramBoolean?"��GPS":"�ر�GPS";
		Toast.makeText(mContext,msg,Toast.LENGTH_SHORT).show();
		editor.putBoolean(AppConstant.SharedPreferencesKey.GPS_SET, paramBoolean);
		editor.commit();
		
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		if(null!=loginInfo&&!StringUtil.isEmpty(loginInfo.getLoginName())){
			intent = new Intent();
			intent.setAction(paramBoolean?AppConstant.ReceiverAction.ACTION_GPSSERVICE_START:AppConstant.ReceiverAction.ACTION_GPSSERVICE_STOP);
			mContext.sendBroadcast(intent);
		}
	}
	

	static class ViewHoder {
		ImageView ImageView;
		TextView textView;
		CheckBox checkBox;
	}

}
