package com.freshpower.android.elec.dao.impl;

import android.content.Context;

import com.freshpower.android.elec.common.DBOperater;
import com.freshpower.android.elec.conf.AppConfig;

/**
 * 
 * @author yangz
 *
 */
public class BaseDaoImpl {
	private DBOperater dbOperater;
	protected Context context;
	
	public DBOperater getDBOperater(Context context){
		if(null == this.dbOperater){
			dbOperater = DBOperater.getInstance(context,AppConfig.getDBFilePath());
		}
		return dbOperater;
	}
	
}
