package com.freshpower.android.elec.dao;

import java.util.List;

import com.freshpower.android.elec.common.DBException;
import com.freshpower.android.elec.domain.AppStore;

/**
 * 
 * @author yangz
 *
 */
public interface AppStoreDao {
	
	public void insert(AppStore appStore)throws DBException;
	
	public List<AppStore> getList() throws DBException;
}
