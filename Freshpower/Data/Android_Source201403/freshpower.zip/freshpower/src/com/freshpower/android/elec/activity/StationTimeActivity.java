package com.freshpower.android.elec.activity;


import java.util.Calendar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.DatePicker.OnDateChangedListener;
import android.widget.LinearLayout;
import android.widget.TimePicker;
import android.widget.TimePicker.OnTimeChangedListener;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;

public class StationTimeActivity extends Activity {
	private int year;  
	private int month;  
	private int day;  
	private int hour;  
	private String time;
	private String selIndex;
	private LinearLayout linearLayout;
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.activity_station_time);
		DatePicker datapicker = (DatePicker) findViewById(R.id.datepicker);  
		TimePicker timepicker =(TimePicker) findViewById(R.id.timepicker);
		timepicker.setIs24HourView(true);
		selIndex = getIntent().getStringExtra("selIndex");
		Calendar c =Calendar.getInstance();  
		year =c.get(Calendar.YEAR);  
		month=c.get(Calendar.MONTH);  
		day=c.get(Calendar.DAY_OF_MONTH);  
		hour = c.get(Calendar.HOUR_OF_DAY);  
		showDate(year,month,day,hour);  
		datapicker.init(year, month, day, new OnDateChangedListener() {  
			@Override  
			public void onDateChanged(DatePicker view, int year, int monthOfYear,  
					int dayOfMonth) {  
				StationTimeActivity.this.year=year;  
				StationTimeActivity.this.month=monthOfYear;  
				StationTimeActivity.this.day=dayOfMonth;  
				showDate(year,month,day,hour);  
			}  
		});
		timepicker.setCurrentHour(hour);
		linearLayout = (LinearLayout)timepicker.getChildAt(0);
		linearLayout.getChildAt(1).setVisibility(View.GONE);
		timepicker.setOnTimeChangedListener(new OnTimeChangedListener() {  
			@Override  
			public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {  
				// TODO Auto-generated method stub  
				StationTimeActivity.this.hour=hourOfDay;  
				showDate(year,month,day,hour);  
			}  
		});  
		Button bt = (Button) findViewById(R.id.bt);  
		bt.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				Intent intent=new Intent();
				intent.putExtra("timeValue", time);
				intent.putExtra("selIndex", selIndex);
				setResult(20, intent);
				finish();
			}
		});
		Button not_bt = (Button) findViewById(R.id.not_bt); 
		not_bt.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				StationTimeActivity.this.onBackPressed();
				finish();
			}
		});
		
	}  
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(20==resultCode)  
		{  
			setResult(20, data);  
			finish();
		}  
		super.onActivityResult(requestCode, resultCode, data);
	}
	private void showDate(int year, int month, int day, int hour) {  
		time=year+"-"+(month+1)+"-"+day+" "+hour+":00";
	}  
}
