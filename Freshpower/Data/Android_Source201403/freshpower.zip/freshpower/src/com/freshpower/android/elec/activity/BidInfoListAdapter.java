package com.freshpower.android.elec.activity;

import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.domain.BidInfo;

public class BidInfoListAdapter extends BaseAdapter {

	private List<BidInfo> bidInfoList = null;
	private Context mContext;
	private Button curDel_btn;
	private float x,ux;

	public BidInfoListAdapter(Context mContext,List<BidInfo> bidInfoList) {
		this.mContext = mContext;
		this.bidInfoList = bidInfoList;
	}

	public int getCount() {
		return bidInfoList.size();
	}

	public Object getItem(int position) {
		return null;
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(final int position, View view, ViewGroup arg2) {
		ViewHolder viewHolder = null;
		if (view == null) {
			viewHolder = new ViewHolder();
			view = LayoutInflater.from(mContext).inflate(R.layout.listitem_bidinfolist, null);
			viewHolder.tvTitle = (TextView) view.findViewById(R.id.titleTv);
			viewHolder.tvPubtime =  (TextView) view.findViewById(R.id.pubtimeTv);
			view.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolder) view.getTag();
		}
		
		//����ֵ
		final BidInfo bidInfo = bidInfoList.get(position);
		viewHolder.tvTitle.setText(bidInfo.getTitle());
		viewHolder.tvPubtime.setText(bidInfo.getPubtime());
		view.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(mContext,BidDetailsActivity.class);
				intent.putExtra(AppConstant.ExtraName.EXTRANAME_ID, bidInfo.getId());
				mContext.startActivity(intent);
			}
		});
		return view;

	}

	final static class ViewHolder {
		TextView tvTitle;
		TextView tvPubtime;
	}
}