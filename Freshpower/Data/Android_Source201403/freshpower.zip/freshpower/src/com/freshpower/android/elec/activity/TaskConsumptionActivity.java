package com.freshpower.android.elec.activity;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.conn.HttpHostConnectException;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.camera.CaptureActivity;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.MathUtil;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.common.TaskDetailGroupOneAdapter;
import com.freshpower.android.elec.domain.Task;
import com.freshpower.android.elec.netapi.TaskDataApi;



public class TaskConsumptionActivity extends Activity {
	public DecimalFormat df = new DecimalFormat("0.000"); //��ȡ��С�������λ
	private RoundCornerListView groupOnelistview;
	private Resources res;
	private String etValue="";
	private String modelSubId="";
	private String resultId="";
	private String scoutcheckContent="";
	private int[] codeType;
	private RelativeLayout layout;
	private String eqType;
	private ImageView operationalScanBtn;
	private List<Task> taskList;
	private String qtKey;
	private String recordType;
	private String taskId="";
	private String gnid="";
	private String value="";
	private String qtKey1;
	private double max;
	private double min;
	private double[] currentArr = new double[3];
	private double val;
	private ProgressDialog processProgress;
	private List<Map<String, Object>> taskConsumptionList;
	private RelativeLayout taskoperation_re;
	private Handler handler = new Handler();
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_task_consumption);
		ActivityUtil.addActivity(this);
		res = getResources();
		
		// ��ʾ���ܹ�ɨ�谴ť
		Intent intent = getIntent();
		eqType = intent.getStringExtra("eqType");
		gnid = intent.getStringExtra("gnId");
		taskId = intent.getStringExtra("qtTask");
		qtKey = intent.getStringExtra("qtKey");
		recordType= intent.getStringExtra("recordType");
		if(eqType.equals("2")&&StringUtil.isEmpty(recordType)) {
			layout = (RelativeLayout)findViewById(R.id.operational_scan_btn_layout);
			layout.setVisibility(View.VISIBLE);
			
			// ɨ�����ܹ�
			operationalScanBtn = (ImageView) findViewById(R.id.operational_scan_btn);
			operationalScanBtn.setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					Intent intent = new Intent();
					intent.putExtra("operateType", "operationalScanBtn");
					intent.setClass(TaskConsumptionActivity.this, CaptureActivity.class);
					startActivityForResult(intent,AppConstant.RequestResultCode.REQUEST_OPERATIONALSCAN);
				}
			});
		}else{
			ScrollView scrollView = (ScrollView)findViewById(R.id.scrollview);
			RelativeLayout.LayoutParams rl= (RelativeLayout.LayoutParams)scrollView.getLayoutParams();
			rl.setMargins(rl.leftMargin,0, rl.rightMargin, rl.bottomMargin);
			scrollView.setLayoutParams(rl);
		}
		
		findViews();
		taskoperation_re=(RelativeLayout)findViewById(R.id.task_relayout);
		processProgress = ProgressDialog.show(TaskConsumptionActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(){
			public void run() {
				taskConsumptionList = getGroupOnelistData();
				Message msgMessage = new Message();
				TaskConsumptionActivity.this.xHandler.sendMessage(msgMessage);
			}
		}.start();
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				TaskConsumptionActivity.this.onBackPressed();
			}
		});
		Button task_bt=(Button)findViewById(R.id.task_submit);
		if(!StringUtil.isEmpty(recordType)&&recordType.equals("2")){
			task_bt.setVisibility(View.GONE);
		}
		task_bt.setOnClickListener(new OnClickListener() {
			Map<String,Object> map=null;
			@Override
			public void onClick(View v) {
				
				if(gnid.equals("RW15")){// ���ܹ�������಻ƽ���%
					boolean isCheck = true;
					for (int i = 0; i < 3; i++) {
						View viewOper = (View)groupOnelistview.getChildAt(i);
						LinearLayout taskDemoOneOper  = (LinearLayout)viewOper.findViewById(R.id.task_demo_one);
						LinearLayout taskDemoTwoOper  = (LinearLayout)viewOper.findViewById(R.id.task_demo_two);
						TextView taskTvOper  = (TextView)taskDemoOneOper.findViewById(R.id.task_demo_tv);
						EditText taskEtOper  = (EditText)taskDemoTwoOper.findViewById(R.id.task_demo_et);
						String taskEtValueOper = taskEtOper.getText().toString();
						if(StringUtil.isEmpty(taskEtValueOper) && taskEtOper.getVisibility() == 0){
							showMsg("����д"+taskTvOper.getText()+"!");
							return;
						}
						Log.d("elec", "taskEtOper="+taskEtOper.getText().toString());
						if(taskEtOper.getText().toString().indexOf("-") != -1) {
							isCheck = false;
						} else {
							currentArr[i] = Double.parseDouble(taskEtValueOper);
						}
					}
					if(isCheck) {
						max = MathUtil.max(currentArr);
						min = MathUtil.min(currentArr);
						val = (max - min) / max;
					} else {
						View viewOper = (View)groupOnelistview.getChildAt(3);
						LinearLayout taskDemoTwoOper  = (LinearLayout)viewOper.findViewById(R.id.task_demo_two);
						EditText taskEtOper  = (EditText)taskDemoTwoOper.findViewById(R.id.task_demo_et);
						String taskEtValueOper = taskEtOper.getText().toString();
						val = Double.parseDouble(taskEtValueOper);
					}
				}
				
				etValue = "";
				processProgress = ProgressDialog.show(TaskConsumptionActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
				for (int i = 0; i < groupOnelistview.getChildCount(); i++) {
					View view=(View)groupOnelistview.getChildAt(i);
					LinearLayout taskDemoOne  = (LinearLayout)view.findViewById(R.id.task_demo_one);
					TextView taskTv  = (TextView)taskDemoOne.findViewById(R.id.task_demo_tv);
					LinearLayout taskDemoTwo  = (LinearLayout)view.findViewById(R.id.task_demo_two);
					EditText taskEt  = (EditText)taskDemoTwo.findViewById(R.id.task_demo_et);
					CheckBox taskChb = (CheckBox)taskDemoTwo.findViewById(R.id.task_demo_chb);
					String taskEtValue=taskEt.getText().toString();
					if(StringUtil.isEmpty(taskEtValue)&&taskEt.getVisibility()==0){
						showMsg("����д"+taskTv.getText().toString().substring(0, taskTv.getText().toString().length()-1)+"��");
						return;
					}
					double etValueTemp = 0;
					Log.d("BID", "codeType"+codeType[i]);
					if(taskEt.getVisibility()==0){
						if(codeType[i] != 2 && codeType[i] != 1 && !taskEtValue.equals("-")){
							try{
								etValueTemp = Double.parseDouble(taskEtValue);
							}catch(Exception e){
								showMsg("��淶��д"+taskTv.getText().toString().substring(0, taskTv.getText().toString().length()-1)+"��");
								return;
							}
						}
						if(codeType[i] == 4){
							if(1 < etValueTemp || 0 > etValueTemp){
								showMsg("��淶��д"+taskTv.getText().toString().substring(0, taskTv.getText().toString().length()-1)+"��");
								return;
							}
						}else if(codeType[i] == 5){
							if(100 < etValueTemp || 0 > etValueTemp){
								showMsg("��淶��д"+taskTv.getText().toString().substring(0, taskTv.getText().toString().length()-1)+"��");
								return;
								
							}
						}
					}
					if(gnid.equals("RW16")){//վ����������
//						Log.d("BID", gnid);
						int j=i+1;
						if(j%3==0){
							Double first;
							Double second;
							String[] str=etValue.split(";");
							String kstr=taskTv.getText().toString();
							int h=kstr.indexOf("=");
							int k=kstr.indexOf("��");
							String ks=kstr.substring(h+1, k);
							if(str[j-3].equals("-")){
								first=0.0;
							}else{
								first=Double.valueOf(str[j-3]);
							}
							if(str[j-2].equals("-")){
								second=0.0;
							}else{
								second=Double.valueOf(str[j-2]);
							}
							if(second>first){
								String[] scoutcheck=scoutcheckContent.split(";");
								showMsg(scoutcheck[j-3]+"����С���ϴζ���");
								return;
							}
							Double dob=(first-second)*(Double.valueOf(ks));
							taskEtValue=String.valueOf(new BigDecimal(dob).setScale(4, BigDecimal.ROUND_HALF_UP));
						};
						if(j==groupOnelistview.getChildCount()){
							etValue=etValue+taskEtValue;
						}else{
							etValue=etValue+taskEtValue+";";
						}
					}else if(gnid.equals("RW17")){//�����豸���
//						Log.d("BID", gnid);
						if(taskEt.getVisibility()==0){
							String edit = "";
							if(codeType[i] == 2 || codeType[i] == 1){
								try {
									edit = URLEncoder.encode(taskEtValue,"GBK");
								} catch (UnsupportedEncodingException e) {
									e.printStackTrace();
								}
							}else{
								edit = String.valueOf(etValueTemp);
							}
							if(taskEtValue.equals("-")){
								edit = "-";
							}
							if(i ==groupOnelistview.getChildCount()-1){
								etValue=etValue+edit;
							}else{
								etValue=etValue+edit+";";
							}
						}
						if(taskChb.getVisibility()==0){
							if(taskChb.isChecked()){
								value = "56";
							}else{
								value = "57";
							}
							if(i ==groupOnelistview.getChildCount()-1){
								etValue = etValue+value;
							}else{
								etValue = etValue+value+";";
							}
						}
					} else if(gnid.equals("RW15")){// ���ܹ�
						String taskEtValueOper=taskEt.getText().toString();
						if(i == groupOnelistview.getChildCount()-1) {
							etValue = etValue+taskEtValueOper;
						} else if(i == 4) {
							etValue = etValue+df.format(val)+";";
						} else {
							etValue = etValue+taskEtValueOper+";";
						}
					}
				}
				new Thread(new Runnable() {
					String msgMessage ;
					@Override
					public void run() {
						msgMessage=getResources().getString(R.string.msg_registeryes); 
						try {
							map = TaskDataApi.saveTask(taskId, modelSubId, resultId, etValue);
						}catch (HttpHostConnectException e) {
							msgMessage=getResources().getString(R.string.msg_abnormal_network);
							e.printStackTrace();
						}catch (Exception e) {
							msgMessage=getResources().getString(R.string.msg_abnormal_net2work); 
							e.printStackTrace();
						}finally{
						// TODO Auto-generated method stub
							processProgress.dismiss();
							handler.post(new Runnable() {
								@Override
								public void run() {
									// TODO Auto-generated method stub
									if(!StringUtil.isEmpty(map.get("result").toString())&&map.get("result").toString().equals("1")){
										msgMessage="����ɹ���";
									}else if(!StringUtil.isEmpty(map.get("result").toString())&&map.get("result").toString().equals("0")){
										msgMessage="����ʧ�ܣ�";
									}
									Toast.makeText(TaskConsumptionActivity.this, msgMessage, Toast.LENGTH_SHORT).show();
									if(!StringUtil.isEmpty(map.get("result").toString())&&map.get("result").toString().equals("1")){
										TaskConsumptionActivity.this.onBackPressed();
									}
								}
							});
						}
					}
				}).start();
				
			}
		});


	}
	private Handler xHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			setAdapter();
			processProgress.dismiss();
			taskoperation_re.setVisibility(View.VISIBLE);
		}
	};
	private void setAdapter(){
		TaskDetailGroupOneAdapter sysOneAdapter = new TaskDetailGroupOneAdapter(taskConsumptionList,TaskConsumptionActivity.this,R.layout.listitem_task_style);
		groupOnelistview.setAdapter(sysOneAdapter);
		setListViewHeightBasedOnChildren(groupOnelistview);
	}
	private void findViews(){
		groupOnelistview = (RoundCornerListView)findViewById(R.id.setTaskMenulistviewOne);
	}
	private List<Map<String, Object>> getGroupOnelistData(){
		Intent intent=getIntent();
		taskId=intent.getStringExtra("taskId");
		String equipmentId=intent.getStringExtra("equipmentId");
		gnid=intent.getStringExtra("gnid");
		recordType= intent.getStringExtra("recordType");
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		try {
			Map taskMap=TaskDataApi.getCheckInfoList(gnid,taskId, equipmentId, qtKey1);
			if(taskMap.get("result").equals("1")) {
				List<Task> taskList=(List<Task>) taskMap.get("taskInfoList");
				codeType = new int[taskList.size()];
				int i = 0;
				for(Task task:taskList){
					Map<String, Object> listItem = new HashMap<String, Object>();
					listItem.put(AppConstant.ListItemTask.SCOUTCHECK_CONTENT, task.getScoutcheckContent());//��������
					listItem.put(AppConstant.ListItemTask.SCOUTCHECK, task.getScoutcheck());//��д���
					listItem.put(AppConstant.ListItemTask.CODE_ID, task.getCodeId());//����Ӧ��д����
					listItem.put(AppConstant.ListItemTask.RESULT_ID, task.getResultId());//���ID����������д��32λ����վ�Զ����ɣ�
					listItem.put(AppConstant.ListItemTask.MODEL_SUB_ID, task.getModelSubId());//�豸����ID
					listItem.put(AppConstant.ListItemTask.CODE_TYPE, task.getType());//����������
					listItem.put(AppConstant.ListItemTask.RECORD_TYPE, recordType);
					if(task.getCodeId().equals("32")){
						codeType[i] = Integer.parseInt(task.getType());
					}
					i++;
					if(listItems.size()==taskList.size()-1){
						modelSubId=modelSubId+task.getModelSubId();
						resultId=resultId+task.getResultId();
						scoutcheckContent=scoutcheckContent+task.getScoutcheckContent();
					}else{
						modelSubId=modelSubId+task.getModelSubId()+";";
						resultId=resultId+task.getResultId()+";";
						scoutcheckContent=scoutcheckContent+task.getScoutcheckContent()+";";
					}
					listItems.add(listItem);
				}
			} else {
				if(!StringUtil.isEmpty(qtKey1)) {
					String remark = String.valueOf(taskMap.get("remark"));
					Toast.makeText(TaskConsumptionActivity.this, remark.substring(remark.indexOf(",")+1), Toast.LENGTH_SHORT).show();
					this.finish();
					Intent intentView = new Intent();
					intentView.setClass(TaskConsumptionActivity.this, TaskConsumptionActivity.class);
					intentView.putExtra("taskId", taskId);// ����ID
					intentView.putExtra("equipmentId", equipmentId);// �豸ID
					intentView.putExtra("eqType", eqType);// �豸����
					intentView.putExtra("gnid", gnid);
					intentView.putExtra("recordType", recordType);
					startActivity(intentView);
				}
			}
		} catch(HttpHostConnectException e) {
			Toast.makeText(TaskConsumptionActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show();
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return listItems;
	}
	/***
	 * ��̬����listview�ĸ߶�
	 * 
	 * @param listView
	 */
	public void setListViewHeightBasedOnChildren(ListView listView) {
		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null) {
			return;
		}
		int totalHeight = 0;
		for (int i = 0; i < listAdapter.getCount(); i++) {
			View listItem = listAdapter.getView(i, null, listView);
			//View listItem = inflater.inflate(android.R.layout.simple_expandable_list_item_1, null);
			listItem.measure(0, 0);
			totalHeight += listItem.getMeasuredHeight();
		}
		ViewGroup.LayoutParams params = listView.getLayoutParams();
		params.height = totalHeight
				+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
		listView.setLayoutParams(params);
	}
	
	/**
	 * ɨ�践��ֵ
	 */
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		Log.d("BID", "resultCode==="+resultCode);
		// ɨ�����ܹ�
		if(AppConstant.RequestResultCode.RESULT_OPERATIONALSCAN == resultCode) {
			if(!StringUtil.isEmpty(data.getStringExtra("twoDimCode")) && data.getStringExtra("twoDimCode").replaceAll(" ", "").length() == 15) {
				qtKey1 = data.getStringExtra("twoDimCode");
			} else {
				Toast.makeText(TaskConsumptionActivity.this, "��ɨ����ȷ�����ܿ��ر�ţ�", Toast.LENGTH_SHORT).show();
			}
			
			modelSubId = "";
			resultId = "";
			taskConsumptionList = getGroupOnelistData();
			setAdapter();
		}else if(AppConstant.RequestResultCode.RESULT_TASKTIME == resultCode){
			int  selIndex  = data.getIntExtra("selIndex",0);
			LinearLayout taskDemoTwo = (LinearLayout) groupOnelistview.getChildAt(selIndex);
			EditText taskEt15  = (EditText)taskDemoTwo.findViewById(R.id.task_demo_et);
			taskEt15.setText(data.getStringExtra("timeValue"));
		}
	}
	/**
	 * ��ʾ��ʾ��Ϣ
	 * @param msg��ʾ��Ϣ����
	 */
	private void showMsg(String msg){
		Toast.makeText(TaskConsumptionActivity.this, msg, Toast.LENGTH_SHORT).show();
		processProgress.dismiss();
		return;
	}
	
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		if(taskConsumptionList!=null){
			taskConsumptionList.clear();
		}
		if(groupOnelistview!=null){
			groupOnelistview.destroyDrawingCache();
		}
		super.onDestroy();
	}
}
