package com.freshpower.android.elec.activity;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.InputType;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.DateUtil;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.domain.CheckTask;
import com.freshpower.android.elec.netapi.CheckTaskApi;

public class CheckMakeEditActivity extends Activity {
	private Spinner workerOperationSpinner;
	private Spinner modelOperationSpinner;
	private List<CheckTask> checkTaskUserList;
	private List<CheckTask> checkTaskModelList;
	private String cpId;// ��ҵID
	private String contractId;// ��ͬID
	private String siteId;// վ��ID
	
	private EditText taskDateText;
	private EditText completeDateText;
	private EditText currentEt;
	private Calendar currentDate;
	private int mYear;
	private int mMonth;
	private int mDay;
	private int mHour;
	private int mMinute;
	private static final int DATE_DIALOG_ID = 0;
	private static final int TIME_DIALOG_ID = 1;
	private CheckTask checkTaskSub = new CheckTask();
	private ProgressDialog processProgress;
	private LinearLayout taskoperation_re;
	private String msgMessage = null;
	private List<String> userNamelist;
	private List<String> modellist;
	private Handler spinnerHandler = new Handler();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.activity_check_make_edit);
		workerOperationSpinner = (Spinner)findViewById(R.id.workerOperationSpinner);
		modelOperationSpinner = (Spinner)findViewById(R.id.modelOperationSpinner);
		Intent intent = getIntent();
		cpId = intent.getStringExtra("cpId");
		contractId = intent.getStringExtra("contractId");
		siteId = intent.getStringExtra("siteId");
		processProgress = ProgressDialog.show(CheckMakeEditActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(new Runnable() {
			public void run() {
				try {
					setUserSpinner();
					setModelSpinner();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally{
					processProgress.dismiss();
					spinnerHandler.post(new Runnable() {
						@Override
						public void run() {
							ArrayAdapter userAdapter = new ArrayAdapter(CheckMakeEditActivity.this, android.R.layout.simple_spinner_item, userNamelist);
							//���������б��ķ��  
							userAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); 
							workerOperationSpinner.setAdapter(userAdapter);
							workerOperationSpinner.setPrompt("ѡ������Ա");
							workerOperationSpinner.setOnItemSelectedListener(new UserSpinnerOnSelectedListener());  
							
							
							ArrayAdapter modelAdapter = new ArrayAdapter(CheckMakeEditActivity.this, android.R.layout.simple_spinner_item, modellist);
							//���������б��ķ��  
							modelAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); 
							modelOperationSpinner.setAdapter(modelAdapter);
							modelOperationSpinner.setPrompt("ѡ��ϵͳģ��");
							modelOperationSpinner.setOnItemSelectedListener(new ModelSpinnerOnSelectedListener());  
						}
					});
				}
			}
		}).start();

		
		taskDateText = (EditText) findViewById(R.id.taskDateText);
		completeDateText = (EditText) findViewById(R.id.completeDateText);
		taskDateText.setInputType(InputType.TYPE_NULL);
		taskDateText.setOnClickListener(new dateListener());
		completeDateText.setInputType(InputType.TYPE_NULL);
		completeDateText.setOnClickListener(new dateListener());
		taskoperation_re = (LinearLayout) findViewById(R.id.taskoperation_re);
		
		Button btn = (Button)findViewById(R.id.checkMakeEditSub);
		btn.setVisibility(View.VISIBLE);
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				taskDateText = (EditText) findViewById(R.id.taskDateText);
				completeDateText = (EditText) findViewById(R.id.completeDateText);
				checkTaskSub.setCpId(cpId);
				checkTaskSub.setContractId(contractId);
				checkTaskSub.setSiteId(siteId);
				if(StringUtil.isEmpty(taskDateText.getText().toString())) {
					Toast.makeText(CheckMakeEditActivity.this, "����������ʱ�䣡", Toast.LENGTH_SHORT).show();
					return;
				}
				if(StringUtil.isEmpty(completeDateText.getText().toString())) {
					Toast.makeText(CheckMakeEditActivity.this, "������Ҫ�����ʱ�䣡", Toast.LENGTH_SHORT).show();
					return;
				}
				try {
					if(DateUtil.dateFormat(taskDateText.getText().toString(), "yyyy-MM-dd").compareTo(DateUtil.dateFormat(completeDateText.getText().toString(), "yyyy-MM-dd")) >= 0) {
						Toast.makeText(CheckMakeEditActivity.this, "����ʱ�����С��Ҫ�����ʱ�䣡", Toast.LENGTH_SHORT).show();
						return;
					}
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				checkTaskSub.setTaskDate(taskDateText.getText().toString());
				checkTaskSub.setCompleteDate(completeDateText.getText().toString());
				
				processProgress = ProgressDialog.show(CheckMakeEditActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
				new Thread(){
					public void run() {
						try {
							Map<String,Object> map = null;
							map = CheckTaskApi.checkMakeSubmit(checkTaskSub);
							if(!StringUtil.isEmpty(map.get("result").toString())&&map.get("result").toString().equals("1")){
								msgMessage = "����ɹ���";
							}else if(!StringUtil.isEmpty(map.get("result").toString())&&map.get("result").toString().equals("0")){
								msgMessage = "����ʧ�ܣ�";
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						Message msgMessage = new Message();
						CheckMakeEditActivity.this.xHandler.sendMessage(msgMessage);
					}
				}.start();
				
			}
		});
		
		// �����¼�
		ImageView returnButton = (ImageView) findViewById(R.id.nav_left);
		returnButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				CheckMakeEditActivity.this.onBackPressed();
			}
		});
	}  

	/**
	 * ���ù�����Ա������
	 */
	private void setUserSpinner() {
		Map checkTaskMap = null;
		try {
			checkTaskMap = CheckTaskApi.getCheckMakeUserList(cpId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		checkTaskUserList = (List<CheckTask>) checkTaskMap.get("checkTaskList");
		userNamelist = new ArrayList<String>();  
		for(CheckTask checkTask : checkTaskUserList) {
			userNamelist.add(checkTask.getUserName());
		}
	}
	
	class UserSpinnerOnSelectedListener implements OnItemSelectedListener {  
		@Override  
		public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {  
				checkTaskSub.setUserId(checkTaskUserList.get((int)id).getUserId());
			}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
			
		} 
	}
	
	/**
	 * ����ϵͳģ��������
	 */
	private void setModelSpinner() {
		Map checkTaskMap = null;
		try {
			checkTaskMap = CheckTaskApi.getCheckMakeModelList();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		checkTaskModelList = (List<CheckTask>) checkTaskMap.get("checkTaskList");
		modellist = new ArrayList<String>();  
		for(CheckTask checkTask : checkTaskModelList) {
			modellist.add(checkTask.getModleName());
		}
	}
	
	class ModelSpinnerOnSelectedListener implements OnItemSelectedListener {  
		@Override  
		public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {  
				checkTaskSub.setModleId(checkTaskModelList.get((int)id).getModleId());
			}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
			
		} 
	}
	
	class dateListener implements View.OnClickListener {
		@Override
		public void onClick(View v) {
			currentEt = (EditText) v;
			// ��õ�ǰ�����ڣ�
			currentDate = Calendar.getInstance();
			mYear = currentDate.get(Calendar.YEAR);
			mMonth = currentDate.get(Calendar.MONTH);
			mDay = currentDate.get(Calendar.DAY_OF_MONTH);
			showDialog(DATE_DIALOG_ID);
		}
	}

	// ��Ҫ���嵯����DatePicker�Ի�����¼���������
	private DatePickerDialog.OnDateSetListener mDateSetListener = new DatePickerDialog.OnDateSetListener() {
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			mYear = year;
			mMonth = monthOfYear;
			mDay = dayOfMonth;
			// �����ı������ݣ�
			currentEt.setText(new StringBuilder().append(mYear).append("-")
					.append(mMonth + 1).append("-")// �õ����·�+1����Ϊ��0��ʼ
					.append(mDay));
		}
	};

	// ��Ҫ���嵯����TimePicker�Ի�����¼���������
	private TimePickerDialog.OnTimeSetListener mTimeSetListener = new TimePickerDialog.OnTimeSetListener() {

		@Override
		public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
			mHour = hourOfDay;
			mMinute = minute;
			currentEt.setText(new StringBuilder().append(pad(mHour))
					.append(":").append(pad(mMinute)));
		}
	};

	private static String pad(int c) {
		if (c >= 10)
			return String.valueOf(c);
		else
			return "0" + String.valueOf(c);
	}

	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DATE_DIALOG_ID:
			return new DatePickerDialog(this, mDateSetListener, mYear, mMonth,
					mDay);
		case TIME_DIALOG_ID:
			return new TimePickerDialog(this, mTimeSetListener, mHour, mMinute,
					false);
		}
		return null;
	}
	
	private Handler xHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			processProgress.dismiss();
			taskoperation_re.setVisibility(View.VISIBLE);
			Toast.makeText(CheckMakeEditActivity.this, msgMessage, Toast.LENGTH_SHORT).show();
			CheckMakeEditActivity.this.onBackPressed();
		}
	};
}
