package com.freshpower.android.elec.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.androidpn.client.Constants;
import org.apache.http.conn.HttpHostConnectException;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View.OnClickListener;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.common.WarnSetGroupOneAdapter;
import com.freshpower.android.elec.domain.CustomerInfo;
import com.freshpower.android.elec.netapi.StationInfoDataApi;
import com.freshpower.android.elec.widget.PullDownListView;

public class WarnActivity extends FrameActivity implements PullDownListView.OnRefreshListioner{
	private RoundCornerListView groupOnelistview;
	private Resources res;
	private ImageButton homeBtn;
	private List<CustomerInfo> warnDetailList;
	private PullDownListView mPullDownView;
	private ListView mListView;
	private WarnSetGroupOneAdapter adapter; 
	private Handler mHandler = new Handler();
	private int maxAount = 20;//�������������ֵ
	private int pageSize = 10;//ÿҳ��ʾ
	private int currentPage =1;//��ǰҳ
	private int totalCnt=0;//�ܼ�¼��
	private int rs=999;//��ѯ���
	private ImageView imgV;
	private RelativeLayout progressRlt = null;
	List<Map<String, Object>> customerInfoMap;
	private ProgressDialog processProgress;
	private Handler handler = new Handler();
	private String warnName;
	private String warnLevel;
	private String warnSort;
	private String catchNot="yes";
	private String result;
	private CheckBox selectAll;

	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_warn);
		res = getResources();
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				WarnActivity.this.onBackPressed();
			}
		});
		Button btn=(Button)findViewById(R.id.warn_select);
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(WarnActivity.this,WarnSearchActivity.class);
				startActivity(intent);
			}
		});

		warnName=getIntent().getStringExtra("warnSearchName");
		warnLevel=getIntent().getStringExtra("warnSearchLevel");
		warnSort=getIntent().getStringExtra("warnSearchSort");

		mPullDownView = (PullDownListView) findViewById(R.id.sreach_list);
		mPullDownView.setRefreshListioner(this);
		mListView = mPullDownView.mListView;
		processProgress = ProgressDialog.show(WarnActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(){
			public void run() {
				customerInfoMap = getGroupOnelistData();
				Message msgMessage = new Message();
				WarnActivity.this.xHandler.sendMessage(msgMessage);
			}
		}.start();
		
		
		String alertMsg = getIntent().getStringExtra(Constants.NOTIFICATION_MESSAGE);
		if(!StringUtil.isEmpty(alertMsg)){
			Toast.makeText(WarnActivity.this, alertMsg, Toast.LENGTH_SHORT).show();
		}
		
		selectAll = (CheckBox)findViewById(R.id.selectAll);
		selectAll.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if(isChecked){
					for(Map<String, Object> customerInfo : customerInfoMap){
						customerInfo.put("checked","true");
					}
				}else{
					for(Map<String, Object> customerInfo : customerInfoMap){
						customerInfo.put("checked","false");
					}
				}
				adapter.notifyDataSetChanged();	
			}
		});
		
		
		Button warnHandleAll =  (Button)findViewById(R.id.warnHandleAll);
		warnHandleAll.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				StringBuffer handleId = new StringBuffer();
				for(Map<String,Object> customerInfo:customerInfoMap){
					if(customerInfo.get("checked").equals("true")){
						handleId.append(customerInfo.get("id")+",");
					}
				}
				if(StringUtil.isEmpty(handleId.toString())){
					Toast.makeText(WarnActivity.this, "��ѡ���ύѡ�", Toast.LENGTH_SHORT).show();
				}else{
					Intent intent = new Intent(WarnActivity.this, WarnHandleActivity.class);
					intent.putExtra("alertId", handleId.toString());
					startActivity(intent);
				}
			}
		});
	}

	private Handler xHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {

			if(customerInfoMap!=null){
				adapter = new WarnSetGroupOneAdapter(customerInfoMap,WarnActivity.this,R.layout.listitem_warn_style,warnDetailList);	
				mListView.setAdapter(adapter);
			}else{
				rs=AppConstant.Result.NO_COUNT;
			}
			if(!StringUtil.isEmpty(result)&&result.equals("0")){
				Toast.makeText(WarnActivity.this, R.string.noSearchResultMsg, Toast.LENGTH_SHORT).show();
			}
			if(catchNot.equals("not")&&!StringUtil.isEmpty(result)&&!result.equals("0")){
				Toast.makeText(WarnActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show();
			}
			if(catchNot.equals("not2")&&!StringUtil.isEmpty(result)&&!result.equals("0")){
				Toast.makeText(WarnActivity.this, R.string.msg_abnormal_net2work, Toast.LENGTH_SHORT).show();
			}

			setShow();
			//		progressRlt.setVisibility(View.GONE);
			mPullDownView.setVisibility(View.VISIBLE);
			processProgress.dismiss();
		};
	};

	private void setShow() {
		if(rs==AppConstant.Result.NO_COUNT){
			RelativeLayout noResultlayout = (RelativeLayout) findViewById(R.id.noResultlayout);
			noResultlayout.setVisibility(View.VISIBLE);
			mPullDownView.setMore(false);
		}else{
			mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
		}
		if(totalCnt<=pageSize){
			mPullDownView.setMore(false);
		}
	}
	private List<Map<String, Object>> getGroupOnelistData(){
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		try {
			Map warnMap = StationInfoDataApi.getWarnInfoList(pageSize,currentPage,warnName,warnLevel,warnSort);
			result = String.valueOf(warnMap.get("result"));
			totalCnt = Integer.parseInt(String.valueOf(warnMap.get("totalCount")));
			warnDetailList=(List<CustomerInfo>) warnMap.get("warnInfoList");
			for (CustomerInfo customerInfo:warnDetailList)
			{
				Map<String, Object> listItem = new HashMap<String, Object>();
				listItem.put("textView1",customerInfo.getSiteName());
				listItem.put("textView2", customerInfo.getAlertDate());
				listItem.put("textView3",customerInfo.getMeterName()==null?"":customerInfo.getMeterName());
				listItem.put("textView4", customerInfo.getContent());
				listItem.put("textView5", customerInfo.getCataLog());
				listItem.put("checked", "false");
				listItem.put("id", customerInfo.getAlertId());
				listItems.add(listItem);
			}
		}catch (HttpHostConnectException e) {
			catchNot="not";
			e.printStackTrace();
		}catch (Exception e) {
			catchNot="not2";
			e.printStackTrace();
		}
		return listItems;
	}
	/**
	 * ˢ�£������list������Ȼ�����¼��ظ�������
	 */
	public void onRefresh() {

		mHandler.postDelayed(new Runnable() {

			public void run() {
				customerInfoMap.clear();
				currentPage =1;
				customerInfoMap.addAll(getGroupOnelistData());

				mPullDownView.onRefreshComplete();//�����ʾˢ�´�����ɺ������ļ���ˢ�½�������
				mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				if(totalCnt<=pageSize){
					mPullDownView.setMore(false);
				}
				adapter.notifyDataSetChanged();	
				selectAll.setChecked(false);
			}
		}, 1500);


	}

	/**
	 * ���ظ��࣬��ԭ��������������������
	 */
	public void onLoadMore() {

		mHandler.postDelayed(new Runnable() {
			public void run() {
				//addLists(5);//ÿ�μ�������������

				currentPage++;
				customerInfoMap.addAll(getGroupOnelistData());

				mPullDownView.onLoadMoreComplete();//�����ʾ���ظ��ദ����ɺ������ļ��ظ�����棨���ػ��������������ࣩ
				//if(list.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
				if(customerInfoMap.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
					mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				else
					mPullDownView.setMore(false);
				adapter.notifyDataSetChanged();	

			}
		}, 1500);
	}
	/***
	 * ��̬����listview�ĸ߶�
	 * 
	 * @param listView
	 */
	public void setListViewHeightBasedOnChildren(ListView listView) {
		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null) {
			return;
		}
		int totalHeight = 0;
		for (int i = 0; i < listAdapter.getCount(); i++) {
			View listItem = listAdapter.getView(i, null, listView);
			listItem.measure(0, 0);
			totalHeight += listItem.getMeasuredHeight();
		}
		ViewGroup.LayoutParams params = listView.getLayoutParams();
		params.height = totalHeight
				+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
		listView.setLayoutParams(params);
	}
	
	protected void onResume() {
		homeBtn = (ImageButton) findViewById(R.id.stationWarnBtn);
		if(homeBtn!=null){
			homeBtn.setOnClickListener(null);
			homeBtn.setBackgroundResource(R.drawable.warnbtn_select);
		}

		TextView toolBtnTv = (TextView)findViewById(R.id.stationWarnTv);
		toolBtnTv.setTextColor(getResources().getColor(R.color.orange));

		super.onResume();
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		if(customerInfoMap!=null){
			customerInfoMap.clear();
		}
		super.onDestroy();
	}
}
