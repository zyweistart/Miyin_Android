package com.freshpower.android.elec.activity;


import java.util.Calendar;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.StringUtil;

public class StationDetailInfoActivity extends FrameActivity {
	private ImageButton homeBtn;
	private String meterId;
	private String cpId;
	private EditText currentEt;
	private Calendar currentDate;
	private int mYear;
	private int mMonth;
	private int mDay;
	private int mHour;
	private int mMinute;
	static final int DATE_DIALOG_ID = 0;
	static final int TIME_DIALOG_ID = 1;
	private EditText startDateEt;
	private EditText endDateEt;
	private Button quantumSpTv;
	private Dialog noticeDialog;



	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_stationdetail);
		Intent it=getIntent();
		TextView textView1=(TextView)findViewById(R.id.stationDeatil_1);
		String meterName =it.getStringExtra("MeterName");
		textView1.setText(meterName);
		TextView textView2=(TextView)findViewById(R.id.stationDeatil_2);
		String reportDate =it.getStringExtra("ReportDate");
		textView2.setText(reportDate);
		TextView textView3=(TextView)findViewById(R.id.stationDeatil_3);
		String switchStatus =it.getStringExtra("SwitchStatus");
		textView3.setText(switchStatus);
		if(switchStatus.equals("��")){
			textView3.setTextColor(android.graphics.Color.RED);
		}else{
			textView3.setTextColor(android.graphics.Color.GREEN);
		}
		TextView textView4=(TextView)findViewById(R.id.stationDeatil_4);
		String dayPower =it.getStringExtra("DayPower");
		textView4.setText(dayPower.length()!=0?dayPower+"kWh":"");
		TextView textView5=(TextView)findViewById(R.id.stationDeatil_5);
		String va =it.getStringExtra("Va");
		textView5.setText(va.length()!=0?va+"V":"");
		TextView textView6=(TextView)findViewById(R.id.stationDeatil_6);
		String vb =it.getStringExtra("Vb");
		textView6.setText(vb.length()!=0?vb+"V":"");
		TextView textView7=(TextView)findViewById(R.id.stationDeatil_7);
		String vc =it.getStringExtra("Vc");
		textView7.setText(vc.length()!=0?vc+"V":"");
		TextView textView8=(TextView)findViewById(R.id.stationDeatil_8);
		String ia =it.getStringExtra("Ia");
		textView8.setText(ia.length()!=0?ia+"A":"");
		TextView textView9=(TextView)findViewById(R.id.stationDeatil_9);
		String ib =it.getStringExtra("Ib");
		textView9.setText(ib.length()!=0?ib+"A":"");
		TextView textView10=(TextView)findViewById(R.id.stationDeatil_10);
		String ic =it.getStringExtra("Ic");
		textView10.setText(ic.length()!=0?ic+"A":"");
		TextView textView11=(TextView)findViewById(R.id.stationDeatil_11);
		String totalPower =it.getStringExtra("Power");
		textView11.setText(totalPower.length()!=0?totalPower+"kW":"");
		TextView textView12=(TextView)findViewById(R.id.stationDeatil_12);
		String factor =it.getStringExtra("factor");
		textView12.setText(factor);
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				StationDetailInfoActivity.this.onBackPressed();
				finish();	
			}
		});
		meterId=it.getStringExtra("MeterId");
		cpId=it.getStringExtra("CpId");
		Button historyData=(Button)findViewById(R.id.historyData_bt);
		historyData.setOnClickListener(new mapSearchDialogIbClickListener());
		Button historyConsumption=(Button)findViewById(R.id.historyConsumption_bt);
		historyConsumption.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						Intent intent = new Intent(StationDetailInfoActivity.this,StationHistoryConsumptionActivity.class);
						intent.putExtra("MeterId", meterId);
						intent.putExtra("CpId", cpId);
						startActivity(intent);
					}
				});

	}
	private class mapSearchDialogIbClickListener implements
	View.OnClickListener {
		@Override
		public void onClick(View v) {
			LayoutInflater factory = LayoutInflater
					.from(StationDetailInfoActivity.this);
			final View DialogView = factory.inflate(R.layout.dialog_stationhistorydata_search,
					null);
			startDateEt = (EditText) DialogView.findViewById(R.id.startDateS);
			endDateEt = (EditText) DialogView.findViewById(R.id.endDateS);
			quantumSpTv = (Button)DialogView.findViewById(R.id.QuantumSpTxt);
			quantumSpTv.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							Intent intent = new Intent(StationDetailInfoActivity.this,StationHistoryDataActivity.class);
							intent.putExtra("MeterId", meterId);
							intent.putExtra("CpId", cpId);
							intent.putExtra("startDate", startDateEt.getText().toString());
							intent.putExtra("endDate", endDateEt.getText().toString());
							startActivity(intent);
						}
					});
			startDateEt.setInputType(InputType.TYPE_NULL);
			startDateEt.setOnClickListener(new startDateListener());
			endDateEt.setInputType(InputType.TYPE_NULL);
			endDateEt.setOnClickListener(new endDateListener());
			// ����Ի���
			AlertDialog alertDialog = new AlertDialog.Builder(StationDetailInfoActivity.this).create();
			alertDialog.setView(DialogView,0,0,0,0);
			noticeDialog = alertDialog;
			noticeDialog.show();
			
			ImageView closebtn = (ImageView)DialogView.findViewById(R.id.set_close);
			closebtn.setOnClickListener(new OnClickListener(){
				public void onClick(View arg0) {
					noticeDialog.cancel();
				}
			});
		}
	}
	protected void onResume() {
		homeBtn = (ImageButton) findViewById(R.id.stationDataBtn);
		if(homeBtn!=null){
			homeBtn.setOnClickListener(null);
			homeBtn.setBackgroundResource(R.drawable.databtn_select);
		}

		TextView toolBtnTv = (TextView)findViewById(R.id.stationDataTv);
		toolBtnTv.setTextColor(getResources().getColor(R.color.orange));

		super.onResume();
	}
	
	class startDateListener implements View.OnClickListener {
		@Override
		public void onClick(View v) {
			Intent intent = new Intent(StationDetailInfoActivity.this, StationTimeActivity.class);
			intent.putExtra("selIndex", "startDate");
			startActivityForResult(intent,100);
		}
	}
	
	class endDateListener implements View.OnClickListener {
		@Override
		public void onClick(View v) {
			Intent intent = new Intent(StationDetailInfoActivity.this, StationTimeActivity.class);
			intent.putExtra("selIndex", "endDate");
			startActivityForResult(intent,100);
		}
	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(AppConstant.RequestResultCode.RESULT_TASKTIME == resultCode){
			String selIndex = data.getStringExtra("selIndex");
			if(!StringUtil.isEmpty(selIndex) && selIndex.equals("startDate")) {
				startDateEt.setText(data.getStringExtra("timeValue"));
			} else if(!StringUtil.isEmpty(selIndex) && selIndex.equals("endDate")) {
				endDateEt.setText(data.getStringExtra("timeValue"));
			}
		}
	}

}
