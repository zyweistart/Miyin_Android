package com.freshpower.android.elec.conf;

/**
 * 
 */

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;

import com.freshpower.android.elec.common.AppCache;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.DBException;
import com.freshpower.android.elec.common.FileUtil;
import com.freshpower.android.elec.dao.AppStoreDao;
import com.freshpower.android.elec.dao.DaoFactory;
import com.freshpower.android.elec.domain.AppStoreInfo;
import com.freshpower.android.elec.domain.AppStore;
/**
 * 
 * @author yangz
 *
 */
public class AppConfig {
	private String etgWebsite;
	private String fpsWebSite;
	private String crmWebSite;
	private String appVersion;
	private AppStoreDao appStoreDao;
	private AppConfig(){
	}
	private static AppConfig appConfig;
	private static Map stores;
	
	//public static final String PHONE_NO_KEY = "PHONE_NO";
	//public static final String MEMBER_ID = "MEMBER_ID";
	public static final String PHONE_AUTHENTICATION = "PHONE_AUTHENTICATION";
	public static synchronized AppConfig getInstance(){
		if(appConfig == null){
			appConfig = new AppConfig();
		}
		return appConfig;
	}
	
	public void initStore(Context context){
		this.appStoreDao = DaoFactory.getAppStoreDao(context);
		stores = new HashMap();
		try {
			List<AppStore> list = appStoreDao.getList();
			if(null!=list){
				for(AppStore app : list){
					stores.put(app.getKey(), app.getValue());
				}
			}
		} catch (DBException e) {
			e.printStackTrace();
		}
	}
	
	public String getStoreValue(String key){
		return (String)stores.get(key);
	}
	
	public void setStore(String key,String value){
		AppStoreInfo appStore = new AppStoreInfo(key,value);
		/*
		try {
			if(appStoreDao.getObject(key)==null){
				appStoreDao.insert(appStore);
			}else{
				appStoreDao.update(appStore);
			}
		} catch (DBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		stores.put(key, value);
	}
	public String getAppVersion() {
		return appVersion;
	}
	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}
	public String getEtgWebsite() {
		return etgWebsite;
	}
	public void setEtgWebsite(String etgWebsite) {
		this.etgWebsite = etgWebsite;
	}
	public String getFpsWebSite() {
		return fpsWebSite;
	}
	public void setFpsWebSite(String fpsWebSite) {
		this.fpsWebSite = fpsWebSite;
	}
	public String getWebSite() {
		/*
		Integer auth_info = (Integer)AppCache.get(AppCache.LOGIN_AUTH_INFO);
		if(auth_info == AppConstant.AuthenticationInfo.ENTERPRISE)
			return getFpsWebSite();
		else if(auth_info == AppConstant.AuthenticationInfo.MANAGER)
			return getEtgWebsite();
		else 
			return null;
		*/
		return "";
	}

	public String getCrmWebSite() {
		return crmWebSite;
	}

	public void setCrmWebSite(String crmWebSite) {
		this.crmWebSite = crmWebSite;
	}
	
	public static String getDBFilePath(){
		return FileUtil.getSDPATH()+File.separator + "elec" + File.separator+"cache3_0.dat";
	}
	
}
