package com.freshpower.android.elec.common;

import java.util.List;
import java.util.Map;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.activity.InspectionRecordActivity;
import com.freshpower.android.elec.activity.StationDetailInfoActivity;



public class StationDetailAdapter extends BaseAdapter {

	List<Map<String, Object>> mData;
	Context mContext;
	int resource;
	public StationDetailAdapter(List<Map<String, Object>> data,
			Context context, int resource) {
		this.mData = data;
		this.mContext = context;
		this.resource = resource;
	}

	@Override
	public int getCount() {
		return mData == null ? 0 : mData.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	static class ViewHoder {
		TableLayout lineMsg;
		TextView warnOne;
		TextView warnTwo;
		TextView warnThree;
		TextView warnFour;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHoder hoder = null;
		if (convertView == null) {
			hoder = new ViewHoder();
			convertView = LayoutInflater.from(mContext).inflate(resource, null);
			hoder.warnOne = (TextView) convertView
					.findViewById(R.id.stationdetailOne);
			hoder.warnTwo = (TextView) convertView
					.findViewById(R.id.stationdetailTwo);
			hoder.warnThree = (TextView) convertView
					.findViewById(R.id.stationdetailThree);
			hoder.warnFour = (TextView) convertView
					.findViewById(R.id.stationdetailFour);
			hoder.lineMsg = (TableLayout)convertView
					.findViewById(R.id.line_msg);
			convertView.setTag(hoder);
		} else {
			hoder = (ViewHoder) convertView.getTag();
		}
		Map<String, Object> data = mData.get(position);
		hoder.warnOne.setText(String.valueOf(data.get(AppConstant.ListItemWarnName.WARN_ONE)));
		hoder.warnTwo.setText(String.valueOf(data.get(AppConstant.ListItemWarnName.WARN_TWO)));
		if(String.valueOf(data.get(AppConstant.ListItemWarnName.WARN_TWO)).indexOf("��")!=-1){
			hoder.warnTwo.setTextColor(Color.parseColor("#009900"));
		}else{
			hoder.warnTwo.setTextColor(Color.parseColor("#FF0000"));
		}
		Log.d("BID", "Status2:"+String.valueOf(data.get(AppConstant.ListItemWarnName.WARN_TWO)));
		hoder.warnThree.setText(String.valueOf(data.get(AppConstant.ListItemWarnName.WARN_THREE)));
		hoder.warnFour.setText(String.valueOf(data.get(AppConstant.ListItemWarnName.WARN_FOUR)));
		TableLayoutListener tableLayoutListener = new TableLayoutListener();
		tableLayoutListener.setData(data);
		hoder.lineMsg.setOnClickListener(tableLayoutListener);
//		hoder.checkRecordTable.setOnClickListener(recordCheckTaskListener);
		return convertView;
	}
	
	
	 class TableLayoutListener implements View.OnClickListener{
		 
		 Map<String, Object> data;
		

		public void setData(Map<String, Object> data) {
			this.data = data;
		}


		@Override
		public void onClick(View v) {
			Intent it = new Intent(mContext, StationDetailInfoActivity.class);
			it.putExtra("MeterName", String.valueOf(data.get("warnOne")));
			it.putExtra("ReportDate", String.valueOf(data.get("warnThree")));
			it.putExtra("SwitchStatus", String.valueOf(data.get("warnTwo")));
			it.putExtra("DayPower", String.valueOf(data.get("warnFour")));
			it.putExtra("Va",  String.valueOf(data.get("Va")));
			it.putExtra("Vb",  String.valueOf(data.get("Vb")));
			it.putExtra("Vc",  String.valueOf(data.get("Vc")));
			it.putExtra("Ia",  String.valueOf(data.get("Ia")));
			it.putExtra("Ib",  String.valueOf(data.get("Ib")));
			it.putExtra("Ic",  String.valueOf(data.get("Ic")));
			it.putExtra("Power",  String.valueOf(data.get("Power")));
			it.putExtra("MeterId",  String.valueOf(data.get("MeterId")));
			it.putExtra("factor",  String.valueOf(data.get("factor")));
			it.putExtra("CpId",  String.valueOf(data.get("CpId")));
			mContext.startActivity(it);
		}
	}

}
