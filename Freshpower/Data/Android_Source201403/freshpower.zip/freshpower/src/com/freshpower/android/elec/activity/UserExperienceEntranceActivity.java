package com.freshpower.android.elec.activity;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class UserExperienceEntranceActivity extends Activity {
	TextView entranceFirstTitel_tv;
	TextView entranceFirstInfo_tv;
	TextView entranceSecondTitel_tv;
	TextView entranceSecondInfo_tv;
	ImageView entranceSecondone_iv;
	ImageView entranceSecondtwo_iv;
	ImageView userExperienceTitel_iv;
	LinearLayout userExperienceFirst_iv;
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_experience_entrance);
		ActivityUtil.addActivity(this);
		entranceFirstTitel_tv=(TextView)findViewById(R.id.userExperienceTitel);
		entranceFirstTitel_tv.setText(R.string.entranceFirstTitel_tv);
		entranceFirstInfo_tv=(TextView)findViewById(R.id.userExperienceInfo);
		entranceFirstInfo_tv.setText(R.string.entranceFirstInfo_tv);
		entranceSecondTitel_tv=(TextView)findViewById(R.id.userExperienceSecondTitel);
		entranceSecondTitel_tv.setText(R.string.entranceSecondTitel_tv);
		entranceSecondInfo_tv=(TextView)findViewById(R.id.userExperienceSecondInfo);
		entranceSecondInfo_tv.setText(R.string.entranceSecondInfo_tv);
		
		
		userExperienceFirst_iv=(LinearLayout)findViewById(R.id.userexperience_first);
		userExperienceFirst_iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(UserExperienceEntranceActivity.this, UserExperienceActivity.class);
				startActivity(intent);
			}
		});
		entranceSecondone_iv=(ImageView)findViewById(R.id.userexperiencesecondoneImageName);
		entranceSecondone_iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(UserExperienceEntranceActivity.this, UserExperienceSecondActivity.class);
				intent.putExtra("userType", "1");
				startActivity(intent);//��ҵ
			}
		});
		entranceSecondtwo_iv=(ImageView)findViewById(R.id.userexperiencesecondtwoImageName);
		entranceSecondtwo_iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(UserExperienceEntranceActivity.this, UserExperienceSecondActivity.class);
				intent.putExtra("userType", "0");
				startActivity(intent);//��ҵ
			}
		});
		userExperienceTitel_iv=(ImageView)findViewById(R.id.nav_left);
		userExperienceTitel_iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				UserExperienceEntranceActivity.this.onBackPressed();
			}
		});
	}

}
