
package com.freshpower.android.elec.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.ImageView;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.HorizontalPager;

public class IndexActivity extends Activity {
	
	private Button button;
	private LayoutInflater inflater;
	private View view;
	private ViewGroup group;
	private ImageView[] imageViews;
	private ImageView imageView;
	private SharedPreferences pref;
	private final int[] backgroundDrawables = {
            R.drawable.guide1, R.drawable.guide2, R.drawable.guide3
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	super.requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        Boolean isFirstIn = false;  
        pref = getSharedPreferences(AppConstant.SHARED_PREFERENCE_NAME, 0);  
        //ȡ����Ӧ��ֵ�����û�и�ֵ��˵����δд�룬��true��ΪĬ��ֵ  
        isFirstIn = pref.getBoolean("isFirstIn", true);  
        if(isFirstIn) {
	        HorizontalPager realViewSwitcher = new HorizontalPager(getApplicationContext());
	        for (int i = 0; i < backgroundDrawables.length; i++) {
	        	inflater = LayoutInflater.from(this);
	            view = inflater.inflate(R.layout.activity_index, null);
	            view.setBackgroundResource(backgroundDrawables[i]);
	            if (i == backgroundDrawables.length-1) {
	            	button = (Button)view.findViewById(R.id.button);
	            	button.setVisibility(View.VISIBLE);
	            }
	            group = (ViewGroup) view.findViewById(R.id.viewGroup);
	            imageViews = new ImageView[backgroundDrawables.length];
	            for (int j = 0; j < backgroundDrawables.length; j++) {
	    			imageView = new ImageView(IndexActivity.this);
	    			imageViews[j] = imageView;
	    			if (j == i) {
	    				// Ĭ��ѡ��
	    				imageViews[j]
	    						.setBackgroundResource(R.drawable.dot_selected);
	    			} else {
	    				imageViews[j].setBackgroundResource(R.drawable.dot_unselected);
	    			}
	    			group.addView(imageViews[j]);
	    		}
	            realViewSwitcher.addView(view);
	        }
	        
	        // ������ͼ����
	        setContentView(realViewSwitcher);
	        realViewSwitcher.setOnScreenSwitchListener(onScreenSwitchListener);
        } else {
        	Intent intent = new Intent(IndexActivity.this, ElecActivity.class);
        	startActivity(intent);
        	finish();
        }
    }

    public void onClick(View view) {
    	Editor editor = pref.edit();  
        editor.putBoolean("isFirstIn", false);  
        editor.commit();  
    	Intent intent = new Intent(IndexActivity.this, ElecActivity.class);
    	startActivity(intent);
    	finish();
    }
    
    private final HorizontalPager.OnScreenSwitchListener onScreenSwitchListener =
            new HorizontalPager.OnScreenSwitchListener() {
                @Override
                public void onScreenSwitched(final int screen) {
                }
            };

}
