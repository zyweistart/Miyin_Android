package com.freshpower.android.elec.activity;

import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.StringUtil;



public class WarningSetAdapter extends BaseAdapter {

	List<Map<String, Object>> mData;
	Context mContext;
	int resource;
	public WarningSetAdapter(List<Map<String, Object>> data,
			Context context, int resource) {
		this.mData = data;
		this.mContext = context;
		this.resource = resource;
	}

	@Override
	public int getCount() {
		return mData == null ? 0 : mData.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	static class ViewHoder {
		TextView cpNameText;
		TextView factorText;
		TextView demandText;
		TableLayout warningSetTable;
		LinearLayout warningSetListitem;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHoder hoder = null;
		if (convertView == null) {
			hoder = new ViewHoder();
			convertView = LayoutInflater.from(mContext).inflate(resource, null);
			hoder.cpNameText = (TextView) convertView
					.findViewById(R.id.cpNameText);
			hoder.factorText = (TextView) convertView
					.findViewById(R.id.factorText);
			hoder.demandText = (TextView) convertView
					.findViewById(R.id.demandText);
			hoder.warningSetTable = (TableLayout) convertView
					.findViewById(R.id.warningSetTable);
			hoder.warningSetListitem = (LinearLayout) convertView
					.findViewById(R.id.warningSetListitem);
			convertView.setTag(hoder);
		} else {
			hoder = (ViewHoder) convertView.getTag();
		}
		Map<String, Object> data = mData.get(position);
		if(position % 2 ==1){
			hoder.warningSetListitem.setBackgroundColor(mContext.getResources().getColor(R.color.bgcolor));
		}else{
			hoder.warningSetListitem.setBackgroundColor(mContext.getResources().getColor(R.color.white));
		}
		hoder.cpNameText.setText(String.valueOf(data.get("cpNameText")));
		hoder.factorText.setText(String.valueOf(data.get("factorText")));
		hoder.demandText.setText(String.valueOf(data.get("demandText")));
		WarningSetListener warningSetListener = new WarningSetListener();
		warningSetListener.setCpId(String.valueOf(data.get("cpId")));
		warningSetListener.setFactor(String.valueOf(data.get("factorText")));
		warningSetListener.setDemand(String.valueOf(data.get("demandText")));
		hoder.warningSetTable.setOnClickListener(warningSetListener);
		return convertView;
	}
	
	
	 class WarningSetListener implements View.OnClickListener{
		 
		private String cpId;
		private String factor;
		private String demand;
		
		public void setCpId(String cpId) {
			this.cpId = cpId;
		}

		public void setFactor(String factor) {
			this.factor = factor;
		}

		public void setDemand(String demand) {
			this.demand = demand;
		}

		@Override
		public void onClick(View v) {
			Activity activity = (Activity)mContext;
			Intent intent = new Intent(mContext, WarningSetDialogActivity.class);
			intent.putExtra("cpId", cpId);
			intent.putExtra("factor", factor);
			intent.putExtra("demand", StringUtil.isEmpty(demand)?"":demand.substring(0, demand.indexOf("KW")));
			activity.startActivityForResult(intent, AppConstant.RequestResultCode.REQUEST_WARNINGSET);
		}
	}

}
