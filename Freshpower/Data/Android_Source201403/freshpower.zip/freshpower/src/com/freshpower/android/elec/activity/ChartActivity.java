package com.freshpower.android.elec.activity;

import java.text.DecimalFormat;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;

public class ChartActivity extends Activity {
	public DecimalFormat df =new DecimalFormat("0.00"); //��ȡ��С�������λ
	LinearLayout electricityCurveChartLayout = null;
	LinearLayout burthenCurveChartLayout = null;
	LinearLayout minuteElectricityAmountBarChartLayout = null;
	LinearLayout minuteElectricityFeeBarChartLayout = null;
	LinearLayout inElectricityAmountPiechartLayout = null;
	LinearLayout outElectricityAmountPiechartLayout = null;
	LinearLayout electricityFeePieChartLayout = null;
	ElectricityCurveChart electricityCurveChart = new ElectricityCurveChart();// �����������
	BurthenCurveChart burthenCurveChart = new BurthenCurveChart();// ��������ͼ
	MinuteElectricityAmountBarChart minuteElectricityAmountBarChart = new MinuteElectricityAmountBarChart();// ���ӵ�����״ͼ
	MinuteElectricityFeeBarChart minuteElectricityFeeBarChart = new MinuteElectricityFeeBarChart();// ���ӵ����״ͼ
	InElectricityAmountPieChart inElectricityAmountPieChart = new InElectricityAmountPieChart();// ���Ƚ��ߵ�����ͼ
	OutElectricityAmountPieChart outElectricityAmountPieChart = new OutElectricityAmountPieChart();// ���ȳ��ߵ�����ͼ
	ElectricityFeePieChart electricityFeePieChart = new ElectricityFeePieChart();// ���ȵ�ѱ�ͼ
	private ArrayList<View> pageViews;
	private ImageView[] imageViews;
	// ��������ͼƬLinearLayout
	private ViewGroup main;
	// ����СԲ���LinearLayout
	private ViewGroup group;
	private ImageView imageView;
	private ViewPager viewPager;
	private int index = 0;
	private OnOffThread thread = new OnOffThread();
	ImageView currentBtn = null;//����
	ImageView voltageBtn = null;//��ѹ
	ImageView switchBtn = null;//����
	private TextView textView;
	
	private TextView lineName;// ��·����
	private TextView aCurrent;// A�����
	private TextView bCurrent;// B�����
	private TextView cCurrent;// C�����
	private TextView charge;// ���й�����
	private TextView factor;// ��������
	private TextView power;// ����ֵ
	private TextView switchStatus;// ����״̬

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		ActivityUtil.addActivity(this);
		// �����ޱ��ⴰ��
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		ActivityUtil.addActivity(this);

		LayoutInflater inflater = getLayoutInflater();
		pageViews = new ArrayList<View>();
		pageViews.add(inflater.inflate(R.layout.sub_line, null));
		pageViews.add(inflater.inflate(R.layout.electricity_curve_chart, null));
		pageViews.add(inflater.inflate(R.layout.burthen_curve_chart, null));
		pageViews.add(inflater.inflate(R.layout.minute_electricity_amount_barchart, null));
		pageViews.add(inflater.inflate(R.layout.minute_electricity_fee_barchart, null));
		if(UserExperienceActivity.textViewNum==1 || UserExperienceActivity.textViewNum==5){
			pageViews.add(inflater.inflate(R.layout.in_electricity_amount_piechart, null));
		}else{
			pageViews.add(inflater.inflate(R.layout.out_electricity_amount_piechart, null));
		}
		pageViews.add(inflater.inflate(R.layout.electricity_fee_piechart, null));

		imageViews = new ImageView[pageViews.size()];
		main = (ViewGroup) inflater.inflate(R.layout.chart_main, null);

		group = (ViewGroup) main.findViewById(R.id.viewGroup);
		viewPager = (ViewPager) main.findViewById(R.id.guidePages);

		for (int i = 0; i < pageViews.size(); i++) {
			imageView = new ImageView(ChartActivity.this);
			imageViews[i] = imageView;

			if (i == 0) {
				// Ĭ��ѡ�е�һ��ͼƬ
				imageViews[i]
						.setBackgroundResource(R.drawable.dot_selected);
			} else {
				imageViews[i].setBackgroundResource(R.drawable.dot_unselected);
			}

			group.addView(imageViews[i]);
		}
		
		setContentView(main);
		
		textView = (TextView)findViewById(R.id.game_title);
		viewPager.setAdapter(new GuidePageAdapter());
		viewPager.setOnPageChangeListener(new GuidePageChangeListener());
		
		ImageView returnButton = (ImageView)findViewById(R.id.nav_left);
	 	returnButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				thread.setDestory(true);
				ChartActivity.this.onBackPressed();
			}
		});
	 	ImageView moreButton = (ImageView)findViewById(R.id.game_morebtn_select);
	 	moreButton.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				Intent intent = new Intent();
				intent.setClass(ChartActivity.this, MoreActivity.class);
				startActivity(intent);
			}
		});
		currentBtn = (ImageView)findViewById(R.id.item_current);//����
		voltageBtn = (ImageView)findViewById(R.id.item_voltage);//��ѹ
		switchBtn = (ImageView)findViewById(R.id.item_switch);//����
		currentBtn.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				Intent it = new Intent();
				it.putExtra("type", "current");
				it.setClass(ChartActivity.this, SetThresholdActivity.class);
				startActivity(it);
			}
		});
		voltageBtn.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				Intent it = new Intent();
				it.putExtra("type", "voltage");
				it.setClass(ChartActivity.this, SetThresholdActivity.class);
				startActivity(it);
			}
		});
		switchBtn.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				Intent it = new Intent();
				it.putExtra("type", "switch");
				it.setClass(ChartActivity.this, SetThresholdActivity.class);
				startActivity(it);
			}
		});

	}

	private Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			if(index == 0) {
				textView.setText(UserExperienceActivity.inComingLine + getResources().getString(R.string.line_info));
				aCurrent.setText(String.valueOf(df.format(UserExperienceActivity.a[11])));
				bCurrent.setText(String.valueOf(df.format(UserExperienceActivity.b[11])));
				cCurrent.setText(String.valueOf(df.format(UserExperienceActivity.c[11])));
				charge.setText(String.valueOf(UserExperienceActivity.sumChargeDoubleList[11]));
				power.setText(String.valueOf(UserExperienceActivity.sumTotalPowerDoubleList[11]));
			} else if(index == 1) {
				electricityCurveChart.setA(UserExperienceActivity.a);
				electricityCurveChart.setB(UserExperienceActivity.b);
				electricityCurveChart.setC(UserExperienceActivity.c);
				electricityCurveChart.setCoefficientList(UserExperienceActivity.coefficientList);
				electricityCurveChart.setTime(UserExperienceActivity.time-2);
				electricityCurveChart.exe(ChartActivity.this, electricityCurveChartLayout);
			} else if(index == 2) {
				burthenCurveChart.setSumChargeDoubleList(UserExperienceActivity.sumChargeDoubleList);
				burthenCurveChart.setTime(UserExperienceActivity.time-2);
				burthenCurveChart.exe(ChartActivity.this, burthenCurveChartLayout);
			}else if(index == 3) {
				minuteElectricityAmountBarChart.setTime(UserExperienceActivity.timeBar-1);
				minuteElectricityAmountBarChart.setSumTotalPowerDoubleList(UserExperienceActivity.sumTotalPowerDoubleList);
				minuteElectricityAmountBarChart.exe(ChartActivity.this,
						minuteElectricityAmountBarChartLayout);
			}else if(index == 4) {
				minuteElectricityFeeBarChart.setSumTotalPowerMoneyList(UserExperienceActivity.sumTotalPowerMoneyList);
				minuteElectricityFeeBarChart.setTime(UserExperienceActivity.timeBar-1);
				minuteElectricityFeeBarChart.exe(ChartActivity.this, minuteElectricityFeeBarChartLayout);
			}else if(index == 5) {
				if(UserExperienceActivity.textViewNum==1 || UserExperienceActivity.textViewNum==5){
					inElectricityAmountPieChart.exe(ChartActivity.this, inElectricityAmountPiechartLayout);
				}else{
					outElectricityAmountPieChart.setA(UserExperienceActivity.a);
					outElectricityAmountPieChart.setB(UserExperienceActivity.b);
					outElectricityAmountPieChart.setC(UserExperienceActivity.c);
					outElectricityAmountPieChart.setCoefficient(UserExperienceActivity.coefficient);
					outElectricityAmountPieChart.exe(ChartActivity.this, outElectricityAmountPiechartLayout);
				}
			}else if(index == 6){
				electricityFeePieChart.setA(UserExperienceActivity.a);
				electricityFeePieChart.setB(UserExperienceActivity.b);
				electricityFeePieChart.setC(UserExperienceActivity.c);
				electricityFeePieChart.setCoefficient(UserExperienceActivity.businessCalculationTime());
				electricityFeePieChart.setCalculationTime(UserExperienceActivity.businessCalculationTime());
				electricityFeePieChart.exe(ChartActivity.this, electricityFeePieChartLayout);
			}
		};
	};

	@Override
	protected void onDestroy() {
		thread.setDestory(true);
		super.onDestroy();
	};

	// ָ��ҳ������������
	class GuidePageAdapter extends PagerAdapter {

		@Override
		public int getCount() {
			return pageViews.size();
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}

		@Override
		public int getItemPosition(Object object) {
			// TODO Auto-generated method stub
			return super.getItemPosition(object);
		}

		@Override
		public void destroyItem(View arg0, int arg1, Object arg2) {
			// TODO Auto-generated method stub
			((ViewPager) arg0).removeView(pageViews.get(arg1));
		}

		@Override
		public Object instantiateItem(View arg0, int arg1) {
			// TODO Auto-generated method stub
			((ViewPager) arg0).addView(pageViews.get(arg1));
			if(arg1 == 0) {
				lineName = (TextView)findViewById(R.id.line_edit01);
				aCurrent = (TextView)findViewById(R.id.line_edit05);
				bCurrent = (TextView)findViewById(R.id.line_edit06);
				cCurrent = (TextView)findViewById(R.id.line_edit07);
				charge = (TextView)findViewById(R.id.line_edit08);
				factor = (TextView)findViewById(R.id.line_edit09);
				power = (TextView)findViewById(R.id.line_edit10);
				switchStatus = (TextView)findViewById(R.id.line_edit11);
				lineName.setText(UserExperienceActivity.inComingLine);
				aCurrent.setText(String.valueOf(df.format(UserExperienceActivity.a[11])));
				bCurrent.setText(String.valueOf(df.format(UserExperienceActivity.b[11])));
				cCurrent.setText(String.valueOf(df.format(UserExperienceActivity.c[11])));
				charge.setText(String.valueOf(UserExperienceActivity.sumChargeDoubleList[11]));
				power.setText(String.valueOf(UserExperienceActivity.sumTotalPowerDoubleList[11]));
				factor.setText(df.format(UserExperienceActivity.powerFactor));
				
				// ����״̬
				for(int i = 1 ; i < 9 ;i++){
					if(UserExperienceActivity.textViewNum == i) {
						if(UserExperienceActivity.finalB[i-1]) {
							switchStatus.setText("��");
							switchStatus.setTextColor(Color.parseColor("#FF0000"));
						} else {
							switchStatus.setText("��");
							switchStatus.setTextColor(Color.parseColor("#009900"));
						}
					} 
				}
				
				thread.setDestory(true);
				thread = new OnOffThread();
				thread.start();
			} else if(arg1 == 1) {
				electricityCurveChartLayout = (LinearLayout) pageViews.get(arg1).findViewById(
						R.id.chart);
				electricityCurveChart.setA(UserExperienceActivity.a);
				electricityCurveChart.setB(UserExperienceActivity.b);
				electricityCurveChart.setC(UserExperienceActivity.c);
				electricityCurveChart.setCoefficientList(UserExperienceActivity.coefficientList);
				electricityCurveChart.setTime(UserExperienceActivity.time-2);
				electricityCurveChart.exe(ChartActivity.this, electricityCurveChartLayout);
			} else if(arg1 == 2) {
				burthenCurveChartLayout = (LinearLayout) pageViews.get(arg1).findViewById(
						R.id.chart);
				burthenCurveChart.setSumChargeDoubleList(UserExperienceActivity.sumChargeDoubleList);
				burthenCurveChart.setTime(UserExperienceActivity.time-2);
				burthenCurveChart.exe(ChartActivity.this, burthenCurveChartLayout);
			}else if(arg1 == 3) {
				minuteElectricityAmountBarChartLayout = (LinearLayout) pageViews.get(arg1).findViewById(
						R.id.chart);
				minuteElectricityAmountBarChart.setTime(UserExperienceActivity.timeBar-1);
				minuteElectricityAmountBarChart.setSumTotalPowerDoubleList(UserExperienceActivity.sumTotalPowerDoubleList);
				minuteElectricityAmountBarChart.exe(ChartActivity.this,
						minuteElectricityAmountBarChartLayout);
			}else if(arg1 == 4) {
				minuteElectricityFeeBarChartLayout = (LinearLayout) pageViews.get(arg1).findViewById(
						R.id.chart);
				minuteElectricityFeeBarChart.setSumTotalPowerMoneyList(UserExperienceActivity.sumTotalPowerMoneyList);
				minuteElectricityFeeBarChart.setTime(UserExperienceActivity.timeBar-1);
				minuteElectricityFeeBarChart.exe(ChartActivity.this, minuteElectricityFeeBarChartLayout);
			}else if(arg1 == 5) {
				if(UserExperienceActivity.textViewNum==1 || UserExperienceActivity.textViewNum==5){
					inElectricityAmountPiechartLayout = (LinearLayout) pageViews.get(arg1).findViewById(
							R.id.chart);
					inElectricityAmountPieChart.exe(ChartActivity.this, inElectricityAmountPiechartLayout);
				}else{
					outElectricityAmountPiechartLayout = (LinearLayout) pageViews.get(arg1).findViewById(
							R.id.chart);
					outElectricityAmountPieChart.setA(UserExperienceActivity.a);
					outElectricityAmountPieChart.setB(UserExperienceActivity.b);
					outElectricityAmountPieChart.setC(UserExperienceActivity.c);
					outElectricityAmountPieChart.setCoefficient(UserExperienceActivity.coefficient);
					outElectricityAmountPieChart.exe(ChartActivity.this, outElectricityAmountPiechartLayout);
				}
			}else if(arg1 == 6){
				electricityFeePieChartLayout = (LinearLayout) pageViews.get(arg1).findViewById(
						R.id.chart);
				electricityFeePieChart.setA(UserExperienceActivity.a);
				electricityFeePieChart.setB(UserExperienceActivity.b);
				electricityFeePieChart.setC(UserExperienceActivity.c);
				electricityFeePieChart.setCoefficient(UserExperienceActivity.businessCalculationTime());
				electricityFeePieChart.setCalculationTime(UserExperienceActivity.businessCalculationTime());
				electricityFeePieChart.exe(ChartActivity.this, electricityFeePieChartLayout);
			}
			return pageViews.get(arg1);
		}

		@Override
		public void restoreState(Parcelable arg0, ClassLoader arg1) {
			// TODO Auto-generated method stub

		}

		@Override
		public Parcelable saveState() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public void startUpdate(View arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void finishUpdate(View arg0) {
			// TODO Auto-generated method stub

		}
	}

	// ָ��ҳ������¼�������
	class GuidePageChangeListener implements OnPageChangeListener {

		@Override
		public void onPageScrollStateChanged(int arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onPageSelected(int arg0) {
			for (int i = 0; i < imageViews.length; i++) {
				imageViews[arg0]
						.setBackgroundResource(R.drawable.dot_selected);

				if (arg0 != i) {
					imageViews[i]
							.setBackgroundResource(R.drawable.dot_unselected);
				}
			}
			index = arg0;
			thread.setDestory(true);
			thread = new OnOffThread();
			thread.start();
			
			if(arg0 == 0) {
				textView.setText(UserExperienceActivity.inComingLine + getResources().getString(R.string.line_info));
			} else if(arg0 == 1) {
				textView.setText(UserExperienceActivity.inComingLine + getResources().getString(R.string.chart_electricity_curve));
			} else if(arg0 == 2) {
				textView.setText(UserExperienceActivity.inComingLine + getResources().getString(R.string.chart_burthen_curve));
			} else if(arg0 == 3) {
				textView.setText(UserExperienceActivity.inComingLine + getResources().getString(R.string.chart_electricity_amount_bar));
			} else if(arg0 == 4) {
				textView.setText(UserExperienceActivity.inComingLine + getResources().getString(R.string.chart_electricity_fee_bar));
			} else if(arg0 == 5) {
				if(UserExperienceActivity.textViewNum==1 || UserExperienceActivity.textViewNum==5){
					textView.setText(UserExperienceActivity.inComingLine + getResources().getString(R.string.chart_in_electricity_amount_pie));
				} else {
					textView.setText(UserExperienceActivity.inComingLine + getResources().getString(R.string.chart_out_electricity_amount_pie));
				}
			} else if(arg0 == 6) {
				textView.setText(UserExperienceActivity.inComingLine + getResources().getString(R.string.chart_electricity_fee_pie));
			}
		}
	}

	class OnOffThread extends Thread {

		private boolean isDestory = false;

		void setDestory(boolean isDestory) {
			this.isDestory = isDestory;
		}

		@Override
		public void run() {
			try {
				while (!isDestory) {
					if (isDestory)
						break;
					Message msg = new Message();
					msg.what = 1;
					handler.sendMessage(msg);
					Thread.sleep(5000);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}