package com.freshpower.android.elec.activity;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.AppConstant.RequestResultCode;
import com.freshpower.android.elec.common.MathUtil;

public class UserExperienceSecondActivity extends Activity implements OnClickListener {
	private DecimalFormat df = new DecimalFormat("#.00"); // ��ȡ��С�������λ
	private Random rand = new Random();
	private double[][] threePhaseCurrentLeft = new double[4][3];// ������������¼
	private double[][] threePhaseCurrentRight = new double[4][3];// �Ҳ����������¼
	private Timer timer = new Timer();
	private ArrayList<List<double[][]>> currentList = new ArrayList<List<double[][]>>();
	private OnOffThread myThread = new OnOffThread();
	
	// �˸���ʾ������TextView
	private TextView gameSwitch1 = null;
	private TextView gameSwitch2 = null;
	private TextView gameSwitch3 = null;
	private TextView gameSwitch4 = null;
	private TextView gameSwitch5 = null;
	private TextView gameSwitch6 = null;
	private TextView gameSwitch7 = null;
	private TextView gameSwitch8 = null;

	private Intent intent = null;
	private int time = 1;// ÿ12�μ��㵱ǰ�ܵ���
	private double electriCurrentTemp = 0;// ��¼�������ĵ���ֵ������ÿ����ǰ������Ĳ���
	private double[] nowMinutes = new double[8];//��ǰ����ӵĵ���
	private double[] totalPowerDouble = new double[8];//ͬһʱ�������߲�ͬ�ĵ���ֵ
	private double[] lastMinutes = new double[8];//��һ���ӵĵ�����
	double lastMintesSum = 0;//��һ���������ߵ��ܵ���
	private TextView sumCharge = null;
	private TextView sumTotalPower = null;
	private double sumChargeDouble = 0; 
	private double sumTotalPowerDouble = 0;
	private int inLineLevel = 1;// ���ߵȼ�
	private double electricCurrentLeft = 0.0;// ��߽�������
	private double electricCurrentRight = 0.0;// �ұ߽�������
	private double maxValue = 0.0;// �������ֵ
	private double minValue = 0.0;// ������Сֵ
	private int userType = 0;// 0:��ҵ�û� 1:��ҵ�û�
	private int charge = 0;// ʵ�ʸ���
	private int industryFee = 0;// ��ҵ�½ڷ�
	private int businessFee = 0;// ��ҵ�½ڷ�
	private double businessElectricityFee = 0.0;// ��ҵ���
	private double industryElectricityFee = 0.0;// ��ҵ���
	private boolean isConfirm = false;// �Ƿ�ȷ����������
	private boolean isConnect = false;// ĸ�������Ƿ�պ�
	
	// ����ʱ����
	private TimerThread timerThread = new TimerThread();
	private TextView timerView;
	private int countDown = 0;
	private int isZero = 0;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_user_experience_second);
		ActivityUtil.addActivity(this);
		Intent intent = getIntent();
		userType = Integer.parseInt(intent.getStringExtra("userType"));
		if(userType == 0) {
			randomGetInLineLevel(4);// ��ҵ�����ȡ���ߵȼ�������[1,4]
		} else if(userType == 1) {
			randomGetInLineLevel(5);// ��ҵ�����ȡ���ߵȼ�������[2,5]
		}
		getFristInLineData();//  ��ȡ��һ����������
		// ΪcurrentList��һ���ֵ�����listsize
		for(int i = 0 ;i < 12 ; i++){
			List temp = new ArrayList<double[][]>();
			for(int j = 0 ; j < 2 ; j++){
				temp.add(new double[4][3]);
			}
			currentList.add(temp);
		}
		
		TextView titleView = (TextView)findViewById(R.id.game_title_second);
		if(userType == 0) {
			countDown = 120;
			isZero = 120;
			titleView.setText(R.string.industry_title);
		} else {
			countDown = 180;
			isZero = 180;
			titleView.setText(R.string.business_title);
		}
		timerThread.start();
		myThread.start();
		ImageView returnButton = (ImageView) findViewById(R.id.nav_left);
		returnButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				UserExperienceSecondActivity.this.onBackPressed();
			}
		});
		
		//������Ϣ
	 	ImageView moreButton = (ImageView)findViewById(R.id.game_morebtn_select);
	 	moreButton.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				Intent intent = new Intent();
				intent.putExtra("userType", String.valueOf(userType));
				intent.putExtra("comeInFrom", "second");
				intent.setClass(UserExperienceSecondActivity.this, MoreActivity.class);
				startActivityForResult(intent, AppConstant.RequestResultCode.REQUEST_USEREXPERIENCESECOND);
			}
		});
	 	//ע��
	 	RelativeLayout registerButton = (RelativeLayout)findViewById(R.id.itemEnd);
	    registerButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
					onDestroy();
					Intent intent = new Intent(UserExperienceSecondActivity.this, UserRegisterActivity.class);
					intent.putExtra("userType", String.valueOf(userType));
					startActivity(intent);
					finish();
				}
	    	});
		
		ActivityUtil.addActivity(this);
	}
	
	/**
	 * ��ҵ�����ȡ���ߵȼ�������[1,4]
	 */
	private void randomGetInLineLevel(int num) {
		inLineLevel = rand.nextInt(num) + 1;
	}
	
	/**
	 * ��ҵ�����ȡ���ߵȼ�������[2,5]
	 */
	private void businessRandomGetInLineLevel(int num) {
		inLineLevel = rand.nextInt(num) + 2;
	}
	
	/**
	 * ��ȡ��һ����������
	 */
	private void getFristInLineData() {
		if(userType == 0) {
			if(inLineLevel == 1) {
				electricCurrentLeft = 577.2*0.9;
				electricCurrentRight = 577.2*0.9;
				maxValue = 577.2;
				minValue = 5.0;
				charge = 800;
				industryFee = 28000;
			} else if(inLineLevel == 2) {
				electricCurrentLeft = 721.5*0.9;
				electricCurrentRight = 721.5*0.9;
				maxValue = 721.5;
				minValue = 577.2;
				charge = 1000;
				industryFee = 20000;
			} else if(inLineLevel == 3) {
				electricCurrentLeft = 865.8*0.9;
				electricCurrentRight = 865.8*0.9;
				maxValue = 865.8;
				minValue = 721.5;
				charge = 1200;
				industryFee = 12000;
			} else if(inLineLevel == 4) {
				electricCurrentLeft = 1010.1*0.9;
				electricCurrentRight = 1010.1*0.9;
				maxValue = 1010.1;
				minValue = 865.8;
				charge = 1400;
				industryFee = 4000;
			}
		} else if(userType == 1) {
			if(inLineLevel == 1) {
				electricCurrentLeft = 288.6*0.9;
				electricCurrentRight = 288.6*0.9;
				maxValue = 288.6;
				minValue = 216.45;
				charge = 400;
				businessFee = 32096;
			} else if(inLineLevel == 2) {
				electricCurrentLeft = 360.75*0.9;
				electricCurrentRight = 360.75*0.9;
				maxValue = 360.75;
				minValue = 288.6;
				charge = 500;
				businessFee = 39961;
			} else if(inLineLevel == 3) {
				electricCurrentLeft = 432.9*0.9;
				electricCurrentRight = 432.9*0.9;
				maxValue = 432.9;
				minValue = 360.75;
				charge = 600;
				businessFee = 47954;
			} else if(inLineLevel == 4) {
				electricCurrentLeft = 505.1*0.9;
				electricCurrentRight = 505.1*0.9;
				maxValue = 505.1;
				minValue = 432.9;
				charge = 700;
				businessFee = 55946;
			} else if(inLineLevel == 5) {
				electricCurrentLeft = 577.2*0.9;
				electricCurrentRight = 577.2*0.9;
				maxValue = 577.2;
				minValue = 505.1;
				charge = 1000;
				businessFee = 65939;
			}
		}
	}
	
	 private Handler  handler = new Handler(){
	    	public void handleMessage(android.os.Message msg) {
	    		if(msg.what==1){
	    			List<double[][]> current = new ArrayList<double[][]>();
	    			current = setCurrentTextView();
	    			currentList.remove(0);
					currentList.add(11,current);
					
					if(countDown == 60 && userType == 0) {// 1������ʾ
						Intent intent = new Intent();
						intent.putExtra("type", "1");// ʱ������
						intent.putExtra("userType", String.valueOf(userType));// �û�����
						intent.putExtra("charge", String.valueOf(charge));
						intent.putExtra("money", String.valueOf(industryFee));
						intent.setClass(UserExperienceSecondActivity.this, ShowToIndustrial.class);
						startActivityForResult(intent, AppConstant.RequestResultCode.REQUEST_USERSECOND);
					} else if(isConfirm && countDown == 0 && userType == 0) {// 2������ʾ
						isConfirm = false;
						Intent intent = new Intent();
						intent.putExtra("type", "2");// ʱ������
						intent.putExtra("userType", String.valueOf(userType));// �û�����
						intent.putExtra("charge", String.valueOf(charge));
						intent.putExtra("money", String.valueOf(industryFee));
						intent.setClass(UserExperienceSecondActivity.this, ShowToIndustrial.class);
						finishActivity(AppConstant.RequestResultCode.REQUEST_USERSECOND);
						startActivityForResult(intent, RequestResultCode.REQUEST_USERSECOND);
					} else if(countDown == 120 && userType == 1) {
						Intent intent = new Intent();
						intent.putExtra("type", "1");// ʱ������
						intent.putExtra("userType", String.valueOf(userType));// �û�����
						intent.putExtra("charge", String.valueOf(charge));
						intent.putExtra("money", String.valueOf(businessFee));
						intent.setClass(UserExperienceSecondActivity.this, ShowToIndustrial.class);
						startActivityForResult(intent, AppConstant.RequestResultCode.REQUEST_USERSECOND);

					} else if(isConfirm && countDown == 0 && userType == 1) {
						// ������ҵ���
						isConfirm = false;
						businessElectricityFee = sumTotalPowerDouble*UserExperienceActivity.businessCalculationTime();
						BigDecimal bigDecimal = new BigDecimal(0);
						// ���㹤ҵ���
						if(inLineLevel == 1) {
							industryElectricityFee = (sumTotalPowerDouble*UserExperienceActivity.calculationIndustrialTime())+Double.parseDouble("0.5555")*3;
						} else if(inLineLevel == 2) {
							bigDecimal = new BigDecimal(3*40*625);
							bigDecimal = bigDecimal.divide(new BigDecimal(43200),2,RoundingMode.HALF_UP);
							industryElectricityFee = (sumTotalPowerDouble*UserExperienceActivity.calculationIndustrialTime())+Double.parseDouble("0.578")*3;
						} else if(inLineLevel == 3) {
							industryElectricityFee = (sumTotalPowerDouble*UserExperienceActivity.calculationIndustrialTime())+Double.parseDouble("0.694")*3;
						} else if(inLineLevel == 4) {
							industryElectricityFee = (sumTotalPowerDouble*UserExperienceActivity.calculationIndustrialTime())+Double.parseDouble("0.81")*3;
						} else if(inLineLevel == 5) {
							industryElectricityFee = (sumTotalPowerDouble*UserExperienceActivity.calculationIndustrialTime())+Double.parseDouble("0.868")*3;
						}
						Intent intent = new Intent();
						intent.putExtra("type", "2");// ʱ������
						intent.putExtra("userType", String.valueOf(userType));// �û�����
						intent.putExtra("charge", String.valueOf(charge));
						intent.putExtra("money", String.valueOf(df.format(sumTotalPowerDouble * UserExperienceActivity.businessCalculationTime() - industryElectricityFee)));
						intent.setClass(UserExperienceSecondActivity.this, ShowToIndustrial.class);
						finishActivity(AppConstant.RequestResultCode.REQUEST_USERSECOND);
						startActivityForResult(intent, RequestResultCode.REQUEST_USERSECOND);
						// ����Ի���
//						AlertDialog.Builder builder = new Builder(UserExperienceSecondActivity.this);
//						builder.setMessage("�������з�ʽ�����ѽ�ʡ���"+Double.parseDouble(df.format(businessElectricityFee-industryElectricityFee))+"Ԫ");
//						builder.setNegativeButton(R.string.soft_validate_validatebtn,
//						new DialogInterface.OnClickListener() {
//							@Override
//							public void onClick(DialogInterface dialog, int which) {
//								dialog.dismiss();
//								UserExperienceSecondActivity.this.onBackPressed();
//							}
//						});
//						builder.setCancelable(false);
//						builder.show();
					}
	    		}
	    	};
	    };

	class OnOffThread extends Thread {

		private boolean isDestory = false;

		void setDestory(boolean isDestory) {
			this.isDestory = isDestory;
		}

		@Override
		public void run() {
			try {
				while (!isDestory) {
					if (isDestory)
						break;
					Message msg = new Message();
					msg.what = 1;
					handler.sendMessage(msg);
					Thread.sleep(5000);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	class TimerThread extends Thread {
		
		private boolean isDestory = false;

		void setDestory(boolean isDestory) {
			this.isDestory = isDestory;
		}
		
		public void run() {
			try {
				while (!isDestory) {
					if (isDestory)
						break;
					Message msg = new Message();
					msg.what = 1;
					timerHandler.sendMessage(msg);
					Thread.sleep(1000);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	 private Handler timerHandler = new Handler(){
    	public void handleMessage(android.os.Message msg) {
    		isZero--;
    		countDown--;
			timerView = (TextView) findViewById(R.id.timer);
			if(countDown > 0) {
				timerView.setText("����ʱ��"+MathUtil.changeTime(countDown));
			}else{
				myThread.setDestory(true);
				myThread = new OnOffThread();
				myThread.start();
				timerThread.setDestory(true);
			}
			if(countDown == 120 && userType == 1){
				myThread.setDestory(true);
				myThread = new OnOffThread();
				myThread.start();
			}
			if(countDown == 60 && userType == 0){
				myThread.setDestory(true);
				myThread = new OnOffThread();
				myThread.start();
			}
			
    	};
	 };
	
	public List<double[][]> setCurrentTextView() {
		List<TextView> listGame = new ArrayList<TextView>();
		gameSwitch1 = (TextView) findViewById(R.id.game_switch01);
		gameSwitch2 = (TextView) findViewById(R.id.game_switch02);
		gameSwitch3 = (TextView) findViewById(R.id.game_switch03);
		gameSwitch4 = (TextView) findViewById(R.id.game_switch04);
		gameSwitch5 = (TextView) findViewById(R.id.game_switch05);
		gameSwitch6 = (TextView) findViewById(R.id.game_switch06);
		gameSwitch7 = (TextView) findViewById(R.id.game_switch07);
		gameSwitch8 = (TextView) findViewById(R.id.game_switch08);
		listGame.add(gameSwitch1);
		listGame.add(gameSwitch2);
		listGame.add(gameSwitch3);
		listGame.add(gameSwitch4);
		listGame.add(gameSwitch5);
		listGame.add(gameSwitch6);
		listGame.add(gameSwitch7);
		listGame.add(gameSwitch8);
		threePhaseCurrentLeft = new double[4][3];
		threePhaseCurrentRight = new double[4][3];
		Double rnd = Math.random();// ����������������
		if (rnd < 0.1) {
			rnd += 0.1;
		}
		rnd = Double.valueOf(df.format(rnd));
		
		//��¼�������ĵ���ֵ������ÿ����ǰ������Ĳ���������5%
		if(time == 1){
			electricCurrentLeft = (minValue+maxValue)/2;
			electriCurrentTemp = electricCurrentLeft ; 
		}else{
			if(rnd>0.5){
				electricCurrentLeft = electriCurrentTemp * 1.05;
			}else{
				electricCurrentLeft = electriCurrentTemp * 0.95;
			}
		}
		electriCurrentTemp = electricCurrentLeft;
		if(isConnect) {
			electriCurrentTemp = this.isChackVal(electriCurrentTemp, minValue*2, maxValue*2);
		} else {
			electriCurrentTemp = this.isChackVal(electriCurrentTemp, minValue, maxValue);
		}
		
		//---------------------------------------------------
		//��������������·�ĵ����˴�֮��������5%
		rnd = Math.random() ;//����������������
		double electricCurrentRight = 0 ;
		if(rnd>0.5){
			electricCurrentRight = electricCurrentLeft * 1.05;
		}else{
			electricCurrentRight = electricCurrentLeft * 0.95;
		}
				
		// ����Ia��Ib��Ic�������֮��ķ��Ȳ�����5%
		int sign = -1;
		double scope = 0.025;
		if(time == 1) {
			// ���ó�ʼ����ֵ
			for(int i = 0 ;i < 3 ; i++){
				this.initCurrent(i, minValue, maxValue);
			}
		} else {
			for (int i = 0; i < 3; i++) {
				rnd = Math.random();
				if (rnd > 0.5) {
					sign = -1;
				} else {
					sign = 1;
				}
				if(isConnect) {
					consolidated(i, isChackVal(electricCurrentLeft * (1 + scope * i * sign), minValue*2, maxValue*2));
				} else {
					calculate(threePhaseCurrentRight, i, 0, isChackVal(electricCurrentRight * (1 + scope * i * sign), minValue, maxValue));
					calculate(threePhaseCurrentLeft, i, 1, isChackVal(electricCurrentLeft * (1 + scope * i * sign), minValue, maxValue));
				}
			}
		}
		// ҳ����ʾ������Ϣ
		for (int i = 0; i < 4; i++) {
			StringBuffer current = new StringBuffer();
			for (char j = 'a'; j < 'd'; j++) {
				current.append("I" + j + "="
						+ threePhaseCurrentLeft[i][j - 97] + ";\n");
			}
			listGame.get(i).setText(current);
		}
		for (int i = 0; i < 4; i++) {
			StringBuffer current = new StringBuffer();
			for (char j = 'a'; j < 'd'; j++) {
				current.append("I" + j + "=" + threePhaseCurrentRight[i][j - 97]
						+ ";\n");
			}
			listGame.get(i + 4).setText(current);
		}
		// --------------------------------------
		// ���ɣ��ܵ���
		sumCharge = (TextView) findViewById(R.id.sumCharge);
		sumTotalPower = (TextView) findViewById(R.id.sumTotalPower);
		// ------------------------
		double lefta = 220 * threePhaseCurrentLeft[0][0] * 0.85;
		double leftb = 220 * threePhaseCurrentLeft[0][1] * 0.85;
		double leftc = 220 * threePhaseCurrentLeft[0][2] * 0.85;
		double righta = 220 * threePhaseCurrentRight[0][0] * 0.85;
		double rightb = 220 * threePhaseCurrentRight[0][1] * 0.85;
		double rightc = 220 * threePhaseCurrentRight[0][2] * 0.85;
		sumChargeDouble = (lefta + leftb + leftc + righta + rightb + rightc) / 1000;
		sumCharge.setText(getResources().getString(R.string.second_charge) + df.format(sumChargeDouble) + "kW");

		if (time == 1) {
			lastMintesSum = sumChargeDouble;
		}
		time++;// ÿ�����ۼ�һ��
		if(time%12==0){
			sumTotalPowerDouble =  sumTotalPowerDouble +(lastMintesSum + sumChargeDouble)/2/60;
			lastMintesSum = sumChargeDouble;
			sumTotalPower.setText(getResources().getString(R.string.second_power) + df.format(sumTotalPowerDouble)+"kWh");
		}
		List<double[][]> current = new ArrayList<double[][]>();
		current.add(threePhaseCurrentLeft);
		current.add(threePhaseCurrentRight);
		sumTotalPowerDouble = Double
				.parseDouble(df.format(sumTotalPowerDouble));
		sumChargeDouble = Double.parseDouble(df.format(sumChargeDouble));
		return current;
	}
	
	/*
	 * ��ȡ��������
	 * threePhaseCurrent�洢���ݶ�ά����
	 * index �ڼ�����
	 * j ��������
	 */
	public void calculate(double [][] threePhaseCurrent,int index,int j,double electricCurrent){
		threePhaseCurrent[0][index] = Double.valueOf(df.format(electricCurrent));//I*(���Էֱ����A,B,C)
		if(j == 0){
			threePhaseCurrent[1][index] = Double.valueOf(df.format(electricCurrent * 0.2));//I*1
			threePhaseCurrent[2][index] = Double.valueOf(df.format(electricCurrent * 0.3));//I*2
			threePhaseCurrent[3][index] = Double.valueOf(df.format(electricCurrent * 0.5));//I*3
		}else if(j == 1){
			threePhaseCurrent[1][index] = Double.valueOf(df.format(electricCurrent * 0.3));//I*1
			threePhaseCurrent[2][index] = Double.valueOf(df.format(electricCurrent * 0.5));//I*2
			threePhaseCurrent[3][index] = Double.valueOf(df.format(electricCurrent * 0.2));//I*3
		}
	}
	
	/**
	 * ĸ�����غ���ʱ�������
	 * @param size
	 * @param electricCurrent
	 */
	public void consolidated(int size,double electricCurrent){//�м�ϲ�ʱ�ļ��㷽��
		threePhaseCurrentRight[0][size] = 0.0;//����2
		threePhaseCurrentRight[1][size] = Double.valueOf(df.format(electricCurrent*0.15));//����2-1
		threePhaseCurrentRight[2][size] = Double.valueOf(df.format(electricCurrent*0.25));//����2-2
		threePhaseCurrentRight[3][size] = Double.valueOf(df.format(electricCurrent*0.1));//����2-3
		threePhaseCurrentLeft[0][size] = Double.valueOf(df.format(electricCurrent));//����1
		threePhaseCurrentLeft[1][size] = Double.valueOf(df.format(electricCurrent*0.15));//����1-1
		threePhaseCurrentLeft[2][size] = Double.valueOf(df.format(electricCurrent*0.25));//����1-2
		threePhaseCurrentLeft[3][size] = Double.valueOf(df.format(electricCurrent*0.1));//����1-3

	}
	
	/**
	 * ��ʼ����ֵ
	 */
	public void initCurrent(int index, double min, double max){
		threePhaseCurrentRight[0][index] = Double.valueOf(df.format((min+max)/2));//����2
		threePhaseCurrentRight[1][index] = Double.valueOf(df.format((min+max)/2*0.15));//����2-1
		threePhaseCurrentRight[2][index] = Double.valueOf(df.format((min+max)/2*0.25));//����2-2
		threePhaseCurrentRight[3][index] = Double.valueOf(df.format((min+max)/2*0.1));//����2-3
		threePhaseCurrentLeft[0][index] = Double.valueOf(df.format((min+max)/2));//����1
		threePhaseCurrentLeft[1][index] = Double.valueOf(df.format((min+max)/2*0.15));//����1-1
		threePhaseCurrentLeft[2][index] = Double.valueOf(df.format((min+max)/2*0.25));//����1-2
		threePhaseCurrentLeft[3][index] = Double.valueOf(df.format((min+max)/2*0.1));//����1-3

	}
	
	/**
	 * �жϵ�ǰֵ�Ƿ���������
	 */
	public double isChackVal(double value, double min, double max){
		double returnVal = 0.0;
		if(min < value && value < max) {
			returnVal = value;
		} else if(min > value) {
			returnVal = value*1.05;
		} else if(value > max) {
			returnVal = value*0.95;
		}
		return returnVal;
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}
	
	protected void onDestroy() {
		if(myThread != null){
			myThread.setDestory(true);
		}
		if(timerThread != null) {
			timerThread.setDestory(true);
		}
		isConfirm = true;
		super.onDestroy();
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		String userTypeStr = getIntent().getStringExtra("userType");
		if(resultCode == AppConstant.RequestResultCode.REQUEST_OPEATERCANCEL){
			UserExperienceSecondActivity.this.onBackPressed();
		}
		if(resultCode == AppConstant.RequestResultCode.REQUEST_OPEATERCOMMIT && userType == 1){
			ImageButton imgBtn5 = (ImageButton)findViewById(R.id.game_btn5);
			ImageButton imgBtn9 = (ImageButton)findViewById(R.id.game_btn9);
			imgBtn5.setBackgroundResource(R.drawable.close);
			imgBtn9.setBackgroundResource(R.drawable.open);
			businessElectricityFee = sumTotalPowerDouble * UserExperienceActivity.businessCalculationTime();
			isConnect = true;
			myThread.setDestory(true);
			myThread = new OnOffThread();
			myThread.start();
			electriCurrentTemp = electriCurrentTemp*2;
		}
		if(resultCode == AppConstant.RequestResultCode.REQUEST_BUY_CLOSETHREAD) {
			onDestroy();// �ر��߳�
			startActivity(data);// ��ת��Ӧ��ҳ��
			finish();// �رյ�ǰҳ��
		}
		isConfirm = true;
		super.onActivityResult(requestCode, resultCode, data);
	}
}
