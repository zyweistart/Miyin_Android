package com.freshpower.android.elec.activity;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.TaskGroupAdapter;
import com.freshpower.android.elec.domain.Task;
import com.freshpower.android.elec.netapi.TaskDataApi;
import com.freshpower.android.elec.widget.PullDownListView;

public class TaskActivity extends FrameActivity implements
		PullDownListView.OnRefreshListioner {
	private PullDownListView mPullDownView;
	private ListView mListView;
	private Resources res;
	private ImageButton homeBtn;
	private List<Task> taskInfoList = new ArrayList<Task>();
	public Handler mHandler = new Handler();
	private int pageSize = 10;// ÿҳ��ʾ
	private int currentPage = 1;// ��ǰҳ
	private int totalCnt;// �ܼ�¼��
	private int rs = 999;// ��ѯ���
	private TaskGroupAdapter adapter;
	List<Map<String, Object>> taskInfoMap;
	public ProgressDialog processProgress;

	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_is_task);
		ImageView iv = (ImageView) findViewById(R.id.nav_left);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				TaskActivity.this.onBackPressed();
			}
		});

		mPullDownView = (PullDownListView) findViewById(R.id.task_list);
		mPullDownView.setRefreshListioner(this);
		mListView = mPullDownView.mListView;
		processProgress = ProgressDialog
				.show(TaskActivity.this,
						"",
						getResources().getString(
								R.string.msg_operate_processing_alert), true);
		new Thread() {
			public void run() {
				taskInfoMap = getGroupOnelistData();
				Message msgMessage = new Message();
				TaskActivity.this.xHandler.sendMessage(msgMessage);
			}
		}.start();

	}

	private Handler xHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			if (taskInfoMap != null) {
				adapter = new TaskGroupAdapter(taskInfoMap, TaskActivity.this,
						R.layout.listitem_is_task, taskInfoList);
				mListView.setAdapter(adapter);
			} else {
				rs = AppConstant.Result.NO_COUNT;
			}
			setShow();
			mPullDownView.setVisibility(View.VISIBLE);
			processProgress.dismiss();
		};
	};

	private void setShow() {
		if (taskInfoList.size() == AppConstant.Result.NO_COUNT) {
			RelativeLayout noResultlayout = (RelativeLayout) findViewById(R.id.noResultlayout);
			noResultlayout.setVisibility(View.VISIBLE);
			RelativeLayout relativelayout = (RelativeLayout) findViewById(R.id.relativelayout);
			relativelayout.setVisibility(View.GONE);
			mPullDownView.setMore(false);
		} else {
			mPullDownView.setMore(true);// ��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
		}
		if (totalCnt <= pageSize) {
			mPullDownView.setMore(false);
		}
	}

	@Override
	public void onRefresh() {
		// TODO Auto-generated method stub
		mHandler.postDelayed(new Runnable() {

			public void run() {
				taskInfoMap.clear();
				currentPage = 1;
				taskInfoMap.addAll(getGroupOnelistData());

				mPullDownView.onRefreshComplete();// �����ʾˢ�´�����ɺ������ļ���ˢ�½�������
				mPullDownView.setMore(true);// ��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				if (totalCnt <= pageSize) {
					mPullDownView.setMore(false);
				}
				adapter.notifyDataSetChanged();
			}
		}, 1500);

	}

	@Override
	public void onLoadMore() {
		mHandler.postDelayed(new Runnable() {
			public void run() {

				currentPage++;
				taskInfoMap.addAll(getGroupOnelistData());

				mPullDownView.onLoadMoreComplete();// �����ʾ���ظ��ദ����ɺ������ļ��ظ�����棨���ػ��������������ࣩ
				// if(list.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
				if (taskInfoMap.size() < totalCnt)// �жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
					mPullDownView.setMore(true);// ��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				else
					mPullDownView.setMore(false);
				adapter.notifyDataSetChanged();

			}
		}, 1500);

	}

	private List<Map<String, Object>> getGroupOnelistData() {
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		res = getResources();
		try {
			Map taskInfoMap = TaskDataApi
					.getTaskInfoList(pageSize, currentPage);
			taskInfoList = (List<Task>) taskInfoMap.get("taskInfoList");
			for (Task taskInfo : taskInfoList) {
				Map<String, Object> listItem = new HashMap<String, Object>();
				listItem.put("taskName", taskInfo.getName()
						+ R.string.responsible_station + taskInfo.getSiteName()
						+ taskInfo.getTaskDate().split(" ")[0]
						+ R.string.created_task);
				listItem.put("taskDate", taskInfo.getTaskDate().split(" ")[0]);
				listItem.put("id", taskInfo.getTaskId());
				listItems.add(listItem);
			}
			totalCnt = Integer.parseInt(String.valueOf(taskInfoMap
					.get("totalCount")));
			return listItems;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listItems;
	}

	protected void onResume() {
		homeBtn = (ImageButton) findViewById(R.id.stationTaskbtn);
		if (homeBtn != null) {
			homeBtn.setOnClickListener(null);
			homeBtn.setBackgroundResource(R.drawable.taskbtn_select);
		}

		TextView taskBtnTv = (TextView) findViewById(R.id.stationTaskTv);
		taskBtnTv.setTextColor(getResources().getColor(R.color.orange));

		super.onResume();
	}

	@Override
	protected void onDestroy() {
		if(taskInfoMap!=null){
			taskInfoMap.clear();
		}
		super.onDestroy();
	}
}
