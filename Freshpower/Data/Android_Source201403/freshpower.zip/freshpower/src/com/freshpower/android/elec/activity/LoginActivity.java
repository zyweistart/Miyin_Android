package com.freshpower.android.elec.activity;

import java.io.File;

import org.androidpn.client.ServiceManager;
import org.apache.http.conn.HttpHostConnectException;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.AppCache;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.CommunicationManager;
import com.freshpower.android.elec.common.DBException;
import com.freshpower.android.elec.common.DBOperater;
import com.freshpower.android.elec.common.FileUtil;
import com.freshpower.android.elec.common.MD5;
import com.freshpower.android.elec.dao.DaoFactory;
import com.freshpower.android.elec.dao.LoginPurviewDao;
import com.freshpower.android.elec.domain.LoginInfo;
import com.freshpower.android.elec.netapi.LoginInfoDataApi;


public class LoginActivity  extends Activity {
	private LoginInfo loginInfo;
	private ProgressDialog processProgress;
	private Handler handler = new Handler();
	private Resources res;
	private LoginPurviewDao loginPurviewDao;
	private SharedPreferences trmsSharedPreferences;
	
	public LoginPurviewDao getLoginPurviewDao() {
		return loginPurviewDao;
	}

	public void setLoginPurviewDao(LoginPurviewDao loginPurviewDao) {
		this.loginPurviewDao = loginPurviewDao;
	}

	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		ActivityUtil.addActivity(this);
		trmsSharedPreferences = getSharedPreferences(
				AppConstant.SHARED_PREFERENCE_NAME, MODE_PRIVATE);
		res=getResources();
		loginPurviewDao=DaoFactory.getLoginPurviewDao(LoginActivity.this);
		Button loginSub=(Button)findViewById(R.id.loginSub);
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				LoginActivity.this.onBackPressed();	
			}
		});
		loginSub.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				EditText loginName_et=(EditText)findViewById(R.id.loginName);
				EditText loginPwd_et=(EditText)findViewById(R.id.loginPwd);
				if(loginName_et.getText().toString().equals(""))
				{
					Toast.makeText(LoginActivity.this, R.string.login_name_msg,Toast.LENGTH_SHORT).show();
					return;
				}else if(loginName_et.getText().toString().indexOf(" ")!=-1){
					Toast.makeText(LoginActivity.this, R.string.login_namepwd_msg,Toast.LENGTH_SHORT).show();
					return;
				}
				if(loginPwd_et.getText().toString().equals(""))
				{
					Toast.makeText(LoginActivity.this, R.string.login_pwd_msg,Toast.LENGTH_SHORT).show();
					return;
				}
				loginInfo=new LoginInfo();
				loginInfo.setLoginName(loginName_et.getText().toString());
				String pwd=loginPwd_et.getText().toString();
				loginInfo.setLoginPwd(MD5.encrypt(pwd.toUpperCase()));
				processProgress = ProgressDialog.show(LoginActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
				new Thread(new Runnable(){
					String msgContent;
					@Override
					public void run() {
						try {
							loginInfo=LoginInfoDataApi.getLoginInfo(loginInfo,LoginActivity.this);
							if(loginInfo.getLoginStatus()==2){
								writeLoginInfoContent(loginInfo);//�û���Ϣ���浽�ļ�
								AppCache.put(AppCache.LOGININFO_OBJ, loginInfo);
								msgContent=getResources().getString(R.string.login_success_msg); 
								
								//����ʵʱ��Ϣ����
								ServiceManager serviceManager = new ServiceManager(LoginActivity.this);
						        serviceManager.setNotificationIcon(R.drawable.notification);
						        serviceManager.setLoginCmd(CommunicationManager.getLogincmd(loginInfo.getLoginName(), loginInfo.getLoginPwd()));
						        serviceManager.startService();
						        
						        initService();
								
								Intent it=getIntent();
								String loginType=it.getStringExtra("LoginType");
								if(null!=loginType&&!"".equals(loginType)&&loginType.equals("station")){
									try {
										boolean result=loginPurviewDao.selectLoginInfo(res.getString(R.string.home_second_top2_bpcode));
										if(result){
											Intent intent = new Intent(LoginActivity.this, StationActivity.class);
											startActivity(intent);
											finish();
										}else{
											Toast.makeText(LoginActivity.this, R.string.login_purview_bpcode,
													Toast.LENGTH_LONG).show();
											Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
											startActivity(intent);
											finish();
											
										}
									}catch (Exception e) {
										Toast.makeText(LoginActivity.this, R.string.login_purview_bpcode,
												Toast.LENGTH_LONG).show();
										e.printStackTrace();
									}
									
								}else if(null!=loginType&&!"".equals(loginType)&&loginType.equals("scan")){
											Intent intent = new Intent(LoginActivity.this, ScanActivity.class);
											startActivity(intent);
											finish();
								} else if(null!=loginType&&!"".equals(loginType)&&loginType.equals("projectSite")) {
									try {
										boolean result=loginPurviewDao.selectLoginInfo(res.getString(R.string.home_second_buttom2_bpcode));
										if(result){
											Intent intent = new Intent(LoginActivity.this, ProjectSiteActivity.class);
											startActivity(intent);
											finish();
										}else{
											Toast.makeText(LoginActivity.this, R.string.login_purview_bpcode,
													Toast.LENGTH_LONG).show();
											Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
											startActivity(intent);
											finish();
											
										}
									}catch (Exception e) {
										Toast.makeText(LoginActivity.this, R.string.login_purview_bpcode,
												Toast.LENGTH_LONG).show();
										e.printStackTrace();
									}
									
								} else if(null!=loginType&&!"".equals(loginType)&&loginType.equals("warningSet")) {
											Intent intent = new Intent(LoginActivity.this, WarningSetActivity.class);
											startActivity(intent);
											finish();
								} else {
									Intent intent = new Intent(LoginActivity.this, ToolActivity.class);
									intent.putExtra("loginStatus", loginInfo.getLoginStatus());
									intent.putExtra("loginName", loginInfo.getLoginName());
									startActivity(intent);
									finish();
								}
							}else if(loginInfo.getLoginStatus()!=2){
								msgContent=getResources().getString(R.string.login_lose_msg); 
								Intent intent = new Intent(LoginActivity.this, LoginActivity.class);
								intent.putExtra("loginStatus", loginInfo.getLoginStatus());
								startActivity(intent);
								finish();
							}
						}catch (HttpHostConnectException e) {
							msgContent=getResources().getString(R.string.msg_abnormal_network); 
						}catch (Exception e) {
							msgContent=getResources().getString(R.string.msg_abnormal_net2work); 
						}finally{
							processProgress.dismiss();
							handler.post(new Runnable() {
								@Override
								public void run() {
									Toast.makeText(LoginActivity.this, msgContent, Toast.LENGTH_SHORT).show(); 								
								}
							});
						}
					}
				}).start();
			}
		});
	}
	public void writeLoginInfoContent(LoginInfo loginInfo){
		if(!FileUtil.isFileExist(FileUtil.getDBFilePath())){
			try {
				File dbFile = new File(FileUtil.getDBFilePath());
				FileUtil.createFolder(dbFile.getParent());
				FileUtil.createFile(dbFile);
			} catch (Exception e) {
				Log.e("dberror", e.toString());
				e.printStackTrace();
			}
		}
		String fileContent = FileUtil.read(FileUtil.getDBFilePath());
		fileContent = loginInfo.getLoginName()
				+ "|"
				+ loginInfo.getLoginPwd()
				+ "|"
				+ fileContent.substring(fileContent
						.lastIndexOf('|') + 1);
		FileUtil.writeBeforeClearContent(
				FileUtil.getDBFilePath(), fileContent); 
	}
	
	
	/**
	 * ��ʼ������
	 */
	private void initService() {
		if (trmsSharedPreferences.getBoolean(
				AppConstant.SharedPreferencesKey.GPS_SET, false)) {
			Intent intent = new Intent();
			intent.setAction(AppConstant.ReceiverAction.ACTION_GPSSERVICE_START);
			sendBroadcast(intent);
		}
	}
}
