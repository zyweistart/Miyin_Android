package com.freshpower.android.elec.domain;

public class CollectorInfo {
	private String meterName;//��·����
	private String meterNo;//��·���
	private String ratio;//���
	private String loadGrade;//���ɵȼ�
	private String switchNo;//���ر��
	private String fixValue;//�����
	private String status2;//����״̬
	private String totalPower;//����й��ܵ���
	private String allHour;//�պ���
	private String vA;//A���ѹ
	private String vB;//b���ѹ
	private String vC;//c���ѹ
	private String iA;//A�����
	private String iB;//b�����
	private String iC;//c�����
	private String pA;//A�๦��
	private String pB;//b�๦��
	private String pC;//c�๦��
	private String fA;//A�๦������
	private String fB;//b�๦������
	private String fC;//c�๦������
	private String hz;//����Ƶ��
	private String reportDate;//�ϱ�ʱ��
	private String result;//����ʱ���صĽ��
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMeterName() {
		return meterName;
	}
	public void setMeterName(String meterName) {
		this.meterName = meterName;
	}
	public String getMeterNo() {
		return meterNo;
	}
	public void setMeterNo(String meterNo) {
		this.meterNo = meterNo;
	}
	public String getRatio() {
		return ratio;
	}
	public void setRatio(String ratio) {
		this.ratio = ratio;
	}
	public String getLoadGrade() {
		return loadGrade;
	}
	public void setLoadGrade(String loadGrade) {
		this.loadGrade = loadGrade;
	}
	public String getSwitchNo() {
		return switchNo;
	}
	public void setSwitchNo(String switchNo) {
		this.switchNo = switchNo;
	}
	public String getFixValue() {
		return fixValue;
	}
	public void setFixValue(String fixValue) {
		this.fixValue = fixValue;
	}
	public String getStatus2() {
		return status2;
	}
	public void setStatus2(String status2) {
		this.status2 = status2;
	}
	public String getTotalPower() {
		return totalPower;
	}
	public void setTotalPower(String totalPower) {
		this.totalPower = totalPower;
	}
	public String getAllHour() {
		return allHour;
	}
	public void setAllHour(String allHour) {
		this.allHour = allHour;
	}
	public String getvA() {
		return vA;
	}
	public void setvA(String vA) {
		this.vA = vA;
	}
	public String getvB() {
		return vB;
	}
	public void setvB(String vB) {
		this.vB = vB;
	}
	public String getvC() {
		return vC;
	}
	public void setvC(String vC) {
		this.vC = vC;
	}
	public String getiA() {
		return iA;
	}
	public void setiA(String iA) {
		this.iA = iA;
	}
	public String getiB() {
		return iB;
	}
	public void setiB(String iB) {
		this.iB = iB;
	}
	public String getiC() {
		return iC;
	}
	public void setiC(String iC) {
		this.iC = iC;
	}
	public String getpA() {
		return pA;
	}
	public void setpA(String pA) {
		this.pA = pA;
	}
	public String getpB() {
		return pB;
	}
	public void setpB(String pB) {
		this.pB = pB;
	}
	public String getpC() {
		return pC;
	}
	public void setpC(String pC) {
		this.pC = pC;
	}
	public String getfA() {
		return fA;
	}
	public void setfA(String fA) {
		this.fA = fA;
	}
	public String getfB() {
		return fB;
	}
	public void setfB(String fB) {
		this.fB = fB;
	}
	public String getfC() {
		return fC;
	}
	public void setfC(String fC) {
		this.fC = fC;
	}
	public String getHz() {
		return hz;
	}
	public void setHz(String hz) {
		this.hz = hz;
	}
	public String getReportDate() {
		return reportDate;
	}
	public void setReportDate(String reportDate) {
		this.reportDate = reportDate;
	}
	
}
