package com.freshpower.android.elec.netapi;

import java.io.File;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.common.AppCache;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.DateUtil;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.conf.AppConfig;
import com.freshpower.android.elec.domain.CheckTask;
import com.freshpower.android.elec.domain.LoginInfo;


public class CheckTaskApi extends JsonDataApi {
	private static final String CHECK_ACTION = "AppMonitoringAlarm.aspx";
	/**
	 * �ͻ�Ѳ��վ����Ϣ
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getCheckMakeList(int pageSize,int pageNum, String cpName, String siteName) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "ZY22");
		api.addParam("QTPINDEX", String.valueOf(pageNum).trim());
		api.addParam("QTPSIZE", String.valueOf(pageSize).trim());
		api.addParam("QTKEY", URLEncoder.encode(cpName, AppConstant.ETG_INTERFACE_CHARSET));
		api.addParam("QTKEY2", URLEncoder.encode(siteName, AppConstant.ETG_INTERFACE_CHARSET));
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+CHECK_ACTION,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("table1");
		CheckTask checkTask = null;
		List<CheckTask> checkTaskList = new ArrayList<CheckTask>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				checkTask = new CheckTask();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				checkTask.setContractId(table1.getString("CONTRACT_ID"));
				checkTask.setCpId(table1.getString("CP_ID"));
				checkTask.setCpName(StringUtil.isEmpty(table1.getString("CP_NAME"))?"":table1.getString("CP_NAME"));
				checkTask.setSiteName(StringUtil.isEmpty(table1.getString("SITE_NAME"))?"":table1.getString("SITE_NAME"));
				checkTask.setSiteId(table1.getString("SITE_ID"));
				checkTaskList.add(checkTask);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("remark", rows.getString("remark"));
		map.put("checkTaskList", checkTaskList);
		map.put("result", rows.getString("result"));
		map.put("totalCount", rows.getString("TotalCount"));
		return map;
	}
	
	/**
	 * ��ȡ�ͻ�������Ա��Ϣ
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getCheckMakeUserList(String cpId) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "ZY23");
		api.addParam("QTCP", cpId);
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+CHECK_ACTION,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("table1");
		CheckTask checkTask = null;
		List<CheckTask> checkTaskList = new ArrayList<CheckTask>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				checkTask = new CheckTask();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				checkTask.setCpId(table1.getString("CP_ID"));
				checkTask.setUserId(table1.getString("USER_ID"));
				checkTask.setUserName(table1.getString("USER_NAME"));
				checkTaskList.add(checkTask);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("remark", rows.getString("remark"));
		map.put("checkTaskList", checkTaskList);
		map.put("result", rows.getString("result"));
		map.put("totalCount", rows.getString("TotalCount"));
		return map;
	}
	
	/**
	 * ��ȡϵͳģ����Ϣ
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getCheckMakeModelList() throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "ZY24");
		api.addParam("QTKEY", "1");
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+CHECK_ACTION,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("table1");
		CheckTask checkTask = null;
		List<CheckTask> checkTaskList = new ArrayList<CheckTask>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				checkTask = new CheckTask();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				checkTask.setModleId(table1.getString("MODEL_ID"));
				checkTask.setModleName(table1.getString("MODEL_NAME"));
				checkTaskList.add(checkTask);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("remark", rows.getString("remark"));
		map.put("checkTaskList", checkTaskList);
		map.put("result", rows.getString("result"));
		map.put("totalCount", rows.getString("TotalCount"));
		return map;
	}
	
	/**
	 * ����Ѳ������
	 * @param checkTask
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> checkMakeSubmit(CheckTask checkTask) throws Exception {
		LoginInfo loginInfo = (LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("imei", loginInfo.getLoginName());
		api.addParam("authentication", loginInfo.getLoginPwd());
		api.addParam("GNID", "RW19");
		api.addParam("QTCP", checkTask.getCpId());
		api.addParam("QTCT", checkTask.getContractId());
		api.addParam("QTST", checkTask.getSiteId());
		api.addParam("QTKEY1", checkTask.getUserId());
		api.addParam("QTKEY2", checkTask.getModleId());
		api.addParam("QTD1", checkTask.getTaskDate());
		api.addParam("QTD2", checkTask.getCompleteDate());
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getEtgWebsite() + File.separator + CHECK_ACTION, AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("remark", rows.getString("remark"));
		map.put("result", rows.getString("result"));
		return map;
	}
	
	/**
	 * ��ȡѲ�������б�
	 * @param pageSize
	 * @param pageNum
	 * @param cpName �ͻ�����
	 * @param siteName վ������
	 * @param taskStartDate ����ʼʱ��
	 * @param taskEndDate �������ʱ��
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getCheckRecordList(int pageSize,int pageNum, String cpName, String siteName, String taskStartDate, String taskEndDate) throws Exception {
		taskEndDate = DateUtil.andOneDay(taskEndDate);
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei",loginInfo.getLoginName());
		api.addParam("authentication",loginInfo.getLoginPwd());
		api.addParam("GNID", "RW18");
		api.addParam("QTPINDEX", String.valueOf(pageNum).trim());
		api.addParam("QTPSIZE", String.valueOf(pageSize).trim());
		api.addParam("QTKEY", URLEncoder.encode(cpName, AppConstant.ETG_INTERFACE_CHARSET));
		api.addParam("QTKEY2", URLEncoder.encode(siteName, AppConstant.ETG_INTERFACE_CHARSET));
		api.addParam("QTD1", URLEncoder.encode(taskStartDate, AppConstant.ETG_INTERFACE_CHARSET));
		api.addParam("QTD2", URLEncoder.encode(taskEndDate, AppConstant.ETG_INTERFACE_CHARSET));
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+File.separator+CHECK_ACTION,AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("table1");
		CheckTask checkTask = null;
		List<CheckTask> checkTaskList = new ArrayList<CheckTask>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				checkTask = new CheckTask();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				checkTask.setTaskId(table1.getString("TASK_ID"));
				checkTask.setCpName(StringUtil.isEmpty(table1.getString("CP_NAME"))?"":table1.getString("CP_NAME"));
				checkTask.setSiteName(StringUtil.isEmpty(table1.getString("SITE_NAME"))?"":table1.getString("SITE_NAME"));
				checkTask.setName(StringUtil.isEmpty(table1.getString("NAME"))?"":table1.getString("NAME"));
				checkTask.setTaskDate(StringUtil.isEmpty(table1.getString("TASK_DATE"))?"":table1.getString("TASK_DATE"));
				checkTask.setCompleteDate(StringUtil.isEmpty(table1.getString("COMPLETE_DATE"))?"":table1.getString("COMPLETE_DATE"));
				checkTask.setIsComplete(table1.getString("IS_COMPLETE").equals("1")?"��":"��");
				checkTask.setRecompleteDate(StringUtil.isEmpty(table1.getString("RECOMPLETE_DATE"))?"":table1.getString("RECOMPLETE_DATE"));
				checkTaskList.add(checkTask);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("remark", rows.getString("remark"));
		map.put("checkTaskList", checkTaskList);
		map.put("result", rows.getString("result"));
		map.put("totalCount", rows.getString("TotalCount"));
		return map;
	}
}
