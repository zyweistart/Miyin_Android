package com.freshpower.android.elec.activity;

import java.text.DecimalFormat;

import com.freshpower.android.elec.R;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN)
@SuppressLint("NewApi")
public class OnlineCalcActivity extends Activity {
	public DecimalFormat df =new DecimalFormat("0.00"); //��ȡ��С�������λ
	ImageView formula;//��ʽ�ı���
	TextView viewOne;//ѡ�еļ��㹫ʽ����
	TextView viewFrist;//��ʽ��һ������
	TextView viewSecond;//��ʽ�ڶ�������
	TextView viewThrid;//��ʽ����������
	TextView viewResult;//���
//	String formulaStr;
	int viewOneStr;
	int viewFristStr;
	int viewSecondStr;
	int viewThridStr;
	int viewResultStr;
	EditText frist;
	EditText second;
	EditText thrid;
	EditText result;
	double fristD;
	double secondD;
	double thridD;
	double resultD;
	int selectedId = 1;
	private Spinner calcTypeS;
	private Button calcTypeB;
	private PopupMenu popup = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.online_calc);
		bindEvent();
		formula = (ImageView)findViewById(R.id.formula);
		viewOne = (TextView)findViewById(R.id.viewOne);
		viewFrist = (TextView)findViewById(R.id.viewfrist);
		viewSecond = (TextView)findViewById(R.id.viewSecond);
		viewThrid = (TextView)findViewById(R.id.viewThrid);
		viewResult = (TextView)findViewById(R.id.viewResult);
		frist = (EditText)findViewById(R.id.viewfristEdit);
		second = (EditText)findViewById(R.id.viewSecondEdit);
		thrid = (EditText)findViewById(R.id.viewThridEdit);
		result = (EditText)findViewById(R.id.viewResultEdit);
		thrid.setEnabled(false);
		result.setVisibility(View.INVISIBLE);
		viewResult.setVisibility(View.INVISIBLE);
		ImageView reutnBtn = (ImageView)findViewById(R.id.nav_left);
		reutnBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				OnlineCalcActivity.this.onBackPressed();
			}
		});
		
		calcTypeS = (Spinner)findViewById(R.id.calc_type_s);
		calcTypeB = (Button)findViewById(R.id.calc_type_b);
		
		if(android.os.Build.VERSION.SDK_INT > android.os.Build.VERSION_CODES.HONEYCOMB){
			calcTypeS.setVisibility(8);
		}else{
			calcTypeB.setVisibility(8);
		}
		calcTypeS.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				int selectId = (int)calcTypeS.getSelectedItemId();
				Log.d("BID", "selectId:"+selectId);
				switch(selectId){
				case 1:
					viewOneStr = R.string.multiplying_power;
					viewFristStr = R.string.CT_ratio;
					viewSecondStr = R.string.PT_ratio;
					viewResultStr = R.string.multiplying_power;
					selectedId = 1;
					setTextView();
					break;
				case 2:
					viewOneStr = R.string.electricity;
					viewFristStr = R.string.now_read;
					viewSecondStr = R.string.last_read;
					viewThridStr = R.string.multiplying_power;
					viewResultStr = R.string.electricity;
					selectedId = 2;
					setTextView();
					break;
				case 3:
					viewOneStr = R.string.powerFactor;
					viewFristStr = R.string.hardPower;
					viewSecondStr = R.string.weast_factor;
					viewResultStr = R.string.powerFactor;
					selectedId = 3;
					setTextView();
					break;
				case 4:
					viewOneStr = R.string.hardPower;
					viewFristStr = R.string.line_votalge;
					viewSecondStr = R.string.elec_current;
					viewThridStr = R.string.powerFactor;
					viewResultStr = R.string.hardPower;
					selectedId = 4;
					setTextView();
					break;
				case 5:
					viewOneStr = R.string.weast_factor;
					viewFristStr = R.string.line_votalge;
					viewSecondStr = R.string.elec_current;
					viewThridStr = R.string.powerFactor;
					viewResultStr = R.string.weast_factor;
					selectedId = 5;
					setTextView();
					break;
				case 6:
					viewOneStr = R.string.loadRate;
					viewFristStr = R.string.avage_load;
					viewSecondStr = R.string.max_load;
					viewResultStr = R.string.loadRate;
					selectedId = 6;
					setTextView();
					break;
				case 7:
					viewOneStr = R.string.transformerCapacity;
					viewFristStr = R.string.apparentPower;
					viewSecondStr = R.string.capacity;
					viewResultStr = R.string.transformerloadrate;
					selectedId = 7;
					setTextView();
					break;
				case 8:
					viewOneStr = R.string.now_power;
					viewFristStr = R.string.activity_power;
					viewSecondStr = R.string.no_activity_power;
					viewResultStr = R.string.now_power;
					selectedId = 8;
					setTextView();
					break;
				}
				calcTypeS.setSelection(0);
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		});
	}
	public void onPopupCilck(View button){
		popup = new PopupMenu(this,button);
		getMenuInflater().inflate(R.menu.calc_menu, popup.getMenu());
		popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
			
			@Override
			public boolean onMenuItemClick(MenuItem item) {
				// TODO Auto-generated method stub
				switch(item.getItemId()){
				case R.id.magnification:
					viewOneStr = R.string.multiplying_power;
					viewFristStr = R.string.CT_ratio;
					viewSecondStr = R.string.PT_ratio;
					viewResultStr = R.string.multiplying_power;
					selectedId = 1;
					setTextView();
					break;
				case R.id.electricity:
					viewOneStr = R.string.electricity;
					viewFristStr = R.string.now_read;
					viewSecondStr = R.string.last_read;
					viewThridStr = R.string.multiplying_power;
					viewResultStr = R.string.electricity;
					selectedId = 2;
					setTextView();
					break;
				case R.id.powerFactor:
					viewOneStr = R.string.powerFactor;
					viewFristStr = R.string.hardPower;
					viewSecondStr = R.string.weast_factor;
					viewResultStr = R.string.powerFactor;
					selectedId = 3;
					setTextView();
					break;
				case R.id.hardPower:
					viewOneStr = R.string.hardPower;
					viewFristStr = R.string.line_votalge;
					viewSecondStr = R.string.elec_current;
					viewThridStr = R.string.powerFactor;
					viewResultStr = R.string.hardPower;
					selectedId = 4;
					setTextView();
					break;
				case R.id.wattlessPower:
					viewOneStr = R.string.weast_factor;
					viewFristStr = R.string.line_votalge;
					viewSecondStr = R.string.elec_current;
					viewThridStr = R.string.powerFactor;
					viewResultStr = R.string.weast_factor;
					selectedId = 5;
					setTextView();
					break;
				case R.id.loadRate:
					viewOneStr = R.string.loadRate;
					viewFristStr = R.string.avage_load;
					viewSecondStr = R.string.max_load;
					viewResultStr = R.string.loadRate;
					selectedId = 6;
					setTextView();
					break;
				case R.id.transformerCapacity:
					viewOneStr = R.string.transformerCapacity;
					viewFristStr = R.string.apparentPower;
					viewSecondStr = R.string.capacity;
					viewResultStr = R.string.transformerloadrate;
					selectedId = 7;
					setTextView();
					break;
				case R.id.apparentPower:
					viewOneStr = R.string.now_power;
					viewFristStr = R.string.activity_power;
					viewSecondStr = R.string.no_activity_power;
					viewResultStr = R.string.now_power;
					selectedId = 8;
					setTextView();
					break;
				}
				return true;
			}
		});
		popup.show();
	}
	
	
	
	private void bindEvent(){
//		TextView magnification = (TextView)findViewById(R.id.magnification);//����
//		magnification.setOnClickListener(new OnClickListener() {
//			@Override
//			public void onClick(View arg0) {
//				viewOneStr = R.string.multiplying_power;
//				viewFristStr = R.string.CT_ratio;
//				viewSecondStr = R.string.PT_ratio;
//				viewResultStr = R.string.multiplying_power;
//				selectedId = 1;
//				setTextView();
//			}
//		});
//		TextView electricity = (TextView)findViewById(R.id.electricity);//����
//		electricity.setOnClickListener(new OnClickListener() {
//			@Override
//			public void onClick(View arg0) {
//				viewOneStr = R.string.electricity;
//				viewFristStr = R.string.now_read;
//				viewSecondStr = R.string.last_read;
//				viewThridStr = R.string.multiplying_power;
//				viewResultStr = R.string.electricity;
//				selectedId = 2;
//				setTextView();
//			}
//		});
//		TextView powerFactor = (TextView)findViewById(R.id.powerFactor);//��������
//		powerFactor.setOnClickListener(new OnClickListener() {
//			@Override
//			public void onClick(View arg0) {
//				viewOneStr = R.string.powerFactor;
//				viewFristStr = R.string.hardPower;
//				viewSecondStr = R.string.weast_factor;
//				viewResultStr = R.string.powerFactor;
//				selectedId = 3;
//				setTextView();
//			}
//		});
//		TextView hardPower = (TextView)findViewById(R.id.hardPower);//�й�����
//		hardPower.setOnClickListener(new OnClickListener() {
//			@Override
//			public void onClick(View arg0) {
//				viewOneStr = R.string.hardPower;
//				viewFristStr = R.string.line_votalge;
//				viewSecondStr = R.string.elec_current;
//				viewThridStr = R.string.powerFactor;
//				viewResultStr = R.string.hardPower;
//				selectedId = 4;
//				setTextView();
//			}
//		});
//		TextView wattlessPower = (TextView)findViewById(R.id.wattlessPower);//�޹�����
//		wattlessPower.setOnClickListener(new OnClickListener() {
//			@Override
//			public void onClick(View arg0) {
//				viewOneStr = R.string.weast_factor;
//				viewFristStr = R.string.line_votalge;
//				viewSecondStr = R.string.elec_current;
//				viewThridStr = R.string.powerFactor;
//				viewResultStr = R.string.weast_factor;
//				selectedId = 5;
//				setTextView();
//			}
//		});
//		TextView loadRate = (TextView)findViewById(R.id.loadRate);//������
//		loadRate.setOnClickListener(new OnClickListener() {
//			@Override
//			public void onClick(View arg0) {
//				viewOneStr = R.string.loadRate;
//				viewFristStr = R.string.avage_load;
//				viewSecondStr = R.string.max_load;
//				viewResultStr = R.string.loadRate;
//				selectedId = 6;
//				setTextView();
//			}
//		});
//		TextView transformerCapacity = (TextView)findViewById(R.id.transformerCapacity);//��ѹ��������
//		transformerCapacity.setOnClickListener(new OnClickListener() {
//			@Override
//			public void onClick(View arg0) {
//				viewOneStr = R.string.transformerCapacity;
//				viewFristStr = R.string.apparentPower;
//				viewSecondStr = R.string.capacity;
//				viewResultStr = R.string.transformerloadrate;
//				selectedId = 7;
//				setTextView();
//			}
//		});
//		TextView apparentPower = (TextView)findViewById(R.id.apparentPower);//���ڹ���
//		apparentPower.setOnClickListener(new OnClickListener() {
//			@Override
//			public void onClick(View arg0) {
//				viewOneStr = R.string.now_power;
//				viewFristStr = R.string.activity_power;
//				viewSecondStr = R.string.no_activity_power;
//				viewResultStr = R.string.now_power;
//				selectedId = 8;
//				setTextView();
//			}
//		});
		Button exeBtn = (Button)findViewById(R.id.exeBtn);
		exeBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				calc();
			}
		});
	}
	@TargetApi(Build.VERSION_CODES.JELLY_BEAN)
	@SuppressLint("NewApi")
	private void setTextView(){
		frist.setFocusable(true);//ÿ��ѡ��ʽ����һ�ı���񽹵�
		frist.setText("");//ÿ��ѡ��ʽ��������������
		second.setText("");
		thrid.setText("");
		result.setText("");
		viewOne.setText(viewOneStr);//ÿ��ѡ��ʽ����������ʾֵ
		viewFrist.setText(viewFristStr);
		viewSecond.setText(viewSecondStr);
		if(selectedId==1){//����
			viewThrid.setText(viewResultStr);
			formula.setImageResource(R.drawable.f1);
			thrid.setEnabled(false);
			result.setVisibility(View.INVISIBLE);
			viewResult.setVisibility(View.INVISIBLE);
		}else if(selectedId == 2){//����
			formula.setImageResource(R.drawable.f2);
			result.setVisibility(View.VISIBLE);
			result.setEnabled(false);
			viewResult.setVisibility(View.VISIBLE);
			viewThrid.setText(viewThridStr);
			thrid.setEnabled(true);
			viewResult.setText(viewResultStr);
		}else if(selectedId == 3){//��������
			formula.setImageResource(R.drawable.f3);
			viewThrid.setText(viewResultStr);
			thrid.setEnabled(false);
			result.setVisibility(View.INVISIBLE);
			viewResult.setVisibility(View.INVISIBLE);
		}else if(selectedId == 4){//�й�����
			formula.setImageResource(R.drawable.f4);
			result.setVisibility(View.VISIBLE);
			result.setEnabled(false);
			viewResult.setVisibility(View.VISIBLE);
			viewThrid.setText(viewThridStr);
			thrid.setEnabled(true);
			viewResult.setText(viewResultStr);
		}else if(selectedId == 5){//�޹�����
			formula.setImageResource(R.drawable.f5);
			result.setVisibility(View.VISIBLE);
			result.setEnabled(false);
			viewResult.setVisibility(View.VISIBLE);
			viewThrid.setText(viewThridStr);
			thrid.setEnabled(true);
			viewResult.setText(viewResultStr);
		}else if(selectedId == 6){//������
			formula.setImageResource(R.drawable.f6);
			viewThrid.setText(viewResultStr);
			thrid.setEnabled(false);
			result.setVisibility(View.INVISIBLE);
			viewResult.setVisibility(View.INVISIBLE);
		}else if(selectedId == 7){//������
			formula.setImageResource(R.drawable.f7);
			viewThrid.setText(viewResultStr);
			thrid.setEnabled(false);
			result.setVisibility(View.INVISIBLE);
			viewResult.setVisibility(View.INVISIBLE);
		}else if(selectedId == 8){//���ڹ���
			formula.setImageResource(R.drawable.f8);
			viewThrid.setText(viewResultStr);
			thrid.setEnabled(false);
			result.setVisibility(View.INVISIBLE);
			viewResult.setVisibility(View.INVISIBLE);
		}
	}
	//����
	private void calc(){
		try{
		double temp;
		fristD = Double.parseDouble(frist.getText().toString());
		secondD = Double.parseDouble(second.getText().toString());
			if(selectedId==1){//����
				thrid.setText(df.format(fristD * secondD));
			}else if(selectedId == 2){//����
				if(fristD < secondD){
					Toast.makeText(OnlineCalcActivity.this, R.string.now_than_last_big, Toast.LENGTH_SHORT).show();
					return;
				}
				thridD = Double.parseDouble(thrid.getText().toString());
				result.setText(df.format((fristD - secondD)*thridD));
			}else if(selectedId == 3){//��������
				temp = Double.parseDouble(df.format(Math.sqrt(fristD * fristD + secondD * secondD)));
				if(temp <= 0){
					Toast.makeText(OnlineCalcActivity.this, R.string.not_zero, Toast.LENGTH_SHORT).show();
					return;
				}
				thrid.setText(df.format(fristD / temp));
			}else if(selectedId == 4){//�й�����
				thridD = Double.parseDouble(thrid.getText().toString());
				if(thridD > 1){
					Toast.makeText(OnlineCalcActivity.this, R.string.powerFactor_zero_one, Toast.LENGTH_SHORT).show();
					return;
				}
				result.setText(df.format(1.732*fristD*secondD*thridD));
			}else if(selectedId == 5){//�޹�����
				thridD = Double.parseDouble(thrid.getText().toString());
				if(thridD > 1){
					Toast.makeText(OnlineCalcActivity.this, R.string.powerFactor_zero_one, Toast.LENGTH_SHORT).show();
					return;
				}
				temp = Double.parseDouble(df.format(Math.sqrt( 1 - thridD * thridD )));
				result.setText(df.format(1.732*fristD*secondD*temp));
			}else if(selectedId == 6){//������
				if(secondD <= 0){
					Toast.makeText(OnlineCalcActivity.this, R.string.not_zero, Toast.LENGTH_SHORT).show();
					return;
				}
				thrid.setText(df.format(fristD / secondD));
			}else if(selectedId == 7){//������
				if(secondD <= 0){
					Toast.makeText(OnlineCalcActivity.this, R.string.not_zero, Toast.LENGTH_SHORT).show();
					return;
				}
				temp = fristD / secondD * 100;
				thrid.setText(df.format(temp)+"%");
			}else if(selectedId == 8){//���ڹ���
				temp = Math.sqrt(fristD * fristD + secondD * secondD);
				thrid.setText(df.format(temp));
			}
		}catch (Exception e){
			Toast.makeText(OnlineCalcActivity.this, R.string.error_input, Toast.LENGTH_SHORT).show();
			return;
		}
	}
}
