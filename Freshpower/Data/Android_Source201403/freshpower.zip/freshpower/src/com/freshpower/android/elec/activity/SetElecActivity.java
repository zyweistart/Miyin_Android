package com.freshpower.android.elec.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.AppCache;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.common.SysSetGroupOneAdapter;
import com.freshpower.android.elec.domain.LoginInfo;

public class SetElecActivity extends Activity{
	private RoundCornerListView groupTwolistview;
	private RoundCornerListView groupThreelistview;
	private String[] menuNames;
	private int[] menuIcoIds;
	private Resources res;
	private ImageView returnBtn;
	Integer update;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_set_elec);
		res = getResources();
		ActivityUtil.addActivity(this);
		findViews();
		setAdapter();
		returnBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				SetElecActivity.this.onBackPressed();
			}
		});
	}

	private void setAdapter(){
		SysSetGroupOneAdapter sysOneAdapter = new SysSetGroupOneAdapter(getGroupTwolistData(),SetElecActivity.this,R.layout.setup);
		groupTwolistview.setAdapter(sysOneAdapter);
		setListViewHeightBasedOnChildren(groupTwolistview);
		
		groupThreelistview.setAdapter(new SimpleAdapter(this,getGroupThreelistData(), R.layout.listitem_style_one, new String[] { AppConstant.ListItemCtlName.MENU_ICO, AppConstant.ListItemCtlName.MENU_NAME}, new int[] { R.id.menuIco,R.id.menuName}));
		setListViewHeightBasedOnChildren(groupThreelistview);
		groupThreelistview.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent,
					View view, int position, long id) {
				LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
				if(null!=loginInfo&&!StringUtil.isEmpty(loginInfo.getLoginName())){
					Intent intent = new Intent(SetElecActivity.this,WarningSetActivity.class);
					startActivity(intent);
				}else{
					Intent intent = new Intent(SetElecActivity.this,LoginActivity.class);
					intent.putExtra("LoginType", "warningSet");
					startActivity(intent);
				}
			}
		});

	}
	protected void onResume() {
		super.onResume();
	}
	private void findViews(){
		returnBtn = (ImageView)findViewById(R.id.nav_left);
		groupTwolistview = (RoundCornerListView)findViewById(R.id.setMenulistviewTwo);
		groupThreelistview = (RoundCornerListView)findViewById(R.id.setMenulistviewThree);
	}
	

	
	private List<Map<String, Object>> getGroupTwolistData(){
		menuNames=res.getStringArray(R.array.soft_myelectric_menuNames);
		menuIcoIds = new int[]{ R.drawable.tip ,R.drawable.vibration, R.drawable.gps};
		Boolean ckStatus[] = new Boolean[]{true,false,true}; 

		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < menuNames.length; i++)
		{
			Map<String, Object> listItem = new HashMap<String, Object>();
			listItem.put("menuIcoId", menuIcoIds[i]);
			listItem.put("menuNames", menuNames[i]);
			listItem.put("ckStatus", ckStatus[i]);
			listItems.add(listItem);
		}
		return listItems;
	}

	private List<Map<String, Object>> getGroupThreelistData(){
		menuNames=res.getStringArray(R.array.soft_warnValue_menuNames);
		menuIcoIds = new int[]{R.drawable.value};
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < menuNames.length; i++)
		{
			Map<String, Object> listItem = new HashMap<String, Object>();
			listItem.put(AppConstant.ListItemCtlName.MENU_ICO, menuIcoIds[i]);
			listItem.put(AppConstant.ListItemCtlName.MENU_NAME, menuNames[i]);
			listItems.add(listItem);
		}
		return listItems;
	}
	
	/***
	 * ��̬����listview�ĸ߶�
	 * 
	 * @param listView
	 */
	public void setListViewHeightBasedOnChildren(ListView listView) {
		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null) {
			return;
		}
		int totalHeight = 0;
		for (int i = 0; i < listAdapter.getCount(); i++) {
			View listItem = listAdapter.getView(i, null, listView);
			//View listItem = inflater.inflate(android.R.layout.simple_expandable_list_item_1, null);
			listItem.measure(0, 0);
			totalHeight += listItem.getMeasuredHeight();
		}
		ViewGroup.LayoutParams params = listView.getLayoutParams();
		params.height = totalHeight
				+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
		listView.setLayoutParams(params);
	}
}
