package com.freshpower.android.elec.activity;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;


public class InspectionRecordActivity extends Activity {
	private ImageView inspection_left;
	private RelativeLayout inspection_degree;
	private RelativeLayout inspection_tmp;
	private RelativeLayout inspection_ele;
	private RelativeLayout inspection_trms;
	private Button appraise_button;
	private String taskId;
	private Intent intent;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.activity_inspection_record);
		inspection_left=(ImageView)findViewById(R.id.nav_left);
		inspection_left.setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
        		InspectionRecordActivity.this.onBackPressed();
			}
		});
		Intent ite=getIntent();
		taskId=ite.getStringExtra("taskId");
		inspection_degree=(RelativeLayout)findViewById(R.id.inspection_degree);
		inspection_degree.setOnClickListener(new OnClickListener() {// վ��������Ϣ
        	@Override
			public void onClick(View v) {
        		startPutIntent(intent,"1","RW16",taskId);
			}
		});
		inspection_tmp=(RelativeLayout)findViewById(R.id.inspection_tmp);
		inspection_tmp.setOnClickListener(new OnClickListener() {// �����豸��ۡ��¶ȼ��
        	@Override
			public void onClick(View v) {
        		startPutIntent(intent,"3","RW17",taskId);
			}
		});
		inspection_ele=(RelativeLayout)findViewById(R.id.inspection_ele);
		inspection_ele.setOnClickListener(new OnClickListener() {// ���ܹ��������
        	@Override
			public void onClick(View v) {
        		startPutIntent(intent,"2","RW15",taskId);
			}
		});
		inspection_trms=(RelativeLayout)findViewById(R.id.inspection_trms);
		inspection_trms.setOnClickListener(new OnClickListener() {// TRMSϵͳѲ�Ӽ��
        	@Override
			public void onClick(View v) {
        		startPutIntent(intent,"4","RW17",taskId);
			}
		});
		
	}
	public void startPutIntent(Intent intent,String qtKey,String gnid,String qtTask){
		intent = new Intent(InspectionRecordActivity.this,OperationalAspectActivity.class);
		intent.putExtra("qtKey",qtKey);
		intent.putExtra("gnid", gnid);
		intent.putExtra("qtTask", qtTask);
		intent.putExtra("recordType", "2");
		startActivity(intent);
	};

}
