package com.freshpower.android.elec.domain;

public class CheckTaskInfo {//�����豸�¶�
	private String resultId;//���Id
	private String modelSubId;//�豸����Id
	private String name;//�豸����
	private String isComplete;//�Ƿ���ɣ�0��δ��ɣ�1�������
	private String scoutcheckContent;//��������
	private String codeId;//����Ӧ��д����
	private String scoutcheck;//��д���
	private String cpId;//��ҵId
	private String remark;//��ע
	public String getResultId() {
		return resultId;
	}
	public void setResultId(String resultId) {
		this.resultId = resultId;
	}
	public String getModelSubId() {
		return modelSubId;
	}
	public void setModelSubId(String modelSubId) {
		this.modelSubId = modelSubId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIsComplete() {
		return isComplete;
	}
	public void setIsComplete(String isComplete) {
		this.isComplete = isComplete;
	}
	public String getScoutcheckContent() {
		return scoutcheckContent;
	}
	public void setScoutcheckContent(String scoutcheckContent) {
		this.scoutcheckContent = scoutcheckContent;
	}
	public String getCodeId() {
		return codeId;
	}
	public void setCodeId(String codeId) {
		this.codeId = codeId;
	}
	public String getScoutcheck() {
		return scoutcheck;
	}
	public void setScoutcheck(String scoutcheck) {
		this.scoutcheck = scoutcheck;
	}
	public String getCpId() {
		return cpId;
	}
	public void setCpId(String cpId) {
		this.cpId = cpId;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
}
