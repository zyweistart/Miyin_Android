package com.freshpower.android.elec.activity;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.freshpower.android.elec.camera.CaptureActivity;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.AppConstant.IOMode;
import com.freshpower.android.elec.common.AppConstant.LineTerminator;
import com.freshpower.android.elec.common.ByteTransHelper;
import com.freshpower.android.elec.common.EnergeDataParse;
import com.freshpower.android.elec.common.Hex2String;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.R;
import com.freshpower.android.elec.service.UARTService;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.TextView;

public class PhoneDebugActivity extends Activity {

	private SharedPreferences trmsSharedPreferences;
	private Editor editor;
	private Button scanBtn;
	private List<Integer> readParamSetArr;
	private String[] groupOneCmd;
	private String[] debugSetgroupOneNameArr;
	private Resources resources;
	boolean isProcessing = false;
	private static final int PROMPT_SERIESNUM_GRAB_RROR = 0x01;
	private Message msgMessage;
	
	protected void initPreference() {
		trmsSharedPreferences = getSharedPreferences(AppConstant.SHARED_PREFERENCE_NAME, this.MODE_PRIVATE);
		editor = trmsSharedPreferences.edit();
		if(!trmsSharedPreferences.contains(AppConstant.ReadParam.CONFIGED)){
			editor.putBoolean(AppConstant.ReadParam.SHAREDP_NAME_VOLTAGE, true);
			editor.putBoolean(AppConstant.ReadParam.SHAREDP_NAME_ELECTRICITY, true);
			editor.putBoolean(AppConstant.ReadParam.SHAREDP_NAME_POWER, true);
			editor.putBoolean(AppConstant.ReadParam.SHAREDP_NAME_POWER_FACTOR, true);
			editor.putBoolean(AppConstant.ReadParam.SHAREDP_NAME_RATE, true);
			editor.putBoolean(AppConstant.ReadParam.SHAREDP_NAME_GROUP_ELECTRIC, true);
			editor.putBoolean(AppConstant.ReadParam.SHAREDP_NAME_POSITIVE_ELECTRIC, true);
			editor.putBoolean(AppConstant.ReadParam.SHAREDP_NAME_STATUS_WORD, true);
			editor.putString(AppConstant.SharedPreferencesKey.KEY_PREF_BAUDRATE, "9600");
			editor.putString(AppConstant.SharedPreferencesKey.KEY_PREF_DATABIT, "8");
			editor.putString(AppConstant.SharedPreferencesKey.KEY_PREF_STOPBIT, "1");
			editor.putString(AppConstant.SharedPreferencesKey.KEY_PREF_PARITY, "2");
			
			editor.putInt(AppConstant.SharedPreferencesKey.KEY_BAUDRATE_INDEX, 4);
			editor.putInt(AppConstant.SharedPreferencesKey.KEY_DATABIT_INDEX, 1);
			editor.putInt(AppConstant.SharedPreferencesKey.KEY_STOPBIT_INDEX, 0);
			editor.putInt(AppConstant.SharedPreferencesKey.KEY_PARITY_INDEX, 2);
			
			editor.commit();
		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(resultCode == AppConstant.RequestResultCode.RESULT_PHONEDEBUGACTIVITY)
		{
			String twoDimCode = data.getStringExtra("twoDimCode");
			try {
				Long.parseLong(twoDimCode);
				
				if(twoDimCode.length()==14){
					String td = twoDimCode.substring(twoDimCode.length()-2, twoDimCode.length());
					if("34".equals(td)){
						twoDimCode = twoDimCode.substring(0,twoDimCode.length()-2);//ȥ��ͨ��
						twoDimCode = String.valueOf(Long.parseLong(twoDimCode)+1);
						twoDimCode = ByteTransHelper.transStandardChar(twoDimCode, 12);//��0
					}else{
						twoDimCode = twoDimCode.substring(0,twoDimCode.length()-2);
					}
				}
				m_TextSentEdit.setText(twoDimCode);
				m_HexSentEdit.setText(twoDimCode);
			} catch (Exception e) {
				Toast.makeText(PhoneDebugActivity.this, R.string.response_date_nonum_invalid, Toast.LENGTH_LONG).show();
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	/*
	 * bindService��ش��뿪ʼ
	 */
	private UARTService uartService = null;
	
	private final ServiceConnection serviceConnection = new ServiceConnection () {

		@Override
		public void onServiceConnected(ComponentName arg0, IBinder arg1) {
			//InformationLogger.log("UARTService connected.\n");
			UARTService.LocalBinder binder = (UARTService.LocalBinder) arg1;
			uartService = binder.getService();
			uartService.init(PhoneDebugActivity.this, 
					m_MaxInBufferSize, 
					m_MaxOutBufferSize);
			uartService.SetConfig(m_BaudRate, (byte)m_DataBit, 
					(byte)m_StopBit, (byte)m_Parity, (byte)m_Flow);
			//yangz editor cancel
			m_RunThread = true;
			m_ReadUARTThread.start();
		}

		@Override
		public void onServiceDisconnected(ComponentName arg0) {
			//this callback will never happen
			//see code in unbindUARTService()
			//InformationLogger.log("UARTService disconnected.\n");
			//InformationLogger.flush();
			m_RunThread = false;
			if (uartService != null){
				uartService.close();
				unbindService(serviceConnection);
				uartService = null;
			}
		}
		
	};
	
	private void bindUARTService(){
		Intent intent = new Intent (this, UARTService.class);
		bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
	}
	
	private void unbindUARTService(){
		m_RunThread = false;
		try {
			m_ReadUARTThread.join();
		} catch (Exception e){}
		if (uartService != null){
			//InformationLogger.log("unbindUARTService being called.\n");
			//InformationLogger.flush();
			uartService.close();
			unbindService(serviceConnection);
			uartService = null;
		}
	}
	
	private void resumeUARTService(){
		if (uartService != null){
			uartService.resume();
		}
	}
	
	private void setUARTConfig(){
		if (uartService != null){
			uartService.SetConfig(m_BaudRate, (byte)m_DataBit, 
					(byte)m_StopBit, (byte)m_Parity, (byte)m_Flow);
		}
	}
	/*
	 * bindService��ش������
	 */
	
	/*
	 * �����ڴ���
	 */
	String m_StringBuffer;
	StringBuffer cmdStringBuffer = new StringBuffer();
	byte[] m_ByteBuffer;
	int [] m_ByteCount;
	byte [] m_SyncLock = new byte [0];
	boolean m_RunThread = false; 
	protected final class ReadUARTThread extends Thread{
		ReadUARTThread(){
			super();
		}
		
		@Override
		public void run(){
			//InformationLogger.log("ReadUARTThread started.\n");
			while (m_RunThread){
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
				}
				try {
					switch (m_IOMode){
					case IOMode.text:  //text mode
						synchronized (m_SyncLock){
							m_StringBuffer = uartService.ReadString();
							if (m_StringBuffer.length() == 0){
								break;
							}
						}
						m_ReceivedView.post(new Runnable (){
							@Override
							public void run() {
								synchronized (m_SyncLock){
									m_ReceivedView.append(m_StringBuffer);
								}
								m_ScrollHandler.post(m_ScrollRunnable);
							}
						});
						break;
					case IOMode.binary:  //binary mode
						synchronized (m_SyncLock){
							if (0x00 != uartService.ReadBytes(m_MaxInBufferSize, m_ByteBuffer, m_ByteCount)){
								break;
							}
							m_StringBuffer = convertByteBufferToString();
						}
						m_ReceivedView.post(new Runnable (){
							@Override
							public void run() {
								synchronized (m_SyncLock){
									//yangz editor
									//m_ReceivedView.append("\r\n"+m_StringBuffer);
									cmdStringBuffer.append(m_StringBuffer);
								}
								m_ScrollHandler.post(m_ScrollRunnable);
							}
						});
						break;
					}
				} catch (NullPointerException e){}
			}
			//InformationLogger.log("ReadUARTThread stopped.\n");
			//InformationLogger.flush();
		}
	}
	
	
	
	protected ReadUARTThread m_ReadUARTThread = new ReadUARTThread();
    protected String convertByteBufferToString(){
    	if (0 == m_ByteCount[0]){
    		return "";
    	}
    	StringBuilder ret = new StringBuilder(m_MaxInBufferSize * 3);
    	int i;
    	for (i = 0; i < m_ByteCount[0]; i++){
    		ret.append(Hex2String.toString(m_ByteBuffer[i]) + " ");
    	}
    	return ret.toString();
    }
    protected Handler m_ScrollHandler = new Handler();
    protected Runnable m_ScrollRunnable = new Runnable () {
		@Override
		public void run() {
			int off = m_ReceivedView.getMeasuredHeight() - m_ScrollView.getHeight(); 
		    if (off > 0) { 
		    	m_ScrollView.scrollTo(0, off); 
		    } 
		}
    };
	/*
	 * �����ڴ���,end.
	 */
	
	/*
	 * fields
	 */
    int m_IOMode;
    boolean m_Echo;
    String m_EchoPrefix;
    boolean m_ClearSendEdit;
    boolean m_AutoWrap;
    int m_LineTerminator;
    int m_BaudRate;
    int m_DataBit;
    int m_StopBit;
    int m_Parity;
    int m_Flow;
    int m_MaxInBufferSize;
    int m_MaxOutBufferSize;
    boolean m_SessionLog;
    
    TextView m_ReceivedView;
    EditText m_TextSentEdit;
    EditText m_HexSentEdit;
    ScrollView m_ScrollView;
	HorizontalScrollView m_HorizontalScrollView;
	/*
	 * fields end.
	 */
    
	/*
	 * Overridden methods
	 */
    @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_phone_debug);
		ActivityUtil.addActivity(this);
		initPreference();
		resources= getResources();
		scanBtn = (Button)findViewById(R.id.toScanImgBtn);
		ImageButton imgBtn = (ImageButton)findViewById(R.id.sysSetImgBtn);
		imgBtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(PhoneDebugActivity.this,PhoneDebugSetActivity.class);
				startActivity(intent);
			}
		});
		
		scanBtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(PhoneDebugActivity.this, CaptureActivity.class);
				intent.putExtra("operateType", "phoneDebug");
				startActivityForResult(intent, AppConstant.RequestResultCode.REQUEST_PHONEDEBUGACTIVITY);
			}
		});
		
		debugSetgroupOneNameArr = resources.getStringArray(R.array.phoneDebugSet_GroupOne);
	
		m_TextSentEdit = (EditText) findViewById(R.id.toSendTextEdit);
		m_HexSentEdit = (EditText) findViewById(R.id.toSendHexEdit);
		m_ScrollView = (ScrollView) findViewById(R.id.scrollView);
        LoadDataFromPreferences();
        if (IOMode.text == m_IOMode && !m_AutoWrap){
        	m_ReceivedView = (TextView) findViewById(R.id.receivedBinaryView);
        	m_ReceivedView.setVisibility(View.GONE);
        	m_HorizontalScrollView.setVisibility(View.VISIBLE);
        	m_ReceivedView = (TextView) findViewById(R.id.receivedTextView);
        	/*m_HorizontalScrollView.setVisibility(View.GONE);
        	m_ReceivedView = (TextView) findViewById(R.id.receivedBinaryView);
        	m_ReceivedView.setVisibility(View.VISIBLE);*/
        }
       	else{
        	m_ReceivedView = (TextView) findViewById(R.id.receivedBinaryView);
        	m_ReceivedView.setVisibility(View.VISIBLE);
        }
        bindUARTService();
        
        Button button = (Button) findViewById(R.id.sendButton);
        button.setOnClickListener(new OnClickListener (){
			@Override
			public void onClick(View arg0) {
				String m_HexSentEditStr = m_HexSentEdit.getText().toString();
				
				if(isProcessing){
					Toast.makeText(PhoneDebugActivity.this, R.string.msg_operate_processing_alert, Toast.LENGTH_SHORT).show();
					return;
				}
				
				if(StringUtil.isEmpty(m_HexSentEditStr)){
					Toast.makeText(PhoneDebugActivity.this, R.string.msg_series_number_input_alert, Toast.LENGTH_SHORT).show();
					return;
				}
				
				if(m_HexSentEditStr.length()!=12){
					Toast.makeText(PhoneDebugActivity.this, R.string.msg_series_number_input_tooLong_alert, Toast.LENGTH_SHORT).show();
					return;
				}
				
				if (uartService == null)
					return;
				switch (m_IOMode){
				case IOMode.text:
					sendText();
					break;
				case IOMode.binary:
					//yangz editor
					sendCommands();
					break;
				}
			}
        });
        
        Button getSeriesNumButton = (Button) findViewById(R.id.getSeriesNumButton);
        getSeriesNumButton.setOnClickListener(new OnClickListener (){
			@Override
			public void onClick(View arg0) {
				if(isProcessing){
					Toast.makeText(PhoneDebugActivity.this, R.string.msg_operate_processing_alert, Toast.LENGTH_SHORT).show();
					return;
				}
				startSendSeriesNumberThread();
			}
        });
        
        ImageView iv=(ImageView)findViewById(R.id.nav_left);
        iv.setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
	    		PhoneDebugActivity.this.finish();	
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		//getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
    @Override 
    public void onBackPressed() { 
    	super.onBackPressed();
    	//System.exit(0);
    }

    /*@Override
    protected void onSaveInstanceState (Bundle outState){
    	super.onSaveInstanceState(outState);
    	SaveDataOfInstanceState(outState);
    }*/
    
    @Override
    protected void onStart() {
        super.onStart();
        // The activity is about to become visible.
        //LoadDataFromPreferences();
        if (IOMode.text == m_IOMode){
        	m_HexSentEdit.setVisibility(View.GONE);
        	m_TextSentEdit.setVisibility(View.VISIBLE);
        }
        if (IOMode.binary == m_IOMode){
        	m_HexSentEdit.setVisibility(View.VISIBLE);
        	m_TextSentEdit.setVisibility(View.GONE);
        }
        if (IOMode.text == m_IOMode && !m_AutoWrap){
        	m_ReceivedView = (TextView) findViewById(R.id.receivedBinaryView);
        	m_ReceivedView.setVisibility(View.GONE);
        	m_HorizontalScrollView.setVisibility(View.VISIBLE);
        	m_ReceivedView = (TextView) findViewById(R.id.receivedTextView);
        	/*m_HorizontalScrollView.setVisibility(View.GONE);
        	m_ReceivedView = (TextView) findViewById(R.id.receivedBinaryView);
        	m_ReceivedView.setVisibility(View.VISIBLE);*/
        }
        else{
        	m_ReceivedView = (TextView) findViewById(R.id.receivedBinaryView);
        	m_ReceivedView.setVisibility(View.VISIBLE);
        }
    }

    @Override
	protected void onResume(){
		super.onResume();
		LoadDataFromPreferences();
		resumeUARTService();
		setUARTConfig();
	}

    @Override
	protected void onDestroy(){
		//InformationLogger.log("onDestroy() being called.\n");
		unbindUARTService();
		//InformationLogger.log("super.onDestroy() being called.\n");
		//InformationLogger.flush();
		super.onDestroy();
		Toast.makeText(this, R.string.disconnect_usb_accessory, Toast.LENGTH_LONG).show();
	}
    /*
	 * Overridden methods end.
	 */

    protected void LoadDataFromPreferences(){
    	SharedPreferences sharedPref =  this.getSharedPreferences(AppConstant.SHARED_PREFERENCE_NAME, this.MODE_PRIVATE);
    	String pref = sharedPref.getString(AppConstant.SharedPreferencesKey.KEY_PREF_IOMODE, "1");
    	m_IOMode = Integer.parseInt(pref);
    	m_Echo = sharedPref.getBoolean(AppConstant.SharedPreferencesKey.KEY_PREF_ECHO, true);
    	m_EchoPrefix = sharedPref.getString(AppConstant.SharedPreferencesKey.KEY_PREF_ECHOPREFIX, ">>>");
    	m_ClearSendEdit = sharedPref.getBoolean(AppConstant.SharedPreferencesKey.KEY_PREF_CLEARSENDEDIT, true);
    	m_AutoWrap = sharedPref.getBoolean(AppConstant.SharedPreferencesKey.KEY_PREF_AUTOWRAP, true);
    	pref = sharedPref.getString(AppConstant.SharedPreferencesKey.KEY_PREF_LT, "0");
    	m_LineTerminator = Integer.parseInt(pref);
    	pref = sharedPref.getString(AppConstant.SharedPreferencesKey.KEY_PREF_BAUDRATE, "9600");
    	m_BaudRate = Integer.parseInt(pref);
    	pref = sharedPref.getString(AppConstant.SharedPreferencesKey.KEY_PREF_DATABIT, "8");
    	m_DataBit = Integer.parseInt(pref);
    	pref = sharedPref.getString(AppConstant.SharedPreferencesKey.KEY_PREF_STOPBIT, "1");
    	m_StopBit = Integer.parseInt(pref);
    	pref = sharedPref.getString(AppConstant.SharedPreferencesKey.KEY_PREF_PARITY, "0");
    	m_Parity = Integer.parseInt(pref);
    	pref = sharedPref.getString(AppConstant.SharedPreferencesKey.KEY_PREF_FLOW, "0");
    	m_Flow = Integer.parseInt(pref);
    	pref = sharedPref.getString(AppConstant.SharedPreferencesKey.KEY_PREF_INBUFFERSIZE, "256");
    	m_MaxInBufferSize = Integer.parseInt(pref);
    	pref = sharedPref.getString(AppConstant.SharedPreferencesKey.KEY_PREF_OUTBUFFERSIZE, "128");
    	m_MaxOutBufferSize = Integer.parseInt(pref);
    	pref = sharedPref.getString(AppConstant.SharedPreferencesKey.KEY_PREF_CHARSET, "2");
    	m_ByteBuffer = new byte [m_MaxInBufferSize];
    	m_ByteCount = new int [1];
    	
    	readParamSetArr = new ArrayList<Integer>();
    	for (int i = 0; i < 8; i++) {
    		boolean booleanPref = sharedPref.getBoolean(AppConstant.ReadParam.readParamMap.get(i), false);
    		if(booleanPref){
    			readParamSetArr.add(i);
    		}
		}
    	
    }
    
    protected void sendText(){
    	String str = m_TextSentEdit.getText().toString();
    	String LT = "";
    	switch (m_LineTerminator){
    	case LineTerminator.crlf:
    		str = str.replaceAll("\n", "\r\n");
    		LT = "\r\n";
    		break;
    	case LineTerminator.cr:
    		str = str.replaceAll("\n", "\r");
    		LT = "\r";
    		break;
    	case LineTerminator.lf:
    		LT = "\n";
    		break;
    	}
    	if (str.length() > LT.length()){
        	if (!LT.equals(str.substring(str.length() - LT.length()))){
        		str += LT;
        	}
    	}
    	else
    		str += LT;
    	if ( 0 == uartService.SendString(str)){
        	if (m_Echo){
        		m_ReceivedView.append(m_EchoPrefix + str);
        	}
        	if (m_ClearSendEdit)
        		m_TextSentEdit.getText().clear();
    	}
    	else {
    		Toast.makeText(this, R.string.content_larger_than_outbuffersize, Toast.LENGTH_LONG).show();
    	}
    }
    
    protected void sendBinary(String str){
    	//String str = m_HexSentEdit.getText().toString() + " ";
    	str+=" ";
    	byte[] byteArray = new byte [str.length()];
    	int bPtr = 0; int sPtr = 0;
    	int pos = str.indexOf(" ");  
    	while (-1 != pos){
    		String s = str.substring(sPtr, pos);
    		if (s.equals("") || s.equals(" ")){
    			//do nothing
    		}
    		else{
        		if (s.length() % 2 == 0){
        			for (int i = 0; i < s.length() / 2; i++){
        				try{
        					byteArray[bPtr] = (byte) Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16);
        					bPtr++;
        				}
        				catch (NumberFormatException e){
        					//do nothing or notify user input error
        				}
        			}
        		}
        		else{
        			for (int i = 0; i < (s.length() + 1) / 2; i++){
        				String tem;
        				if (i == 0){
        					tem = s.substring(0, 1);
        				}
        				else{
        					tem = s.substring(i * 2 - 1, i * 2 + 1);
        				}
        				try{
        					byteArray[bPtr] = (byte) Integer.parseInt(tem, 16);
        					bPtr++;
        				}
        				catch (NumberFormatException e){
        					//do nothing or notify user input error
        				}
        			}
        		}
    		}
    		sPtr = pos + 1;
    		pos = str.indexOf(" ", sPtr);
    	}
    	if ( 0 == uartService.SendBytes(bPtr, byteArray)){
        	if (m_ClearSendEdit){//YANGZ
        		m_HexSentEdit.post(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						//m_HexSentEdit.getText().clear();
					}
				});
        	}
    	}
    	else {
    		Toast.makeText(this, R.string.content_larger_than_outbuffersize, Toast.LENGTH_LONG).show();
    	}
    }
    
    void sendCommands(){
    	m_ReceivedView.setText("");//clear
    	groupOneCmd = resources.getStringArray(R.array.phoneDebugSet_GroupOneCmd);
    
    	String seriesNumber = m_HexSentEdit.getText().toString();
    	
    	StringBuffer seriesNumberRevertSb = new StringBuffer();
    	for (int i = seriesNumber.length()/2-1; i >= 0; i--){
    		seriesNumberRevertSb.append(seriesNumber.substring(i * 2, i * 2 + 2));
		}
    	
    	String tempCmd="";
    	for (int i = 0; i < readParamSetArr.size(); i++) {
    		tempCmd = groupOneCmd[readParamSetArr.get(i)];
    		tempCmd = tempCmd.replace("{0}", seriesNumberRevertSb.toString());
    		String csBeforeStr = tempCmd.substring(0,tempCmd.indexOf("{1}")).replaceAll(" ", "");
        	tempCmd = tempCmd.replace("{1}",EnergeDataParse.getCS(csBeforeStr));
    		groupOneCmd[readParamSetArr.get(i)] = tempCmd.replaceAll(" ", "");
		}
    	
    	startSendCmdThread();
    }
    
    
    /**
     * ����ָ���߳� start
     */
    int sendIndex=0;
    String energeData="";
    int currentCmdIndex=0;
    String readParamName;
    SendCmdThread sendCmdThread = new SendCmdThread();
    class SendCmdThread extends Thread{
    	SendCmdThread(){
			super();
		}
		
		@Override
		public void run(){
			isProcessing = true;
			try {
				for(sendIndex=0;sendIndex<readParamSetArr.size();sendIndex++) {
					//clear
					cmdStringBuffer = new StringBuffer();
					sendBinary(groupOneCmd[readParamSetArr.get(sendIndex)]);
					/*
					m_ReceivedView.post(new Runnable() {
						
						@Override
						public void run() {
							m_ReceivedView.append("���ͣ�"+groupOneCmd[readParamSetArr.get(sendIndex)]+"\r\n");
						}
					});
					*/
					int j=0;
					while(j<20){
						try {
							Thread.sleep(100);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						
						//ҵ����
						energeData = EnergeDataParse.grabEnergeDataString(EnergeDataParse.fillZeroOneChar(cmdStringBuffer.toString()));
						currentCmdIndex = readParamSetArr.get(sendIndex);
						readParamName = "��ȡ "+debugSetgroupOneNameArr[currentCmdIndex]+"=======\r\n";
						if(!StringUtil.isEmpty(energeData)){
							m_ReceivedView.post(new Runnable() {
								@Override
								public void run() {
									try {
										m_ReceivedView.append(readParamName);
										m_ReceivedView.append(EnergeDataParse.processByteToBrizStr(currentCmdIndex, energeData));
										m_ReceivedView.append("\r\n\r\n");
									} catch (Exception e) {
										e.printStackTrace();
									}
									m_ScrollHandler.post(m_ScrollRunnable);
								}
							});
							
							break;
						}else if(j==19 && StringUtil.isEmpty(cmdStringBuffer.toString())){
							m_ReceivedView.post(new Runnable() {
									@Override
									public void run() {
										m_ReceivedView.append(readParamName);
										m_ReceivedView.append(resources.getString(R.string.time_out_request));
										m_ReceivedView.append("\r\n\r\n");
										m_ScrollHandler.post(m_ScrollRunnable);
									}
							});
						}else if(j==19 && !StringUtil.isEmpty(cmdStringBuffer.toString())){
							m_ReceivedView.post(new Runnable() {
									@Override
									public void run() {
										m_ReceivedView.append(readParamName);
										m_ReceivedView.append(resources.getString(R.string.response_date_invalid));
										m_ReceivedView.append("\r\n\r\n");
										m_ScrollHandler.post(m_ScrollRunnable);
									}
							});
						}
	
						j++;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				isProcessing = false;
			}
		}
	}
    
    void startSendCmdThread(){
        sendIndex = 0 ;
        sendCmdThread = new SendCmdThread();
        sendCmdThread.start();
    }
    
    /**
     * ����ָ���߳� end
     */
    
    
    /**
     * ��ȡ���к��߳�start
     */
    SendSeriesNumberThread sendSeriesThread = new SendSeriesNumberThread();
    class SendSeriesNumberThread extends Thread{
    	SendSeriesNumberThread(){
			super();
		}
		
		@Override
		public void run(){
			isProcessing = true;
			try {
				int j = 0;
				cmdStringBuffer = new StringBuffer();
				sendBinary(resources.getString(R.string.seriesNumberGetCmd));
				while(j<20){
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					
					//ҵ����
					energeData = EnergeDataParse.reverseOrderByByte(EnergeDataParse.grabSeriesNumString(EnergeDataParse.fillZeroOneChar(cmdStringBuffer.toString())));
					if(!StringUtil.isEmpty(energeData)){
						m_HexSentEdit.post(new Runnable() {
							@Override
							public void run() {
								m_HexSentEdit.setText(energeData);
							}
						});
						
						break;
					}else if(j==19){
						msgMessage = new Message();
						msgMessage.what = PROMPT_SERIESNUM_GRAB_RROR;
						promptHandler.sendMessage(msgMessage);
					}
					j++;
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				isProcessing = false;
			}
		}
	}
    
    void startSendSeriesNumberThread(){
    	sendSeriesThread = new SendSeriesNumberThread();
    	sendSeriesThread.start();
    }
    
    /**
     * ��ȡ���к��߳�end
     */
    
    private Handler  promptHandler = new Handler(){
    	public void handleMessage(Message msg) {
    		switch (msg.what) {
			case PROMPT_SERIESNUM_GRAB_RROR:
				Toast.makeText(PhoneDebugActivity.this, R.string.time_out_request, Toast.LENGTH_SHORT).show();
				break;
			default:
				break;
			}
    	};
    };
}

