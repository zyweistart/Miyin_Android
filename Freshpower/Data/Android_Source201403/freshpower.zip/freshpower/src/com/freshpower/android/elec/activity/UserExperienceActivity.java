package com.freshpower.android.elec.activity;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.AppConstant;

public class UserExperienceActivity extends Activity {
	public static DecimalFormat df = new DecimalFormat("0.00"); // ��ȡ��С�������λ
	double[][] threePhaseCurrentLeft = new double[4][3];// ������������¼
	double[][] threePhaseCurrentRight = new double[4][3];// �Ҳ����������¼
	public Timer timer = new Timer();
	private Boolean Start = true;
	static int time = 1;// ÿ12�μ��㵱ǰ�ܵ���
	static int timeBar = 1;// ��״ͼʹ��ˢ�½���ֵ
	static ArrayList<List<double[][]>> currentList = new ArrayList<List<double[][]>>();
	OnOffThread myThread = new OnOffThread();
	Intent intent = null;
	static int textViewNum = 1;
	int textViewNumTemp = 1;
	static double[] coefficientList = new double[12];// ���ֵlist
	static double coefficient = 0;// ϵ��B
	// ����������һ�ν����Ƿ�ͱ��ν�����ͬһ���ߣ��Ƿ�����ֵ������䣩
	// ����ͼ�ε���·
	static String inComingLine = "";
	// ----------------------
	// �˸����ذ�ť
	ImageButton imgBtn1 = null;
	ImageButton imgBtn2 = null;
	ImageButton imgBtn3 = null;
	ImageButton imgBtn4 = null;
	ImageButton imgBtn5 = null;
	ImageButton imgBtn6 = null;
	ImageButton imgBtn7 = null;
	ImageButton imgBtn8 = null;
	ImageButton imgBtn9 = null;// ĸ�߿���
	ImageView returnButton = null;// ���ذ�ť
	// -----------------
	// �˸���ť�Ƿ�������
	public static Boolean[] finalB = new Boolean[8];
	public static Boolean finalB9 = false;// �м俪�أ�Ĭ��Ϊ��բ״̬
	// ------------------------------
	public static double[] a = new double[12];// ����a
	public static double[] b = new double[12];// ����b
	public static double[] c = new double[12];// ����c
	// �˸���ʾ������TextView
	TextView gameSwitch1 = null;
	TextView gameSwitch2 = null;
	TextView gameSwitch3 = null;
	TextView gameSwitch4 = null;
	TextView gameSwitch5 = null;
	TextView gameSwitch6 = null;
	TextView gameSwitch7 = null;
	TextView gameSwitch8 = null;
	// ---------------------------
	// չʾҳ���ܸ��ɡ��ܵ���
	TextView sumCharge = null;
	TextView sumTotalPower = null;
	double sumChargeDouble = 0; // �ܸ���
	double sumChargeLeft = 0;
	double sumChargeRight = 0;
	double sumTotalPowerDouble = 0;
	double[] nowMinutes = new double[8];// ��ǰ����ӵĵ���
	double[] lastMinutes = new double[8];// ��һ���ӵĵ�����
	double lastMintesSum = 0;// ��һ���������ߵ��ܵ���
	double lastMintesLeft = 0;
	double lastMintesRight = 0;
	static double[] sumTotalPowerDoubleList = new double[12];// �ܵ���list(���ڵ�ǰչʾ��12���������)
	double[] totalPowerDouble = new double[8];// ͬһʱ�������߲�ͬ�ĵ���ֵ
	ArrayList<double[]> totalPowerDoubleList = new ArrayList<double[]>();
	static double[] sumChargeDoubleList = new double[12];// �ܸ���List������չʾ��12���㣩
	static double[] sumTotalPowerMoneyList = new double[12];// �ܵ��list
	public static double powerFactor = 0;
	private boolean isLoadReport = false;// �Ƿ����������ɱ���
	private double loadReportValue = 0; // �����ɱ���ֵ
	ArrayList<double[]> chargeDoubleList = new ArrayList<double[]>();// �����ܸ���
	double chargeSumList[] = new double[8];// ���ߵ�������(��Ž���list����ͬһʱ��İ����߲�ֵͬ)

	double electriCurrentTemp = 0;// ��¼�������ĵ���ֵ������ÿ����ǰ������Ĳ���

	// ---------------

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		SetThresholdActivity.isEffective = true;
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_user_experience);
		// Ϊ������ʹ�õ���list����ֵ����ֹ����ָ�����
		for (int i = 0; i < 12; i++) {
			List temp = new ArrayList<double[][]>();
			for (int j = 0; j < 2; j++) {
				temp.add(new double[4][3]);
			}
			chargeDoubleList.add(new double[8]);// �����ܸ��ɳ�ʼ��
			totalPowerDoubleList.add(new double[8]);// �����ܵ�����ʼ��
			currentList.add(temp);
		}
		for (int i = 0; i < 8; i++) {
			finalB[i] = true;
		}
		this.setCurrentTextView();
		// --------------------------
		// ҳ����ʾ��ʾ��Ϣ������˵����
		TextView opeaterShow = (TextView) findViewById(R.id.title);
		opeaterShow.setText(R.string.experience_top);
		TextView opeaterShowTitle = (TextView) findViewById(R.id.content);
		opeaterShowTitle.setText(R.string.experience_buttom);
		// ---------------------------------
		myThread.start(); // ������������߳�
		// ---------------------------------
		// ������Ϣ
		ImageView moreButton = (ImageView) findViewById(R.id.game_morebtn_select);
		moreButton.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				Intent intent = new Intent();
				intent.setClass(UserExperienceActivity.this, MoreActivity.class);
				startActivity(intent);
			}
		});
		// ע��
		RelativeLayout registerButton = (RelativeLayout) findViewById(R.id.UserExperienceBottom);
		registerButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(UserExperienceActivity.this,
						UserRegisterActivity.class);
				startActivity(intent);
				finish();
			}
		});
		// ���޸��ɱ���
		RelativeLayout overLoad = (RelativeLayout) findViewById(R.id.UserExperienceLoad);
		overLoad.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent();
				intent.putExtra("type", "load");
				intent.setClass(UserExperienceActivity.this,
						SetThresholdActivity.class);
				startActivityForResult(intent,
						AppConstant.RequestResultCode.REQUEST_LOAD_REPORT);
			}
		});
		powerFactor = getCosRandom();
		buttonOnClick();
		gameSwitchOnclick();
		ActivityUtil.addActivity(this);
	}

	private Handler handler = new Handler() {
		@SuppressLint("HandlerLeak")
		public void handleMessage(android.os.Message msg) {
			List<double[][]> Current = new ArrayList<double[][]>();
			Current = setCurrentTextView();
			currentList.remove(0);
			currentList.add(11, Current);
			chargeDoubleList.remove(0);
			chargeDoubleList.add(11, chargeSumList);
			double[][] temp = null;
			for (int i = 0; i < 12; i++) {
				if (textViewNum >= 5) {// ÿ��list��ǰ�ĸ�Ϊ�Ҳ�
					temp = currentList.get(i).get(1);
					a[i] = temp[textViewNum - 5][0];// ÿ����һ��ĵ���ֵ
					b[i] = temp[textViewNum - 5][1];
					c[i] = temp[textViewNum - 5][2];
					sumChargeDoubleList[i] = chargeDoubleList.get(i)[textViewNum - 1];// ÿ����һ��ĸ���ֵ
				} else {// ÿ��list�к��ĸ�Ϊ���
					temp = currentList.get(i).get(0);
					a[i] = temp[textViewNum - 1][0];// ÿ����һ��ĵ���ֵ
					b[i] = temp[textViewNum - 1][1];
					c[i] = temp[textViewNum - 1][2];
					sumChargeDoubleList[i] = chargeDoubleList.get(i)[textViewNum - 1];// ÿ����һ��ĸ���ֵ
				}
			}
			textViewNumTemp = textViewNum;// ���˴ν������·��ż�¼����
			if (time % 12 == 0) {// ������·����һ����ʱ�����²��õ���ͼ
				totalPowerDoubleList.remove(0);
				totalPowerDoubleList.add(11, totalPowerDouble);
				// Log.d("BID","totalPowerDoubleList��"+totalPowerDoubleList.get(11)[4]);
				timeBar++;
			}
			for (int i = 0; i < 12; i++) {
				sumTotalPowerDoubleList[i] = Double.valueOf(df
						.format(totalPowerDoubleList.get(i)[textViewNum - 1]));
				sumTotalPowerMoneyList[i] = Double.valueOf(df
						.format(totalPowerDoubleList.get(i)[textViewNum - 1]
								* businessCalculationTime()));
			}
		};
	};

	class OnOffThread extends Thread {

		private boolean isDestory = false;

		void setDestory(boolean isDestory) {
			this.isDestory = isDestory;
		}

		@Override
		public void run() {
			try {
				while (!isDestory) {
					if (isDestory)
						break;
					Message msg = new Message();
					msg.what = 1;
					handler.sendMessage(msg);
					Thread.sleep(5000);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public List<double[][]> setCurrentTextView() {
		List<TextView> listGame = new ArrayList<TextView>();
		gameSwitch1 = (TextView) findViewById(R.id.game_switch01);
		gameSwitch2 = (TextView) findViewById(R.id.game_switch02);
		gameSwitch3 = (TextView) findViewById(R.id.game_switch03);
		gameSwitch4 = (TextView) findViewById(R.id.game_switch04);
		gameSwitch5 = (TextView) findViewById(R.id.game_switch05);
		gameSwitch6 = (TextView) findViewById(R.id.game_switch06);
		gameSwitch7 = (TextView) findViewById(R.id.game_switch07);
		gameSwitch8 = (TextView) findViewById(R.id.game_switch08);
		listGame.add(gameSwitch1);
		listGame.add(gameSwitch2);
		listGame.add(gameSwitch3);
		listGame.add(gameSwitch4);
		listGame.add(gameSwitch5);
		listGame.add(gameSwitch6);
		listGame.add(gameSwitch7);
		listGame.add(gameSwitch8);
		chargeSumList = new double[8];// ���½�����ʵ����,��ֹ��β���ͬһ�ڴ��ַ
		threePhaseCurrentLeft = new double[4][3];
		threePhaseCurrentRight = new double[4][3];
		Double rnd = Math.random();// ����������������
		if (rnd < 0.1) {
			rnd += 0.1;
		}
		rnd = Double.valueOf(df.format(rnd));
		double electricCurrentLeft = 0;
		// ��¼�������ĵ���ֵ������ÿ����ǰ������Ĳ���������5%
		if (time == 1) {
			electricCurrentLeft = 1443.4 * rnd;
			electriCurrentTemp = electricCurrentLeft;
		} else {
			if (rnd > 0.5) {
				electricCurrentLeft = electriCurrentTemp * 1.05;
			} else {
				electricCurrentLeft = electriCurrentTemp * 0.95;
			}
		}
		if (electricCurrentLeft >= 1345) {
			electricCurrentLeft = 1443 - 108.2;
		}
		if (electricCurrentLeft < 160) {
			electricCurrentLeft = 160;
		}
		electriCurrentTemp = electricCurrentLeft;
		// ---------------------------------------------------
		// ��������������·�ĵ����˴�֮��������5%
		rnd = Math.random();// ����������������
		double electricCurrentRight = 0;
		if (rnd > 0.5) {
			electricCurrentRight = electricCurrentLeft * 1.05;
		} else {
			electricCurrentRight = electricCurrentLeft * 0.95;
		}
		if (electricCurrentRight >= 1345) {
			electricCurrentRight = 1443 - 108.2;
		}

		int sign = -1;
		if (isLoadReport) {
			double transCurrent = this.setTransCurrent(loadReportValue);// �����ɱ�������
			if (finalB9) {
				setSixCurrent(transCurrent);
			} else {
				threePhaseCurrentLeft = setThreePhaseCurrent(transCurrent, 1);
				threePhaseCurrentRight = setThreePhaseCurrent(transCurrent, 2);
			}
			isLoadReport = false;
		} else {
			// --------------------------------------------------
			// ����Ia��Ib��Ic�������֮��ķ��Ȳ�����5%
			// int sign = -1;
			double scope = 0.025;
			if (finalB9) {
				for (int i = 0; i < 3; i++) {
					rnd = Math.random();
					if (rnd > 0.5) {
						sign = -1;
					} else {
						sign = 1;
					}
					if (finalB[0]) {
						consolidated(i, electricCurrentLeft
								* (1 + scope * i * sign));
					} else if (finalB[4]) {
						consolidated(i, electricCurrentRight
								* (1 + scope * i * sign));
					}
				}
			} else {
				for (int i = 0; i < 3; i++) {
					rnd = Math.random();
					if (rnd > 0.5) {
						sign = -1;
					} else {
						sign = 1;
					}
					calculate(threePhaseCurrentLeft, i, 0, electricCurrentRight
							* (1 + scope * i * sign));// ���
					calculate(threePhaseCurrentRight, i, 1, electricCurrentLeft
							* (1 + scope * i * sign));// �ұ�
				}
			}
		}

		// ----------------------------------------------
		// ҳ����ʾ������Ϣ
		for (int i = 0; i < 4; i++) {
			double currentSum = 0;
			StringBuffer current = new StringBuffer();
			for (char j = 'a'; j < 'd'; j++) {
				current.append("I" + j + "="
						+ df.format(threePhaseCurrentLeft[i][j - 97]) + ";\n");
				currentSum += threePhaseCurrentLeft[i][j - 97];
			}
			listGame.get(i).setText(current);
			chargeSumList[i] = Double.parseDouble(df.format(220 * currentSum
					* powerFactor / 1000));
		}
		for (int i = 0; i < 4; i++) {
			double currentSum = 0;
			StringBuffer current = new StringBuffer();
			for (char j = 'a'; j < 'd'; j++) {
				current.append("I" + j + "="
						+ df.format(threePhaseCurrentRight[i][j - 97]) + ";\n");
				currentSum += threePhaseCurrentRight[i][j - 97];
			}
			listGame.get(i + 4).setText(current);
			chargeSumList[i + 4] = Double.parseDouble(df.format(220
					* currentSum * powerFactor / 1000));
		}
		// --------------------------------------
		// ���ɣ��ܵ���
		sumCharge = (TextView) findViewById(R.id.sumCharge);
		sumTotalPower = (TextView) findViewById(R.id.sumTotalPower);

		// ------------------------
		double lefta = 220 * threePhaseCurrentLeft[0][0] * powerFactor;
		double leftb = 220 * threePhaseCurrentLeft[0][1] * powerFactor;
		double leftc = 220 * threePhaseCurrentLeft[0][2] * powerFactor;
		double righta = 220 * threePhaseCurrentRight[0][0] * powerFactor;
		double rightb = 220 * threePhaseCurrentRight[0][1] * powerFactor;
		double rightc = 220 * threePhaseCurrentRight[0][2] * powerFactor;
		sumChargeLeft = lefta + leftb + leftc;
		sumChargeRight = righta + rightb + rightc;
		sumChargeDouble = (sumChargeLeft + sumChargeRight) / 1000;
		sumCharge.setText("��ǰ���ɣ�" + df.format(sumChargeDouble) + "kW");

		if (time == 1) {
			for (int i = 0; i < 4; i++) {// ��¼ÿ�������ʼ�ĵ���
				lastMinutes[i] = 220 * threePhaseCurrentLeft[i][0]
						* powerFactor + 220 * threePhaseCurrentLeft[i][1]
						* powerFactor + 220 * threePhaseCurrentLeft[i][2]
						* powerFactor;
			}
			for (int i = 0; i < 4; i++) {
				lastMinutes[i + 4] = 220 * threePhaseCurrentRight[i][0]
						* powerFactor + 220 * threePhaseCurrentRight[i][1]
						* powerFactor + 220 * threePhaseCurrentRight[i][2]
						* powerFactor;
			}
		}
		time++;// ÿ�����ۼ�һ��
		if (time % 12 == 0) {
			totalPowerDouble = new double[8];
			if (!finalB[0] && !finalB[4]) {
				sumTotalPowerDouble = sumTotalPowerDouble;
			} else if (!finalB[1] && !finalB[2] && !finalB[3] && !finalB[5]
					&& !finalB[6] && !finalB[7]) {
				sumTotalPowerDouble = sumTotalPowerDouble;
			} else {
				if (finalB[0]) {
					lastMintesSum = lastMintesSum + lastMinutes[0];
				}
				if (finalB[4]) {
					lastMintesSum = lastMintesSum + lastMinutes[4];
				}
				lastMintesSum = lastMintesSum / 1000;
				sumTotalPowerDouble = sumTotalPowerDouble
						+ (lastMintesSum + sumChargeDouble) / 2 / 60;
				lastMintesSum = 0;
			}
			for (int i = 0; i < 4; i++) {// ��¼ÿ�������ʼ�ĵ���
				nowMinutes[i] = 220 * threePhaseCurrentLeft[i][0] * powerFactor
						+ 220 * threePhaseCurrentLeft[i][1] * powerFactor + 220
						* threePhaseCurrentLeft[i][2] * powerFactor;
			}
			for (int i = 0; i < 4; i++) {
				nowMinutes[i + 4] = 220 * threePhaseCurrentRight[i][0]
						* powerFactor + 220 * threePhaseCurrentRight[i][1]
						* powerFactor + 220 * threePhaseCurrentRight[i][2]
						* powerFactor;
			}
			setTotalPower();
			sumTotalPower.setText("��ǰ�ܵ�����" + df.format(sumTotalPowerDouble)
					+ "kWh");
		}
		List<double[][]> Current = new ArrayList<double[][]>();
		Current.add(threePhaseCurrentLeft);
		Current.add(threePhaseCurrentRight);
		sumTotalPowerDouble = Double
				.parseDouble(df.format(sumTotalPowerDouble));
		sumChargeDouble = Double.parseDouble(df.format(sumChargeDouble));
		return Current;
	}

	/**
	 * ����ÿ���ߵĵ���ֵ
	 */
	private void setTotalPower() {
		for (int i = 0; i < 8; i++) {
			if (!finalB[i]) {
				totalPowerDouble[i] = 0;
				lastMinutes[i] = 0;
			} else {
				totalPowerDouble[i] = Double
						.parseDouble(df
								.format((nowMinutes[i] + lastMinutes[i]) / 2 / 60 / 1000));
				lastMinutes[i] = nowMinutes[i];
			}
		}
	}

	// public static double calculationTime(){//���㵱ǰʱ��ĵ��
	// Date time = new Date();
	// double money = 0 ;
	// int hour = time.getHours();
	// if(hour >= 19 && hour < 21){
	// money = 1.406;
	// }else if ((hour >= 8 && hour< 11)||(hour >= 13&&hour<19)||
	// (hour >= 21 && hour < 22)){
	// money = 1.108;
	// }else {
	// money = 0.596;
	// }
	// return money;
	// }

	public static double businessCalculationTime() {// ���㵱ǰʱ�����ҵ���
		Date time = new Date();
		double money = 0;
		int hour = time.getHours();
		if (hour >= 19 && hour < 21) {
			money = 1.406;
		} else if ((hour >= 8 && hour < 11) || (hour >= 13 && hour < 19)
				|| (hour >= 21 && hour < 22)) {
			money = 1.108;
		} else {
			money = 0.596;
		}
		return money;
	}

	public static double calculationIndustrialTime() {// ���㵱ǰʱ��Ĺ�ҵ���
		Date time = new Date();
		double money = 0;
		int hour = time.getHours();
		if (hour >= 19 && hour < 21) {
			money = 1.123;
		} else if ((hour >= 8 && hour < 11) || (hour >= 13 && hour < 19)
				|| (hour >= 21 && hour < 22)) {
			money = 0.941;
		} else {
			money = 0.457;
		}
		return money;
	}

	/*
	 * ��ȡ�������� threePhaseCurrent�洢���ݶ�ά���� size �ڼ����� j ��������
	 */
	public void calculate(double[][] threePhaseCurrent, int size, int j,
			double electricCurrent) {
		if (!finalB[0] && j == 0) {// �ұ�
			threePhaseCurrent[0][size] = 0.0;// I*(���Էֱ����A,B,C)
			threePhaseCurrent[1][size] = 0.0;// I*1
			threePhaseCurrent[2][size] = 0.0;// I*2
			threePhaseCurrent[3][size] = 0.0;// I*3
		} else if (!finalB[4] && j == 1) {// ���
			threePhaseCurrent[0][size] = 0.0;// I*(���Էֱ����A,B,C)
			threePhaseCurrent[1][size] = 0.0;// I*1
			threePhaseCurrent[2][size] = 0.0;// I*2
			threePhaseCurrent[3][size] = 0.0;// I*3
		} else {
			// getRandom();
			threePhaseCurrent[0][size] = Double.valueOf(df
					.format(electricCurrent));// I*(���Էֱ����A,B,C)
			if (j == 0) {
				threePhaseCurrent[1][size] = electricCurrent * 0.2;// I*1
				threePhaseCurrent[2][size] = electricCurrent * 0.3;// I*2
				threePhaseCurrent[3][size] = electricCurrent * 0.5;// I*3
				if (!finalB[1]) {
					threePhaseCurrent[0][size] = threePhaseCurrent[0][size]
							- threePhaseCurrent[1][size];
					threePhaseCurrent[1][size] = 0.0;
				}
				if (!finalB[2]) {
					threePhaseCurrent[0][size] = threePhaseCurrent[0][size]
							- threePhaseCurrent[2][size];
					threePhaseCurrent[2][size] = 0.0;
				}
				if (!finalB[3]) {
					threePhaseCurrent[0][size] = threePhaseCurrent[0][size]
							- threePhaseCurrent[3][size];
					threePhaseCurrent[3][size] = 0.0;
				}
				if (threePhaseCurrent[0][size] < 5)
					threePhaseCurrent[0][size] = 0.0;
			} else if (j == 1) {
				threePhaseCurrent[1][size] = electricCurrent * 0.3;// I*1
				threePhaseCurrent[2][size] = electricCurrent * 0.5;// I*2
				threePhaseCurrent[3][size] = electricCurrent * 0.2;// I*3
				if (!finalB[5]) {
					threePhaseCurrent[0][size] = threePhaseCurrent[0][size]
							- threePhaseCurrent[1][size];
					threePhaseCurrent[1][size] = 0.0;
				}
				if (!finalB[6]) {
					threePhaseCurrent[0][size] = threePhaseCurrent[0][size]
							- threePhaseCurrent[2][size];
					threePhaseCurrent[2][size] = 0.0;
				}
				if (!finalB[7]) {
					threePhaseCurrent[0][size] = threePhaseCurrent[0][size]
							- threePhaseCurrent[3][size];
					threePhaseCurrent[3][size] = 0.0;
				}
				if (threePhaseCurrent[0][size] < 5)
					threePhaseCurrent[0][size] = 0.0;
			}
		}
	}

	public void consolidated(int size, double electricCurrent) {// �м�ϲ�ʱ�ļ��㷽��
		if (!finalB[0] && !finalB[4]) {
			threePhaseCurrentRight[0][size] = 0.0;// I*(���Էֱ����A,B,C)
			threePhaseCurrentRight[1][size] = 0.0;// I*1
			threePhaseCurrentRight[2][size] = 0.0;// I*2
			threePhaseCurrentRight[3][size] = 0.0;// I*3
			threePhaseCurrentLeft[0][size] = 0.0;// I*1
			threePhaseCurrentLeft[1][size] = 0.0;// I*1
			threePhaseCurrentLeft[2][size] = 0.0;// I*2
			threePhaseCurrentLeft[3][size] = 0.0;// I*3
		} else {
			threePhaseCurrentRight[1][size] = electricCurrent * 0.15;// I*1
			threePhaseCurrentRight[2][size] = electricCurrent * 0.25;// I*2
			threePhaseCurrentRight[3][size] = electricCurrent * 0.1;// I*3
			threePhaseCurrentLeft[1][size] = electricCurrent * 0.15;// I*1
			threePhaseCurrentLeft[2][size] = electricCurrent * 0.25;// I*2
			threePhaseCurrentLeft[3][size] = electricCurrent * 0.1;// I*3
			if (!finalB[1]) {
				electricCurrent = electricCurrent
						- threePhaseCurrentLeft[1][size];
				threePhaseCurrentLeft[1][size] = 0.0;
			}
			if (!finalB[2]) {
				electricCurrent = electricCurrent
						- threePhaseCurrentLeft[2][size];
				threePhaseCurrentLeft[2][size] = 0.0;
			}
			if (!finalB[3]) {
				electricCurrent = electricCurrent
						- threePhaseCurrentLeft[3][size];
				threePhaseCurrentLeft[3][size] = 0.0;
			}
			if (!finalB[5]) {
				electricCurrent = electricCurrent
						- threePhaseCurrentRight[1][size];
				threePhaseCurrentRight[1][size] = 0.0;
			}
			if (!finalB[6]) {
				electricCurrent = electricCurrent
						- threePhaseCurrentRight[2][size];
				threePhaseCurrentRight[2][size] = 0.0;
			}
			if (!finalB[7]) {
				electricCurrent = electricCurrent
						- threePhaseCurrentRight[3][size];
				threePhaseCurrentRight[3][size] = 0.0;
			}
			if (finalB[0]) {
				threePhaseCurrentRight[0][size] = 0.0;
				if (electricCurrent < 5)
					threePhaseCurrentLeft[0][size] = 0.0;
				else
					threePhaseCurrentLeft[0][size] = electricCurrent;
			}
			if (finalB[4]) {
				threePhaseCurrentLeft[0][size] = 0.0;
				if (electricCurrent < 5)
					threePhaseCurrentRight[0][size] = 0.0;
				else
					threePhaseCurrentRight[0][size] = electricCurrent;
			}
		}
	}

	/*
	 * ���������cosֵ
	 */
	public static double getCosRandom() {
		double rnd = Math.random() * 0.1 + 0.9;
		return rnd;
	}

	/**
	 * ���û�ȡ��·�ı������¼�
	 */
	private void gameSwitchOnclick() {
		gameSwitch1.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				textViewNum = 1;
				coefficient = 1;
				UserExperienceActivity.inComingLine = "����1";
				startMyActivity();
				openMyThread();
			}
		});
		gameSwitch2.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				textViewNum = 2;
				coefficient = 0.2;
				UserExperienceActivity.inComingLine = "����B1-1";
				startMyActivity();
				openMyThread();
			}
		});
		gameSwitch3.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				textViewNum = 3;
				coefficient = 0.3;
				UserExperienceActivity.inComingLine = "����B1-2";
				startMyActivity();
				openMyThread();
			}
		});
		gameSwitch4.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				textViewNum = 4;
				coefficient = 0.5;
				UserExperienceActivity.inComingLine = "����B1-3";
				startMyActivity();
				openMyThread();
			}
		});
		gameSwitch5.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				textViewNum = 5;
				coefficient = 1;
				UserExperienceActivity.inComingLine = "����2";
				startMyActivity();
				openMyThread();
			}
		});
		gameSwitch6.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				textViewNum = 6;
				coefficient = 0.3;
				UserExperienceActivity.inComingLine = "����B2-1";
				startMyActivity();
				openMyThread();
			}
		});
		gameSwitch7.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				textViewNum = 7;
				coefficient = 0.5;
				UserExperienceActivity.inComingLine = "����B2-2";
				startMyActivity();
				openMyThread();
			}
		});
		gameSwitch8.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				textViewNum = 8;
				coefficient = 0.2;
				UserExperienceActivity.inComingLine = "����B2-3";
				startMyActivity();
				openMyThread();
			}
		});
	}

	// ����������ֵ
	private void setCoefficientList() {
		for (int i = 0; i < 12; i++) {
			coefficientList[i] = coefficient * 1443.4;
		}
	}

	// �¿��߳�
	private void openMyThread() {
		myThread.setDestory(true);
		myThread = new OnOffThread();
		myThread.start();
	}

	// �����µ�ͼƬactivity
	private void startMyActivity() {
		setCoefficientList();
		Intent intent = new Intent();
		intent.setClass(UserExperienceActivity.this, ChartActivity.class);
		startActivity(intent);
	}

	// ��ť�����¼�
	private void buttonOnClick() {
		// �˸����ذ�ť
		imgBtn1 = (ImageButton) findViewById(R.id.game_btn1);
		imgBtn2 = (ImageButton) findViewById(R.id.game_btn2);
		imgBtn3 = (ImageButton) findViewById(R.id.game_btn3);
		imgBtn4 = (ImageButton) findViewById(R.id.game_btn4);
		imgBtn5 = (ImageButton) findViewById(R.id.game_btn5);
		imgBtn6 = (ImageButton) findViewById(R.id.game_btn6);
		imgBtn7 = (ImageButton) findViewById(R.id.game_btn7);
		imgBtn8 = (ImageButton) findViewById(R.id.game_btn8);
		imgBtn9 = (ImageButton) findViewById(R.id.game_btn9);
		returnButton = (ImageView) findViewById(R.id.nav_left);
		// -------------------------------------
		imgBtn1.setOnClickListener(new OnClickListener() {
			@SuppressLint("NewApi")
			public void onClick(View v) {
				if (finalB9 && finalB[4]) {
					Toast.makeText(UserExperienceActivity.this,
							R.string.user_experience_kill_parent,
							Toast.LENGTH_SHORT).show();
					return;
				}
				Start = false;
				if (finalB[0]) {
					if (!finalB[4]) {
						Toast.makeText(UserExperienceActivity.this,
								R.string.user_experience_lose_current,
								Toast.LENGTH_SHORT).show();
						return;
					}
					finalB[0] = false;
					imgBtn1.setBackgroundResource(R.drawable.close);
					openMyThread();
				} else {
					finalB[0] = true;
					imgBtn1.setBackgroundResource(R.drawable.open);
					openMyThread();
				}
			}
		});
		imgBtn2.setOnClickListener(new OnClickListener() {
			@SuppressLint("NewApi")
			public void onClick(View v) {
				Start = false;
				if (finalB[1]) {
					finalB[1] = false;
					imgBtn2.setBackgroundResource(R.drawable.close);
					openMyThread();
				} else {
					finalB[1] = true;
					imgBtn2.setBackgroundResource(R.drawable.open);
					openMyThread();
				}
			}
		});
		imgBtn3.setOnClickListener(new OnClickListener() {
			@SuppressLint("NewApi")
			public void onClick(View v) {
				Start = false;
				if (finalB[2]) {
					finalB[2] = false;
					imgBtn3.setBackgroundResource(R.drawable.close);
					openMyThread();
				} else {
					finalB[2] = true;
					imgBtn3.setBackgroundResource(R.drawable.open);
					openMyThread();
				}
			}
		});
		imgBtn4.setOnClickListener(new OnClickListener() {
			@SuppressLint("NewApi")
			public void onClick(View v) {
				Start = false;
				if (finalB[3]) {
					finalB[3] = false;
					imgBtn4.setBackgroundResource(R.drawable.close);
					openMyThread();
				} else {
					finalB[3] = true;
					imgBtn4.setBackgroundResource(R.drawable.open);
					openMyThread();
				}
			}
		});
		imgBtn5.setOnClickListener(new OnClickListener() {
			@SuppressLint("NewApi")
			public void onClick(View v) {
				if (finalB9 && finalB[0]) {
					Toast.makeText(UserExperienceActivity.this,
							R.string.user_experience_kill_parent,
							Toast.LENGTH_SHORT).show();
					return;
				}
				Start = false;
				if (finalB[4]) {
					if (!finalB[0]) {
						Toast.makeText(UserExperienceActivity.this,
								R.string.user_experience_lose_current,
								Toast.LENGTH_SHORT).show();
						return;
					}
					finalB[4] = false;
					imgBtn5.setBackgroundResource(R.drawable.close);
					openMyThread();
				} else {
					finalB[4] = true;
					imgBtn5.setBackgroundResource(R.drawable.open);
					openMyThread();
				}
			}
		});
		imgBtn6.setOnClickListener(new OnClickListener() {
			@SuppressLint("NewApi")
			public void onClick(View v) {
				Start = false;
				if (finalB[5]) {
					finalB[5] = false;
					imgBtn6.setBackgroundResource(R.drawable.close);
					openMyThread();
				} else {
					finalB[5] = true;
					imgBtn6.setBackgroundResource(R.drawable.open);
					openMyThread();
				}
			}
		});
		imgBtn7.setOnClickListener(new OnClickListener() {
			@SuppressLint("NewApi")
			public void onClick(View v) {
				Start = false;
				if (finalB[6]) {
					finalB[6] = false;
					imgBtn7.setBackgroundResource(R.drawable.close);
					openMyThread();
				} else {
					finalB[6] = true;
					imgBtn7.setBackgroundResource(R.drawable.open);
					openMyThread();
				}
			}
		});
		imgBtn8.setOnClickListener(new OnClickListener() {
			@SuppressLint("NewApi")
			public void onClick(View v) {
				Start = false;
				if (finalB[7]) {
					finalB[7] = false;
					imgBtn8.setBackgroundResource(R.drawable.close);
					openMyThread();
				} else {
					finalB[7] = true;
					imgBtn8.setBackgroundResource(R.drawable.open);
					openMyThread();
				}
			}
		});
		imgBtn9.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if (finalB[0] && finalB[4]) {
					Toast.makeText(UserExperienceActivity.this,
							R.string.user_experience_kill_line,
							Toast.LENGTH_SHORT).show();
					return;
				}
				Start = false;
				if (finalB9) {
					finalB9 = false;
					imgBtn9.setBackgroundResource(R.drawable.close);
					openMyThread();
				} else {
					finalB9 = true;
					imgBtn9.setBackgroundResource(R.drawable.open);
					openMyThread();
				}
			}
		});
		returnButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				UserExperienceActivity.this.onBackPressed();
			}
		});
	}

	/**
	 * ͨ������״̬��ȷ�����ɵ���
	 * 
	 * @param load
	 * @return
	 */
	private double setTransCurrent(double load) {
		double current = 0;
		// Log.d("BID","load:"+load);
		if (!finalB[0] || !finalB[4]) {
			load = load;
		} else if ((!finalB[1] && !finalB[2] && !finalB[3])
				|| (!finalB[5] && !finalB[6] && !finalB[7])) {
			load = load;
		} else {
			load = load / 2;
		}
		current = load * 1000 / 220 / powerFactor / 3 * 1.15;
		Log.d("BID", "LOD_CURRENT:" + current);
		return current;
	}

	/**
	 * ���ɱ�����������
	 * 
	 * @param currentȷ������
	 * @param size
	 * @return
	 */
	private double[][] setThreePhaseCurrent(double currentDouble, int size) {
		int i = 0;// ��ʾ��Щ���Ǳպ�״̬
		double rnd = 0;// ѡ�����¸�������
		int sign = 0;// ����λ��ʾ��
		double scope = 0.025;// ���Ƹ����׷��
		double currentThreeDouble = 0;
		double[][] currentArr = new double[4][3];// һ����������ң�
		if (size == 1) {
			if (finalB[1]) {
				i++;
			}
			if (finalB[2]) {
				i++;
			}
			if (finalB[3]) {
				i++;
			}
		} else {
			if (finalB[5]) {
				i++;
			}
			if (finalB[6]) {
				i++;
			}
			if (finalB[7]) {
				i++;
			}
		}
		for (int x = 0; x < 3; x++) {
			rnd = Math.random();
			if (rnd > 0.5) {
				sign = -1;
			} else {
				sign = 1;
			}
			currentDouble = currentDouble * (1 + scope * x * sign);
			Log.d("BID", "currentDouble" + x + ":" + currentDouble);
			if (i > 0) {
				currentThreeDouble = currentDouble / i;
			}
			currentArr[0][x] = currentDouble;
			for (int y = 1; y < 4; y++) {
				currentArr[y][x] = currentThreeDouble;
			}
			// Log.d("BID", "currentThreeDouble"+i+"��"+currentThreeDouble);
			if (size == 1) {
				if (!finalB[1] || !finalB[0]) {
					currentArr[1][x] = 0;
				}
				if (!finalB[2] || !finalB[0]) {
					currentArr[2][x] = 0;
				}
				if (!finalB[3] || !finalB[0]) {
					currentArr[3][x] = 0;
				}
				if ((!finalB[1] && !finalB[2] && !finalB[3]) || !finalB[0]) {
					currentArr[0][x] = 0;
				}
			} else {
				if (!finalB[5] || !finalB[4]) {
					currentArr[1][x] = 0;
				}
				if (!finalB[6] || !finalB[4]) {
					currentArr[2][x] = 0;
				}
				if (!finalB[7] || !finalB[4]) {
					currentArr[3][x] = 0;
				}
				if ((!finalB[5] && !finalB[6] && !finalB[7]) || !finalB[4]) {
					currentArr[0][x] = 0;
				}
			}
		}
		return currentArr;
	}

	/**
	 * ���ɱ�����ĸ���ϣ���������
	 */
	private void setSixCurrent(double currentDouble) {
		int i = 0;
		double currentThreeDouble = 0;
		double rnd = 0;
		int sign = 0;
		double scope = 0.025;
		if (finalB[1]) {
			i++;
		}
		if (finalB[2]) {
			i++;
		}
		if (finalB[3]) {
			i++;
		}
		if (finalB[5]) {
			i++;
		}
		if (finalB[6]) {
			i++;
		}
		if (finalB[7]) {
			i++;
		}
		for (int x = 0; x < 3; x++) {
			rnd = Math.random();
			if (rnd > 0.5) {
				sign = -1;
			} else {
				sign = 1;
			}
			currentDouble = currentDouble * (1 + scope * x * sign);
			Log.d("BID", "currentDouble" + x + ":" + currentDouble);
			if (i > 0) {
				currentThreeDouble = currentDouble / i;
			}
			if (finalB[0]) {
				threePhaseCurrentLeft[0][x] = currentDouble;
			} else {
				threePhaseCurrentRight[0][x] = currentDouble;
			}

			if (finalB[1]) {
				threePhaseCurrentLeft[1][x] = currentThreeDouble;
			} else {
				threePhaseCurrentLeft[1][x] = 0;
			}
			if (finalB[2]) {
				threePhaseCurrentLeft[2][x] = currentThreeDouble;
			} else {
				threePhaseCurrentLeft[2][x] = 0;
			}
			if (finalB[3]) {
				threePhaseCurrentLeft[3][x] = currentThreeDouble;
			} else {
				threePhaseCurrentLeft[3][x] = 0;
			}
			if (finalB[5]) {
				threePhaseCurrentRight[1][x] = currentThreeDouble;
			} else {
				threePhaseCurrentRight[1][x] = 0;
			}
			if (finalB[6]) {
				threePhaseCurrentRight[2][x] = currentThreeDouble;
			} else {
				threePhaseCurrentRight[2][x] = 0;
			}
			if (finalB[7]) {
				threePhaseCurrentRight[3][x] = currentThreeDouble;
			} else {
				threePhaseCurrentRight[3][x] = 0;
			}
			if (!finalB[1] && !finalB[2] && !finalB[3] && !finalB[5]
					&& !finalB[6] && !finalB[7]) {
				if (finalB[0]) {
					threePhaseCurrentLeft[0][x] = 0;
				} else {
					threePhaseCurrentRight[0][x] = 0;
				}
			}
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == AppConstant.RequestResultCode.RESULT_LOAD_REPORT) {
			isLoadReport = true;
			loadReportValue = Double.parseDouble(data.getStringExtra("load"));
			if (loadReportValue < sumChargeDouble) {
				if (finalB[1] || finalB[2] || finalB[3] || finalB[5]
						|| finalB[6] || finalB[7]) {
					isLoadReport = false;
					notiInfoAction();
				}
			} else {
				openMyThread();
				if (finalB[1] || finalB[2] || finalB[3] || finalB[5]
						|| finalB[6] || finalB[7]) {
					notiInfoAction();
				}
			}
		}
	}

	public void notiInfoAction() {
		MediaPlayer mediaPlayer = new MediaPlayer();
		mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
		mediaPlayer.setOnCompletionListener(alarmListener);
		AssetFileDescriptor file = getResources()
				.openRawResourceFd(R.raw.alarm);
		Intent it = new Intent();
		it.putExtra("type", "load");
		it.setClass(UserExperienceActivity.this, ShowWarnActivity.class);
		startActivity(it);
		try {
			mediaPlayer.setDataSource(file.getFileDescriptor(),
					file.getStartOffset(), file.getLength());
			file.close();
			mediaPlayer.prepare();
			mediaPlayer.start();
		} catch (IOException e) {
			mediaPlayer = null;
		}

	}

	private final OnCompletionListener alarmListener = new OnCompletionListener() {
		public void onCompletion(MediaPlayer mediaPlayer) {
			mediaPlayer.release();
		}
	};

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		// Log.d("elec", "onDestroy");
		if (myThread != null) {
			myThread.setDestory(true);
		}
		finalB[0] = true;
		finalB[1] = true;
		finalB[2] = true;
		finalB[3] = true;
		finalB[4] = true;
		finalB[5] = true;
		finalB[6] = true;
		finalB[7] = true;
		finalB9 = false;
		sumTotalPowerDoubleList = new double[12];// �ܵ���list
		sumChargeDoubleList = new double[12];// �ܸ���List
		sumTotalPowerMoneyList = new double[12];
		a = new double[12];
		b = new double[12];
		c = new double[12];
		textViewNum = 1;
		textViewNumTemp = 1;
		coefficientList = new double[12];
		coefficient = 0;
		time = 1;
		timeBar = 1;
		inComingLine = "";
		currentList = new ArrayList<List<double[][]>>();
		SetThresholdActivity.isEffective = false;// ������ʱ������ҳ��δ��������������Ϊ������
		super.onDestroy();
	}
}