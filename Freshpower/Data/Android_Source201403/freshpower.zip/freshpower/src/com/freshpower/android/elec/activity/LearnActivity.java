package com.freshpower.android.elec.activity;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppConstant;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class LearnActivity extends FrameActivity {
	private RoundCornerListView groupTwolistview;
	private String[] menuNames;
	private String[] menuSize;
	private Resources res;
	private ImageButton learnBtn;
	@Override
	protected void init(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_learn);
		res = getResources();
		findViews();
		setAdapter();
	}	
	
	private void findViews(){
//		groupOnelistview = (RoundCornerListView)findViewById(R.id.setMenulistviewOne);
		groupTwolistview = (RoundCornerListView)findViewById(R.id.learn_list);
	}
	private void setAdapter(){
		groupTwolistview.setAdapter(new SimpleAdapter(this,getGroupTwolistData(),R.layout.learn_listitem_style_one, new String[] { AppConstant.ListItemCtlName.MENU_SIZE,AppConstant.ListItemCtlName.MENU_NAME}, new int[] { R.id.menuSize,R.id.menuName}));
		setListViewHeightBasedOnChildren(groupTwolistview);
		groupTwolistview.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent,
					View view, int position, long id) {
				Map<String, Object> listItem = (Map<String, Object>)parent.getItemAtPosition(position);
				Intent it = new Intent();
				if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_SIZE).toString())==1){
					it.putExtra("type", "1");
				}else if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_SIZE).toString())==2){
					it.putExtra("type", "2");
				}else if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_SIZE).toString())==3){
					it.putExtra("type", "3");
				}else if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_SIZE).toString())==4){
					it.putExtra("type", "4");
				}
				it.setClass(LearnActivity.this,IntroduceActivity.class);
				startActivity(it);
			}
			
		});
	}
	private List<Map<String, Object>> getGroupTwolistData(){
		menuNames=res.getStringArray(R.array.soft_myelectric_learn);
		menuSize = res.getStringArray(R.array.soft_myelectric_learn_size);
		
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < menuNames.length; i++)
		{
			//Log.d("elec", String.valueOf(menuSize[i]));
			Map<String, Object> listItem1 = new HashMap<String, Object>();
			listItem1.put(AppConstant.ListItemCtlName.MENU_SIZE, menuSize[i]);
			listItem1.put(AppConstant.ListItemCtlName.MENU_NAME, menuNames[i]);
			listItems.add(listItem1);
		}
		return listItems;
	}
	/***
     * ��̬����listview�ĸ߶�
     * 
     * @param listView
     */
    public void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            return;
        }
        int totalHeight = 0;
        for (int i = 0; i < listAdapter.getCount(); i++) {
            View listItem = listAdapter.getView(i, null, listView);
        	//View listItem = inflater.inflate(android.R.layout.simple_expandable_list_item_1, null);
            listItem.measure(0, 0);
            totalHeight += listItem.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight
                + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        listView.setLayoutParams(params);
    }

	@Override
	protected void onResume() {
		
		learnBtn = (ImageButton) findViewById(R.id.learnBtn);
		if(learnBtn!=null){
			learnBtn.setOnClickListener(null);
			learnBtn.setBackgroundResource(R.drawable.learnbtn_select);
		}
		
		TextView learnBtnTv = (TextView)findViewById(R.id.learnBtnTv);
		learnBtnTv.setTextColor(getResources().getColor(R.color.white));
		
		super.onResume();
	}
}
