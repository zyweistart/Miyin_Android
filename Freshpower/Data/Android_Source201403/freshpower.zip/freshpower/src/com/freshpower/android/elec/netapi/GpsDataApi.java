/**   
 * @{#} GpsDataApi.java Create on 2013-4-24 ����02:23:32   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.netapi;

import java.io.File;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import android.util.Log;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.LogFactory;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.conf.AppConfig;
import com.freshpower.android.elec.domain.GpsDataInfo;
import com.freshpower.android.elec.domain.LoginInfo;
import com.freshpower.android.elec.domain.TimeQuantum;

/**
 * @author <a href="mailto:yangz@freshpower.cn">yangz</a>
 * @version 1.0
 */

public class GpsDataApi extends JsonDataApi {
	private static final String ACTION_NAME = "sendLocationInfo.aspx";
	private static final String ACTION_NAME_GETLOCATION = "getLocationInfo.aspx";
	private static LogFactory logger = LogFactory.getLogger(GpsDataApi.class);

	public static void sendLocationInfo(GpsDataInfo gpsDataInfo, LoginInfo user)
			throws Exception {
		WebDataApi api = new WebDataApi();
		api.addParam("longitude", String.valueOf(gpsDataInfo.getLongitude()));
		api.addParam("latitude", String.valueOf(gpsDataInfo.getLatitude()));
		api.addParam("speed", String.valueOf(gpsDataInfo.getSpeed()));
		api.addParam("direction", String.valueOf(gpsDataInfo.getDirection()));
		api.addParam("longitudeEW", "E");
		api.addParam("latitudeNS", "N");
		api.addParam("gpsTime", URLEncoder.encode(gpsDataInfo.getGpsTime()));
		api.addParam("imei", user.getLoginName());
		api.addParam("authentication", user.getLoginPwd());
		api.addParam("key", user.getKey());
		logger.d("trmsDebug", "sendLocationInfo.....");
		// api.getRequest("http://mail.freshpower.com.cn:7023/product/struts/portal/toTestRequest.do");
		api.getRequest(AppConfig.getInstance().getEtgWebsite() + File.separator
				+ ACTION_NAME);
		logger.d("trmsDebug", "sendLocationInfo result.....:");
	}
	
	/**
	 * ��ѯ�û���GPS��Ϣ
	 * @param user �û�������Ϣ
	 * @param startDate ��ѯ��ʼʱ��
	 * @param endDate ��ѯ����ʱ��
	 * @param gpsRequestQueryRtype ��ѯGPS��������
	 * @param quantumStr ʱ����ַ���
	 * @return
	 * @throws Exception
	 */
	public static int getLocationInfo(LoginInfo user, String startDate,
			String endDate,int gpsRequestQueryRtype,String quantumStr) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("imei", user.getLoginName());
		api.addParam("authentication", user.getLoginPwd());
		api.addParam("phoneNum", user.getPhoneNum());
		api.addParam("startDate", URLEncoder.encode(startDate));
		api.addParam("endDate", URLEncoder.encode(endDate));
		api.addParam("UUid", user.getUUID());
		api.addParam("userId", user.getUserId());
		if(gpsRequestQueryRtype!=AppConstant.GpsRequestQueryRtype.SEARCH_DEFAULT){
			api.addParam("rtype", String.valueOf(gpsRequestQueryRtype));
			if(!StringUtil.isEmpty(quantumStr))
				api.addParam("rvalue", quantumStr);
		}
		JSONObject jsonResult = api
				.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+ File.separator + ACTION_NAME_GETLOCATION,"GBK");
		/*
		LoginInfo userTemp = JSON
				.parseObject(
						URLDecoder.decode(jsonResult.toJSONString(), "GBK"),
						LoginInfo.class);
		*/
		
		JSONArray gpsDataInfoListJArr = jsonResult.getJSONArray("gpsDataInfoList");
		JSONArray timeQuantumJArr = jsonResult.getJSONArray("timeQuantum");
		
		List<GpsDataInfo> gpsDataInfoList = new ArrayList<GpsDataInfo>();
		GpsDataInfo gpsDataInfo = null;
		JSONObject jobj = null;
		if(gpsDataInfoListJArr!=null){
			for (int i = 0; i < gpsDataInfoListJArr.size(); i++) {
				gpsDataInfo = new GpsDataInfo();
				jobj = (JSONObject)gpsDataInfoListJArr.get(i);
				gpsDataInfo.setLongitude(Double.parseDouble(jobj.getString("longitude")));
				gpsDataInfo.setLatitude(Double.parseDouble(jobj.getString("latitude")));
				gpsDataInfo.setGpsTime(jobj.getString("gpsTime"));
				gpsDataInfoList.add(gpsDataInfo);
			}
		}
		
		List<TimeQuantum> timeQuantumList = new ArrayList<TimeQuantum>();
		TimeQuantum timeQuantum = null;
		if(timeQuantumJArr!=null){
			for (int i = 0; i < timeQuantumJArr.size(); i++) {
				timeQuantum = new TimeQuantum();
				jobj = (JSONObject)timeQuantumJArr.get(i);
				timeQuantum.setDateValue(jobj.getString("dateValue"));
				timeQuantumList.add(timeQuantum);
			}
		}
		
		user.setGpsDataInfoList(gpsDataInfoList);
		user.setTimeQuantum(timeQuantumList);
		user.setUserName(jsonResult.getString("userName"));
		return jsonResult.getInteger("result");
	}
	
	public static List<LoginInfo> getValidUserList(LoginInfo user,String startDateStr,String endDateStr) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("imei", user.getLoginName());
		api.addParam("authentication", user.getLoginPwd());
		api.addParam("rtype", String.valueOf(3));
		api.addParam("startDate", URLEncoder.encode(startDateStr));
		api.addParam("endDate", URLEncoder.encode(endDateStr));
		JSONObject jsonResult = api
				.getForJsonResult(AppConfig.getInstance().getEtgWebsite()+ File.separator + ACTION_NAME_GETLOCATION);
		JSONArray jArr=JSON.parseObject(URLDecoder.decode(jsonResult.toJSONString(), "GBK")).getJSONArray("gpsUserList");
		LoginInfo userTemp = null;
		List<LoginInfo> userList = new ArrayList<LoginInfo>();
		for (int i = 0; i < jArr.size(); i++) {
			JSONObject jobj = (JSONObject)jArr.get(i);
			userTemp = new LoginInfo();
			userTemp.setUserName(jobj.getString("userName"));
			userTemp.setPhoneNum(jobj.getString("phoneNum"));
			userTemp.setUUID(jobj.getString("UUID"));
			userTemp.setUserId(jobj.getString("userId"));
			userList.add(userTemp);
		}
		
		return userList;
	}

}
