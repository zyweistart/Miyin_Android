/**   
 * @{#} SysSetGroupOneAdapter.java Create on 2012-11-5 ����11:00:47   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.common;

import java.util.List;
import java.util.Map;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.activity.TaskConsumptionActivity;
import com.freshpower.android.elec.activity.TaskTimeActivity;
import com.freshpower.android.elec.activity.WarnHandleActivity;
import com.freshpower.android.elec.common.WarnSetGroupOneAdapter.WarnSetItemOnClickListener;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class TaskDetailGroupOneAdapter extends BaseAdapter {

	List<Map<String, Object>> mData;
	Context mContext;
	int resource;
	private SharedPreferences trmsSharedPreferences;
	private Editor editor;
	private Intent intent;

	public TaskDetailGroupOneAdapter(List<Map<String, Object>> data,
			Context context, int resource) {
		this.mData = data;
		this.mContext = context;
		this.resource = resource;
	}
	static class ViewHoder {
		LinearLayout taskStyleParent;
		EditText editView;
		TextView textView;
		CheckBox checkBox;
		TextView recordtv;
	}
	@Override
	public int getCount() {
		return mData == null ? 0 : mData.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@SuppressLint("NewApi")
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHoder hoder = null;
		if (convertView == null) {
			hoder = new ViewHoder();
			convertView = LayoutInflater.from(mContext).inflate(resource, null);
			hoder.taskStyleParent = (LinearLayout)convertView
					.findViewById(R.id.task_style_parent);
			hoder.textView = (TextView) convertView
					.findViewById(R.id.task_demo_tv);
			hoder.editView = (EditText) convertView
					.findViewById(R.id.task_demo_et);
			hoder.checkBox = (CheckBox) convertView
					.findViewById(R.id.task_demo_chb);
			hoder.recordtv = (TextView) convertView
					.findViewById(R.id.task_demo_recordtv);
			convertView.setTag(hoder);
		} else {
			hoder = (ViewHoder) convertView.getTag();
		}
		
		if(position % 2 ==1){
			hoder.taskStyleParent.setBackgroundColor(mContext.getResources().getColor(R.color.bgcolor));
		}else{
			hoder.taskStyleParent.setBackgroundColor(mContext.getResources().getColor(R.color.white));
		}
		
		Map<String, Object> data = mData.get(position);
		hoder.textView.setText(String.valueOf(data.get("scoutcheckContent"))+":");//��������
		String code=String.valueOf(data.get("codeId"));//����Ӧ��д����
		if(data.get("recordType")==null||data.get("recordType")==""){
			if(!StringUtil.isEmpty(code)&&code.equals("18")){
				hoder.editView.setText("");
				hoder.checkBox.setVisibility(View.GONE);//��д��� ��ѡ����-34��-35  
			}else if(!StringUtil.isEmpty(code)&&code.equals("26")){ 
				hoder.editView.setVisibility(View.GONE);
				hoder.checkBox.setVisibility(View.VISIBLE);//��д��� ��ѡ������-56�쳣-57��-154 
				if(String.valueOf(data.get("scoutcheck")).equals("56")){
					hoder.checkBox.setChecked(true);
				}else if(String.valueOf(data.get("scoutcheck")).equals("57")){
					hoder.checkBox.setChecked(false);
				}else{
					hoder.checkBox.setChecked(true);
				}
			}else{
				if(data.get("codeType").toString().equals("1")){
					TaskSetItemOnClickListener TaskSetItemOnClickListener = new TaskSetItemOnClickListener(position);
					hoder.editView.setOnClickListener(TaskSetItemOnClickListener);
					hoder.editView.setFocusable(false);
					hoder.editView.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
				}
				if(data.get("codeType").toString().equals("2")){
					hoder.editView.setFilters(new InputFilter[]{new InputFilter.LengthFilter(200)});
					EditText editText = hoder.editView;
					editText.setInputType(InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_CLASS_TEXT);
					editText.setLines(6);
//					hoder.editView.setSingleLine(true);
				}
				hoder.editView.setText(String.valueOf(data.get("scoutcheck")));//��д���
				hoder.checkBox.setVisibility(View.GONE);
			}
		}else{
			hoder.editView.setVisibility(View.GONE);
			hoder.checkBox.setVisibility(View.GONE);
			hoder.recordtv.setVisibility(View.VISIBLE);
			if(String.valueOf(data.get("scoutcheck")).equals("56")){
				hoder.recordtv.setText("����");
			}else if(String.valueOf(data.get("scoutcheck")).equals("57")){
				hoder.recordtv.setText("�쳣");
			}else if(String.valueOf(data.get("scoutcheck")).equals("154")){
				hoder.recordtv.setText("��");
			}else{
				hoder.recordtv.setText(String.valueOf(data.get("scoutcheck")));
			}
			hoder.recordtv.setHeight(80);
		}
		
		return convertView;
	}
	 class TaskSetItemOnClickListener implements View.OnClickListener{
		 	private int currentPosition;
		 	public TaskSetItemOnClickListener(int currentPosition) {
		 		this.currentPosition = currentPosition;
			}
		 	
			@Override
			public void onClick(View v) {
				TaskConsumptionActivity taskConsumptionActivity = (TaskConsumptionActivity)mContext;
				Intent intent = new Intent(taskConsumptionActivity, TaskTimeActivity.class);
				intent.putExtra("selIndex", currentPosition);
				taskConsumptionActivity.startActivityForResult(intent,100);
			}
		}

}
