package com.freshpower.android.elec.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.UpdateManager;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Toast;

public class AboutActivity extends Activity {
	private RoundCornerListView groupOnelistview;
	private String[] menuNames;
	private int[] menuIcoIds;
	private Resources res;
	private boolean isUpdate=false;
	Integer update;
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.activity_about);
		res = getResources();
		UpdateManager updateManager=new UpdateManager(AboutActivity.this);
		isUpdate=updateManager.isUpdate();
		findViews();
		setAdapter();
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
	        iv.setOnClickListener(new OnClickListener() {
	        	@Override
				public void onClick(View v) {
					Intent intent = new Intent(AboutActivity.this,ToolActivity.class);
		    		startActivity(intent);
		    		finish();	
				}
			});

	}
	private void setAdapter(){
		groupOnelistview.setAdapter(new SimpleAdapter(this,getGroupOnelistData(), R.layout.listitem_style_one, new String[] { AppConstant.ListItemCtlName.MENU_ICO, AppConstant.ListItemCtlName.MENU_NAME}, new int[] { R.id.menuIco,R.id.menuName}));
		setListViewHeightBasedOnChildren(groupOnelistview);
		groupOnelistview.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent,
					View view, int position, long id) {
				Map<String, Object> listItem = (Map<String, Object>)parent.getItemAtPosition(position);
				UpdateManager manager = new UpdateManager(AboutActivity.this);
				if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_ICO).toString())==R.drawable.freshpower){
					Intent it = new Intent(AboutActivity.this,AboutIntroduceActivity.class);
					it.putExtra("type", "1");
					startActivity(it);
				}else if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_ICO).toString())==R.drawable.opinion){
					Intent it = new Intent(AboutActivity.this,FeedBackActivity.class);
					startActivity(it);
				}else if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_ICO).toString())==R.drawable.checkupdate_new){
					Toast.makeText(AboutActivity.this, R.string.soft_update_checking, Toast.LENGTH_SHORT).show();
					manager.checkUpdate(false);
				}else if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_ICO).toString())==R.drawable.checkupdate){
					Toast.makeText(AboutActivity.this, R.string.soft_update_checking, Toast.LENGTH_SHORT).show();
					manager.checkUpdate(false);
				}else{
					Intent it = new Intent(AboutActivity.this,AboutIntroduceActivity.class);
					it.putExtra("type", "2");
					startActivity(it);
				}
			}
			
		});
	}
	private void findViews(){
		groupOnelistview = (RoundCornerListView)findViewById(R.id.setMenulistviewOne);
	}
	private List<Map<String, Object>> getGroupOnelistData(){
		if(isUpdate){
			update=R.drawable.checkupdate_new;
		}else{
			update=R.drawable.checkupdate;
		}
		menuNames=res.getStringArray(R.array.soft_about_menuNames);
		menuIcoIds = new int[]{ update,R.drawable.opinion,R.drawable.freshpower,R.drawable.agreement};
		
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < menuNames.length; i++)
		{
			Map<String, Object> listItem = new HashMap<String, Object>();
			listItem.put(AppConstant.ListItemCtlName.MENU_ICO, menuIcoIds[i]);
			listItem.put(AppConstant.ListItemCtlName.MENU_NAME, menuNames[i]);
			listItems.add(listItem);
		}
		return listItems;
	}
	/***
     * ��̬����listview�ĸ߶�
     * 
     * @param listView
     */
    public void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            return;
        }
        int totalHeight = 0;
        for (int i = 0; i < listAdapter.getCount(); i++) {
           View listItem = listAdapter.getView(i, null, listView);
        	//View listItem = inflater.inflate(android.R.layout.simple_expandable_list_item_1, null);
            listItem.measure(0, 0);
            totalHeight += listItem.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight
                + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        listView.setLayoutParams(params);
    }
}