package com.freshpower.android.elec.activity;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.FileUtil;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ZoomButtonsController;

public class HomeIntroduceActivity extends Activity {
	private WebView webView;
	private ImageView returnButton;    
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_homeintroduce);
		ActivityUtil.addActivity(this);
		webView = (WebView) findViewById(R.id.webView);
		webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		
		WebSettings webSettings =webView.getSettings();
	 	webSettings.setJavaScriptEnabled(true);
	 	webSettings.setBuiltInZoomControls(true);
	 	webSettings.setUseWideViewPort(true);//��������
	 	webSettings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);//����û���ļ�����������
	 	setZoomControlGone(webView);
	 	webView.requestFocus();
	 	String sdpath = FileUtil.getAppRootPath();// ��ô洢����·��
	 	Intent it = getIntent();
	 	String type =it.getStringExtra("type");
		File newsFile = new File(sdpath+"download"+File.separator+"newsFile.txt");
		if(newsFile.exists()){
			Log.d("BID","type:"+type);
			webView.loadUrl(type);
		}else{
		 	if(type.equals("0")){
		 		webView.loadUrl("file:///android_asset/www/homeIntroduceone.html");
		 	}else if(type.equals("1")){
		 		webView.loadUrl("file:///android_asset/www/homeIntroducethree.html");
		 	}else if(type.equals("2")){
		 		webView.loadUrl("file:///android_asset/www/homeIntroducefour.html");
		 	}else if(type.equals("3")){
		 		webView.loadUrl("file:///android_asset/www/homeIntroducefive.html");
		 	}
		}
	 	
	 	ImageView iv=(ImageView)findViewById(R.id.listbnItem);
        iv.setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
				Intent intent = new Intent(HomeIntroduceActivity.this,HomeInformationActivity.class);
	    		startActivity(intent);
	    		finish();	
			}
		});
        ImageView returnButton=(ImageView)findViewById(R.id.nav_left);
        returnButton.setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
	    		HomeIntroduceActivity.this.onBackPressed();
			}
		});
	}

	public void setZoomControlGone(WebView view) {
		Class classType;
		Field field;
		try {
			classType = WebView.class;
			field = classType.getDeclaredField("mZoomButtonsController");
			field.setAccessible(true);
			ZoomButtonsController mZoomButtonsController = new ZoomButtonsController(view);
			mZoomButtonsController.getZoomControls().setVisibility(View.GONE);
			try {
				field.set(view, mZoomButtonsController);
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			classType = WebSettings.class;
		 	try {
				Method methodTemp = classType.getMethod("setDisplayZoomControls", new Class[] { boolean.class });
				methodTemp.invoke(view.getSettings(), false);
		 	} catch (SecurityException ex) {
				e.printStackTrace();
			} catch (NoSuchMethodException ex) {
				e.printStackTrace();
			}catch (Exception ex) {
				e.printStackTrace();
			}
		}
	}

}
