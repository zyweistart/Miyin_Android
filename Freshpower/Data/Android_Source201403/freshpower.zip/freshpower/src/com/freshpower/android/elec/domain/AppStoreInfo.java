package com.freshpower.android.elec.domain;


/**
 * 
 * @author yzsunlight
 *
 */
public class AppStoreInfo {
	private Long id;
	private String key;
	private String value;
	private String verCode;
	private String verFilePah;
	private Long frequency;
	private String vNo;
	private String changeInfo;
	private String must;
	private String url;
	private String rs;
	
	
	public String getvNo() {
		return vNo;
	}
	public void setvNo(String vNo) {
		this.vNo = vNo;
	}
	public String getChangeInfo() {
		return changeInfo;
	}
	public void setChangeInfo(String changeInfo) {
		this.changeInfo = changeInfo;
	}
	public String getMust() {
		return must;
	}
	public void setMust(String must) {
		this.must = must;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getRs() {
		return rs;
	}
	public void setRs(String rs) {
		this.rs = rs;
	}
	public AppStoreInfo(String key,String value){
		this.key = key;
		this.value = value;
	}
	public AppStoreInfo(){}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getVerCode() {
		return verCode;
	}
	public void setVerCode(String verCode) {
		this.verCode = verCode;
	}
	public String getVerFilePah() {
		return verFilePah;
	}
	public void setVerFilePah(String verFilePah) {
		this.verFilePah = verFilePah;
	}
	public Long getFrequency() {
		return frequency;
	}
	public void setFrequency(Long frequency) {
		this.frequency = frequency;
	}
	
}
