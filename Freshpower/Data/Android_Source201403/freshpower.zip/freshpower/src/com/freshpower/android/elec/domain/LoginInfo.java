package com.freshpower.android.elec.domain;

import java.util.List;

/*
 * �û���¼
 */
public class LoginInfo {
	private String loginName;
	private String loginPwd;
	private Integer loginStatus;
	private String twoDimCode;
	private int theme;
	private String key;
	private String userName;
	private String phoneNum;
	private String userId;
	private String UUID;
	private List<GpsDataInfo> gpsDataInfoList;
	private List<TimeQuantum> timeQuantum;
    private String bpId;//����ID
    private String parentId;//�ϼ�����ID
    private String bpCode;//���ܴ���
    private String bpName;//��������
    private String cpId;//�ͻ�ID 
    private String purviewId;//Ȩ��ID 

	
	public String getPurviewId() {
		return purviewId;
	}
	public void setPurviewId(String purviewId) {
		this.purviewId = purviewId;
	}
	public String getCpId() {
		return cpId;
	}
	public void setCpId(String cpId) {
		this.cpId = cpId;
	}
	public String getBpId() {
		return bpId;
	}
	public void setBpId(String bpId) {
		this.bpId = bpId;
	}
	public String getParentId() {
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public String getBpCode() {
		return bpCode;
	}
	public void setBpCode(String bpCode) {
		this.bpCode = bpCode;
	}
	public String getBpName() {
		return bpName;
	}
	public void setBpName(String bpName) {
		this.bpName = bpName;
	}
	public Integer getLoginStatus() {
		return loginStatus;
	}
	public void setLoginStatus(Integer loginStatus) {
		this.loginStatus = loginStatus;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getLoginPwd() {
		return loginPwd;
	}
	public void setLoginPwd(String loginPwd) {
		this.loginPwd = loginPwd;
	}
	
	

	public String getTwoDimCode() {
		return twoDimCode;
	}

	public void setTwoDimCode(String twoDimCode) {
		this.twoDimCode = twoDimCode;
	}

	public int getTheme() {
		return theme;
	}

	public void setTheme(int theme) {
		this.theme = theme;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public List<GpsDataInfo> getGpsDataInfoList() {
		return gpsDataInfoList;
	}

	public void setGpsDataInfoList(List<GpsDataInfo> gpsDataInfoList) {
		this.gpsDataInfoList = gpsDataInfoList;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUUID() {
		return UUID;
	}

	public void setUUID(String uUID) {
		UUID = uUID;
	}

	public List<TimeQuantum> getTimeQuantum() {
		return timeQuantum;
	}

	public void setTimeQuantum(List<TimeQuantum> timeQuantum) {
		this.timeQuantum = timeQuantum;
	}
	
	
}
