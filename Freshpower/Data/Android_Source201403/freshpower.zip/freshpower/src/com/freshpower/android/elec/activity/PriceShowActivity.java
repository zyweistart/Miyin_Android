package com.freshpower.android.elec.activity;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.view.Window;
import android.widget.TextView;

public class PriceShowActivity extends Activity {

	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_price_show);
		
		ForegroundColorSpan redSpanRed = new ForegroundColorSpan(Color.parseColor("#FF0000"));
		ForegroundColorSpan redSpanGreen = new ForegroundColorSpan(Color.parseColor("#66CC00"));
		ForegroundColorSpan orangeSpanGreen = new ForegroundColorSpan(Color.parseColor("#FF6600"));
		
		TextView textView01 = (TextView)findViewById(R.id.TextView01);  
		SpannableStringBuilder builder = new SpannableStringBuilder(textView01.getText().toString()); 
		builder.setSpan(redSpanRed, 27, 31, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		builder.setSpan(redSpanGreen, 33, 41, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		builder.setSpan(orangeSpanGreen, 56, 59, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		textView01.setText(builder);
		
		TextView textView06 = (TextView)findViewById(R.id.TextView06);  
		SpannableStringBuilder builder06 = new SpannableStringBuilder(textView06.getText().toString()); 
		builder06.setSpan(redSpanRed, 26, 31, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		builder06.setSpan(redSpanGreen, 33, 41, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		builder06.setSpan(orangeSpanGreen, 56, 59, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		textView06.setText(builder06);
		
		ActivityUtil.addActivity(this);
	}
	
}
