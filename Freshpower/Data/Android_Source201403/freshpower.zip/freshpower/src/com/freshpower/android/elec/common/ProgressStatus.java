/**   
 * @{#} ProgressStatus.java Create on 2012-10-23 ����09:30:22   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.common;   
  
/**   
 * @author <a href="mailto:yangz@freshpower.cn">yangz</a>  
 * @version 1.0   
 */

public interface ProgressStatus {
	/**
	 * ���½�����״̬
	 * @param size ��ǰ����
	 * @param totSize �ܽ���
	 */
	public void update(Integer size,Integer totSize);
}
  
