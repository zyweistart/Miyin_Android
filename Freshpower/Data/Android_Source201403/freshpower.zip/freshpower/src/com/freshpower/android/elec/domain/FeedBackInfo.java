package com.freshpower.android.elec.domain;

public class FeedBackInfo {
	private String feedBackInfo;
	private String feedBackMail;
	private String feedBackTel;
	public String getFeedBackInfo() {
		return feedBackInfo;
	}
	public void setFeedBackInfo(String feedBackInfo) {
		this.feedBackInfo = feedBackInfo;
	}
	public String getFeedBackMail() {
		return feedBackMail;
	}
	public void setFeedBackMail(String feedBackMail) {
		this.feedBackMail = feedBackMail;
	}
	public String getFeedBackTel() {
		return feedBackTel;
	}
	public void setFeedBackTel(String feedBackTel) {
		this.feedBackTel = feedBackTel;
	}
	
}
