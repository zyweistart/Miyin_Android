package com.freshpower.android.elec.domain;
/**
 * ���̽�վ�ɼ�����
 * @author Administrator
 *
 */
public class ProjectSiteCollector {
	private String serialNo;// ���к�
	private String lineName;// ��·����
	private String ratio;// ���
	private String lineCrrent;// �����
	private String transType1;// ������
	private String operationType;// �ɼ�����
	private String meterId;// �ɼ���ID
	private String msiteId;// վ��ID
	private String channel;// ͨ��
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getSerialNo() {
		return serialNo;
	}
	public String getMsiteId() {
		return msiteId;
	}
	public void setMsiteId(String msiteId) {
		this.msiteId = msiteId;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	public String getLineName() {
		return lineName;
	}
	public void setLineName(String lineName) {
		this.lineName = lineName;
	}
	public String getRatio() {
		return ratio;
	}
	public void setRatio(String ratio) {
		this.ratio = ratio;
	}
	public String getLineCrrent() {
		return lineCrrent;
	}
	public void setLineCrrent(String lineCrrent) {
		this.lineCrrent = lineCrrent;
	}
	public String getTransType1() {
		return transType1;
	}
	public void setTransType1(String transType1) {
		this.transType1 = transType1;
	}
	public String getOperationType() {
		return operationType;
	}
	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}
	public String getMeterId() {
		return meterId;
	}
	public void setMeterId(String meterId) {
		this.meterId = meterId;
	}
}
