package com.freshpower.android.elec.dao.impl;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.Cursor;

import com.freshpower.android.elec.common.DBException;
import com.freshpower.android.elec.common.DBOperater;
import com.freshpower.android.elec.dao.AppStoreDao;
import com.freshpower.android.elec.domain.AppStore;

/**
 * 
 * @author yangz
 * 
 */
public class AppStoreDaoImpl extends BaseDaoImpl implements AppStoreDao {
	
	public AppStoreDaoImpl(Context context) {
		this.context = context;
	}

	public void insert(AppStore appStore) throws DBException {
		StringBuffer sb = new StringBuffer();
		sb.append("INSERT INTO SM_T_APP_STORE(STORE_KEY,STORE_VALUE) VALUES(");
		sb.append("'").append(appStore.getKey()).append("','");
		sb.append(appStore.getValue()).append("')");
		this.getDBOperater(context).execQuery(sb.toString());
	}

	public List<AppStore> getList() throws DBException {
		List<AppStore>  appStoreList = null;
		
	    StringBuffer sb = new StringBuffer("SELECT ID,STORE_KEY,STORE_VALUE FROM SM_T_APP_STORE ");
	    DBOperater localDBOperater = getDBOperater(context);
	    Cursor localCursor = localDBOperater.openQuery(sb.toString(), null);
	    if (localCursor.getCount() > 0)
	    	appStoreList = new ArrayList<AppStore>();
	    while (localCursor.moveToNext())
	    {
	      AppStore localAppStore = new AppStore();
	      localAppStore.setId(Long.valueOf(localCursor.getLong(localCursor.getColumnIndex("ID"))));
	      localAppStore.setKey(localCursor.getString(localCursor.getColumnIndex("STORE_KEY")));
	      localAppStore.setValue(localCursor.getString(localCursor.getColumnIndex("STORE_VALUE")));
	      appStoreList.add(localAppStore);
	      
	      if (localCursor.isAfterLast())
	      {
	        localCursor.close();
	      }
	    }
	    return appStoreList;
	}

}
