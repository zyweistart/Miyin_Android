package com.freshpower.android.elec.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.domain.BidInfo;
import com.freshpower.android.elec.netapi.BidInfoDataApi;
public class BidDetailsActivity extends Activity {
	/** Called when the activity is first created. */

	private BidInfo bidInfo;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.biddetails);
		ActivityUtil.addActivity(this);
		WebSettings settings;
		try {
			long id=getIntent().getLongExtra(AppConstant.ExtraName.EXTRANAME_ID, 0);
			bidInfo=BidInfoDataApi.getBidInfo(String.valueOf(id));
			TextView Details_bidTv=(TextView)findViewById(R.id.Details_bidTv);
			Details_bidTv.setText(R.string.details_bidTv);
			TextView Details_bidTitleTv=(TextView)findViewById(R.id.Details_bidTitleTv);
			Details_bidTitleTv.setText(bidInfo.getTitle());
			TextView Details_bidTimeTv=(TextView)findViewById(R.id.Details_bidTimeTv);
			Details_bidTimeTv.setText(bidInfo.getPubtime());
			WebView wv=(WebView) findViewById(R.id.bid_wv);
			settings = wv.getSettings();
			settings.setSupportZoom(true);
			//Log.d("BID", String.valueOf(settings.getTextSize()));
			if (settings.getTextSize() == WebSettings.TextSize.SMALLEST) {
				settings.setTextSize(WebSettings.TextSize.SMALLEST);
			} else if (settings.getTextSize() == WebSettings.TextSize.SMALLER) {
				settings.setTextSize(WebSettings.TextSize.SMALLER);
			} else if (settings.getTextSize() == WebSettings.TextSize.NORMAL) {
				settings.setTextSize(WebSettings.TextSize.NORMAL);
			} else if (settings.getTextSize() == WebSettings.TextSize.LARGER) {
				settings.setTextSize(WebSettings.TextSize.LARGER);
			} else if (settings.getTextSize() == WebSettings.TextSize.LARGEST) {
				settings.setTextSize(WebSettings.TextSize.LARGEST);
			}

			wv.loadDataWithBaseURL(null, bidInfo.getContent(), "text/html", "UTF-8",null) ;
			//wv.loadUrl(bidInfo.getContent());
			ImageView iv=(ImageView)findViewById(R.id.nav_left);
			iv.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View arg0) {
//					Intent intent=new Intent(BidDetailsActivity.this,BidInfoListActivity.class);
//					startActivity(intent);
//					finish();
					BidDetailsActivity.this.onBackPressed();
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}