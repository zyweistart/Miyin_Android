package com.freshpower.android.elec.activity;

import java.util.Map;
import java.util.Timer;

import org.apache.http.conn.HttpHostConnectException;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.netapi.WarningSetApi;

public class WarningSetDialogActivity extends Activity {
	private ImageView closeButton;  
	private EditText factorEdit;
	private EditText demandEdit;
	private String cpId;
	private String factor;
	private String demand;
	private ProgressDialog processProgress;
	private Map<String,Object> map;
	private static final int SUBMIT_FINISH = 0x100;// �ύ�ɹ�
	private static final int SUBMIT_ERROR = 0x200;// �ύʧ��
	private static final int NETWORK_ERROR = 0x300;// �����쳣
	private static final int SYSTEM_ERROR = 0x400;// ϵͳ����
	private static final int SYSTEM_FINISH = 0x500;// �رս�����
	private String alertMsg;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		setContentView(R.layout.activity_waring_set_dialog);
		ActivityUtil.addActivity(this);
		Intent intent = getIntent();
		cpId = intent.getStringExtra("cpId");
		factor = intent.getStringExtra("factor");
		demand = intent.getStringExtra("demand");
		factorEdit = (EditText)findViewById(R.id.factorEdit);
		factorEdit.setText(factor);
		demandEdit = (EditText)findViewById(R.id.demandEdit);
		demandEdit.setText(demand);
		closeButton = (ImageView)findViewById(R.id.closeBtn);
		closeButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				WarningSetDialogActivity.this.onBackPressed();
			}
		});
		Button submitBtn = (Button)findViewById(R.id.submit);
		submitBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				processProgress = ProgressDialog.show(WarningSetDialogActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
        		//�߳����ݴ���
        		new Thread(){
        			public void run() {
        				Message msgMessage = null;
        				try{
        					factorEdit = (EditText)findViewById(R.id.factorEdit);
        					demandEdit = (EditText)findViewById(R.id.demandEdit);
        					map = WarningSetApi.editWarningSet(cpId, factorEdit.getText().toString(), demandEdit.getText().toString());
        					msgMessage = new Message();
        					if(map.get("result").equals("1")) {
        						msgMessage = new Message();
        						msgMessage.what = SUBMIT_FINISH;
        						WarningSetDialogActivity.this.xHandler.sendMessage(msgMessage);
        					} else {
        						alertMsg = map.get("remark").toString().substring(map.get("remark").toString().indexOf(",")+1);
        						msgMessage = new Message();
        						msgMessage.what = SUBMIT_ERROR;
        						WarningSetDialogActivity.this.xHandler.sendMessage(msgMessage);
        					}
        				} catch(HttpHostConnectException e) {
        					msgMessage = new Message();
        					msgMessage.what = NETWORK_ERROR;
        					WarningSetDialogActivity.this.xHandler.sendMessage(msgMessage);
        					e.printStackTrace();
        				} catch (Exception e) {
        					alertMsg = map.get("remark").toString().substring(map.get("remark").toString().indexOf(",")+1);
        					msgMessage = new Message();
        					msgMessage.what = SYSTEM_ERROR;
        					WarningSetDialogActivity.this.xHandler.sendMessage(msgMessage);
        					e.printStackTrace();
        				} finally {
        					msgMessage = new Message();
        					msgMessage.what = SYSTEM_FINISH;
        					WarningSetDialogActivity.this.xHandler.sendMessage(msgMessage);
        				}
        			};
        		}.start();
			}
		});
	}
	
	private Handler xHandler = new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case SUBMIT_FINISH:
				finish();
				Toast.makeText(WarningSetDialogActivity.this, "�ύ�ɹ���", Toast.LENGTH_SHORT).show(); 
				break;
			case SUBMIT_ERROR:
				Toast.makeText(WarningSetDialogActivity.this, alertMsg, Toast.LENGTH_SHORT).show();
				break;
			case SYSTEM_ERROR:
				Toast.makeText(WarningSetDialogActivity.this, alertMsg, Toast.LENGTH_SHORT).show();
				break;
			case NETWORK_ERROR:
				Toast.makeText(WarningSetDialogActivity.this, R.string.msg_abnormal_net2work, Toast.LENGTH_SHORT).show(); 		
				break;
			case SYSTEM_FINISH:
				processProgress.dismiss();
				break;
			default:
				break;
			}
		};
				
	};
}
