package com.freshpower.android.elec.common;

/*
 * ͨѶ����
 */
public class CommunicationManager {
	
	public static String getLogincmd(String loginName,String loginPwd){
		StringBuffer sb = new StringBuffer();
		sb.append("hetp9999000099instdata")
		.append(loginName)
		.append(" ")
		.append(loginPwd)
		.append("hh");
		return sb.toString();
	}
}
