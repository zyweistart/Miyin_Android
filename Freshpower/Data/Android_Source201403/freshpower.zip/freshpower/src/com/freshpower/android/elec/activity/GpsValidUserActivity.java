/**
 * 
 */
package com.freshpower.android.elec.activity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppCache;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.DateUtil;
import com.freshpower.android.elec.common.AppConstant.GpsRequestQueryRtype;
import com.freshpower.android.elec.domain.LoginInfo;
import com.freshpower.android.elec.netapi.GpsDataApi;
/**
 * @author allin
 * 
 */
public class GpsValidUserActivity extends ListActivity {
	private List<Map<String, Object>> mData;
	private int gpsRequestQueryRtype;
	private String startDateStr = "";
	private String endDateStr = "";
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		gpsRequestQueryRtype = getIntent().getIntExtra("GpsRequestQueryRtype", 0);
		mData = getData();
		
		if(mData.size()==0){
			Intent intent=new Intent();
			setResult(AppConstant.ResultCode.RESULT_CODE_RESULT_NULL, intent);
			GpsValidUserActivity.this.finish();
		}
		
		MyAdapter adapter = new MyAdapter(this);
		setListAdapter(adapter);
	}

	private List<Map<String, Object>> getData() {
		
		List<LoginInfo> userList = null;
		try {
			if(gpsRequestQueryRtype == GpsRequestQueryRtype.SEARCH_MONTH){
				/*startDateStr = DateUtil.getCurrentFirstDayOfMonth();
				endDateStr = DateUtil.getCurrentLastDayOfMonth();*/
				startDateStr = DateUtil.amountDateStr(Calendar.DAY_OF_MONTH, -30);
				endDateStr = DateUtil.getDateTime(new Date(), "yyyy-MM-dd 23:59");
				Log.d("trmsDebug", "startDateStr:"+startDateStr);
				Log.d("trmsDebug", "endDateStr:"+endDateStr);
			}else if(gpsRequestQueryRtype == GpsRequestQueryRtype.SEARCH_DAY){
				startDateStr = DateUtil.getDateTime(new Date(), "yyyy-MM-dd 00:00");
				endDateStr = DateUtil.getDateTime(new Date(), "yyyy-MM-dd 23:59");
			}
			
			userList = GpsDataApi.getValidUserList((LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ),startDateStr,endDateStr);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		
		Map<String, Object> map = null;
		
		if(userList!=null){
			for (int i = 0; i < userList.size(); i++) {
				map = new HashMap<String, Object>();
				map.put("userName", userList.get(i).getUserName());
				map.put("phoneNum", userList.get(i).getPhoneNum());
				map.put("UUID", userList.get(i).getUUID());
				map.put("userId", userList.get(i).getUserId());
				list.add(map);
			}
		}
		
		return list;
	}
	
	// ListView ��ĳ�ѡ�к���߼�
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
	}
	
	/**
	 * listview�е�����������Ի���
	 */
	public void showInfo(String phoneNum,String UUID,String userId,String userName){
		Intent intent=new Intent();
		intent.putExtra("GpsRequestQueryRtype", getIntent().getIntExtra("GpsRequestQueryRtype", 0));
		intent.putExtra("phoneNum", phoneNum);
		intent.putExtra("UUID", UUID);
		intent.putExtra("userId", userId);
		intent.putExtra("userName", userName);
		intent.putExtra("startDateStr", startDateStr);
		intent.putExtra("endDateStr", endDateStr);
		
		setResult(AppConstant.ResultCode.RESULT_CODE_SUCCESS, intent);
		GpsValidUserActivity.this.finish();
	}
	
	public final class ViewHolder{
		public TextView userName;
		public TextView phoneNum;
		public Button viewBtn;
	}
	
	public class MyAdapter extends BaseAdapter{

		private LayoutInflater mInflater;
		
		
		public MyAdapter(Context context){
			this.mInflater = LayoutInflater.from(context);
		}
		@Override
		public int getCount() {
			return mData.size();
		}

		@Override
		public Object getItem(int arg0) {
			return null;
		}

		@Override
		public long getItemId(int arg0) {
			return 0;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			
			ViewHolder holder = null;
			if (convertView == null) {
				
				holder=new ViewHolder();  
				
				convertView = mInflater.inflate(R.layout.listitem_validuser, null);
				holder.userName = (TextView)convertView.findViewById(R.id.userName);
				holder.phoneNum = (TextView)convertView.findViewById(R.id.phoneNum);
				holder.viewBtn = (RadioButton)convertView.findViewById(R.id.view_btn);
				convertView.setTag(holder);
				
			}else {
				
				holder = (ViewHolder)convertView.getTag();
			}
			
			holder.userName.setText((String)mData.get(position).get("userName"));
			holder.phoneNum.setText((String)mData.get(position).get("phoneNum"));
			
			holder.viewBtn.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					showInfo((String)mData.get(position).get("phoneNum"),(String)mData.get(position).get("UUID"),(String)mData.get(position).get("userId"),(String)mData.get(position).get("userName"));					
				}
			});
			
			return convertView;
		}
		
	}
	
	
	
	
}
