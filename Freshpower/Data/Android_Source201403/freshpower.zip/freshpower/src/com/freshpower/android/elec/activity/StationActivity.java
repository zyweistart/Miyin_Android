package com.freshpower.android.elec.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.domain.CustomerInfo;
import com.freshpower.android.elec.netapi.StationInfoDataApi;
import com.freshpower.android.elec.widget.PullDownListView;

public class StationActivity  extends FrameActivity  implements PullDownListView.OnRefreshListioner{
	private RoundCornerListView groupOnelistview;
	private PullDownListView mPullDownView;
	private ListView mListView;
	private Resources res;
	private ImageButton homeBtn;
	private List<CustomerInfo> customerInfoList;
	private Handler mHandler = new Handler();
	private int pageSize = 10;//ÿҳ��ʾ
	private int currentPage =1;//��ǰҳ
	private int totalCnt=0;//�ܼ�¼��
	private int rs=999;//��ѯ���
	private SimpleAdapter adapter;
	private RelativeLayout progressRlt = null;
	List<Map<String, Object>> customerInfoMap;
	private ProgressDialog processProgress;
	private Handler handler = new Handler();
	private String cpName = "";// �ͻ�����
	private EditText cpNameEdit;
	private Button queryBtn;
	private TextView nameView;
	private TextView searchTitle;
	private AlertDialog alertDialog;

	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_station);
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				StationActivity.this.onBackPressed();	
			}
		});
		
		Button btn = (Button)findViewById(R.id.station_search);
		btn.setOnClickListener(new mapSearchDialogIbClickListener());

		mPullDownView = (PullDownListView) findViewById(R.id.sreach_list);
		mPullDownView.setRefreshListioner(this);
		mListView = mPullDownView.mListView;
		mListView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent,
					View view, int position, long id) {
				Intent intent = new Intent(StationActivity.this,StationDetailActivity.class);
				Map map=(Map) customerInfoMap.get(position-1);
				intent.putExtra("ID", String.valueOf(map.get("ID")));
				startActivity(intent);
//				finish();
			}	
		});
		processProgress = ProgressDialog.show(StationActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(){
			public void run() {
				customerInfoMap = getGroupOnelistData(customerInfoList);
				Message msgMessage = new Message();
				StationActivity.this.xHandler.sendMessage(msgMessage);
			}
		}.start();

	}
	private Handler xHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			adapter = new SimpleAdapter(StationActivity.this,customerInfoMap, 
					R.layout.listitem_station_style, 
					new String[] { AppConstant.ListItemWarnName.WARN_ONE, 
					AppConstant.ListItemWarnName.WARN_TWO,
					AppConstant.ListItemWarnName.WARN_THREE,
					AppConstant.ListItemWarnName.WARN_FOUR
			}, 
			new int[] { 
					R.id.stationOne,
					R.id.stationTwo,
					R.id.stationThree,
					R.id.stationFour});
			mListView.setAdapter(adapter);
			if(customerInfoMap.size()==0){
				Toast.makeText(StationActivity.this, R.string.noSearchResultMsg,Toast.LENGTH_SHORT).show();
				rs=AppConstant.Result.NO_COUNT;
			} else {
				rs=AppConstant.Result.SUCCESS;
			}
			setShow();
			//	    		progressRlt.setVisibility(View.GONE);
			mPullDownView.setVisibility(View.VISIBLE);
			processProgress.dismiss();
		};
	};
	private void setShow() {
		RelativeLayout noResultlayout = (RelativeLayout) findViewById(R.id.noResultlayout);
		if(rs==AppConstant.Result.NO_COUNT){
			noResultlayout.setVisibility(View.VISIBLE);
			mPullDownView.setMore(false);
		}else{
			noResultlayout.setVisibility(View.GONE);
			mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
		}
		if(totalCnt<=pageSize){
			mPullDownView.setMore(false);
		}
	}    
	@Override
	public void onRefresh() {
		// TODO Auto-generated method stub
		mHandler.postDelayed(new Runnable() {

			public void run() {
				customerInfoMap.clear();
				currentPage =1;
				customerInfoMap.addAll(getGroupOnelistData(customerInfoList));

				mPullDownView.onRefreshComplete();//�����ʾˢ�´�����ɺ������ļ���ˢ�½�������
				mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				if(totalCnt<=pageSize){
					mPullDownView.setMore(false);
				}
				adapter.notifyDataSetChanged();	
			}
		}, 1500);

	}
	@Override
	public void onLoadMore() {
		mHandler.postDelayed(new Runnable() {
			public void run() {

				currentPage++;
				customerInfoMap.addAll(getGroupOnelistData(customerInfoList));

				mPullDownView.onLoadMoreComplete();//�����ʾ���ظ��ദ����ɺ������ļ��ظ�����棨���ػ��������������ࣩ
				//if(list.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
				if(customerInfoMap.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
					mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				else
					mPullDownView.setMore(false);
				adapter.notifyDataSetChanged();	

			}
		}, 1500);

	}


	private List<Map<String, Object>> getGroupOnelistData(List<CustomerInfo> customerInfoList){
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		res = getResources();
		try {
			Map customerInfoMap=StationInfoDataApi.getStationInfoList(pageSize,currentPage,cpName);
			customerInfoList=(List<CustomerInfo>) customerInfoMap.get("customerInfoList");
			for (CustomerInfo customerInfo:customerInfoList)
			{
				Map<String, Object> listItem = new HashMap<String, Object>();
				listItem.put(AppConstant.ListItemWarnName.WARN_ONE, customerInfo.getCpName());
				listItem.put(AppConstant.ListItemWarnName.WARN_TWO, customerInfo.getTransCount());
				listItem.put(AppConstant.ListItemWarnName.WARN_THREE,customerInfo.getMaxDate());
				listItem.put(AppConstant.ListItemWarnName.WARN_FOUR, customerInfo.getMaxLoad());
				listItem.put("ID", customerInfo.getCpId());
				listItems.add(listItem);
			}
			totalCnt = Integer.parseInt(String.valueOf(customerInfoMap.get("totalCount")));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listItems;
	}
	protected void onResume() {
		homeBtn = (ImageButton) findViewById(R.id.stationDataBtn);
		if(homeBtn!=null){
			homeBtn.setOnClickListener(null);
			homeBtn.setBackgroundResource(R.drawable.databtn_select);
		}

		TextView toolBtnTv = (TextView)findViewById(R.id.stationDataTv);
		toolBtnTv.setTextColor(getResources().getColor(R.color.orange));

		super.onResume();
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		if(mPullDownView!=null){
			customerInfoMap.clear();
		}
		super.onDestroy();
	}
	
	private class mapSearchDialogIbClickListener implements
	View.OnClickListener {
		@Override
		public void onClick(View v) {
			LayoutInflater factory = LayoutInflater
					.from(StationActivity.this);
			final View dialogView = factory.inflate(R.layout.activity_station_search,
					null);
			dialogView.setBackgroundResource(android.R.color.white);
			searchTitle = (TextView)dialogView.findViewById(R.id.search_title);
			nameView = (TextView)dialogView.findViewById(R.id.name_view);
			searchTitle.setText("�ͻ���ѯ");
			nameView.setText("�ͻ�����");
			queryBtn = (Button)dialogView.findViewById(R.id.submit);
			queryBtn.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							processProgress = ProgressDialog.show(StationActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
							new Thread(){
								public void run() {
									cpNameEdit = (EditText) dialogView.findViewById(R.id.name_edit);
									cpName = cpNameEdit.getText().toString();
									alertDialog.cancel();
									customerInfoMap.clear();
									customerInfoMap = getGroupOnelistData(customerInfoList);
									Message msgMessage = new Message();
									StationActivity.this.xHandler.sendMessage(msgMessage);
								}
							}.start();
						}
					});
			// ����Ի���
			alertDialog = new AlertDialog.Builder(StationActivity.this).create();
			alertDialog.setView(dialogView,0,0,0,0);
			alertDialog.show();
			
			ImageView closebtn = (ImageView)dialogView.findViewById(R.id.closeBtn);
			closebtn.setOnClickListener(new OnClickListener(){
				public void onClick(View arg0) {
					alertDialog.cancel();
				}
			});
		}
	}
	
}
