package com.freshpower.android.elec.activity;



import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

public class WarnSearchActivity extends FrameActivity {
	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_warnsearch);
		ActivityUtil.addActivity(this);
		Button btn=(Button)findViewById(R.id.warnSub);
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				WarnSearchActivity.this.onBackPressed();
			}
		});
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				EditText edt=(EditText)findViewById(R.id.warnName);
				String  warnName=edt.getText().toString();
				Spinner spn=(Spinner)findViewById(R.id.warnLevel);
				String warnLevel=String.valueOf(spn.getSelectedItemId());
				Spinner sort=(Spinner)findViewById(R.id.warnSort);
				String warnSort=String.valueOf(sort.getSelectedItemId());
				if(warnName==null||warnName.equals("")){
					Toast.makeText(WarnSearchActivity.this, R.string.warn_search_name, Toast.LENGTH_SHORT).show();
					return;
				}
				if(warnLevel==null||warnLevel.equals("")){
					Toast.makeText(WarnSearchActivity.this, R.string.warn_search_level, Toast.LENGTH_SHORT).show(); 
					return;
				}
				try {
//					Map warnMap = StationInfoDataApi.getWarnSearchInfo(warnName,warnLevel);
					Intent intent = new Intent(WarnSearchActivity.this,WarnActivity.class);
					intent.putExtra("warnSearch", "warnSearch");
					intent.putExtra("warnSearchName", warnName);
					intent.putExtra("warnSearchLevel", warnLevel);
					intent.putExtra("warnSearchSort", warnSort);
		    		startActivity(intent);
		    		finish();
				}catch (Exception e) {
					Toast.makeText(WarnSearchActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show(); 
					e.printStackTrace();
				}
			}
		});
	}
}
