package com.freshpower.android.elec.activity;

import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TabWidget;
import android.widget.TextView;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.SizeUtil;
import com.freshpower.android.elec.common.StringUtil;

public class BuyActivity extends TabActivity {
	private String userType = "";
	private String comeInFrom = "" ;
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_buy);
		userType = getIntent().getStringExtra("userType");
		comeInFrom = getIntent().getStringExtra("comeInFrom");
//		Log.d("BID", "BID2");
//		Log.d("BID", userType);
		TabHost tabHost = getTabHost();
		
		Intent priceShowIntent = new Intent();
		priceShowIntent.setClass(this, PriceShowActivity.class);
		TabHost.TabSpec priceShowTS = tabHost.newTabSpec("�۸�չʾ");
		priceShowTS.setIndicator("�۸�չʾ");
		priceShowTS.setContent(priceShowIntent);
		tabHost.addTab(priceShowTS);
		
		Intent quotationIntent = new Intent();
		quotationIntent.setClass(this, QuotationActivity.class);
		TabHost.TabSpec quotationTS = tabHost.newTabSpec("���߱��۵�");
		quotationTS.setIndicator("���߱��۵�");
		quotationTS.setContent(quotationIntent);
		tabHost.addTab(quotationTS);
		
		TabWidget tabWidget = tabHost.getTabWidget();
		 for (int i =0; i < tabWidget.getChildCount(); i++) {
			 tabWidget.getChildAt(i).getLayoutParams().height = SizeUtil.dip2px(this, 40F);
			 tabWidget.getChildAt(i).getLayoutParams().width = SizeUtil.dip2px(this, 65F);
			 tabWidget.getChildAt(i).setBackgroundResource(R.color.purple);
			 TextView tv = (TextView) tabWidget.getChildAt(i).findViewById(android.R.id.title);
			 tv.setTextSize(15);
			 tv.setTextColor(this.getResources().getColorStateList(android.R.color.white));
		 }
		
		// �����¼�
		ImageView returnButton = (ImageView) findViewById(R.id.nav_left);
		returnButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(!StringUtil.isEmpty(userType)) {
					Intent intent = new Intent(BuyActivity.this,UserExperienceSecondActivity.class);
					intent.putExtra("userType", userType);
					startActivity(intent);
					finish();
				} else {
					BuyActivity.this.onBackPressed();
				}
			}
		});
		
		Button onlineBuyBtn = (Button)findViewById(R.id.onlineBuyBtn);
		onlineBuyBtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Uri uri = Uri.parse("http://www.fps365.net/WEB/Index/lineOrder/LostElery.aspx");
				Intent buyIntent = new Intent(Intent.ACTION_VIEW,uri);
				startActivity(buyIntent);
			}
		});
	}
	
}
