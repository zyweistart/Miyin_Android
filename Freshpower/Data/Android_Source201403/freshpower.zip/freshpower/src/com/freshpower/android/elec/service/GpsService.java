/**   
 * @{#} GpsService.java Create on 2013-4-17 ����08:48:23   
 *   
 * Copyright (c) 2012 by yangz.   
 */
package com.freshpower.android.elec.service;

import java.util.Date;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.text.format.DateFormat;
import android.util.Log;

import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.FileUtil;
import com.freshpower.android.elec.common.LogFactory;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.common.SystemServiceUtil;
import com.freshpower.android.elec.domain.GpsDataInfo;
import com.freshpower.android.elec.domain.LoginInfo;
import com.freshpower.android.elec.netapi.GpsDataApi;

/**
 * @author <a href="mailto:yangz@freshpower.cn">yangz</a>
 * @version 1.0
 */

public class GpsService extends Service {

	private LogFactory logger = LogFactory.getLogger(GpsService.class);
	private LocationManager locationManager;
	private String provider;
	private boolean threadDisable;
	private WakeLock mWakeLock;
	private GpsDataInfo gpsDataInfo;
	private UserLocationListener userLocationListener;
	private final long minTime = 30000;
	private final float minDistance = 0;
	private LoginInfo user;
	private final long defaultFrequency = 60000;

	@Override
	public IBinder onBind(Intent intent) {
		logger.d("trmsDebug", "onBind...");
		return null;
	}

	/**
	 * ����services�������ȵ���
	 */
	@Override
	public void onCreate() {
		logger.d("trmsDebug", "GpsService onCreate...");
		this.acquireWakeLock();

		FileUtil.appFilesDir = this.getFilesDir().getPath();
		String fileContentStr = FileUtil.read(FileUtil.getDBFilePath());
		if (!StringUtil.isEmpty(fileContentStr)) {
			user = new LoginInfo();
			user.setLoginName(fileContentStr.split("\\|")[0]);
			user.setLoginPwd(fileContentStr.split("\\|")[1]);
			user.setKey(SystemServiceUtil.getTelephonyManager(this)
					.getDeviceId());
		}

		locationManager = (LocationManager) this
				.getSystemService(Context.LOCATION_SERVICE);
		userLocationListener = new UserLocationListener();
		Criteria criteria = initLocation();
		provider = locationManager.getBestProvider(criteria, true);
		if (provider == null) {
			provider = LocationManager.GPS_PROVIDER;
		}
		locationManager.requestLocationUpdates(provider, minTime, minDistance,
				userLocationListener);
		super.onCreate();
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		logger.d("trmsDebug", "Service onStartCommand");

		Thread gpsSendThread = new Thread(new Runnable() {
			@Override
			public void run() {
				while (!threadDisable) {
					try {
						logger.d("trmsDebug", "gps send...:" + this);
						if (gpsDataInfo != null && user != null) {
							GpsDataApi.sendLocationInfo(gpsDataInfo, user);
							gpsDataInfo = null;
						}
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						try {
							Thread.sleep(getSharedPreferences(
									AppConstant.SHARED_PREFERENCE_NAME,
									MODE_PRIVATE).getLong(
									AppConstant.SharedPreferencesKey.FREQUENCY,
									defaultFrequency));
						} catch (InterruptedException e) {
							threadDisable = true;
							e.printStackTrace();
						}
					}
				}
			}
		});
		gpsSendThread.start();

		flags = START_STICKY;
		return super.onStartCommand(intent, flags, startId);
	}

	/**
	 * service���ٵ���
	 */
	@Override
	public void onDestroy() {
		logger.d("trmsDebug", "Service onDestroy");
		threadDisable = true;
		releaseWakeLock();
		if (locationManager != null && userLocationListener != null) {
			locationManager.removeUpdates(userLocationListener);
		}
		super.onDestroy();
	}

	private class UserLocationListener implements LocationListener {

		@Override
		public void onLocationChanged(Location location) {
			logger.d("trmsDebug", "onLocationChanged....");
			gpsDataInfo = getLastLocation(locationManager, provider);
		}

		@Override
		public void onProviderDisabled(String provider) {
			logger.d("trmsDebug", "onProviderDisabled....");
			gpsDataInfo = null;
		}

		@Override
		public void onProviderEnabled(String provider) {
			logger.d("trmsDebug", "onProviderEnabled....");
			Intent intent = new Intent();
			intent.setAction(AppConstant.ReceiverAction.ACTION_GPSSERVICE_START);
			sendBroadcast(intent);
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub
		}
	}

	/**
	 * init GPS
	 * 
	 * @return
	 */
	public Criteria initLocation() {
		Criteria criteria = new Criteria();
		criteria.setAccuracy(Criteria.ACCURACY_FINE);
		criteria.setAltitudeRequired(true);
		criteria.setBearingRequired(true);
		criteria.setCostAllowed(false);
		criteria.setPowerRequirement(Criteria.POWER_LOW);// �͹���
		return criteria;
	}

	public GpsDataInfo getLastLocation(LocationManager lm, String provider) {
		GpsDataInfo data = new GpsDataInfo();
		Location location = lm.getLastKnownLocation(provider);
		if (location != null) {
			data.setDirection(location.getBearing());
			Date d = new Date();
			d.setTime(location.getTime());// UTCʱ��,ת����ʱ��+8Сʱ
			data.setGpsTime(DateFormat.format("yyyy-MM-dd kk:mm:ss", d)
					.toString());
			// data.setLatitude((int) (location.getLatitude() * 1E6));
			// data.setLongitude((int) (location.getLongitude() * 1E6));
			data.setLatitude(location.getLatitude());
			data.setLongitude(location.getLongitude());
			data.setSpeed(location.getSpeed());
		}
		return data;
	}

	private void acquireWakeLock() {
		if (null == mWakeLock) {
			PowerManager pm = (PowerManager) this
					.getSystemService(Context.POWER_SERVICE);
			mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK
					| PowerManager.ON_AFTER_RELEASE, "GpsService");
			if (null != mWakeLock) {
				mWakeLock.acquire();
			}
		}
	}

	private void releaseWakeLock() {
		if (null != mWakeLock) {
			mWakeLock.release();
			mWakeLock = null;
		}
	}

}
