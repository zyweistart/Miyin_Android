package com.freshpower.android.elec.activity;


import org.androidpn.client.Constants;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;

public class MessageInfoActivity extends Activity {
	Button closeBtn;
	EditText titleEt;
	EditText contentEt;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_messageinfo);
		ActivityUtil.addActivity(this);
		
		closeBtn=(Button)findViewById(R.id.closeBtn);
		titleEt=(EditText)findViewById(R.id.titleEt);
		contentEt=(EditText)findViewById(R.id.contentEt);

		Intent intent = getIntent();
		titleEt.setText(intent.getStringExtra(Constants.NOTIFICATION_TITLE));
		contentEt.setText(intent.getStringExtra(Constants.NOTIFICATION_MESSAGE));
		
		closeBtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				MessageInfoActivity.this.finish();
			}
		});
	}

}
