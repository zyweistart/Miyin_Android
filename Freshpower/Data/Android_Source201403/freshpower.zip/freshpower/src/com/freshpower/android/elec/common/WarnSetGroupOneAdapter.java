package com.freshpower.android.elec.common;

import java.util.List;
import java.util.Map;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.activity.LoginActivity;
import com.freshpower.android.elec.activity.ToolActivity;
import com.freshpower.android.elec.activity.WarnHandleActivity;
import com.freshpower.android.elec.domain.CustomerInfo;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.Toast;



public class WarnSetGroupOneAdapter extends BaseAdapter {

	List<Map<String, Object>> mData;
	Context mContext;
	int resource;
	private Intent intent;
	private List<CustomerInfo> warnDetailList;
	private String alertId;
	public WarnSetGroupOneAdapter(List<Map<String, Object>> data,
			Context context, int resource,List<CustomerInfo> warnDetailList) {
		this.mData = data;
		this.mContext = context;
		this.resource = resource;
		this.warnDetailList = warnDetailList;
	}

	@Override
	public int getCount() {
		return mData == null ? 0 : mData.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	static class ViewHoder {
		TextView warnOne;
		TextView warnTwo;
		TextView warnThree;
		TextView warnFour;
		TextView warnFive;
		Button warnHandle;
//		Button warnHistory;
		CheckBox checkBox;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHoder hoder = null;
		if (convertView == null) {
			hoder = new ViewHoder();
			convertView = LayoutInflater.from(mContext).inflate(resource, null);
			hoder.warnOne = (TextView) convertView
					.findViewById(R.id.warnOne);
			hoder.warnTwo = (TextView) convertView
					.findViewById(R.id.warnTwo);
			hoder.warnThree = (TextView) convertView
					.findViewById(R.id.warnThree);
			hoder.warnFour = (TextView) convertView
					.findViewById(R.id.warnFour);
			hoder.warnFive = (TextView) convertView
					.findViewById(R.id.warnFive);
			hoder.warnHandle = (Button) convertView
					.findViewById(R.id.warnHandle);
//			hoder.warnHistory = (Button)convertView
//					.findViewById(R.id.warnHistory);
			hoder.checkBox = (CheckBox)convertView.
					findViewById(R.id.checkBox);
			convertView.setTag(hoder);
		} else {
			hoder = (ViewHoder) convertView.getTag();
		}
		Map<String, Object> data = mData.get(position);
		hoder.warnOne.setText(String.valueOf(data.get("textView1")));
		hoder.warnTwo.setText(String.valueOf(data.get("textView2")));
		hoder.warnThree.setText(String.valueOf(data.get("textView3")));
		hoder.warnFour.setText(String.valueOf(data.get("textView4")));
		hoder.warnFive.setText(String.valueOf(data.get("textView5")));
		if(data.get("checked").equals("false")){
			hoder.checkBox.setChecked(false);
		}else{
			hoder.checkBox.setChecked(true);
		}
		CheckBoxCheckChangerListener changerListener = new CheckBoxCheckChangerListener();
		changerListener.setData(data);
		hoder.checkBox.setOnCheckedChangeListener(changerListener);
//		hoder.warnHistory.setOnClickListener(new OnClickListener() {
//			@Override
//			public void onClick(View arg0) {
//				// TODO Auto-generated method stub
//				Toast.makeText(mContext, "���ڽ�����", Toast.LENGTH_SHORT).show();
//			}
//		});
		
		
		WarnSetItemOnClickListener WarnSetItemOnClickListener = new WarnSetItemOnClickListener();
		WarnSetItemOnClickListener.setAlertId(String.valueOf(data.get("id")));
		hoder.warnHandle.setOnClickListener(WarnSetItemOnClickListener);
		return convertView;
	}
	
	
	
	class CheckBoxCheckChangerListener implements OnCheckedChangeListener{
		Map<String, Object> data;
		public void setData(Map<String, Object> data) {
			this.data = data;
		}
		@Override
		public void onCheckedChanged(CompoundButton buttonView,
				boolean isChecked) {
			if(isChecked){
				data.put("checked", "true");
			}else{
				data.put("checked", "false");
			}
		}
		
	}
	
	 class WarnSetItemOnClickListener implements View.OnClickListener{
		 
		private String alertId;
		
		public void setAlertId(String alertId) {
			this.alertId = alertId;
		}

		@Override
		public void onClick(View v) {
			Intent intent = new Intent(mContext, WarnHandleActivity.class);
			intent.putExtra("alertId", alertId);
			mContext.startActivity(intent);
		}
	}

}
