package com.freshpower.android.elec.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.conn.HttpHostConnectException;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.domain.WarningSet;
import com.freshpower.android.elec.netapi.WarningSetApi;
import com.freshpower.android.elec.widget.PullDownListView;

public class WarningSetActivity extends FrameActivity implements PullDownListView.OnRefreshListioner{
	private Resources res;
	private List<WarningSet> warningSetList;
	private PullDownListView mPullDownView;
	private ListView mListView;
	private WarningSetAdapter adapter; 
	private Handler mHandler = new Handler();
	private int pageSize = 10;//ÿҳ��ʾ
	private int currentPage =1;//��ǰҳ
	private int totalCnt=0;//�ܼ�¼��
	private int rs=999;//��ѯ���
	private List<Map<String, Object>> warningSetMap;
	private ProgressDialog processProgress;
	private String catchNot="yes";
	private String result;
	private Message msgMessage;
	private static final int SYSTEM_FINISH = 0x500;// �رս�����
	private static final int SYSTEM_ERROR = 0x400;// ϵͳ����

	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.warning_set_list);
		res = getResources();
		mPullDownView = (PullDownListView) findViewById(R.id.sreach_list);
		mPullDownView.setRefreshListioner(this);
		mListView = mPullDownView.mListView;
		processProgress = ProgressDialog.show(WarningSetActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(){
			public void run() {
				try{
					warningSetMap = getGroupOnelistData();
					msgMessage = new Message();
					WarningSetActivity.this.xHandler.sendMessage(msgMessage);
				} catch (Exception e) {
					msgMessage = new Message();
					msgMessage.what = SYSTEM_ERROR;
					WarningSetActivity.this.xHandler.sendMessage(msgMessage);
					e.printStackTrace();
				} finally {
					msgMessage = new Message();
					msgMessage.what = SYSTEM_FINISH;
					WarningSetActivity.this.xHandler.sendMessage(msgMessage);
				}
			}
		}.start();
		
		// �����¼�
		ImageView returnButton = (ImageView) findViewById(R.id.nav_left);
		returnButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				WarningSetActivity.this.onBackPressed();
			}
		});
		
	}

	private Handler xHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {

			switch (msg.what) {
			case SYSTEM_ERROR:
				Toast.makeText(WarningSetActivity.this, R.string.msg_abnormal_network, Toast.LENGTH_SHORT).show(); 		
				break;
			case SYSTEM_FINISH:
				adapter = new WarningSetAdapter(warningSetMap,WarningSetActivity.this,R.layout.warning_set_style);	
				mListView.setAdapter(adapter);
				processProgress.dismiss();
				break;
			default:
				break;
			}
			if(warningSetMap==null){
				rs=AppConstant.Result.NO_COUNT;
			}
			setShow();
			mPullDownView.setVisibility(View.VISIBLE);
			processProgress.dismiss();
		};
	};

	private void setShow() {
		if(rs==AppConstant.Result.NO_COUNT){
			RelativeLayout noResultlayout = (RelativeLayout) findViewById(R.id.noResultlayout);
			noResultlayout.setVisibility(View.VISIBLE);
			mPullDownView.setMore(false);
		}else{
			mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
		}
		if(totalCnt<10){
			mPullDownView.setMore(false);
		}
	}
	private List<Map<String, Object>> getGroupOnelistData() throws Exception {
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
			Map warningSetMap = WarningSetApi.getWarningSetList(pageSize, currentPage);
			result = String.valueOf(warningSetMap.get("result"));
			totalCnt = Integer.parseInt(String.valueOf(warningSetMap.get("totalCount")));
			warningSetList = (List<WarningSet>) warningSetMap.get("warningSetList");
			for (WarningSet warningSet : warningSetList)
			{
				Map<String, Object> listItem = new HashMap<String, Object>();
				listItem.put("cpId", warningSet.getCpId());
				listItem.put("cpNameText", warningSet.getCpName());
				listItem.put("factorText", warningSet.getFactor());
				listItem.put("demandText",warningSet.getDemand());
				listItems.add(listItem);
			}
		return listItems;
	}
	/**
	 * ˢ�£������list������Ȼ�����¼��ظ�������
	 */
	public void onRefresh() {

		mHandler.postDelayed(new Runnable() {

			public void run() {
				warningSetMap.clear();
				currentPage =1;
				try {
					warningSetMap.addAll(getGroupOnelistData());
				} catch (Exception e) {
					msgMessage = new Message();
					msgMessage.what = SYSTEM_ERROR;
					WarningSetActivity.this.xHandler.sendMessage(msgMessage);
					e.printStackTrace();
				} finally {
					msgMessage = new Message();
					msgMessage.what = SYSTEM_FINISH;
					WarningSetActivity.this.xHandler.sendMessage(msgMessage);
				}

				mPullDownView.onRefreshComplete();//�����ʾˢ�´�����ɺ������ļ���ˢ�½�������
				mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				if(warningSetMap.size()<10){
					mPullDownView.setMore(false);
				}
				adapter.notifyDataSetChanged();	
			}
		}, 1500);


	}

	/**
	 * ���ظ��࣬��ԭ��������������������
	 */
	public void onLoadMore() {

		mHandler.postDelayed(new Runnable() {
			public void run() {
				//addLists(5);//ÿ�μ�������������

				currentPage++;
				try {
					warningSetMap.addAll(getGroupOnelistData());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				mPullDownView.onLoadMoreComplete();//�����ʾ���ظ��ദ����ɺ������ļ��ظ�����棨���ػ��������������ࣩ
				//if(list.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
				if(warningSetMap.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
					mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				else
					mPullDownView.setMore(false);
				adapter.notifyDataSetChanged();	

			}
		}, 1500);
	}
	/***
	 * ��̬����listview�ĸ߶�
	 * 
	 * @param listView
	 */
	public void setListViewHeightBasedOnChildren(ListView listView) {
		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null) {
			return;
		}
		int totalHeight = 0;
		for (int i = 0; i < listAdapter.getCount(); i++) {
			View listItem = listAdapter.getView(i, null, listView);
			listItem.measure(0, 0);
			totalHeight += listItem.getMeasuredHeight();
		}
		ViewGroup.LayoutParams params = listView.getLayoutParams();
		params.height = totalHeight
				+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
		listView.setLayoutParams(params);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(requestCode == AppConstant.RequestResultCode.REQUEST_WARNINGSET) {
			onRefresh();
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
}
