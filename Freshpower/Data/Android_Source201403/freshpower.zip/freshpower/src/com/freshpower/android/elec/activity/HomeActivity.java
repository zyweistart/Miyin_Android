package com.freshpower.android.elec.activity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ImageView.ScaleType;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppCache;
import com.freshpower.android.elec.common.FileUtil;
import com.freshpower.android.elec.common.UpdateManager;
import com.freshpower.android.elec.dao.DaoFactory;
import com.freshpower.android.elec.dao.LoginPurviewDao;
import com.freshpower.android.elec.domain.LoginInfo;

public class HomeActivity extends FrameActivity {
	private String[] menutitleNames;
	private String[] menudetailNames;
	private int[] menuIcoIds;
	private Resources res;
	private ImageButton homeBtn;
	private LinearLayout userExperienceBtn;
	private Integer num;
	private Intent intent;
	private TextView homeBtnTv;
	private LoginInfo loginInfo;
	private File pictureNameFile;
	private String sdpath = FileUtil.getAppRootPath();// ��ô洢����·��
	
	//����ʹ��ͨ�ñ���
	private File newsFile;
	private String[] content;
	private String[] titles;
	private String[] pictureNames;
	private String[] visitURL;
	private String[] details;
	
	
	private ViewPager viewPager; // android-support-v4�еĻ������
	private List<ImageView> imageViews; // ������ͼƬ����
	private int[] imageResId; // ͼƬID
	private LinearLayout dots; // ͼƬ�������ĵ���Щ��
	private int currentItem = 0; // ��ǰͼƬ��������
	private ScheduledExecutorService scheduledExecutorService;
	
	private LoginPurviewDao loginPurviewDao;
	
	public LoginPurviewDao getLoginPurviewDao() {
		return loginPurviewDao;
	}

	public void setLoginPurviewDao(LoginPurviewDao loginPurviewDao) {
		this.loginPurviewDao = loginPurviewDao;
	}

	@Override
	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_home);
		res = getResources();
		loginPurviewDao=DaoFactory.getLoginPurviewDao(HomeActivity.this);
		Intent updateIntent = getIntent();
		String isFirst =updateIntent.getStringExtra("isFirst");
		if(null!=isFirst&&isFirst.equals("isFirst")){
			UpdateManager manager = new UpdateManager(HomeActivity.this);
			manager.checkUpdate(true);
		}
		
		LinearLayout Home_thrid = (LinearLayout) findViewById(R.id.Home_thrid);
		newsFile = new File(sdpath+"download"+File.separator+"newsFile.txt");
		if (android.os.Environment.getExternalStorageState().equals(
				android.os.Environment.MEDIA_MOUNTED) //�ж��Ƿ��SD���ж�дȨ��
				&& newsFile.exists()){ //�жϸ��ļ����Ƿ����) 
			this.setNews();
			File file = new File(sdpath+"download/www/images");
			num=(int) ((Math.random()*file.list().length));
		}else{
			num=(int) ((Math.random()*3));
		}
		Home_thrid.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				intent = new Intent(HomeActivity.this,HomeIntroduceActivity.class);
				if(newsFile.exists()){
					intent.putExtra("type", visitURL[num]);
				}else{
					intent.putExtra("type", num.toString());
				}
				startActivity(intent);
			}
		});
		menuIcoIds = new int[]{ R.drawable.pic_1,R.drawable.pic_3,R.drawable.pic_4,R.drawable.pic_5};
		menutitleNames=res.getStringArray(R.array.soft_homeinformation_menuNames);
		menudetailNames=res.getStringArray(R.array.soft_homeinformationdetail_menuNames);
		ImageView thridImage=(ImageView)findViewById(R.id.homeThridImageName);
		TextView thridTextName=(TextView)findViewById(R.id.homeThridTextName);
		TextView thridTextNameDetial=(TextView)findViewById(R.id.homeThridTextNameDetial);
		if(newsFile.exists()){
			LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT);  
			String path = pictureNames[num];// MMͼƬ·��
			String filePath = sdpath+"download/www/images/";
			Bitmap bm = BitmapFactory.decodeFile(filePath+path.split("\\.")[0]);//����ͼƬչ��
			thridImage.setImageBitmap(bm);
			thridImage.setLayoutParams(lp2);
			thridTextName.setText(titles[num]);
			thridTextNameDetial.setText(details[num]);
			thridImage.destroyDrawingCache();//�ͷ�ͼƬ��ռ�ڴ�
		}else{
			thridImage.setBackgroundResource(menuIcoIds[num]);
			thridTextName.setText(menutitleNames[num]);
			thridTextNameDetial.setText(menudetailNames[num]);
		}
		bindEvent();
		
		//����ҳ����ͷ������ͼƬ
		imageViews = new ArrayList<ImageView>();
		pictureNameFile = new File(sdpath+"download"+File.separator+"pictureNameFile.txt");
		try {
			if (android.os.Environment.getExternalStorageState().equals(
					android.os.Environment.MEDIA_MOUNTED) //�ж��Ƿ��SD���ж�дȨ��
					&& pictureNameFile.exists()){ //�жϸ��ļ����Ƿ����) 
				setTopPicture();
			}else{
				imageResId = new int[] { R.drawable.image1, R.drawable.image2, R.drawable.image3, R.drawable.image4 };
				for (int i = 0; i < imageResId.length; i++) {
					ImageView imageView = new ImageView(this);
					imageView.setBackgroundResource(imageResId[i]);
					imageView.setScaleType(ScaleType.CENTER_CROP);
					imageViews.add(imageView);
					imageView.destroyDrawingCache();
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		dots = (LinearLayout)findViewById(R.id.dot);
		RelativeLayout.LayoutParams lp; 
		ImageView view;
		for(int i = 0 ; i < imageViews.size() ;i++){
			view = new ImageView(HomeActivity.this);
			lp = new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
			lp.setMargins(2, 0, 2, 0);
			view.setLayoutParams(lp);
			view.setImageResource(R.drawable.dot_unselected);
			dots.addView(view);
			view.destroyDrawingCache();
		}
		view = (ImageView)dots.getChildAt(0);
		view.setImageResource(R.drawable.dot_selected);
		
		viewPager = (ViewPager) findViewById(R.id.vp);
		viewPager.setAdapter(new TopPictureAdapter());// �������ViewPagerҳ���������
		// ����һ������������ViewPager�е�ҳ��ı�ʱ����
		viewPager.setOnPageChangeListener(new MyPageChangeListener());
		scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
		// ��Activity��ʾ������ÿ�������л�һ��ͼƬ��ʾ
		scheduledExecutorService.scheduleAtFixedRate(new ScrollTask(), 1, 3, TimeUnit.SECONDS);
	}
	
	// �л���ǰ��ʾ��ͼƬ
	private Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			viewPager.setCurrentItem(currentItem);// �л���ǰ��ʾ��ͼƬ
		};
	};


	//���¼�
	private void bindEvent() {
		LinearLayout homePhoneDebugLl = (LinearLayout) findViewById(R.id.homePhoneDebugLl);//���Թ���
		homePhoneDebugLl.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if(android.os.Build.VERSION.SDK_INT > android.os.Build.VERSION_CODES.HONEYCOMB_MR1){
							intent = new Intent(HomeActivity.this,PhoneDebugActivity.class);
							startActivity(intent);
				}else{
					Toast.makeText(HomeActivity.this, R.string.msg_32_support_version,
					Toast.LENGTH_LONG).show();
				}
//				Intent intent = new Intent(HomeActivity.this, UserExperienceActivity.class);
//				startActivity(intent);
			}
		});
		LinearLayout homeSecondButtom3 = (LinearLayout) findViewById(R.id.Home_second_buttom3);//ɨ�����
		homeSecondButtom3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
				if(null!=loginInfo&&!"".equals(loginInfo)&&null!=loginInfo.getLoginName()&&!"".equals(loginInfo.getLoginName())){
							Intent intent = new Intent(HomeActivity.this,ScanActivity.class);
							intent.putExtra("loginName", loginInfo.getLoginName());
							intent.putExtra("loginPwd", loginInfo.getLoginPwd());
							startActivity(intent);
				}else{
					Intent intent = new Intent(HomeActivity.this,LoginActivity.class);
					intent.putExtra("LoginType", "scan");
					startActivity(intent);
				}
			}
		});
		userExperienceBtn = (LinearLayout) findViewById(R.id.Home_second_top2);//�ҹ�Ͻ�ı��վ
		userExperienceBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
				if(null!=loginInfo&&!"".equals(loginInfo)&&null!=loginInfo.getLoginName()&&!"".equals(loginInfo.getLoginName())){
					try {
						boolean result=loginPurviewDao.selectLoginInfo(res.getString(R.string.home_second_top2_bpcode));
						if(result){
							Intent intent = new Intent(HomeActivity.this,StationActivity.class);
							startActivity(intent);
						}else{
							Toast.makeText(HomeActivity.this, R.string.login_purview_bpcode,
									Toast.LENGTH_LONG).show();
						}
					}catch (Exception e) {
						Toast.makeText(HomeActivity.this, R.string.login_purview_bpcode,
								Toast.LENGTH_LONG).show();
						e.printStackTrace();
					}
				}else{
					Intent intent = new Intent(HomeActivity.this,LoginActivity.class);
					intent.putExtra("LoginType", "station");
					startActivity(intent);
				}
			}
		});
		LinearLayout onlineCalculation =(LinearLayout)findViewById(R.id.Home_second_buttom4);
		onlineCalculation.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(HomeActivity.this,OnlineCalcActivity.class);
				startActivity(intent);
			}
		});

		userExperienceBtn = (LinearLayout) findViewById(R.id.Home_second_buttom2);//���̽�վ
		userExperienceBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				LoginInfo loginInfo=(LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
				if(null!=loginInfo&&!"".equals(loginInfo)&&null!=loginInfo.getLoginName()&&!"".equals(loginInfo.getLoginName())){
					try {
						boolean result=loginPurviewDao.selectLoginInfo(res.getString(R.string.home_second_buttom2_bpcode));
						if(result){
							Intent intent = new Intent(HomeActivity.this,ProjectSiteActivity.class);
							startActivity(intent);
						}else{
							Toast.makeText(HomeActivity.this, R.string.login_purview_bpcode,
									Toast.LENGTH_LONG).show();
						}
					}catch (Exception e) {
						Toast.makeText(HomeActivity.this, R.string.login_purview_bpcode,
								Toast.LENGTH_LONG).show();
						e.printStackTrace();
					}
				}else{
					Intent intent = new Intent(HomeActivity.this,LoginActivity.class);
					intent.putExtra("LoginType", "projectSite");
					startActivity(intent);
				}
			}
		});
		
		userExperienceBtn = (LinearLayout) findViewById(R.id.homeUserExperLl);//�û�����
		userExperienceBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(HomeActivity.this, UserLearnGuideViewActivity.class);
				startActivity(intent);
			}
		});
	}

	private void setNews(){
		FileReader fileReader;
		try {
			fileReader = new FileReader(sdpath+"download"+File.separator+"newsFile.txt");
			BufferedReader br = new BufferedReader(fileReader);
			String temp = "";
			StringBuffer fileContent = new StringBuffer();
			while((temp = br.readLine())!=null){             
				fileContent.append(temp);             
			}
			content = fileContent.toString().split("\\|");
			titles = content[1]!=null?content[1].split(","):"".split(",");//����
			pictureNames = content[0]!=null?content[0].split(","):"".split(",");//Сͼ��
			details = content[2]!=null?content[2].split(","):"".split(",");//��ϸ����
			visitURL = content[3]!=null?content[3].split(","):"".split(",");//����url
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	Bitmap bitmap;
    BitmapDrawable bitmapDrawable;
	
	//��ȡͷ��ͼƬ
	private void setTopPicture() throws IOException{
		//-----------------��ȡ�ļ���---------------------
		FileReader file = new FileReader(sdpath+"download/pictureNameFile.txt");
		BufferedReader br = new BufferedReader(file);
		String temp = "";
		StringBuffer fileContent = new StringBuffer();
        while((temp = br.readLine())!=null){             
        	fileContent.append(temp);             
        }
        //------------------------------------------------
        String[] fileName = fileContent.toString().split(",");
		String filePath = sdpath+"download/toppicture";
        File wall;// MMͼƬ
        String path;//ͼƬ·��
        RelativeLayout.LayoutParams lp2 = new RelativeLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT);  
        ImageView btn;
        
		for(int i = 0 ; i < fileName.length ; i++){
	        wall = new File(filePath+"/"+ fileName[i].split("\\.")[0]);//��ȡͼƬ�ļ�
	        path = wall.getAbsolutePath();// MMͼƬ·��
	        btn = new ImageView(HomeActivity.this);
			bitmap = BitmapFactory.decodeFile(path);//����bitmapͼƬ
			bitmapDrawable = new BitmapDrawable(bitmap);
		    btn.setBackgroundDrawable(bitmapDrawable);//����ͼƬչ��
		    btn.setLayoutParams(lp2);//����ͼƬ�Ŀ���
		    btn.setScaleType(ScaleType.FIT_CENTER);
		    imageViews.add(btn);//����ť���ӽ���ͷ������
		    btn.destroyDrawingCache();//�ͷ�ͼƬ��ռ�ڴ�
		}
		if(br!=null){
        	br.close();
        }
	}
	
	@Override
	protected void onResume() {

		homeBtn = (ImageButton) findViewById(R.id.homeBtn);
		if(homeBtn!=null){
			homeBtn.setOnClickListener(null);
			homeBtn.setBackgroundResource(R.drawable.homebtn_select);
		}
		Log.d("BID","onResume......");
		TextView homeBtnTv = (TextView)findViewById(R.id.homeBtnTv);
		homeBtnTv.setTextColor(getResources().getColor(R.color.white));

		super.onResume();
	}
	
	@Override
	protected void onStop() {
		Log.d("BID","onStop......");
		scheduledExecutorService.shutdown();
		super.onStop();
	}
	
	@Override
	protected void onRestart() {
		scheduledExecutorService = Executors.newSingleThreadScheduledExecutor(); 
		scheduledExecutorService.scheduleAtFixedRate(new ScrollTask(), 1, 3, TimeUnit.SECONDS);
		super.onRestart();
	}
	
	@Override
	protected void onDestroy() {
		Log.d("BID","onDestroy......");
		// ��Activity���ɼ���ʱ��ֹͣ�л�
		scheduledExecutorService.shutdown();
		scheduledExecutorService.shutdownNow();
		if(viewPager!=null){
			viewPager.destroyDrawingCache();
		}
		if(imageViews!=null){
			for (int i = 0; i < imageViews.size(); i++) {
				nullViewDrawable(imageViews.get(i));
			}
			
			imageViews.clear();
		}
		if(dots!=null){
			dots.destroyDrawingCache();
		}
		 if(bitmapDrawable!=null && !bitmapDrawable.getBitmap().isRecycled()){
		    	bitmapDrawable.getBitmap().recycle();
		    	bitmap.recycle();
	    }
		 
//		System.gc();
		// TODO Auto-generated method stub
		super.onDestroy();
	}
	
	private void nullViewDrawable(View view){
		try
		{
			view.setBackgroundDrawable(null);
		}
		catch(Exception e){}
		
		try
		{
			 ImageView imageView = (ImageView)view;
			 imageView.setImageDrawable(null);
			 imageView.setBackgroundDrawable(null);
		}
		catch(Exception e){}
	}
	
	/**
	 * �����л�����
	 * 
	 * @author Administrator
	 * 
	 */
	private class ScrollTask implements Runnable {

		public void run() {
			synchronized (viewPager) {
				System.out.println("currentItem: " + currentItem);
				currentItem = (currentItem + 1) % imageViews.size();
				handler.obtainMessage().sendToTarget(); // ͨ��Handler�л�ͼƬ
			}
		}

	}

	/**
	 * ��ViewPager��ҳ���״̬�����ı�ʱ����
	 * 
	 * @author Administrator
	 * 
	 */
	private class MyPageChangeListener implements OnPageChangeListener {
		private int oldPosition = 0;

		/**
		 * This method will be invoked when a new page becomes selected.
		 * position: Position index of the new selected page.
		 */
		public void onPageSelected(int position) {
			currentItem = position;
			ImageView image = (ImageView)(dots.getChildAt(oldPosition));
			image.setImageResource(R.drawable.dot_unselected);
			image = (ImageView)(dots.getChildAt(position));
			image.setImageResource(R.drawable.dot_selected);
			oldPosition = position;
		}

		public void onPageScrollStateChanged(int arg0) {

		}

		public void onPageScrolled(int arg0, float arg1, int arg2) {

		}
	}

	/**
	 * ���ViewPagerҳ���������
	 * 
	 * @author Administrator
	 * 
	 */
	private class TopPictureAdapter extends PagerAdapter {

		@Override
		public int getCount() {
			return imageViews.size();
		}

		@Override
		public Object instantiateItem(View arg0, int arg1) {
			((ViewPager) arg0).addView(imageViews.get(arg1));
			return imageViews.get(arg1);
		}

		@Override
		public void destroyItem(View arg0, int arg1, Object arg2) {
			((ViewPager) arg0).removeView((View) arg2);
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}

		@Override
		public void restoreState(Parcelable arg0, ClassLoader arg1) {

		}

		@Override
		public Parcelable saveState() {
			return null;
		}

		@Override
		public void startUpdate(View arg0) {

		}

		@Override
		public void finishUpdate(View arg0) {

		}
	}
}
