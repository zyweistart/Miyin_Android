package com.freshpower.android.elec.netapi;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.common.AppCache;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.conf.AppConfig;
import com.freshpower.android.elec.domain.LoginInfo;
import com.freshpower.android.elec.domain.WarningSet;


public class WarningSetApi extends JsonDataApi {
	private static final String WARNING_SET_ACTION = "AppMonitoringAlarm.aspx";
	/**
	 * ��ȡ���������б��ӿ�
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> getWarningSetList(int pageSize,int pageNum) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo = (LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei", loginInfo.getLoginName());
		api.addParam("authentication", loginInfo.getLoginPwd().toUpperCase());
		api.addParam("GNID", "CP10");
		api.addParam("QTPINDEX", String.valueOf(pageNum).trim());
		api.addParam("QTPSIZE", String.valueOf(pageSize).trim());
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getEtgWebsite() + File.separator + WARNING_SET_ACTION, AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		JSONArray jsonObj = jsonResult.getJSONArray("table1");
		WarningSet warningSet = null;
		List<WarningSet> warningSetList = new ArrayList<WarningSet>();
		if(Integer.valueOf(rows.getString("result"))>0){
			for(int i=0;i<jsonObj.size();i++){
				warningSet = new WarningSet();
				JSONObject table1 = (JSONObject) jsonObj.get(i);
				warningSet.setCpId(StringUtil.isEmpty(table1.getString("CP_ID"))?"":table1.getString("CP_ID"));
				warningSet.setCpName(StringUtil.isEmpty(table1.getString("NAME"))?"":table1.getString("NAME"));
				warningSet.setFactor(StringUtil.isEmpty(table1.getString("TOTAL_FACTOR"))?"":table1.getString("TOTAL_FACTOR"));
				warningSet.setDemand(StringUtil.isEmpty(table1.getString("POWER_DEMAND"))?"":table1.getString("POWER_DEMAND")+"KW");
				warningSetList.add(warningSet);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("result", rows.getString("result"));
		map.put("remark", rows.getString("remark"));
		map.put("totalCount", rows.getString("TotalCount"));
		map.put("warningSetList", warningSetList);
		return map;
	}
	
	/**
	 * ������ҵ���������������ӿ�
	 * @param cpId ��ҵID
	 * @param factor ��������
	 * @param demand ����
	 * @return
	 * @throws Exception
	 */
	public static Map<String,Object> editWarningSet(String cpId, String factor, String demand) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		LoginInfo loginInfo = (LoginInfo)AppCache.get(AppCache.LOGININFO_OBJ);
		api.addParam("imei", loginInfo.getLoginName());
		api.addParam("authentication", loginInfo.getLoginPwd().toUpperCase());
		api.addParam("GNID", "CP11");
		api.addParam("QTCP", cpId);
		api.addParam("QTVAL", factor);
		api.addParam("QTVAL1", demand);
		JSONObject jsonResult = api.getForJsonResult(AppConfig.getInstance().getEtgWebsite() + File.separator + WARNING_SET_ACTION, AppConstant.ETG_INTERFACE_CHARSET);
		JSONObject rows = jsonResult.getJSONObject("Rows");
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("result", rows.getString("result"));
		map.put("remark", rows.getString("remark"));
		return map;
	}
	
}
