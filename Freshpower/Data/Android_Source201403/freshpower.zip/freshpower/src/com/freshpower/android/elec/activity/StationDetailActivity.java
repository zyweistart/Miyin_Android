package com.freshpower.android.elec.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.StationDetailAdapter;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.domain.CustomerInfo;
import com.freshpower.android.elec.netapi.StationInfoDataApi;
import com.freshpower.android.elec.widget.PullDownListView;

public class StationDetailActivity extends FrameActivity  implements PullDownListView.OnRefreshListioner{
	private PullDownListView mPullDownView;
	private ListView mListView;
	private Resources res;
	private ImageButton homeBtn;
	private List<CustomerInfo> stationDetailList;
	private List<CustomerInfo> transList;
	private Handler mHandler = new Handler();
	private int pageSize = 10;//ÿҳ��ʾ
	private int currentPage =1;//��ǰҳ
	private int totalCnt=0;//�ܼ�¼��
	private int rs=999;//��ѯ���
	private StationDetailAdapter adapter;
	private RelativeLayout progressRlt = null;
	private List<Map<String, Object>> customerInfoMap;
	private ProgressDialog processProgress;
	private Handler spinnerHandler = new Handler();
	private Handler handler = new Handler();
	private Button queryBtn;
	private AlertDialog alertDialog;
	private TextView nameView;
	private TextView searchTitle;
	private String meterName = "";// ��·����
	private EditText meterNameEdit;
	private TableRow transformerSpinner;
	private TableRow transformerView;
	private Intent it = null;
	private String id = "";// �ͻ�ID
	private Spinner operationSpinner;
	private String transNo = "";// ��ѹ�����

	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_stationdetaillv);
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				StationDetailActivity.this.onBackPressed();
			}
		});
		
		Button btn = (Button)findViewById(R.id.station_search);
		btn.setOnClickListener(new mapSearchDialogIbClickListener());

		mPullDownView = (PullDownListView) findViewById(R.id.sreach_list);
		mPullDownView.setRefreshListioner(this);
		mListView = mPullDownView.mListView;

		processProgress = ProgressDialog.show(StationDetailActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(){
			public void run() {
				customerInfoMap = getGroupOnelistData(stationDetailList);
				Message msgMessage = new Message();
				StationDetailActivity.this.xHandler.sendMessage(msgMessage);
			}
		}.start();

	}
	private Handler xHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			adapter = new StationDetailAdapter(customerInfoMap, StationDetailActivity.this,
					R.layout.listitem_stationdetail_style);
			if(customerInfoMap.size()==0){
				Toast.makeText(StationDetailActivity.this, R.string.noSearchResultMsg,Toast.LENGTH_SHORT).show();
				rs=AppConstant.Result.NO_COUNT;
			} else {
				rs=AppConstant.Result.SUCCESS;
			}
			mListView.setAdapter(adapter);
			setListViewHeightBasedOnChildren(mListView);
			setShow();
			mPullDownView.setVisibility(View.VISIBLE);
			processProgress.dismiss();
		};
	};
	private void setShow() {
		RelativeLayout noResultlayout = (RelativeLayout) findViewById(R.id.noResultlayout);
		if(rs==AppConstant.Result.NO_COUNT){
			noResultlayout.setVisibility(View.VISIBLE);
			mPullDownView.setMore(false);
		}else{
			noResultlayout.setVisibility(View.GONE);
			mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
		}
		if(totalCnt<=pageSize){
			mPullDownView.setMore(false);
		}
	}    
	@Override
	public void onRefresh() {
		// TODO Auto-generated method stub
		mHandler.postDelayed(new Runnable() {

			public void run() {
				customerInfoMap.clear();
				currentPage =1;
				customerInfoMap.addAll(getGroupOnelistData(stationDetailList));

				mPullDownView.onRefreshComplete();//�����ʾˢ�´�����ɺ������ļ���ˢ�½�������
				mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				if(totalCnt<=pageSize){
					mPullDownView.setMore(false);
				}
				adapter.notifyDataSetChanged();	
			}
		}, 1500);

	}
	@Override
	public void onLoadMore() {
		mHandler.postDelayed(new Runnable() {
			public void run() {

				currentPage++;
				customerInfoMap.addAll(getGroupOnelistData(stationDetailList));

				mPullDownView.onLoadMoreComplete();//�����ʾ���ظ��ദ����ɺ������ļ��ظ�����棨���ػ��������������ࣩ
				//if(list.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
				if(customerInfoMap.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
					mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				else
					mPullDownView.setMore(false);
				adapter.notifyDataSetChanged();	

			}
		}, 1500);

	}
	private List<Map<String, Object>> getGroupOnelistData(List<CustomerInfo> stationDetailList){
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		it = getIntent();
		id = it.getStringExtra("ID");
		try {
			Map customerInfoMap =StationInfoDataApi.getStationDetailInfoList(pageSize,currentPage,id,transNo,meterName);
			if(!"0".equals(customerInfoMap.get("result"))){
				stationDetailList=(List<CustomerInfo>) customerInfoMap.get("customerDatailList");
				for (CustomerInfo customerInfo:stationDetailList)
				{
					Map<String, Object> listItem = new HashMap<String, Object>();
					listItem.put(AppConstant.ListItemWarnName.WARN_ONE, customerInfo.getMeterName());
					if(!StringUtil.isEmpty(customerInfo.getSwitchStatus())){
						listItem.put(AppConstant.ListItemWarnName.WARN_TWO, customerInfo.getSwitchStatus().equals("0")?"��":"��");
					}else{
						listItem.put(AppConstant.ListItemWarnName.WARN_TWO,"");
					}
					listItem.put(AppConstant.ListItemWarnName.WARN_THREE,customerInfo.getReportDate());
					listItem.put(AppConstant.ListItemWarnName.WARN_FOUR, customerInfo.getDayPower());
					listItem.put("Va", customerInfo.getVa());
					listItem.put("Vb", customerInfo.getVb());
					listItem.put("Vc", customerInfo.getVc());
					listItem.put("Ia", customerInfo.getIa());
					listItem.put("Ib", customerInfo.getIb());
					listItem.put("Ic", customerInfo.getIc());
					listItem.put("Power", customerInfo.getPower());
					listItem.put("MeterId", customerInfo.getMeterId());
					listItem.put("factor", customerInfo.getFactor());
					listItem.put("CpId", id);
					listItems.add(listItem);
				}
					totalCnt = Integer.parseInt(String.valueOf(customerInfoMap.get("totalCount")));
				return listItems;
			}else{
				return listItems;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listItems;
	}
	/***
	 * ��̬����listview�ĸ߶�
	 * 
	 * @param listView
	 */
	public void setListViewHeightBasedOnChildren(ListView listView) {
		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null) {
			return;
		}
		int totalHeight = 0;
		
		ViewGroup.LayoutParams params = listView.getLayoutParams();
		params.height = totalHeight
				+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
		listView.setLayoutParams(params);
	}
	
	protected void onResume() {
		homeBtn = (ImageButton) findViewById(R.id.stationDataBtn);
		if(homeBtn!=null){
			homeBtn.setOnClickListener(null);
			homeBtn.setBackgroundResource(R.drawable.databtn_select);
		}

		TextView toolBtnTv = (TextView)findViewById(R.id.stationDataTv);
		toolBtnTv.setTextColor(getResources().getColor(R.color.orange));

		super.onResume();
	}
	
	private class mapSearchDialogIbClickListener implements
	View.OnClickListener {
		@Override
		public void onClick(View v) {
			LayoutInflater factory = LayoutInflater
					.from(StationDetailActivity.this);
			final View dialogView = factory.inflate(R.layout.activity_station_search,
					null);
			dialogView.setBackgroundResource(android.R.color.white);
			searchTitle = (TextView)dialogView.findViewById(R.id.search_title);
			nameView = (TextView)dialogView.findViewById(R.id.name_view);
			transformerSpinner = (TableRow)dialogView.findViewById(R.id.transformerSpinner);
			transformerView = (TableRow)dialogView.findViewById(R.id.transformerView);
			transformerSpinner.setVisibility(View.VISIBLE);
			transformerView.setVisibility(View.VISIBLE);
			searchTitle.setText("��·��ѯ");
			nameView.setText("��·����");
			queryBtn = (Button)dialogView.findViewById(R.id.submit);
			queryBtn.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							processProgress = ProgressDialog.show(StationDetailActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
							new Thread(){
								public void run() {
									meterNameEdit = (EditText) dialogView.findViewById(R.id.name_edit);
									meterName = meterNameEdit.getText().toString();
									alertDialog.cancel();
									customerInfoMap.clear();
									customerInfoMap.addAll(getGroupOnelistData(stationDetailList));
									Message msgMessage = new Message();
									StationDetailActivity.this.xHandler.sendMessage(msgMessage);
								}
							}.start();
						}
					});
			// ����Ի���
			alertDialog = new AlertDialog.Builder(StationDetailActivity.this).create();
			alertDialog.setView(dialogView,0,0,0,0);
			alertDialog.show();
			
			operationSpinner = (Spinner)dialogView.findViewById(R.id.operationSpinner);
			setTransSpinner();
			
			ImageView closebtn = (ImageView)dialogView.findViewById(R.id.closeBtn);
			closebtn.setOnClickListener(new OnClickListener(){
				public void onClick(View arg0) {
					alertDialog.cancel();
				}
			});
//			Message msgMessage = new Message();
//			StationDetailActivity.this.xHandler.sendMessage(msgMessage);
		}
	}
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		if(customerInfoMap!=null){
			customerInfoMap.clear();
		}
		super.onDestroy();
	}
	/**
	 * ���ñ�ѹ��������
	 */
	private void setTransSpinner() {
		processProgress = ProgressDialog.show(StationDetailActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(new Runnable() {
			Map transMap = null;
			public void run() {
				try {
					transMap = StationInfoDataApi.getTransList(id);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally{
					processProgress.dismiss();
					spinnerHandler.post(new Runnable() {
						@Override
						public void run() {
							transList = (List<CustomerInfo>) transMap.get("customerInfoList");
							List<String> list = new ArrayList<String>();  
							list.add("--��ѡ��--");
							for(CustomerInfo customerInfo : transList) {
								list.add(customerInfo.getTransName());
							}
							ArrayAdapter<String> adapter = new ArrayAdapter<String>(StationDetailActivity.this, android.R.layout.simple_spinner_item, list);
							//���������б��ķ��  
					        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);  
							operationSpinner.setAdapter(adapter);
							operationSpinner.setPrompt("ѡ���ѹ��");
							operationSpinner.setOnItemSelectedListener(new UserSpinnerOnSelectedListener());
						}
					});
				}
			}
		}).start();
	}
	
	class UserSpinnerOnSelectedListener implements OnItemSelectedListener {  
		@Override  
		public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {  
				if((int)id != 0) {
					transNo = transList.get((int)id-1).getTransNo();
				} else {
					transNo = "";
				}
			}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
			
		} 
	}
}
