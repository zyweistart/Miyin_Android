package com.freshpower.android.elec.domain;
/**
 * �û�ע��
 * @author Administrator
 *
 */
public class UserRegisterInfo {
	private String loginRegisterTel;
	private String loginRegisterName;
	private String loginRegisterCardNum;
	private String  loginRegisterStruts;
	private String loginRegisterAddress;
	private String province;
	private String city;
	private String county;
	
	
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public String getLoginRegisterAddress() {
		return loginRegisterAddress;
	}
	public void setLoginRegisterAddress(String loginRegisterAddress) {
		this.loginRegisterAddress = loginRegisterAddress;
	}
	public String getLoginRegisterStruts() {
		return loginRegisterStruts;
	}
	public void setLoginRegisterStruts(String loginRegisterStruts) {
		this.loginRegisterStruts = loginRegisterStruts;
	}
	public String getLoginRegisterTel() {
		return loginRegisterTel;
	}
	public void setLoginRegisterTel(String loginRegisterTel) {
		this.loginRegisterTel = loginRegisterTel;
	}
	public String getLoginRegisterName() {
		return loginRegisterName;
	}
	public void setLoginRegisterName(String loginRegisterName) {
		this.loginRegisterName = loginRegisterName;
	}
	public String getLoginRegisterCardNum() {
		return loginRegisterCardNum;
	}
	public void setLoginRegisterCardNum(String loginRegisterCardNum) {
		this.loginRegisterCardNum = loginRegisterCardNum;
	}
	
}
