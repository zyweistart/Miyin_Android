package com.freshpower.android.elec.domain;


public class Task {
	private String taskId;//����ID
	private String taskName;
	private String cpName;//����ͻ�����
	private String siteName;//����վ������
	private String name;//Ѳ��������
	private String taskDate;//��������
	private String completeDate;//�������
	private String isComplete;//�Ƿ���ɣ�1�ǣ�0��
	private String recompleteDate;//Ҫ�����ʱ��
	private String equipmentId;//�豸ID
	private String equipmentName;//�豸
	
	private String modelSubId;//�豸����ID
	private String scoutcheckContent;//��������
	private String resultId;	//���ID����������д��32λ����վ�Զ����ɣ�
	private String scoutcheck;	//��д���
	private String codeId;//����Ӧ��д����
	
	
	private String cpId;//��ҵId
	private String remark;//��ע
	
	private String type;//�������ͣ�����code_idΪ32����Ч��
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCpId() {
		return cpId;
	}
	public void setCpId(String cpId) {
		this.cpId = cpId;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	public String getModelSubId() {
		return modelSubId;
	}
	public void setModelSubId(String modelSubId) {
		this.modelSubId = modelSubId;
	}
	public String getScoutcheckContent() {
		return scoutcheckContent;
	}
	public void setScoutcheckContent(String scoutcheckContent) {
		this.scoutcheckContent = scoutcheckContent;
	}
	public String getResultId() {
		return resultId;
	}
	public void setResultId(String resultId) {
		this.resultId = resultId;
	}
	public String getScoutcheck() {
		return scoutcheck;
	}
	public void setScoutcheck(String scoutcheck) {
		this.scoutcheck = scoutcheck;
	}
	public String getCodeId() {
		return codeId;
	}
	public void setCodeId(String codeId) {
		this.codeId = codeId;
	}
	public String getEquipmentId() {
		return equipmentId;
	}
	public void setEquipmentId(String equipmentId) {
		this.equipmentId = equipmentId;
	}
	public String getEquipmentName() {
		return equipmentName;
	}
	public void setEquipmentName(String equipmentName) {
		this.equipmentName = equipmentName;
	}
	public String getCpName() {
		return cpName;
	}
	public void setCpName(String cpName) {
		this.cpName = cpName;
	}
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTaskDate() {
		return taskDate;
	}
	public void setTaskDate(String taskDate) {
		this.taskDate = taskDate;
	}
	public String getCompleteDate() {
		return completeDate;
	}
	public void setCompleteDate(String completeDate) {
		this.completeDate = completeDate;
	}
	public String getIsComplete() {
		return isComplete;
	}
	public void setIsComplete(String isComplete) {
		this.isComplete = isComplete;
	}
	public String getRecompleteDate() {
		return recompleteDate;
	}
	public void setRecompleteDate(String recompleteDate) {
		this.recompleteDate = recompleteDate;
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
}
