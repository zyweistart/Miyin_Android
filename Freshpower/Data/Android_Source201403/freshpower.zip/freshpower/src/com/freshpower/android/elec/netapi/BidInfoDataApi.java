package com.freshpower.android.elec.netapi;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.Base64;
import com.freshpower.android.elec.conf.AppConfig;
import com.freshpower.android.elec.domain.BidInfo;

public class BidInfoDataApi extends JsonDataApi {
	private static final String ACTION_NAME_BIDINFOLIST = "struts/app/getBidInfoList.do";
	private static final String ACTION_NAME_BIDINFO = "struts/app/getBidInfo.do";
	
	/**
	 * ��ѯ�б���Ϣ�б�
	 * @param keyword �ؼ���
	 * @param purchase �ɹ�����
	 * @param area ����
	 * @param industry ��ҵ
	 * @param time ʱ��
	 * @return �б���ϢMap��Ϣ
	 * @throws Exception
	 */
	public static Map<String,Object> getBidInfoList(String keyword,String pType,String area,String industry,String pubtime,int pageSize,int pageNum) throws Exception {
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("pagesize", String.valueOf(pageSize));
		api.addParam("pagenum", String.valueOf(pageNum));
		api.addParam("title", Base64.encode(keyword.getBytes("GBK")));
		api.addParam("pType",pType==null?"":pType.trim());
		api.addParam("area",  area==null?"":area.trim());
		api.addParam("industry", industry==null?"":industry.trim());
		api.addParam("pubtime",  pubtime==null?"":pubtime.trim());
		JSONObject jsonResult =api.postForJsonResult(""+File.separator+ACTION_NAME_BIDINFOLIST);
		JSONArray jsonArray = jsonResult.getJSONArray("bidInfoList");
		BidInfo bidInfo = null;
		List<BidInfo> bidInfoList = new ArrayList<BidInfo>();
		if(jsonResult.getIntValue("rs")==AppConstant.Result.SUCCESS){
			for (int i = 0; i < jsonArray.size(); i++) {
				 JSONObject jsonObj = (JSONObject) jsonArray.get(i);
				 bidInfo = new BidInfo();
				 bidInfo.setId(jsonObj.getLong("id"));
				 bidInfo.setTitle(new String(Base64.decode(jsonObj.getString("title")),"GBK"));
				 bidInfo.setPubtime(jsonObj.getString("pubtime"));
				 bidInfoList.add(bidInfo);
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("bidInfoList", bidInfoList);
		map.put("totalCnt", jsonResult.getIntValue("total"));
		map.put("rs", jsonResult.getIntValue("rs"));
		return map;
	}
	/**
	 * �鿴�б���Ϣ����
	 */
	public static BidInfo getBidInfo(String id) throws Exception {
		BidInfo bidInfo=new BidInfo();
		JsonDataApi api = JsonDataApi.getInstance();
		api.addParam("id",id.trim());
		JSONObject jsonResult =api.postForJsonResult(""+File.separator+ACTION_NAME_BIDINFO); 
		bidInfo.setProjNo(jsonResult.getJSONObject("bidInfo").getString("pNo"));
		bidInfo.setLinkMan(jsonResult.getJSONObject("bidInfo").getString("linkMan"));
		bidInfo.setIndustry(jsonResult.getJSONObject("bidInfo").getString("industry"));
		String title=new String(Base64.decode(jsonResult.getJSONObject("bidInfo").getString("title")),"GBK");
		bidInfo.setTitle(title);
		bidInfo.setThumb(jsonResult.getJSONObject("bidInfo").getString("thumb"));
		String content=new String(Base64.decode(jsonResult.getJSONObject("bidInfo").getString("content")),"GBK");
		bidInfo.setContent(content);
		bidInfo.setProjSrc(jsonResult.getJSONObject("bidInfo").getString("pSrc"));
		bidInfo.setProjType(jsonResult.getJSONObject("bidInfo").getString("pType"));
		bidInfo.setTel(jsonResult.getJSONObject("bidInfo").getString("tel"));
		bidInfo.setArea(jsonResult.getJSONObject("bidInfo").getString("area"));
		bidInfo.setPubtime(jsonResult.getJSONObject("bidInfo").getString("pubtime"));
		return bidInfo;
	}
}
