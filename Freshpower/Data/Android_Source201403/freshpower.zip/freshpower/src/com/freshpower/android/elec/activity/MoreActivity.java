package com.freshpower.android.elec.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.StringUtil;

public class MoreActivity extends Activity {
	private String userType = "";// 0:��ҵ�û� 1:��ҵ�û�
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_more_elec);
		getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		userType = getIntent().getStringExtra("userType");
		ImageView closeBtn = (ImageView)findViewById(R.id.closeBtn);
		closeBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				MoreActivity.this.onBackPressed();
			}
		});
		
		TextView assess = (TextView)findViewById(R.id.assesstext);//����
		assess.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(MoreActivity.this,FeedBackActivity.class);
				if(!StringUtil.isEmpty(userType)) {
					intent.putExtra("userType", userType);
					setResult(AppConstant.RequestResultCode.REQUEST_BUY_CLOSETHREAD,intent);
					MoreActivity.this.onBackPressed();
				} else {
					startActivity(intent);
				}
			}
		});
		TextView share = (TextView)findViewById(R.id.sharetext);//����
		share.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(Intent.ACTION_SEND); // �����������͵�����
				intent.setType("text/plain");
				intent.putExtra(Intent.EXTRA_SUBJECT, "subject");
				intent.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.msg_share_msg)); // ����������
				intent = Intent.createChooser(intent, getResources().getString(R.string.menu_share));
				MoreActivity.this.startActivity(intent);// Ŀ��Ӧ��ѡ��Ի���ı���
			}
		});
		TextView buy = (TextView)findViewById(R.id.buytext);//����
		buy.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(MoreActivity.this,BuyActivity.class);
				if(!StringUtil.isEmpty(userType)) {
					intent.putExtra("userType", userType);
					setResult(AppConstant.RequestResultCode.REQUEST_BUY_CLOSETHREAD,intent);
					MoreActivity.this.onBackPressed();
				} else {
					startActivity(intent);
				}
			}
		});
		TextView notAssess = (TextView)findViewById(R.id.notassesstext);//������
		notAssess.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				MoreActivity.this.onBackPressed();
			}
		});
	}
}
