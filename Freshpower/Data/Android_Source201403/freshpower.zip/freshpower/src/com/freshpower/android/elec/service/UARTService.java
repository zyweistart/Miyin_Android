package com.freshpower.android.elec.service;

import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.hardware.usb.UsbAccessory;
import android.hardware.usb.UsbManager;
import android.os.Binder;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.preference.PreferenceManager;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.*;
import java.nio.charset.*;

import com.freshpower.android.elec.common.AppConstant;

public class UARTService extends Service {
	
	/*
	 * bindService��ش��뿪ʼ
	 */
	public final class LocalBinder extends Binder {
		public UARTService getService(){
			return UARTService.this;
		}
	}
	private final LocalBinder binder = new LocalBinder ();
	
	@Override
	public IBinder onBind(Intent intent) {
		return binder;
	}
	/*
	 * bindService��ش������
	 */
	public UARTService() {
	}

	/*
	 * �ַ���ת�������࣬�����ֽ�������ַ���֮��Ļ���װ��
	 */
	public final static class CharsetCodec {
		
		public static String m_Charset = "GB18030";

		public static String decode(byte[] byteArray){
			return Charset.forName(m_Charset).decode(ByteBuffer.wrap(byteArray)).toString();
		}
		
		public static byte[] encode(String string){
			ByteBuffer bb = Charset.forName(m_Charset).encode(string);
			byte[] ret = new byte [bb.limit()];
			bb.get(ret);
			return ret;
		}
		
		public static CharsetDecoder getDecoder(){
			CharsetDecoder decoder = Charset.forName(m_Charset).newDecoder();
			decoder.onMalformedInput(CodingErrorAction.REPLACE);
			decoder.onUnmappableCharacter(CodingErrorAction.REPLACE);
			return decoder;
		}
		
	}
	/*
	 * �ַ���ת��������ӽ���
	 */
	
	/*
	 * some constants
	 */
	public static interface Parity{
		public static final int none = 0;
		public static final int odd = 1;
		public static final int even = 2;
		public static final int mark = 3;
		public static final int space = 4;
	}
	public static interface Flow{
		public static final int none = 0;
		public static final int ctsrts = 1;
	}
	/*
	 * some constants end.
	 */

	/*
	 * ��Ա��������ʼ
	 */
	private static final String MANUFACTURER_STRING = "mManufacturer=FTDI";
	private static final String MODEL_STRING = "mModel=FTDIUARTDemo";
	private static final String VERSION_STRING = "mVersion=1.0";
	private static final String ACTION_USB_PERMISSION = "com.fstec.hehjiong.usbtouartterminal.USB_PERMISSION";
    private static final byte MAX_NUM_BYTES = 64;
	private int maxInBufferSize;
	private int maxOutBufferSize;
	private Context context;
	private UsbManager usbManager;
	private PendingIntent permissionIntent;
	private IntentFilter filter;
	private boolean permissionRequestPending;
	private ParcelFileDescriptor fileDescriptor;
	//private UsbAccessory usbAccessory;
	private FileInputStream inputStream;
	private FileOutputStream outputStream;
	private byte [] usbDataIn;
	private byte [] usbDataOut;
	private boolean readUsbEnable = false;
    //private boolean dataReceived = false;
    private int readCount;
    private ReadUSBThread readUsbThread;
    private boolean usbAccessoryAttached = false;
    private boolean isInitialized = false;
    private byte [] readBuffer; /*circular buffer*/
    private Object readBufferLock;
    private int totalBytes;
    private int writeIndex;
    private int readIndex;
    
    private int m_BaudRate = 9600;
    private byte m_DataBit = 8;
    private byte m_StopBit = 1;
    private byte m_Parity = 0;
    private byte m_Flow = 0;

	private final BroadcastReceiver usbReceiver = new BroadcastReceiver() 
	{
		@Override
		public void onReceive(Context context, Intent intent) 
		{
			String action = intent.getAction();
			if (ACTION_USB_PERMISSION.equals(action)) 
			{
				synchronized (this)
				{
					if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
					{
						UsbAccessory accessory = (UsbAccessory) intent.getParcelableExtra(UsbManager.EXTRA_ACCESSORY);
						OpenAccessory(accessory);
						//InformationLogger.log("USB permission granted.\n");
					} 
					else 
					{
						usbAccessoryAttached = false;
					}
					permissionRequestPending = false;
				}
			} 
			else if (UsbManager.ACTION_USB_ACCESSORY_DETACHED.equals(action)) 
			{
				//CloseAccessory();
				//InformationLogger.log("USB accessory detached.\n");
				DestroyAccessory();
				usbAccessoryAttached = false;
			}else
			{
			}
		}	
	};
	
	/*
	 * ��Ա����������
	 */

	/*
	 * public methods
	 */
	public void init(Context context, int maxInBufferSize, int maxOutBufferSize){
		if (isInitialized){
			return;
		}
		this.context = context;
		this.maxInBufferSize = maxInBufferSize;
		this.maxOutBufferSize = maxOutBufferSize;
		LoadDataFromPreferences(context);
		usbManager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
		permissionIntent = PendingIntent.getBroadcast(context, 0, new Intent(ACTION_USB_PERMISSION), 0);
		filter = new IntentFilter (ACTION_USB_PERMISSION);
		filter.addAction(UsbManager.ACTION_USB_ACCESSORY_DETACHED);
		context.registerReceiver(usbReceiver, filter);
		inputStream = null;
		outputStream = null;
		usbDataIn = new byte [MAX_NUM_BYTES];
		usbDataOut = new byte [maxOutBufferSize];
        readBuffer = new byte [maxInBufferSize];
        readBufferLock = new Object();
        readIndex = 0;
        writeIndex = 0;
		isInitialized = true;
		//Reset();
		resume();
	}

	public void close(){
		if (isInitialized){
			try {context.unregisterReceiver(usbReceiver);} catch (Exception e) {}
			DestroyAccessory();
			isInitialized = false;
		}
	}

	public void resume(){
		if (isInitialized){
			ResumeAccessory();
		}
	}

	public void Reset()
 	{
 		if (!isInitialized){
 			return;
 		}
 		/*create the packet*/
 		usbDataOut[0] = 0x49;
 		usbDataOut[1] = 0x00;
 		usbDataOut[2] = 0x00;
 		usbDataOut[3] = 0x00;
 		
		/*send the packet over the USB*/
		SendPacket(4);
 	}
	
 	public void SetConfig(int baud, byte dataBits, byte stopBits,
			 byte parity, byte flowControl)
 	{

 		m_BaudRate = baud;
 		m_DataBit = dataBits;
 		m_StopBit = stopBits;
 		m_Parity = parity;
 		m_Flow = flowControl;

 		/*prepare the baud rate buffer*/
 		usbDataOut[0] = (byte)baud;
 		usbDataOut[1] = (byte)(baud >> 8);
 		usbDataOut[2] = (byte)(baud >> 16);
 		usbDataOut[3] = (byte)(baud >> 24);
		
		/*data bits*/
 		usbDataOut[4] = dataBits;
		/*stop bits*/
 		usbDataOut[5] = stopBits;
		/*parity*/
 		usbDataOut[6] = parity;
		/*flow control*/
 		usbDataOut[7] = flowControl;
		
		/*send the UART configuration packet*/
		SendPacket((int)8);
 	}

 	public byte SendBytes(int numBytes, byte[] buffer) {
 		
 		/*
 		 * if num bytes are more than maximum limit
 		 */
 		if(numBytes < 1){
 			/*return the status with the error in the command*/
 			return 0x00;
 		}
 		
 		/*check for maximum limit*/
 		if(numBytes > maxOutBufferSize){
 			return 0x01;
 		}
 		
 		/*prepare the packet to be sent*/
 		for(int count = 0; count < numBytes; count++)
 		{	
 			usbDataOut[count] = buffer[count];
 		}
 		SendPacket((int)numBytes);
 		return 0x00;
 	}

 	public byte SendString(String str){
 		byte[] bytes = CharsetCodec.encode(str);
 		return SendBytes(bytes.length, bytes);
 	}

 	public byte ReadBytes(int numBytes,byte[] buffer, int [] actualNumBytes)
 	{
			/*should be at least one byte to read*/
		if((numBytes < 1) || (totalBytes == 0)){
			actualNumBytes[0] = 0x00;
			return 0x01;
		}
 		synchronized(readBufferLock){
			/*check for max limit*/
			if(numBytes > maxInBufferSize){
				numBytes = maxInBufferSize;
			}
			if(numBytes > totalBytes)
				numBytes = totalBytes;
			/*update the number of bytes available*/
			totalBytes -= numBytes;
			actualNumBytes[0] = numBytes;	
			/*copy to the user buffer*/	
			for(int count = 0; count < numBytes; count++)
			{
				buffer[count] = readBuffer[readIndex];
				readIndex++;
				/*shouldnt read more than what is there in the buffer,
				 * 	so no need to check the overflow
				 */
				readIndex %= maxInBufferSize;
			}
 		}
 		//appendDebugString("ReadBytes() returns status 0 and " + Integer.toString(actualNumBytes[0]) + " bytes.\n");
		return 0x00;
 	}
 	
 	/*String m_DebugString = "Background thread not started.\n";
 	public String DebugString(){
 		String ret;
 		synchronized(m_DebugString){
 			ret = m_DebugString;
 			m_DebugString = "";
 		}
 		return ret;
 	}
 	private void appendDebugString(String toAppend){
 		synchronized(m_DebugString){
 	 		m_DebugString += toAppend;
 		}
 	}*/
 	
 	public String ReadString(){
 		String ret;
		/*should be at least one byte to read*/
		if(totalBytes == 0){
			return new String();
		}
 		synchronized(readBufferLock){
			/*check for max limit*/
			int numBytes = maxInBufferSize;
			if(numBytes > totalBytes)
				numBytes = totalBytes;
			/*update the number of bytes available*/
			int readIndex = this.readIndex;
			byte [] buffer = new byte [numBytes];
			/*copy to the user buffer*/	
			for(int count = 0; count < numBytes; count++)
			{
				buffer[count] = readBuffer[readIndex];
				readIndex++;
				/*shouldnt read more than what is there in the buffer,
				 * 	so no need to check the overflow
				 */
				readIndex %= maxInBufferSize;
			}
			ret = CharsetCodec.decode(buffer);
			CharsetDecoder decoder = CharsetCodec.getDecoder();
			String replace = decoder.replacement();
			int i = 0;
			while (ret.length() >= replace.length() && 
					i < 8 && 
					replace.equals(ret.substring(ret.length() - replace.length()))){
				ret = ret.substring(0, ret.length() - replace.length());
				i++;
			}
			byte [] rep = CharsetCodec.encode(ret);
			i = buffer.length - rep.length;
			readIndex -= i;
			if (readIndex < 0)
				this.readIndex = maxInBufferSize + readIndex;
			else
				this.readIndex = readIndex % maxInBufferSize;
    		if(writeIndex >= this.readIndex)
    			totalBytes = writeIndex - this.readIndex;
    		else
    			totalBytes = (maxInBufferSize - this.readIndex) + writeIndex;
    		return ret;
 		}
 	}
 	/*
	 * public methods end.
	 */

 	/*
 	 * helpers
 	 */
	private void ResumeAccessory()
	{
		// Intent intent = getIntent();
		//InformationLogger.log("USB accessory resuming.\n");
		if (inputStream != null && outputStream != null) {
			//InformationLogger.log("inputStream and outputStream is not null.\n");
			return;
		}
		
		UsbAccessory[] accessories = usbManager.getAccessoryList();
		if(accessories != null)
		{
		}
		else
		{
			usbAccessoryAttached = false;
			//InformationLogger.log("UsbManager.getAccessoryList() returns null.\n");
			return;
		}

		usbAccessoryAttached = false;
		UsbAccessory accessory = (accessories == null ? null : accessories[0]);
		if (accessory != null) {
			if( -1 == accessory.toString().indexOf(MANUFACTURER_STRING))
			{
				//InformationLogger.log("MANUFACTURER_STRING not matched.\n");
				return;
			}

			if( -1 == accessory.toString().indexOf(MODEL_STRING))
			{
				//InformationLogger.log("MODEL_STRING not matched.\n");
				return;
			}
			
			if( -1 == accessory.toString().indexOf(VERSION_STRING))
			{
				//InformationLogger.log("VERSION_STRING not matched.\n");
				return;
			}
			
			usbAccessoryAttached = true;
			/*InformationLogger.log("USB accessory attached.\n");
			InformationLogger.log("UsbAccessory.toString() = " + accessory.toString() + ".\n");
			InformationLogger.flush();*/

			if (usbManager.hasPermission(accessory)) {
				OpenAccessory(accessory);
			} 
			else
			{
				synchronized (usbReceiver) {
					if (!permissionRequestPending) {
						usbManager.requestPermission(accessory,
								permissionIntent);
						permissionRequestPending = true;
					}
			}
		}
		} else {}

	}

	private void OpenAccessory(UsbAccessory accessory)
	{
		fileDescriptor = usbManager.openAccessory(accessory);
		if(fileDescriptor != null){
			//usbAccessory = accessory;
			FileDescriptor fd = fileDescriptor.getFileDescriptor();
			inputStream = new FileInputStream(fd);
			outputStream = new FileOutputStream(fd);
			/*check if any of them are null*/
			if(inputStream == null || outputStream==null){
				return;
			}
		}
		
		SetConfig(m_BaudRate, m_DataBit, m_StopBit, m_Parity, m_Flow);
		
		readUsbEnable = true;
		readUsbThread = new ReadUSBThread(inputStream);
		readUsbThread.start();
	}
	
	private void CloseAccessory()
	{
		try{
			if(fileDescriptor != null)
				fileDescriptor.close();
			
		}catch (IOException e){}
		
		try {
			if(inputStream != null)
					inputStream.close();
		} catch(IOException e){}
		
		try {
			if(outputStream != null)
					outputStream.close();
			
		}catch(IOException e){}
		
		
		fileDescriptor = null;
		inputStream = null;
		outputStream = null;
		
		//System.exit(0);
	}
	
	private void DestroyAccessory(){
		if(usbAccessoryAttached == true)
		{
			readUsbEnable = false;
			usbDataOut[0] = 0;
			SendPacket(1);//send dummy data for instream.read() going
			try{Thread.sleep(100);}
	 		catch(Exception e){}
			usbAccessoryAttached = false;
		}
		CloseAccessory();
	}
	
	private class ReadUSBThread  extends Thread {
		FileInputStream instream;
		
		ReadUSBThread(FileInputStream stream ){
			instream = stream;
		}
		
		@Override
		public void run()
		{
			//InformationLogger.log("ReadUSBThread started.\n");
			//appendDebugString("Background thread started.\n");
			while(readUsbEnable && !isInterrupted())
			{
				try
				{
					/*dont overwrite the previous buffer*/
					if(instream != null)
					{	
						readCount = instream.read(usbDataIn, 0, MAX_NUM_BYTES);
						//appendDebugString(Integer.toString(readCount) + " bytes received.\n");
						//InformationLogger.log(Integer.toString(readCount) + " bytes received.\n");
						if(readCount > 0)
						{
							synchronized (readBufferLock){
					    		for(int count = 0; count < readCount; count++)
					    		{					    			
					    			readBuffer[writeIndex] = usbDataIn[count];
					    			writeIndex++;
					    			writeIndex %= maxInBufferSize;
					    		}
					    		
					    		if(writeIndex >= readIndex)
					    			totalBytes = writeIndex - readIndex;
					    		else
					    			totalBytes = (maxInBufferSize - readIndex) + writeIndex;
							}
						}
					}
				}catch (IOException e){}
			}
			//appendDebugString("Background thread stopped.\n");
			//InformationLogger.log("ReadUSBThread stopped.\n");
			//InformationLogger.flush();
		}
	}
	
 	private void SendPacket(int numBytes)
	{
		try {
			int base = 0;
			int sendCount;
			while (numBytes > 0){
				if (numBytes > 250){
					sendCount = 250;
				}
				else{
					sendCount = numBytes;
				}
				if (outputStream != null){
					outputStream.write(usbDataOut, base, sendCount);
				}
				base += sendCount;
				numBytes -= 250;
			}
		} catch (IOException e) {
		}
	}

    protected void LoadDataFromPreferences(Context context){
    	SharedPreferences sharedPref =  context.getSharedPreferences(AppConstant.SHARED_PREFERENCE_NAME, context.MODE_PRIVATE);
    	String pref;
    	pref = sharedPref.getString(AppConstant.SharedPreferencesKey.KEY_PREF_BAUDRATE, "9600");
    	m_BaudRate = Integer.parseInt(pref);
    	pref = sharedPref.getString(AppConstant.SharedPreferencesKey.KEY_PREF_DATABIT, "8");
    	m_DataBit = (byte) Integer.parseInt(pref);
    	pref = sharedPref.getString(AppConstant.SharedPreferencesKey.KEY_PREF_STOPBIT, "1");
    	m_StopBit = (byte) Integer.parseInt(pref);
    	pref = sharedPref.getString(AppConstant.SharedPreferencesKey.KEY_PREF_PARITY, "0");
    	m_Parity = (byte) Integer.parseInt(pref);
    }
 	
 	/*
 	 * helpers end.
 	 */
 	
}
