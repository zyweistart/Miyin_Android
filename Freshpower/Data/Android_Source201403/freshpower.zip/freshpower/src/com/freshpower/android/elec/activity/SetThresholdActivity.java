package com.freshpower.android.elec.activity;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.AppConstant;

import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.media.MediaPlayer.OnCompletionListener;

public class SetThresholdActivity extends Activity {
	TextView setThresholdText1 =null;
	TextView setThresholdText2 =null;
	static boolean isEffective = true;
	WarnThread warnCurrentThread = new WarnThread();
	static boolean warnCurrentRunning = false;//���������Ƿ�������
	WarnThread warnVoltageThread = new WarnThread();
	static boolean warnVoltageRunning = false;//��ѹ�����Ƿ�������
	WarnThread warnSwitchThread = new WarnThread();
	static boolean warnSwitchRunning = false;//���ص��������Ƿ�������
	String type = "";
	//double warnValue = 0; 
	static double warnCurrentValue = 0; 
	static double warnVoltageValue = 0; 
	public DecimalFormat df =new DecimalFormat("#.00"); //��ȡ��С�������λ
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		setContentView(R.layout.activity_set_threshold);
		ActivityUtil.addActivity(this);
		Button submit = (Button)findViewById(R.id.set_threshold_submit);
		ImageView closebtn = (ImageView)findViewById(R.id.set_threshold_close);
		setThresholdText1 = (TextView)findViewById(R.id.set_threshold_text1);
		setThresholdText2 = (TextView)findViewById(R.id.set_threshold_text2);
		EditText edit = (EditText)findViewById(R.id.set_threshold_edit_text);
		Intent last = getIntent();
		Bundle bundle = last.getExtras();
		type = bundle.getString("type");
		if(type.equals("current")){
			setThresholdText1.setText(R.string.current_set_range);
			setThresholdText2.setText(getResources().getString(R.string.current_range_before)+df.format(UserExperienceActivity.coefficient*1443.4)+getResources().getString(R.string.current_range_after));
			if(SetThresholdActivity.warnCurrentValue != 0){
				edit.setText(String.valueOf(SetThresholdActivity.warnCurrentValue));
			}
		}else if(type.equals("voltage")){
			setThresholdText1.setText(R.string.voltage_set_range);
			setThresholdText2.setVisibility(8);
			if(SetThresholdActivity.warnVoltageValue != 0){
				edit.setText(String.valueOf(SetThresholdActivity.warnVoltageValue));
			}
		}else if(type.equals("switch")){
			setThresholdText1.setText(R.string.switch_state);
			setThresholdText2.setVisibility(8);
			setThresholdText1.setPadding(10, 30, 0, 0);
			edit.setVisibility(8);
		}else if(type.equals("load")){
			setThresholdText1.setText(R.string.company_load_experience);
			setThresholdText2.setText(R.string.load_range);
			if(SetThresholdActivity.warnCurrentValue != 0){
				edit.setText(String.valueOf(SetThresholdActivity.warnCurrentValue));
			}
		}
		submit.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				EditText edit = (EditText)findViewById(R.id.set_threshold_edit_text);
				if(!type.equals("switch")){
					String warn = edit.getText().toString();
					if(warn.equals("")){
						Toast.makeText(SetThresholdActivity.this, R.string.please_input_threshold, Toast.LENGTH_LONG).show();
						return;
					}else{
						try{
							if(type.equals("current")){
								double temp = Double.valueOf(edit.getText().toString());
								if(temp > UserExperienceActivity.coefficient*1443.4){
									Toast.makeText(SetThresholdActivity.this, R.string.over_threshold, Toast.LENGTH_SHORT).show();
									return;
								}
								if(warnCurrentRunning){
									warnCurrentValue = temp ; 
								}else{
									warnCurrentValue =  temp;
									warnCurrentThread.start();
									warnCurrentRunning = true;
								}
							}else if (type.equals("voltage")){
								double temp = Double.valueOf(edit.getText().toString());
								if(warnVoltageRunning){
									warnVoltageValue = temp;
								}else{
									warnVoltageValue = temp;
									warnVoltageThread.start();
									warnVoltageRunning = true ;
								}
							}else if(type.equals("load")){
								double temp = Double.valueOf(edit.getText().toString());
								if(temp > 2500){
									Toast.makeText(SetThresholdActivity.this, R.string.over_threshold, Toast.LENGTH_SHORT).show();
									return;
								}
								Intent intent = new Intent();
								intent.putExtra("load", String.valueOf(temp));
								setResult(AppConstant.RequestResultCode.REQUEST_LOAD_REPORT,intent);
							}
						}catch (Exception e){
							Toast.makeText(SetThresholdActivity.this, R.string.error_input, Toast.LENGTH_SHORT).show();
							return;
						}
					}
				}else{
					if(warnSwitchRunning){
					}else{
						warnSwitchThread.start();
						warnSwitchRunning = true ;
					}
				}
				finish();
			}
		});
		closebtn.setOnClickListener(new OnClickListener(){
			public void onClick(View arg0) {
				SetThresholdActivity.this.onBackPressed();
			}
		});
		
	}

	 class  WarnThread extends Thread{
    	
    	private boolean isDestory = false;
    	
    	void setDestory(boolean isDestory){
    		this.isDestory = isDestory;
    	}
    	
    	
    	@Override
    	public void run() {
    		try {
        		while(!isDestory && isEffective){
					if(isDestory)break;
	            	Message msg  = new Message();
	            	msg.what = 1;
	            	handler.sendMessage(msg);
	            	Thread.sleep(5000);
	            	warnTime++;
	            	//Log.d("elec", String.valueOf(warnTime));
        		}
        		
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
    		
    	}
    }
    private int warnTime = 1;
    private Handler  handler = new Handler(){
    	public void handleMessage(android.os.Message msg) {
    		double a = 0;
    		double b = 0;
    		double c = 0;
    		if(type.equals("current")){
				a = UserExperienceActivity.a[11];
				b = UserExperienceActivity.b[11];
				c = UserExperienceActivity.c[11];
				if(a > warnCurrentValue || b > warnCurrentValue ||c > warnCurrentValue){
					notiInfoAction();
				}else if(warnTime > 12){
					notiInfoAction();
					UserExperienceActivity.a[11] = warnCurrentValue + 30;
				}
				//Log.d("ddd", String.valueOf(warnCurrentValue));
    		}else if (type.equals("voltage")){
    			if(warnTime > 4){
					notiInfoAction();
				}
    		}else if(type.equals("switch")){
    			UserExperienceActivity user = new UserExperienceActivity();
    			//Log.d("elec", String.valueOf(user.finalB1));
    			if(!user.finalB[0] || !user.finalB[1]||
    					!user.finalB[2] || !user.finalB[3] ||
    					!user.finalB[4] || !user.finalB[5] ||
    					!user.finalB[6] || !user.finalB[7]){
    				notiInfoAction();
    			}
    		}
    		
    	};
    };
	public void notiInfoAction(){
		MediaPlayer mediaPlayer = new MediaPlayer();
		mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
		mediaPlayer.setOnCompletionListener(alarmListener);
		AssetFileDescriptor file = getResources().openRawResourceFd(R.raw.alarm);
		Intent it = new Intent();
		it.putExtra("type", type);
		it.setClass(SetThresholdActivity.this, ShowWarnActivity.class);
		startActivity(it);
		try {
			mediaPlayer.setDataSource(file.getFileDescriptor(),
			file.getStartOffset(), file.getLength());
			file.close();
			mediaPlayer.prepare();
			mediaPlayer.start();
		} catch (IOException e) {
			mediaPlayer = null;
		} 
		if(type.equals("current")){
			warnCurrentThread.setDestory(true);
			warnCurrentRunning = false;
		}else if(type.equals("voltage")){
			warnVoltageThread.setDestory(true);
			warnVoltageRunning = false;
		}else if(type.equals("switch")){
			warnSwitchThread.setDestory(true);
			warnSwitchRunning =  false;
		}
		
	}
	private final OnCompletionListener alarmListener = new OnCompletionListener() {
		public void onCompletion(MediaPlayer mediaPlayer) {
			mediaPlayer.release();
		}
	};
}
