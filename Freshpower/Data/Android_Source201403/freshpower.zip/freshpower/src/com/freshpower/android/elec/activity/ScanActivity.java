package com.freshpower.android.elec.activity;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.camera.CaptureActivity;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.domain.AggregatorInfo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

public class ScanActivity extends Activity {
	Spinner scanOperationSpinner = null;
	AggregatorInfo agg = new AggregatorInfo();
	EditText scanSerialNo;
	String scanSerialNoStr;
	String chanel;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		ActivityUtil.addActivity(this);
		setContentView(R.layout.activity_scan);
		Button scanSub = (Button)findViewById(R.id.scanSub);
		scanOperationSpinner = (Spinner)findViewById(R.id.scanOperationSpinner);
		scanSerialNo = (EditText)findViewById(R.id.scanSerialNo);
		ImageView returnBtn = (ImageView)findViewById(R.id.nav_left);
		returnBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				ScanActivity.this.onBackPressed();
			}
		});
		RelativeLayout scanSerialLyt = (RelativeLayout)findViewById(R.id.scanSerialLyt);
		scanSub.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent();
				scanSerialNoStr = scanSerialNo.getText().toString().replaceAll(" ", "");
				if(scanSerialNoStr.length()==14){
					chanel = scanSerialNoStr.substring(12, 14);
					scanSerialNoStr = scanSerialNoStr.substring(0,12);
				}
				if(chanel != null && scanSerialNoStr.length() == 12){
					if(scanOperationSpinner.getSelectedItemId() == 1){
						intent.putExtra("serialNo", scanSerialNoStr);
						intent.putExtra("chanel", chanel);
						intent.setClass(ScanActivity.this, LineInfoActivity.class);
						startActivity(intent);
					}else if (scanOperationSpinner.getSelectedItemId() == 2){
						intent.putExtra("serialNo", scanSerialNoStr);
						intent.setClass(ScanActivity.this, ChangeMaterialActivity.class);
						startActivity(intent);
					}else{
						Toast.makeText(ScanActivity.this, "��ѡ��������ͣ�", Toast.LENGTH_SHORT).show();
						return;
					}
				}else if(scanSerialNoStr.length() == 12){//�ɹ�
					if(scanOperationSpinner.getSelectedItemId() == 1 || scanOperationSpinner.getSelectedItemId() == 2){
						Toast.makeText(ScanActivity.this, "��ɨ��ɼ�����", Toast.LENGTH_SHORT).show();
						return;
					}else{
						intent.putExtra("serialNo", scanSerialNoStr);
						intent.setClass(ScanActivity.this, ScanAggregatorActivity.class);
						startActivity(intent);
					}
				}else{
					Toast.makeText(ScanActivity.this, "��ά�벻���Ϲ���", Toast.LENGTH_SHORT).show();
					return;
				}
			}
		});
		
		scanSerialLyt.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				chanel = null;
				scanSerialNoStr = null;
				Intent intent = new Intent(ScanActivity.this, CaptureActivity.class);
				intent.putExtra("operateType", "phoneDebug");
				startActivityForResult(intent, AppConstant.RequestResultCode.REQUEST_SCANACTIVITY);
			}
		});
		
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if(requestCode == AppConstant.RequestResultCode.RESULT_SCANACTIVITY){
			if(data!=null){
				String twoDimCode = data.getStringExtra("twoDimCode");
				String code ;
				if(twoDimCode.length()>=12){
					code = twoDimCode.substring(0,4)+" "+twoDimCode.substring(4,8)+" "+twoDimCode.substring(8,12);
				}else{
					Toast.makeText(ScanActivity.this, "��ɨ����ȷ�Ķ�ά�룡", Toast.LENGTH_SHORT).show();
					return;
				}
				if(twoDimCode.length()==14){
					chanel = " "+twoDimCode.substring(12, 14);
				}
				scanSerialNo.setText(code);
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
}
