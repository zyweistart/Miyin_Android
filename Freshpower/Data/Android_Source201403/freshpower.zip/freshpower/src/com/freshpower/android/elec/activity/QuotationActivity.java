package com.freshpower.android.elec.activity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.StringUtil;

public class QuotationActivity extends Activity {
	
	private int a;
	private int b;
	private int c;

	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_quotation);
		ActivityUtil.addActivity(this);
//		TextView opeaterShowTitle = (TextView)findViewById(R.id.content);
//		opeaterShowTitle.setText("����˵����˫ƴ���߻�·��2������·���㡣");
		Button exeButton = (Button)findViewById(R.id.exeBtn);
		exeButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				EditText aText = (EditText)findViewById(R.id.aText);
				EditText bText = (EditText)findViewById(R.id.bText);
				Log.d("elec", "aText="+aText.length());
				if(aText.length()==0) {
					Toast.makeText(QuotationActivity.this, "��������緿������", Toast.LENGTH_SHORT).show();
					return;
				}
				if(bText.length()==0) {
					Toast.makeText(QuotationActivity.this, "���������·����", Toast.LENGTH_SHORT).show();
					return;
				}
				EditText priceText = (EditText)findViewById(R.id.priceText);
				a = Integer.parseInt(aText.getText().toString());
				b = Integer.parseInt(bText.getText().toString());
				if((b-a*6)<0) {
					c = 10000*a;
				} else {
					c = 10000*a+(b-a*6)*500;
				}
				priceText.setText(String.valueOf(c));
			}
		});
	}
	
}
