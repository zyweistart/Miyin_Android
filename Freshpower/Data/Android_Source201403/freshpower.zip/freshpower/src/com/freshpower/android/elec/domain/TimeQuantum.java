package com.freshpower.android.elec.domain;

public class TimeQuantum {
	private String dateValue;

	public String getDateValue() {
		return dateValue;
	}

	public void setDateValue(String dateValue) {
		this.dateValue = dateValue;
	}
	
}
