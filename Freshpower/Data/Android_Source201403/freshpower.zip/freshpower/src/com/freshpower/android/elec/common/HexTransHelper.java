/**
 HexHelper.java Created on 2011-4-26 ����05:57:39
 Copyright (c) 2011 by �㽭�������Ƽ����޹�˾
 */
package com.freshpower.android.elec.common;


/**
Title: ����ת��������
 * 
@author <a href=mailto:zhouja@freshpower.cn>zhouja</a>
@version 1.0
 */
public class HexTransHelper {
	
	/**
	 * ��16����תΪΪ2����
	 * @param hex
	 * @return
	 */
	public static String hexToBin(String hex){
		int i = Integer.valueOf(hex, 16);
		String binStr = Integer.toBinaryString(i);
		return binStr;
	}
	
	/**
	 * ��16����ת��Ϊ10����
	 * @param hex
	 * @return
	 */
	public static int hexToOct(String hex){
		int i = Integer.valueOf(hex, 16);
		return i;
	}
	
	/**
	 * 10����ת��Ϊ16����
	 * @param octValue
	 * @return
	 */
	public static String octToHex(int octValue) {
		return Integer.toHexString(octValue);
	}
	
	/**
	 * 10����ת��Ϊ�����ơ���û�в�λ
	 * @param octStr
	 * @return
	 */
	public static String octToBin(int octStr) {
		return Integer.toBinaryString(octStr);
	}
	
	/**
	 * ������ת��Ϊ10����
	 * @param binStr
	 * @return
	 */
	public static String binToOct(String binStr) {
		return Integer.valueOf(binStr, 2).toString();
	}
	
	/**
	 * ������ת��Ϊ16����
	 * @param binStr
	 * @return
	 */
	public static String binToHex(String binStr) {
		int octValue = Integer.valueOf(binStr, 2);
		return Integer.toHexString(octValue);
	}
	
	/**
	 * ��ȡ16���Ƶķ���
	 * @param hex
	 * @return
	 */
	public static String hexToBackHex(String hex){
		//ת��Ϊ������
		String bHex = hexToBin(hex);
		bHex = ByteTransHelper.transStandardChar(bHex, 8);
		//����
		StringBuffer buf = new StringBuffer("");
		String binValue = "";
		for (int i=0;i<bHex.length();i++) {
			binValue = bHex.substring(i,i+1);
			if ("1".equals(binValue)) {
				buf.append("0");
			} else {
				buf.append("1");
			}
		}
		bHex = buf.toString();
		//ת��Ϊ16����
		bHex = binToHex(bHex);
		return bHex.toUpperCase();
	}
	
	/**
	 * �����Ʒ���
	 * @param bin
	 * @return
	 */
	public static String binToBackBin(String binStr){
		StringBuffer buf = new StringBuffer("");
		String binValue = "";
		for (int i=0;i<binStr.length();i++) {
			binValue = binStr.substring(i,i+1);
			if ("1".equals(binValue)) {
				buf.append("0");
			} else {
				buf.append("1");
			}
		}
		return buf.toString();
	}
	
	public static void main(String[] args) throws Exception {
//		System.out.println("====" + octToBin(6));
//		System.out.println("====" + binToOct("010"));
//		System.out.println("====AA:" + binToHex("101010"));
//		System.out.println("====AA:" + hexToBin("99"));
//		System.out.println("====AA:" + hexToOct("C655"));
//		System.out.println("====CC:" + hexToBackHex("32"));
		
//		Calendar c = Calendar.getInstance();
//		c.setTimeInMillis(Long.parseLong(String.valueOf(2054684690 * 1000)));
//		System.out.println("����ʱ�䣺" + c.get(Calendar.YEAR)+"-"+c.get(Calendar.MONTH)+"-"+c.get(Calendar.DAY_OF_MONTH) + " " + c.get(Calendar.HOUR) + ":" + c.get(Calendar.MINUTE));
	}
}
