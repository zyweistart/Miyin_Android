package com.freshpower.android.elec.activity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.AdapterView.OnItemClickListener;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.FileUtil;

public class HomeInformationActivity extends Activity {
	private RoundCornerListView groupOnelistview;
	private String[] menuNames;
	private int[] menuIcoIds;
	private Resources res;
	private File newsFile;
	private List<Map<String, Object>> listItems;
	private String sdpath = FileUtil.getAppRootPath();// ��ô洢����·��
	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_homeinformation);
		ActivityUtil.addActivity(this);
		res = getResources();
		findViews();
		setAdapter();
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
	        iv.setOnClickListener(new OnClickListener() {
	        	@Override
				public void onClick(View v) {
					Intent intent = new Intent(HomeInformationActivity.this,HomeActivity.class);
		    		startActivity(intent);
		    		finish();	
				}
			});
	    
	}
	private void setAdapter(){
		groupOnelistview.setAdapter(new SimpleAdapter(this,getGroupOnelistData(), R.layout.listitem_homeinformation, new String[] { AppConstant.ListItemCtlName.MENU_ICO, AppConstant.ListItemCtlName.MENU_NAME}, new int[] { R.id.menuIco,R.id.menuName}));
		setListViewHeightBasedOnChildren(groupOnelistview);
		groupOnelistview.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent,
					View view, int position, long id) {
				sdpath = FileUtil.getAppRootPath();// ��ô洢����·��
				newsFile = new File(sdpath+"download"+File.separator+"newsFile.txt");
				Map<String, Object> listItem = (Map<String, Object>)parent.getItemAtPosition(position);
				if(newsFile.exists()){
					Intent it = new Intent(HomeInformationActivity.this,HomeIntroduceActivity.class);
					it.putExtra("type", listItem.get("visitURL").toString());
					startActivity(it);
					finish();
				}else{
					if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_ICO).toString())==R.drawable.pic_small_1){
						Intent it = new Intent(HomeInformationActivity.this,HomeIntroduceActivity.class);
						it.putExtra("type", "0");
						startActivity(it);
						finish();
					}else if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_ICO).toString())==R.drawable.pic_small_3){
						Intent it = new Intent(HomeInformationActivity.this,HomeIntroduceActivity.class);
						it.putExtra("type", "1");
						startActivity(it);
						finish();
					}else if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_ICO).toString())==R.drawable.pic_small_4){
						Intent it = new Intent(HomeInformationActivity.this,HomeIntroduceActivity.class);
						it.putExtra("type", "2");
						startActivity(it);
						finish();
					}else if(Integer.parseInt(listItem.get(AppConstant.ListItemCtlName.MENU_ICO).toString())==R.drawable.pic_small_5){
						Intent it = new Intent(HomeInformationActivity.this,HomeIntroduceActivity.class);
						it.putExtra("type", "3");
						startActivity(it);
						finish();
					}
				}
			}
			
		});
	}
	private void findViews(){
		groupOnelistview = (RoundCornerListView)findViewById(R.id.setMenulistviewOne);
	}
	private List<Map<String, Object>> getGroupOnelistData(){
		newsFile = new File(sdpath+"download"+File.separator+"newsFile.txt");
		String[] pictureNames = new String[10];
		String[] visitURL = new String[10];
		//�ļ����ڣ�����ļ��ж�ȡ������Ϣ
		if(newsFile.exists()){
			FileReader fileReader;
			String[] content;
			try {
				fileReader = new FileReader(sdpath+"download"+File.separator+"newsFile.txt");
				BufferedReader br = new BufferedReader(fileReader);
				String temp = "";
				StringBuffer fileContent = new StringBuffer();
				while((temp = br.readLine())!=null){             
					fileContent.append(temp);             
				}
				content = fileContent.toString().split("\\|");
				menuNames = content[1].split(",");//����
				pictureNames = content[0].split(",");//Сͼ��
				visitURL = content[3].split(",");//����url
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}else{
			menuNames=res.getStringArray(R.array.soft_homeinformation_menuNames);
			menuIcoIds = new int[]{ R.drawable.pic_small_1,R.drawable.pic_small_3,R.drawable.pic_small_4,R.drawable.pic_small_5};
		}
		listItems = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < menuNames.length; i++)
		{
			Map<String, Object> listItem = new HashMap<String, Object>();
			listItem.put(AppConstant.ListItemCtlName.MENU_ICO,newsFile.exists()? new File(sdpath+"download/www/images"+File.separator+pictureNames[i].split("\\.")[0]):menuIcoIds[i]);
			listItem.put(AppConstant.ListItemCtlName.MENU_NAME, menuNames[i]);
			listItem.put("visitURL", visitURL[i]);//����URL
			listItems.add(listItem);
		}
		return listItems;
	}
	/***
     * ��̬����listview�ĸ߶�
     * 
     * @param listView
     */
    public void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        
        if (listAdapter == null) {
            return;
        }
        int totalHeight = 0;
        for (int i = 0; i < listAdapter.getCount(); i++) {
           View listItem = listAdapter.getView(i, null, listView);
        	//View listItem = inflater.inflate(android.R.layout.simple_expandable_list_item_1, null);
            listItem.measure(0, 0);
            totalHeight += listItem.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight
                + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        listView.setLayoutParams(params);
    }
    
    @Override
    protected void onDestroy() {
    	// TODO Auto-generated method stub
    	if(groupOnelistview!=null){
    		listItems.clear();
    	}
    	super.onDestroy();
    }
}

