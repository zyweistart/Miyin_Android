package com.freshpower.android.elec.activity;

import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.conn.HttpHostConnectException;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.DBOperater;
import com.freshpower.android.elec.common.FileUtil;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.domain.UserRegisterInfo;
import com.freshpower.android.elec.netapi.LoginInfoDataApi;

public class UserRegisterActivity  extends Activity {
	private UserRegisterInfo userRegisterInfo;
	private Button loginSub;
	private ProgressDialog processProgress;
	private Handler handler = new Handler();
	private String userType = "";

	private Spinner province_spinner;
	private Spinner city_spinner;
	private Spinner county_spinner;
	private Integer provinceId;
	private Integer cityId;
	private EditText display;
	private String strProvince;
	private String strCity;
	private String strCounty;
	//�У�����������
	private int[] city = { R.array.beijingshi_province_item,
			R.array.tianjinshi_province_item, R.array.hebeisheng_province_item,
			R.array.shanxisheng_province_item, R.array.neimengguzizhiqu_province_item,
			R.array.liaoningsheng_province_item, R.array.jilinsheng_province_item,
			R.array.heilongjiangsheng_province_item, R.array.shanghaishi_province_item,
			R.array.jiangsusheng_province_item, R.array.zhejiangsheng_province_item,
			R.array.anhuisheng_province_item, R.array.fujiansheng_province_item,
			R.array.jiangxisheng_province_item, R.array.shandongsheng_province_item,
			R.array.henansheng_province_item, R.array.hubeisheng_province_item,
			R.array.hunansheng_province_item, R.array.guangdongsheng_province_item,
			R.array.guangxizhuangzuzizhiqu_province_item, R.array.hainansheng_province_item,
			R.array.chongqingshi_province_item, R.array.sichuansheng_province_item,
			R.array.guizhousheng_province_item, R.array.yunnansheng_province_item,
			R.array.xizangzizhiqu_province_item, R.array.shanxisheng2_province_item,
			R.array.gansusheng_province_item, R.array.qinghaisheng_province_item,
			R.array.ningxiahuizuzizhiqu_province_item, R.array.xinjiangweiwuerzizhiqu_province_item,
			R.array.xianggang_province_item,R.array.aomen_province_item};
	private int[] countyOfBeiJing = {R.array.beijingshixiaqu_city_item,R.array.beijingxian_city_item};
	private int[] countyOfTianJing = {R.array.tianjingshixiaqu_city_item,R.array.tianjingxian_city_item};
	private int[] countyOfHeBei = { R.array.shijiazhuangshi_city_item,
			R.array.tangshanshi_city_item,
			R.array.qinhuangdaoshi_city_item,
			R.array.handanshi_city_item,
			R.array.xingtaishi_city_item,
			R.array.baodingshi_city_item,
			R.array.zhangjiakoushi_city_item,
			R.array.chengdeshi_city_item,
			R.array.cangzhoushi_city_item,
			R.array.langfangshi_city_item,
			R.array.hengshuishi_city_item };
	private int[] countyOfShanXi1 = { R.array.taiyuanshi_city_item,
			R.array.datongshi_city_item,
			R.array.yangquanshi_city_item,
			R.array.zhangzhishi_city_item,
			R.array.jinchengshi_city_item,
			R.array.shuozhoushi_city_item,
			R.array.jinzhongshi_city_item,
			R.array.yunchengshi_city_item,
			R.array.xinzhoushi_city_item,
			R.array.linfenshi_city_item,
			R.array.luliangshi_city_item};
	private int[] countyOfNeiMengGu = { R.array.huhehaoteshi_city_item,
			R.array.baotoushi_city_item,
			R.array.wuhaishi_city_item,
			R.array.chifengshi_city_item,
			R.array.tongliaoshi_city_item,
			R.array.eerduosishi_city_item,
			R.array.hulunbeiershi_city_item,
			R.array.bayannaoershi_city_item,
			R.array.wulanchabushi_city_item,
			R.array.xinganmeng_city_item,
			R.array.xilinguolemeng_city_item,
			R.array.alashanmeng_city_item};
	private int[] countyOfLiaoNing = { R.array.shenyangshi_city_item,
			R.array.dalianshi_city_item,
			R.array.anshanshi_city_item,
			R.array.fushunshi_city_item,
			R.array.benxishi_city_item,
			R.array.dandongshi_city_item,
			R.array.jinzhoushi_city_item,
			R.array.yingkoushi_city_item,
			R.array.fuxinshi_city_item,
			R.array.liaoyangshi_city_item,
			R.array.panjinshi_city_item,
			R.array.tielingshi_city_item,
			R.array.chaoyangshi_city_item,
			R.array.huludaoshi_city_item };
	private int[] countyOfJiLin = { R.array.zhangchunshi_city_item,
			R.array.jilinshi_city_item,
			R.array.sipingshi_city_item,
			R.array.liaoyuanshi_city_item,
			R.array.tonghuashi_city_item,
			R.array.baishanshi_city_item,
			R.array.songyuanshi_city_item,
			R.array.baichengshi_city_item,
			R.array.yanbianchaoxianzuzizhizhou_city_item };
	private int[] countyOfHeiLongJiang = {R.array.haerbinshi_city_item,
			R.array.qiqihaershi_city_item,
			R.array.jixishi_city_item,
			R.array.hegangshi_city_item,
			R.array.shuangyashanshi_city_item,
			R.array.daqingshi_city_item,
			R.array.yichunshi_city_item,
			R.array.jiamusishi_city_item,
			R.array.qitaiheshi_city_item,
			R.array.mudanjiangshi_city_item,
			R.array.heiheshi_city_item,
			R.array.suihuashi_city_item,
			R.array.daxinganlingdiqu_city_item };
	private int[] countyOfShangHai = { R.array.shanghaishixiaqu_city_item,R.array.shanghaixian_city_item };

	private int[] countyOfJiangSu = { R.array.nanjingshi_city_item,
			R.array.wuxishi_city_item,
			R.array.xuzhoushi_city_item,
			R.array.changzhoushi_city_item,
			R.array.suzhoushi_city_item,
			R.array.nantongshi_city_item,
			R.array.lianyungangshi_city_item,
			R.array.huaianshi_city_item,
			R.array.yanchengshi_city_item,
			R.array.yangzhoushi_city_item,
			R.array.zhenjiangshi_city_item,
			R.array.taizhoushi_city_item,
			R.array.suqianshi_city_item };
	private int[] countyOfZheJiang = {R.array.hangzhoushi_city_item,
			R.array.ningboshi_city_item,
			R.array.wenzhoushi_city_item,
			R.array.jiaxingshi_city_item,
			R.array.huzhoushi_city_item,
			R.array.shaoxingshi_city_item,
			R.array.jinhuashi_city_item,
			R.array.quzhoushi_city_item,
			R.array.zhoushanshi_city_item,
			R.array.taizhoushi2_city_item,
			R.array.lishuishi_city_item};
	private int[] countyOfAnHui = { R.array.hefeishi_city_item,
			R.array.wuhushi_city_item,
			R.array.bangbushi_city_item,
			R.array.huainanshi_city_item,
			R.array.maanshanshi_city_item,
			R.array.huaibeishi_city_item,
			R.array.tonglingshi_city_item,
			R.array.anqingshi_city_item,
			R.array.huangshanshi_city_item,
			R.array.chuzhoushi_city_item,
			R.array.fuyangshi_city_item,
			R.array.suzhoushi2_city_item,
			R.array.chaohushi_city_item,
			R.array.liuanshi_city_item,
			R.array.bozhoushi_city_item,
			R.array.chizhoushi_city_item,
			R.array.xuanchengshi_city_item };
	private int[] countyOfFuJian = { R.array.fuzhoushi_city_item,
			R.array.shamenshi_city_item,
			R.array.putianshi_city_item,
			R.array.sanmingshi_city_item,
			R.array.quanzhoushi_city_item,
			R.array.zhangzhoushi_city_item,
			R.array.nanpingshi_city_item,
			R.array.longyanshi_city_item,
			R.array.ningdeshi_city_item };
	private int[] countyOfJiangXi = { R.array.nanchangshi_city_item,
			R.array.jingdezhenshi_city_item,
			R.array.pingxiangshi_city_item,
			R.array.jiujiangshi_city_item,
			R.array.xinyushi_city_item,
			R.array.yingtanshi_city_item,
			R.array.ganzhoushi_city_item,
			R.array.jianshi_city_item,
			R.array.yichunshi2_city_item,
			R.array.fuzhoushi2_city_item,
			R.array.shangraoshi_city_item };
	private int[] countyOfShanDong = {R.array.jinanshi_city_item,
			R.array.qingdaoshi_city_item,
			R.array.ziboshi_city_item,
			R.array.zaozhuangshi_city_item,
			R.array.dongyingshi_city_item,
			R.array.yantaishi_city_item,
			R.array.weifangshi_city_item,
			R.array.jiningshi_city_item,
			R.array.taianshi_city_item,
			R.array.weihaishi_city_item,
			R.array.rizhaoshi_city_item,
			R.array.laiwushi_city_item,
			R.array.linyishi_city_item,
			R.array.dezhoushi_city_item,
			R.array.liaochengshi_city_item,
			R.array.binzhoushi_city_item,
			R.array.hezeshi_city_item};
	private int[] countyOfHeNan = { R.array.zhengzhoushi_city_item,
			R.array.kaifengshi_city_item,
			R.array.luoyangshi_city_item,
			R.array.pingdingshanshi_city_item,
			R.array.anyangshi_city_item,
			R.array.hebishi_city_item,
			R.array.xinxiangshi_city_item,
			R.array.jiaozuoshi_city_item,
			R.array.puyangshi_city_item,
			R.array.xuchangshi_city_item,
			R.array.luoheshi_city_item,
			R.array.sanmenxiashi_city_item,
			R.array.nanyangshi_city_item,
			R.array.shangqiushi_city_item,
			R.array.xinyangshi_city_item,
			R.array.zhoukoushi_city_item,
			R.array.zhumadianshi_city_item };
	private int[] countyOfHuBei = {R.array.wuhanshi_city_item,
			R.array.huangshishi_city_item,
			R.array.shiyanshi_city_item,
			R.array.yichangshi_city_item,
			R.array.xiangfanshi_city_item,
			R.array.ezhoushi_city_item,
			R.array.jingmenshi_city_item,
			R.array.xiaoganshi_city_item,
			R.array.jingzhoushi_city_item,
			R.array.huanggangshi_city_item,
			R.array.xianningshi_city_item,
			R.array.suizhoushi_city_item,
			R.array.enshitujiazumiaozuzizhizhou_city_item,
			R.array.shengzhixiaxingzhengdanwei_city_item};

	private int[] countyOfHuNan = { R.array.zhangshashi_city_item,
			R.array.zhuzhoushi_city_item,
			R.array.xiangtanshi_city_item,
			R.array.hengyangshi_city_item,
			R.array.shaoyangshi_city_item,
			R.array.yueyangshi_city_item,
			R.array.changdeshi_city_item,
			R.array.zhangjiajieshi_city_item,
			R.array.yiyangshi_city_item,
			R.array.chenzhoushi_city_item,
			R.array.yongzhoushi_city_item,
			R.array.huaihuashi_city_item,
			R.array.loudishi_city_item,
			R.array.xiangxitujiazumiaozuzizhizhou_city_item };
	private int[] countyOfGuangDong = { R.array.guangzhoushi_city_item,
			R.array.shaoguanshi_city_item,
			R.array.shenzhenshi_city_item,
			R.array.zhuhaishi_city_item,
			R.array.shantoushi_city_item,
			R.array.foshanshi_city_item,
			R.array.jiangmenshi_city_item,
			R.array.zhanjiangshi_city_item,
			R.array.maomingshi_city_item,
			R.array.zhaoqingshi_city_item,
			R.array.huizhoushi_city_item,
			R.array.meizhoushi_city_item,
			R.array.shanweishi_city_item,
			R.array.heyuanshi_city_item,
			R.array.yangjiangshi_city_item,
			R.array.qingyuanshi_city_item,
			R.array.dongguanshi_city_item,
			R.array.zhongshanshi_city_item,
			R.array.chaozhoushi_city_item,
			R.array.jieyangshi_city_item,
			R.array.yunfushi_city_item };
	private int[] countyOfGuangXi = {R.array.nanningshi_city_item,
			R.array.liuzhoushi_city_item,
			R.array.guilinshi_city_item,
			R.array.wuzhoushi_city_item,
			R.array.beihaishi_city_item,
			R.array.fangchenggangshi_city_item,
			R.array.qinzhoushi_city_item,
			R.array.guigangshi_city_item,
			R.array.yulinshi_city_item,
			R.array.baiseshi_city_item,
			R.array.hezhoushi_city_item,
			R.array.hechishi_city_item,
			R.array.laibinshi_city_item,
			R.array.chongzuoshi_city_item };
	private int[] countyOfHaiNan = { R.array.haikoushi_city_item,
			R.array.sanyashi_city_item,
			R.array.shengzhixiaxianjixingzhengdanwei_city_item};
	private int[] countyOfChongQing = { R.array.chongqingshixiaqu_city_item,
			R.array.chongqingxian_city_item };
	private int[] countyOfSiChuan = { R.array.chengdoushi_city_item,
			R.array.zigongshi_city_item,
			R.array.panzhihuashi_city_item,
			R.array.luzhoushi_city_item,
			R.array.deyangshi_city_item,
			R.array.mianyangshi_city_item,
			R.array.guangyuanshi_city_item,
			R.array.suiningshi_city_item,
			R.array.neijiangshi_city_item,
			R.array.leshanshi_city_item,
			R.array.nanchongshi_city_item,
			R.array.meishanshi_city_item,
			R.array.yibinshi_city_item,
			R.array.guanganshi_city_item,
			R.array.dazhoushi_city_item,
			R.array.yaanshi_city_item,
			R.array.bazhongshi_city_item,
			R.array.ziyangshi_city_item,
			R.array.abazangzuqiangzuzizhizhou_city_item,
			R.array.ganzizangzuzizhizhou_city_item,
			R.array.liangshanyizuzizhizhou_city_item };
	private int[] countyOfGuiZhou = { R.array.guiyangshi_city_item,
			R.array.liupanshuishi_city_item,
			R.array.zunyishi_city_item,
			R.array.anshunshi_city_item,
			R.array.tongrendiqu_city_item,
			R.array.qianxinanbuyizumiaozuzizhizhou_city_item,
			R.array.bijiediqu_city_item,
			R.array.qiandongnanmiaozudongzuzizhizhou_city_item,
			R.array.qiannanbuyizumiaozuzizhizhou_city_item};
	private int[] countyOfYunNan = { R.array.kunmingshi_city_item,
			R.array.qujingshi_city_item,
			R.array.yuxishi_city_item,
			R.array.baoshanshi_city_item,
			R.array.zhaotongshi_city_item,
			R.array.lijiangshi_city_item,
			R.array.simaoshi_city_item,
			R.array.lincangshi_city_item,
			R.array.chuxiongyizuzizhizhou_city_item,
			R.array.honghehanizuyizuzizhizhou_city_item,
			R.array.wenshanzhuangzumiaozuzizhizhou_city_item,
			R.array.xishuangbannadaizuzizhizhou_city_item,
			R.array.dalibaizuzizhizhou_city_item,
			R.array.dehongdaizujingpozuzizhizhou_city_item,
			R.array.nujianglisuzuzizhizhou_city_item,
			R.array.diqingzangzuzizhizhou_city_item };
	private int[] countyOfXiZang = { R.array.lasashi_city_item,
			R.array.changdoudiqu_city_item,
			R.array.shannandiqu_city_item,
			R.array.rikazediqu_city_item,
			R.array.neiqudiqu_city_item,
			R.array.alidiqu_city_item,
			R.array.linzhidiqu_city_item };

	private int[] countyOfShanXi2 = { R.array.xianshi_city_item,
			R.array.tongchuanshi_city_item,
			R.array.baojishi_city_item,
			R.array.xianyangshi_city_item,
			R.array.weinanshi_city_item,
			R.array.yananshi_city_item,
			R.array.hanzhongshi_city_item,
			R.array.yulinshi2_city_item,
			R.array.ankangshi_city_item,
			R.array.shangluoshi_city_item };
	private int[] countyOfGanSu = {R.array.lanzhoushi_city_item,
			R.array.jiayuguanshi_city_item,
			R.array.jinchangshi_city_item,
			R.array.baiyinshi_city_item,
			R.array.tianshuishi_city_item,
			R.array.wuweishi_city_item,
			R.array.zhangyeshi_city_item,
			R.array.pingliangshi_city_item,
			R.array.jiuquanshi_city_item,
			R.array.qingyangshi_city_item,
			R.array.dingxishi_city_item,
			R.array.longnanshi_city_item,
			R.array.linxiahuizuzizhizhou_city_item,
			R.array.gannanzangzuzizhizhou_city_item };
	private int[] countyOfQingHai = { R.array.xiningshi_city_item,
			R.array.haidongdiqu_city_item,
			R.array.haibeizangzuzizhizhou_city_item,
			R.array.huangnanzangzuzizhizhou_city_item,
			R.array.hainanzangzuzizhizhou_city_item,
			R.array.guoluozangzuzizhizhou_city_item,
			R.array.yushuzangzuzizhizhou_city_item,
			R.array.haiximengguzuzangzuzizhizhou_city_item };
	private int[] countyOfNingXia = { R.array.yinchuanshi_city_item,
			R.array.shizuishanshi_city_item,
			R.array.wuzhongshi_city_item,
			R.array.guyuanshi_city_item,
			R.array.zhongweishi_city_item };
	private int[] countyOfXinJiang = { R.array.wulumuqishi_city_item,
			R.array.kelamayishi_city_item,
			R.array.tulufandiqu_city_item,
			R.array.hamidiqu_city_item,
			R.array.changjihuizuzizhizhou_city_item,
			R.array.boertalamengguzizhizhou_city_item,
			R.array.bayinguolengmengguzizhizhou_city_item,
			R.array.akesudiqu_city_item,
			R.array.kezilesukeerkezizizhizhou_city_item,
			R.array.kashendiqu_city_item,
			R.array.hetiandiqu_city_item,
			R.array.yilihasakezizhizhou_city_item,
			R.array.tachengdiqu_city_item,
			R.array.aletaidiqu_city_item,
			R.array.shengzhixiaxingzhengdanwei2_city_item};
	private int[] countyOfXiangGang = { R.array.xianggang_city_item};
	private int[] countyOfAoMen = { R.array.aomen_city_item};

	private ArrayAdapter<CharSequence> province_adapter;
	private ArrayAdapter<CharSequence> city_adapter;
	private ArrayAdapter<CharSequence> county_adapter;

	protected void onCreate(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_userregister);
		ActivityUtil.addActivity(this);
		loadSpinner();
		userType = getIntent().getStringExtra("userType");
		loginSub=(Button)findViewById(R.id.loginRegisterSub);
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(!StringUtil.isEmpty(userType)) {
					Intent intent = new Intent(UserRegisterActivity.this,UserExperienceSecondActivity.class);
					intent.putExtra("userType", userType);
					startActivity(intent);
					finish();
				} else {
					UserRegisterActivity.this.onBackPressed();
				}
			}
		});

//		EditText registerAddress=(EditText)findViewById(R.id.loginRegisterAddress);
//		registerAddress.setOnClickListener(new OnClickListener() {
//			@Override
//			public void onClick(View v) {
//				Intent intent = new Intent(UserRegisterActivity.this,SearchConditionActivity.class);
//				intent.putExtra(AppConstant.ExtraName.EXTRANAME_NAME, "");
//				intent.putExtra(AppConstant.ExtraName.EXTRANAME_TYPE, AppConstant.PurchaseType.AREA);
//				startActivityForResult(intent,100);
//			}
//		});
		loginSub.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				EditText loginRegisterName_et=(EditText)findViewById(R.id.loginRegisterName);
				EditText loginRegisterTel_et=(EditText)findViewById(R.id.loginRegisterTel);
				EditText loginRegisterCardNum_et=(EditText)findViewById(R.id.loginRegisterCardNum);
				province_spinner=(Spinner)findViewById(R.id.province_spinner);
				city_spinner=(Spinner)findViewById(R.id.city_spinner);
				county_spinner=(Spinner)findViewById(R.id.county_spinner);
//				Pattern pattern;
//				Matcher matcher;
//				if(loginRegisterName_et.getText().toString().equals(""))
//				{
//					Toast.makeText(UserRegisterActivity.this, R.string.user_register_name, Toast.LENGTH_SHORT).show();
//					return;
//				}
//				if(loginRegisterTel_et.getText().toString().equals(""))
//				{
//					Toast.makeText(UserRegisterActivity.this, R.string.user_register_tel, Toast.LENGTH_SHORT).show();
//					return;
//				}else if(11!=loginRegisterTel_et.getText().toString().length()){
//					Toast.makeText(UserRegisterActivity.this, R.string.user_register_telNot, Toast.LENGTH_SHORT).show();
//					return;
//				}
//				if(loginRegisterCardNum_et.getText().toString().equals(""))
//				{
//					Toast.makeText(UserRegisterActivity.this, R.string.user_register_card, Toast.LENGTH_SHORT).show();
//					return;
//				}
//				else {
//					pattern = Pattern.compile(StringUtil.IS18IDCARD);
//					matcher = pattern.matcher(loginRegisterCardNum_et.getText().toString());
//					if(!matcher.matches()){
//						Toast.makeText(UserRegisterActivity.this, R.string.user_register_cardNot, Toast.LENGTH_SHORT).show();
//						return;
//					}
//				}
				userRegisterInfo=new UserRegisterInfo();
				userRegisterInfo.setLoginRegisterName("����");
				userRegisterInfo.setLoginRegisterTel("1373829382");
				userRegisterInfo.setLoginRegisterCardNum("330182938192038193");
				userRegisterInfo.setLoginRegisterAddress(province_spinner.getSelectedItem()
						.toString()+city_spinner.getSelectedItem()
						.toString()+county_spinner.getSelectedItem()
						.toString());
				userRegisterInfo.setCity(city_spinner.getSelectedItem().toString());
				userRegisterInfo.setCounty(county_spinner.getSelectedItem().toString());
				userRegisterInfo.setProvince(province_spinner.getSelectedItem().toString());
				processProgress = ProgressDialog.show(UserRegisterActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
				new Thread(new Runnable(){
					String msgContent;
					@Override
					public void run() {
						String crmRs="0";
						try {
							//					Intent intent =getIntent();
							//					if(intent.getStringExtra("fileNot")!=null&&!intent.getStringExtra("fileNot").equals("")&&intent.getStringExtra("fileNot").equals("0")){//�ļ�������
							//						String rs=LoginInfoDataApi.getRegisterInfoAuditTrms(userRegisterInfo);//���״̬�ӿ�
							//						//�ӿ� �õ���
							//						if(rs.equals("1")){//���ͨ��
							//							Intent intent1 = new Intent(UserRegisterActivity.this,UserExperienceActivity.class);
							//							startActivity(intent1);
							//						}else if(rs.equals("0")){//��˲�ͨ��
							//							Toast.makeText(UserRegisterActivity.this, R.string.msg_auditnot_network,Toast.LENGTH_SHORT).show();
							//							return;
							//						}else if(rs.equals("2")){//�����
							//							Toast.makeText(UserRegisterActivity.this, R.string.msg_audit_network,Toast.LENGTH_SHORT).show();
							//							return;
							//						}else if(rs.equals("3")){//δ�ύ����   CRM��֤
							//							//�ӿ� CRM
							//							String crmRs=LoginInfoDataApi.getRegisterInfoCrm(userRegisterInfo);
							//							if("1".equals(crmRs)){//CRM�ж��Ƿ����   ����ֱ������
							//								Intent intent2 = new Intent(UserRegisterActivity.this, UserExperienceActivity.class);
							//								startActivity(intent2);
							//								finish();	
							//							}else if("0".equals(crmRs)){//������    �ϴ�ע����Ϣ
							//								writeLoginInfoContent(userRegisterInfo);
							//								Intent phonto = new Intent(UserRegisterActivity.this, PhontoActivity.class);
							//								phonto.putExtra("registerName", userRegisterInfo.getLoginRegisterName());
							//								phonto.putExtra("registerCardNum", userRegisterInfo.getLoginRegisterCardNum());
							//								phonto.putExtra("registerTel", userRegisterInfo.getLoginRegisterTel());
							//								phonto.putExtra("registerAddress", userRegisterInfo.getLoginRegisterAddress());
							//								startActivity(phonto);
							//								finish();	
							//							}else{//����ʧ��
							//								
							//							}
							//						}
							//					}else{
							//�ӿ� CRM
							crmRs=LoginInfoDataApi.getRegisterInfoCrm(userRegisterInfo);
							//					}
						}catch (HttpHostConnectException e) {
							msgContent = getResources().getString(R.string.msg_abnormal_network);
						}catch (Exception e) {
							msgContent = getResources().getString(R.string.msg_abnormal_network); 
						}finally{
							processProgress.dismiss();
							//							handler.post(new Runnable() {
							//								@Override
							//								public void run() {
							//									Toast.makeText(UserRegisterActivity.this, msgContent, Toast.LENGTH_SHORT).show(); 								
							//								}
							//							});
							if(crmRs.equals("1")){//CRM�ж��Ƿ����  
								Intent it = new Intent(UserRegisterActivity.this, HomeActivity.class);
								startActivity(it);
								finish();	
							}else if(crmRs.equals("0")){//������    �ϴ�ע����Ϣ
								//							writeLoginInfoContent(userRegisterInfo);
								Intent phonto = new Intent(UserRegisterActivity.this, PhontoActivity.class);
								phonto.putExtra("registerName", userRegisterInfo.getLoginRegisterName());
								phonto.putExtra("registerCardNum", userRegisterInfo.getLoginRegisterCardNum());
								phonto.putExtra("registerTel", userRegisterInfo.getLoginRegisterTel());
								phonto.putExtra("registerAddress", userRegisterInfo.getLoginRegisterAddress());
								phonto.putExtra("city", userRegisterInfo.getCity());
								phonto.putExtra("county", userRegisterInfo.getCounty());
								phonto.putExtra("province", userRegisterInfo.getProvince());
								startActivity(phonto);
							}
						}
					}
				}).start();
			}

		});
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(20==resultCode)  
		{  
			String name=data.getExtras().getString(AppConstant.ExtraName.EXTRANAME_NAME);
			TextView registerAddress=(TextView)findViewById(R.id.loginRegisterAddress);
			registerAddress.setText(name);

		}  

		super.onActivityResult(requestCode, resultCode, data);
	}
	public void writeLoginInfoContent(UserRegisterInfo userRegisterInfo){
		if(!FileUtil.isFileExist(FileUtil.getElecFilePath())){
			//			DBOperater.openOrCreateDB(FileUtil.getElecFilePath());
			try {
				File dbFile = new File(FileUtil.getElecFilePath());
				FileUtil.createFolder(dbFile.getParent());
				FileUtil.createFile(dbFile);
			} catch (Exception e) {
				Log.e("dberror", e.toString());
				e.printStackTrace();
			}
		}else{
			String fileContent = FileUtil.read(FileUtil.getElecFilePath());
			fileContent = userRegisterInfo.getLoginRegisterName()
					+ "|"
					+ userRegisterInfo.getLoginRegisterTel()
					+ "|"
					+ userRegisterInfo.getLoginRegisterCardNum()
					+ "|"
					+ userRegisterInfo.getLoginRegisterAddress()
					+ "|"
					+ fileContent.substring(fileContent
							.lastIndexOf('|') + 1);
			FileUtil.writeBeforeClearContent(
					FileUtil.getElecFilePath(), fileContent); 
		}

	}
	private void loadSpinner() {
//		display = (EditText) findViewById(R.id.loginRegisterAddress);
		province_spinner = (Spinner) findViewById(R.id.province_spinner);
		//��ʡ�ݵ�����
		province_spinner.setPrompt("��ѡ��ʡ��");
		province_adapter = ArrayAdapter.createFromResource(this,
				R.array.province_item, android.R.layout.simple_spinner_item);
		province_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		province_spinner.setAdapter(province_adapter);
		// select(province_spinner, province_adapter, R.array.province_item);
		//���Ӽ�����һ��ʼ��ʱ����У������������ǲ���ʾ�Ķ��Ǹ���ʡ�����ݽ�������
		province_spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				provinceId = province_spinner.getSelectedItemPosition();
				strProvince = province_spinner.getSelectedItem()
						.toString();//�õ�ѡ������ݣ�Ҳ����ʡ������
				city_spinner = (Spinner) findViewById(R.id.city_spinner);
				if (true) {
					county_spinner = (Spinner) findViewById(R.id.county_spinner);
					city_spinner = (Spinner) findViewById(R.id.city_spinner);
					city_spinner.setPrompt("��ѡ�����");//���ñ���
					select(city_spinner, city_adapter, city[provinceId]);//����һ�������ݰ�
					/*ͨ�����city[provinceId]ָ���˸�ʡ�е�City����
					 * R��array.beijing*/
					city_spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
						@Override
						public void onItemSelected(
								AdapterView<?> arg0, View arg1,
								int arg2, long arg3) {
							cityId = city_spinner
									.getSelectedItemPosition();//�õ�city��id
							strCity = city_spinner
									.getSelectedItem()
									.toString();//�õ�city������
							if (true) {
								//���￪ʼ��������һ��������
								county_spinner = (Spinner) findViewById(R.id.county_spinner);
								county_spinner.setPrompt("��ѡ������");
								switch (provinceId) {
								case 0:
									select(county_spinner,
											county_adapter,
											countyOfBeiJing[cityId]);
									break;
								case 1:
									select(county_spinner,
											county_adapter,
											countyOfTianJing[cityId]);
									break;
								case 2:
									select(county_spinner,
											county_adapter,
											countyOfHeBei[cityId]);
									break;
								case 3:
									select(county_spinner,
											county_adapter,
											countyOfShanXi1[cityId]);
									break;
								case 4:
									select(county_spinner,
											county_adapter,
											countyOfNeiMengGu[cityId]);
									break;
								case 5:
									select(county_spinner,
											county_adapter,
											countyOfLiaoNing[cityId]);
									break;
								case 6:
									select(county_spinner,
											county_adapter,
											countyOfJiLin[cityId]);
									break;
								case 7:
									select(county_spinner,
											county_adapter,
											countyOfHeiLongJiang[cityId]);
									break;
								case 8:
									select(county_spinner,
											county_adapter,
											countyOfShangHai[cityId]);
									break;
								case 9:
									select(county_spinner,
											county_adapter,
											countyOfJiangSu[cityId]);
									break;
								case 10:
									select(county_spinner,
											county_adapter,
											countyOfZheJiang[cityId]);
									break;
								case 11:
									select(county_spinner,
											county_adapter,
											countyOfAnHui[cityId]);
									break;
								case 12:
									select(county_spinner,
											county_adapter,
											countyOfFuJian[cityId]);
									break;
								case 13:
									select(county_spinner,
											county_adapter,
											countyOfJiangXi[cityId]);
									break;
								case 14:
									select(county_spinner,
											county_adapter,
											countyOfShanDong[cityId]);
									break;
								case 15:
									select(county_spinner,
											county_adapter,
											countyOfHeNan[cityId]);
									break;
								case 16:
									select(county_spinner,
											county_adapter,
											countyOfHuBei[cityId]);
									break;
								case 17:
									select(county_spinner,
											county_adapter,
											countyOfHuNan[cityId]);
									break;
								case 18:
									select(county_spinner,
											county_adapter,
											countyOfGuangDong[cityId]);
									break;
								case 19:
									select(county_spinner,
											county_adapter,
											countyOfGuangXi[cityId]);
									break;
								case 20:
									select(county_spinner,
											county_adapter,
											countyOfHaiNan[cityId]);
									break;
								case 21:
									select(county_spinner,
											county_adapter,
											countyOfChongQing[cityId]);
									break;
								case 22:
									select(county_spinner,
											county_adapter,
											countyOfSiChuan[cityId]);
									break;
								case 23:
									select(county_spinner,
											county_adapter,
											countyOfGuiZhou[cityId]);
									break;
								case 24:
									select(county_spinner,
											county_adapter,
											countyOfYunNan[cityId]);
									break;
								case 25:
									select(county_spinner,
											county_adapter,
											countyOfXiZang[cityId]);
									break;
								case 26:
									select(county_spinner,
											county_adapter,
											countyOfShanXi2[cityId]);
									break;
								case 27:
									select(county_spinner,
											county_adapter,
											countyOfGanSu[cityId]);
									break;
								case 28:
									select(county_spinner,
											county_adapter,
											countyOfQingHai[cityId]);
									break;
								case 29:
									select(county_spinner,
											county_adapter,
											countyOfNingXia[cityId]);
									break;
								case 30:
									select(county_spinner,
											county_adapter,
											countyOfXinJiang[cityId]);
									break;
								case 31:
									select(county_spinner,
											county_adapter,
											countyOfXiangGang[cityId]);
									break;
								case 32:
									select(county_spinner,
											county_adapter,
											countyOfAoMen[cityId]);
									break;
								/*case 33:
									select(county_spinner,
											county_adapter,
											countyOfTaiWan[cityId]);
									break;*/

								default:
									break;
								}

								county_spinner
								.setOnItemSelectedListener(new OnItemSelectedListener() {

									@Override
									public void onItemSelected(
											AdapterView<?> arg0,
											View arg1,
											int arg2,
											long arg3) {
										strCounty = county_spinner
												.getSelectedItem()
												.toString();
//										display.setText(strProvince
//												+ "-"
//												+ strCity
//												+ "-"
//												+ strCounty);
									}

									@Override
									public void onNothingSelected(
											AdapterView<?> arg0) {

									}

								});
							}
						}

						@Override
						public void onNothingSelected(
								AdapterView<?> arg0) {
							// TODO Auto-generated method stub

						}

					});
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {

			}
		});

	}
	 /*ͨ��������̬������������*/
		private void select(Spinner spin, ArrayAdapter<CharSequence> adapter,
				int arry) {
			//ע�������arry����������һ�����Σ���������һ�����飡
			adapter = ArrayAdapter.createFromResource(this, arry,
					android.R.layout.simple_spinner_item);
			adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spin.setAdapter(adapter);
			// spin.setSelection(0,true);
		}

	@Override
	protected void onRestart() {
		loginSub.setEnabled(true);//�������ؼ�����Ϊ���� 
		super.onRestart();  
	}


}
