package com.freshpower.android.elec.activity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.domain.CustomerInfo;
import com.freshpower.android.elec.netapi.StationInfoDataApi;
import com.freshpower.android.elec.widget.PullDownListView;

public class StationHistoryConsumptionActivity extends FrameActivity  implements PullDownListView.OnRefreshListioner{
	private PullDownListView mPullDownView;
	private ListView mListView;
	private Resources res;
	private ImageButton homeBtn;
	private List<CustomerInfo> stationDetailList;
	private Handler mHandler = new Handler();
	private int pageSize = 20;//ÿҳ��ʾ
	private int currentPage =1;//��ǰҳ
	private int totalCnt=0;//�ܼ�¼��
	private int rs=999;//��ѯ���
	private SimpleAdapter adapter;
	private RelativeLayout progressRlt = null;
	List<Map<String, Object>> customerInfoMap;
	private ProgressDialog processProgress;
	private Handler handler = new Handler();


	protected void init(Bundle savedInstanceState) {
		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_station_historydata);
		ImageView iv=(ImageView)findViewById(R.id.nav_left);
		iv.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				StationHistoryConsumptionActivity.this.onBackPressed();
			}
		});
		TextView history_tv=(TextView)findViewById(R.id.history_tv);
		Calendar date=Calendar.getInstance();
		int month=date.get(Calendar.MONTH)+1;
		history_tv.setText(month+"�·���ʷ����");
		mPullDownView = (PullDownListView) findViewById(R.id.sreach_list);
		mPullDownView.setRefreshListioner(this);
		mListView = mPullDownView.mListView;
		processProgress = ProgressDialog.show(StationHistoryConsumptionActivity.this, "",getResources().getString(R.string.msg_operate_processing_alert),true);
		new Thread(){
			public void run() {
				customerInfoMap = getGroupOnelistData(stationDetailList);
				Message msgMessage = new Message();
				StationHistoryConsumptionActivity.this.xHandler.sendMessage(msgMessage);
			}
		}.start();

	}
	private Handler xHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			adapter = new SimpleAdapter(StationHistoryConsumptionActivity.this,customerInfoMap, 
					R.layout.listitem_stationhistoryconsumption, 
					new String[] { AppConstant.ListItemWarnName.WARN_ONE, 
					AppConstant.ListItemWarnName.WARN_TWO,
					AppConstant.ListItemWarnName.WARN_THREE,
					AppConstant.ListItemWarnName.WARN_FOUR
					}, 
					new int[] { R.id.stationhistoryData_1,
					R.id.stationhistoryData_2,
					R.id.stationhistoryData_3,
					R.id.stationhistoryData_4
					});

			if(customerInfoMap.size()==0){
				Toast.makeText(StationHistoryConsumptionActivity.this, R.string.noSearchResultMsg,Toast.LENGTH_SHORT).show();
				rs=AppConstant.Result.NO_COUNT;
			}
			mListView.setAdapter(adapter);
		
			setShow();
			//	    		progressRlt.setVisibility(View.GONE);
			mPullDownView.setVisibility(View.VISIBLE);
			processProgress.dismiss();
		};
	};
	private void setShow() {
		if(rs==AppConstant.Result.NO_COUNT){
			RelativeLayout noResultlayout = (RelativeLayout) findViewById(R.id.noResultlayout);
			noResultlayout.setVisibility(View.VISIBLE);
			mPullDownView.setMore(false);
		}else{
			mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
		}
		if(customerInfoMap.size()<10){
			mPullDownView.setMore(false);
		}
	}    
	@Override
	public void onRefresh() {
		// TODO Auto-generated method stub
		mHandler.postDelayed(new Runnable() {

			public void run() {
				customerInfoMap.clear();
				currentPage =1;
				customerInfoMap.addAll(getGroupOnelistData(stationDetailList));

				mPullDownView.onRefreshComplete();//�����ʾˢ�´�����ɺ������ļ���ˢ�½�������
				mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				if(customerInfoMap.size()<10){
					mPullDownView.setMore(false);
				}
				adapter.notifyDataSetChanged();	
			}
		}, 1500);

	}
	@Override
	public void onLoadMore() {
		mHandler.postDelayed(new Runnable() {
			public void run() {

				currentPage++;
				customerInfoMap.addAll(getGroupOnelistData(stationDetailList));

				mPullDownView.onLoadMoreComplete();//�����ʾ���ظ��ദ����ɺ������ļ��ظ�����棨���ػ��������������ࣩ
				//if(list.size()<totalCnt)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
				if(customerInfoMap.size()<totalCnt/2)//�жϵ�ǰlist�������ӵ������Ƿ�С�����ֵmaxAount������ô����ʾ���������ʾ
					mPullDownView.setMore(true);//��������true��ʾ���и�����أ�����Ϊfalse�ײ�������ʾ����
				else
					mPullDownView.setMore(false);
				adapter.notifyDataSetChanged();	

			}
		}, 1500);

	}
	private List<Map<String, Object>> getGroupOnelistData(List<CustomerInfo> stationDetailList){
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		Intent it=getIntent();
		String meterId =it.getStringExtra("MeterId");
		String cpId =it.getStringExtra("CpId");
		try {
			Map customerInfoMap=StationInfoDataApi.getStationDetailHistoryConsumptionList(pageSize,currentPage,meterId,cpId);
			if(!"0".equals(customerInfoMap.get("result"))){
				stationDetailList=(List<CustomerInfo>) customerInfoMap.get("customerDatailList");
				for(int i=0;i<stationDetailList.size();i++){
					CustomerInfo customerInfo=stationDetailList.get(i);
					Map<String, Object> listItem = new HashMap<String, Object>();
					listItem.put(AppConstant.ListItemWarnName.WARN_ONE, customerInfo.getReportMonth()+"��"+customerInfo.getReportDay()+"�գ�");
					listItem.put(AppConstant.ListItemWarnName.WARN_TWO, customerInfo.getTotalPower());
					int j=i+1;
					if(j<stationDetailList.size()){
						CustomerInfo customerInfo2=stationDetailList.get(j);
						listItem.put(AppConstant.ListItemWarnName.WARN_THREE,customerInfo2.getReportMonth()+"��"+customerInfo2.getReportDay()+"�գ�");
						listItem.put(AppConstant.ListItemWarnName.WARN_FOUR, customerInfo2.getTotalPower());
						i++;
					}
					listItems.add(listItem);
				}
					totalCnt = Integer.parseInt(String.valueOf(customerInfoMap.get("totalCount")));
				return listItems;
			}else{
				return listItems;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listItems;
	}
	protected void onResume() {
		homeBtn = (ImageButton) findViewById(R.id.stationDataBtn);
		if(homeBtn!=null){
			homeBtn.setOnClickListener(null);
			homeBtn.setBackgroundResource(R.drawable.databtn_select);
		}
		TextView toolBtnTv = (TextView)findViewById(R.id.stationDataTv);
		toolBtnTv.setTextColor(getResources().getColor(R.color.orange));

		super.onResume();
	}
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		if(customerInfoMap!=null){
			customerInfoMap.clear();
		}
		super.onDestroy();
	}
}
