package com.freshpower.android.elec.activity;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ZoomButtonsController;

public class IntroduceActivity extends Activity {
	private WebView webView;
	private ImageButton returnButton;    
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_introduce);
		ActivityUtil.addActivity(this);
		webView = (WebView) findViewById(R.id.webView);
		webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		returnButton = (ImageButton)findViewById(R.id.nav_left);
		WebSettings webSettings =webView.getSettings();
	 	webSettings.setJavaScriptEnabled(true);
	 	webSettings.setBuiltInZoomControls(true);
	 	webSettings.setUseWideViewPort(true);//��������
	 	setZoomControlGone(webView);
	 	webView.requestFocus();
	 	
	 	Intent it = getIntent();
	 	String type = it.getStringExtra("type");
	 	if(type.equals("1")){
	 		webView.loadUrl("file:///android_asset/www/elec_telnet_test.html");
	 	}else if(type.equals("2")){
	 		webView.loadUrl("file:///android_asset/www/loss_power_Setup.html");
	 	}else if(type.equals("3")){
	 		webView.loadUrl("file:///android_asset/www/sys_service_specification.html");
	 	}else if(type.equals("4")){
	 		webView.loadUrl("file:///android_asset/www/install_debug_problems.html");
	 	}
	 	
	 	returnButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				IntroduceActivity.this.onBackPressed();
			}
		});
	}

	public void setZoomControlGone(WebView view) {
		Class classType;
		Field field;
		try {
			classType = WebView.class;
			field = classType.getDeclaredField("mZoomButtonsController");
			field.setAccessible(true);
			ZoomButtonsController mZoomButtonsController = new ZoomButtonsController(view);
			mZoomButtonsController.getZoomControls().setVisibility(View.GONE);
			try {
				field.set(view, mZoomButtonsController);
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			classType = WebSettings.class;
		 	try {
				Method methodTemp = classType.getMethod("setDisplayZoomControls", new Class[] { boolean.class });
				methodTemp.invoke(view.getSettings(), false);
		 	} catch (SecurityException ex) {
				e.printStackTrace();
			} catch (NoSuchMethodException ex) {
				e.printStackTrace();
			}catch (Exception ex) {
				e.printStackTrace();
			}
		}
	}

}
