package com.freshpower.android.elec.activity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.SearchManager.OnCancelListener;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.freshpower.android.elec.R;
import com.freshpower.android.elec.common.ActivityUtil;
import com.freshpower.android.elec.common.AppConstant;
import com.freshpower.android.elec.common.AppConstant.GpsRequestQueryRtype;
import com.freshpower.android.elec.common.DialogUtil;
import com.freshpower.android.elec.common.FileUtil;
import com.freshpower.android.elec.common.StringUtil;
import com.freshpower.android.elec.common.SystemServiceUtil;
import com.freshpower.android.elec.domain.GpsDataInfo;
import com.freshpower.android.elec.domain.LoginInfo;
import com.freshpower.android.elec.domain.TimeQuantum;
import com.freshpower.android.elec.netapi.GpsDataApi;

public class LocationMapActivity extends FragmentActivity {

//	private GoogleMap mMap;
//	private PolylineOptions polylineOptions = null;
//	private LoginInfo user = null;
//	private EditText phoneNumEt;
//	private EditText startDateEt;
//	private EditText startTimeEt;
//	private EditText endDateEt;
//	private EditText endTimeEt;
//	private EditText currentEt;
//	private ImageButton mapSearchDialogIb;
//	private ImageButton viewUserListIb;
//	private Calendar currentDate;
//	private int result;
//	private Spinner quantumSp;
//	private TextView quantumSpTv;
//	private int mYear;
//	private int mMonth;
//	private int mDay;
//	private int mHour;
//	private int mMinute;
//	static final int DATE_DIALOG_ID = 0;
//	static final int TIME_DIALOG_ID = 1;
//	private final long polylineWidth = 5;
//	private final float mapZoom = 15;
//	private LatLng defaultGpsLatLng = new LatLng(30.287786360161632,
//			120.15082687139511);
//	private boolean isInputDateValid = true;
//	private String startDateStr = "";
//	private String endDateStr = "";
//	private int gpsRequestQueryRtype;
//	private String quantumSpLastSelValue;
//	private List<TimeQuantum> timeQuantumList = new ArrayList<TimeQuantum>();//����ʱ���
//
//	@Override
//	protected void onCreate(Bundle savedInstanceState) {
//		super.onCreate(savedInstanceState);
//		super.requestWindowFeature(Window.FEATURE_NO_TITLE);
//		/*if (AppCache.getSize() == 0) {
//			Intent intent = new Intent(this, TrmsActivity.class);
//			startActivity(intent);
//			this.finish();
//			return;
//		}*/
//		setContentView(R.layout.activity_location_map);
//		ActivityUtil.addActivity(this);
//		gpsRequestQueryRtype = AppConstant.GpsRequestQueryRtype.SEARCH_DEFAULT;
//		
//		mapSearchDialogIb = (ImageButton) findViewById(R.id.mapSearchDialogIb);
//		mapSearchDialogIb
//				.setOnClickListener(new mapSearchDialogIbClickListener());
//		
//		viewUserListIb = (ImageButton) findViewById(R.id.viewUserListIb);
//		viewUserListIb.setOnClickListener(new View.OnClickListener() {
//			
//			@Override
//			public void onClick(View v) {
//				try {
//					showSelectQueryTrailStyleDialog();
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//		
//		ImageView iv=(ImageView)findViewById(R.id.nav_left);
//        iv.setOnClickListener(new View.OnClickListener() {
//        	@Override
//			public void onClick(View v) {
//	    		LocationMapActivity.this.finish();	
//			}
//		});
//
//		if (!checkSetUpMapEnvir()) {
//			mapSearchDialogIb.setVisibility(View.INVISIBLE);
//			viewUserListIb.setVisibility(View.INVISIBLE);
//			return;
//		}
//		setUpMapIfNeeded();
//	}
//	
//	private void showSelectQueryTrailStyleDialog(){
//		AlertDialog.Builder builder = new Builder(LocationMapActivity.this);
//		builder.setTitle(R.string.dialog_map_search_trail_title)
//				.setPositiveButton(R.string.dialog_map_search_trail_btn_month, new DialogInterface.OnClickListener() {
//					@Override
//					public void onClick(DialogInterface dialog, int which) {
//						Intent intent = new Intent(LocationMapActivity.this, GpsValidUserActivity.class);
//						intent.putExtra("GpsRequestQueryRtype", AppConstant.GpsRequestQueryRtype.SEARCH_MONTH);
//						startActivityForResult(intent, AppConstant.ResultCode.RESULT_CODE_REQUEST);
//						dialog.dismiss();
//					}
//				})
//				.setNegativeButton(R.string.dialog_map_search_trail_btn_today, new DialogInterface.OnClickListener() {
//					@Override
//					public void onClick(DialogInterface dialog, int which) {
//						Intent intent = new Intent(LocationMapActivity.this, GpsValidUserActivity.class);
//						intent.putExtra("GpsRequestQueryRtype", AppConstant.GpsRequestQueryRtype.SEARCH_DAY);
//						startActivityForResult(intent, AppConstant.ResultCode.RESULT_CODE_REQUEST);
//						dialog.dismiss();
//					}
//				});
//		Dialog noticeDialog = builder.create();
//		noticeDialog.setCanceledOnTouchOutside(false);
//		noticeDialog.show();
//		
//	}
//	
//	class dateListener implements View.OnClickListener {
//		@Override
//		public void onClick(View v) {
//			currentEt = (EditText) v;
//			// ��õ�ǰ�����ڣ�
//			currentDate = Calendar.getInstance();
//			mYear = currentDate.get(Calendar.YEAR);
//			mMonth = currentDate.get(Calendar.MONTH);
//			mDay = currentDate.get(Calendar.DAY_OF_MONTH);
//			/*
//			 * // �����ı������ݣ� date.setText(new
//			 * StringBuilder().append(mYear).append("-") .append(mMonth +
//			 * 1).append("-")// �õ����·�+1����Ϊ��0��ʼ .append(mDay));
//			 */
//			showDialog(DATE_DIALOG_ID);
//		}
//	}
//
//	class timeListener implements View.OnClickListener {
//		@Override
//		public void onClick(View v) {
//			currentEt = (EditText) v;
//
//			currentDate = Calendar.getInstance();
//			mHour = currentDate.get(Calendar.HOUR_OF_DAY);
//			mMinute = currentDate.get(Calendar.MINUTE);
//			// display the current date
//			currentEt.setText(new StringBuilder().append(pad(mHour))
//					.append(":").append(pad(mMinute)));
//
//			showDialog(TIME_DIALOG_ID);
//		}
//
//	}
//
//	// ��Ҫ���嵯����DatePicker�Ի�����¼���������
//	private DatePickerDialog.OnDateSetListener mDateSetListener = new DatePickerDialog.OnDateSetListener() {
//		public void onDateSet(DatePicker view, int year, int monthOfYear,
//				int dayOfMonth) {
//			mYear = year;
//			mMonth = monthOfYear;
//			mDay = dayOfMonth;
//			// �����ı������ݣ�
//			currentEt.setText(new StringBuilder().append(mYear).append("-")
//					.append(mMonth + 1).append("-")// �õ����·�+1����Ϊ��0��ʼ
//					.append(mDay));
//		}
//	};
//
//	// ��Ҫ���嵯����TimePicker�Ի�����¼���������
//	private TimePickerDialog.OnTimeSetListener mTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
//
//		@Override
//		public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
//			mHour = hourOfDay;
//			mMinute = minute;
//			currentEt.setText(new StringBuilder().append(pad(mHour))
//					.append(":").append(pad(mMinute)));
//		}
//	};
//
//	private static String pad(int c) {
//		if (c >= 10)
//			return String.valueOf(c);
//		else
//			return "0" + String.valueOf(c);
//	}
//
//	protected Dialog onCreateDialog(int id) {
//		switch (id) {
//		case DATE_DIALOG_ID:
//			return new DatePickerDialog(this, mDateSetListener, mYear, mMonth,
//					mDay);
//		case TIME_DIALOG_ID:
//			return new TimePickerDialog(this, mTimeSetListener, mHour, mMinute,
//					false);
//		}
//		return null;
//	}
//
//	private LoginInfo getCurrentUser(){
//		FileUtil.appFilesDir = this.getFilesDir().getPath();
//		String fileContentStr = FileUtil.read(FileUtil.getDBFilePath());
//		if (!StringUtil.isEmpty(fileContentStr)) {
//			if(user==null)
//				user = new LoginInfo();
//			user.setLoginName(fileContentStr.split("\\|")[0]);
//			user.setLoginPwd(fileContentStr.split("\\|")[1]);
//		}
//		return user;
//	}
//	
//	private int getUserLocationInfo(String phoneNumStr, String startDateStr,
//			String endDateStr,String quantumStr) {
//		result = 0;
//		user = getCurrentUser();
//		try {
//			user.setPhoneNum(phoneNumStr);
//			result = GpsDataApi.getLocationInfo(user, startDateStr, endDateStr, gpsRequestQueryRtype,quantumStr);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return result;
//	}
//	
//	private int getUserLocationInfo(String phoneNumStr,String UUID,String userId,String userName,String startDateStr,
//			String endDateStr,String quantumStr) {
//		result = 0;
//		user = getCurrentUser();
//		try {
//			user.setUserName(userName);
//			user.setPhoneNum(phoneNumStr);
//			user.setUUID(UUID);
//			user.setUserId(userId);
//			result = GpsDataApi.getLocationInfo(user, startDateStr, endDateStr, gpsRequestQueryRtype,quantumStr);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return result;
//	}
//
//	private void showGpsInfoIfValid(int result, DialogInterface dialog) {
//		boolean valid=true;
//		if (result == AppConstant.GpsDataApiResult.RESULT_ERROR) {
//			mMap.clear();
//			Toast.makeText(LocationMapActivity.this,
//					R.string.gps_dataapi_result_error, Toast.LENGTH_SHORT)
//					.show();
//			valid = false;
//		} else if (result == AppConstant.GpsDataApiResult.RESULT_PERMISSION_NOT) {
//			mMap.clear();
//			Toast.makeText(LocationMapActivity.this,
//					R.string.gps_dataapi_result_permission_not,
//					Toast.LENGTH_SHORT).show();
//			valid = false;
//		} else if (result == AppConstant.GpsDataApiResult.RESULT_PHONENUM_NOTEXIST) {
//			mMap.clear();
//			Toast.makeText(LocationMapActivity.this,
//					R.string.gps_dataapi_result_phonenum_notexist,
//					Toast.LENGTH_SHORT).show();
//			valid = false;
//		}
//		
//		if(!valid){
//			if(dialog!=null)
//				dialog.dismiss();
//			return;
//		}
//
//		setUpMap();
//	}
//
//	@Override
//	protected void onResume() {
//		super.onResume();
//		setUpMapIfNeeded();
//	}
//
//	private void setUpMapIfNeeded() {
//		if (mMap == null) {
//			mMap = ((SupportMapFragment) getSupportFragmentManager()
//					.findFragmentById(R.id.map)).getMap();
//			if (mMap != null) {
//				setUpMap();
//			}
//		}
//	}
//
//	private boolean checkReady() {
//		if (mMap == null) {
//			Toast.makeText(this, R.string.map_not_ready, Toast.LENGTH_SHORT)
//					.show();
//			return false;
//		}
//		return true;
//	}
//
//	private void setUpMap() {
//
//		mMap.clear();
//
//		addMarkersToMap();
//
//		if (polylineOptions != null && polylineOptions.getPoints().size() > 1) {
//			mMap.addPolyline(polylineOptions.width(polylineWidth)
//					.color(Color.BLUE).geodesic(true));
//			defaultGpsLatLng = polylineOptions.getPoints().get(
//					polylineOptions.getPoints().size() - 1);
//		}else if (polylineOptions != null && polylineOptions.getPoints().size()==0) {
//			gpsRequestQueryRtype = GpsRequestQueryRtype.SEARCH_DEFAULT;
//			Toast.makeText(LocationMapActivity.this,
//					R.string.gps_dataapi_result_noRecord, Toast.LENGTH_SHORT)
//					.show();
//		}
//		
//
//		mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultGpsLatLng,
//				mapZoom));
//	}
//
//	private void addMarkersToMap() {
//		polylineOptions = new PolylineOptions();
//		LatLng latLngTemp = null;
//		if (user != null && user.getGpsDataInfoList() != null) {
//			List<GpsDataInfo> gpsDataInfoList = user.getGpsDataInfoList();
//			GpsDataInfo gpsDataInfo;
//
//			BitmapDescriptor bitmapDescriptorTemp;
//			for (int i = 0; i < gpsDataInfoList.size(); i++) {
//				gpsDataInfo = gpsDataInfoList.get(i);
//				if (gpsDataInfo.getLatitude() == 0D)
//					continue;
//
//				latLngTemp = new LatLng(gpsDataInfo.getLatitude(),
//						gpsDataInfo.getLongitude());
//				
//				bitmapDescriptorTemp = BitmapDescriptorFactory.defaultMarker();
//				if (i == 0){
//					bitmapDescriptorTemp = BitmapDescriptorFactory
//							.defaultMarker(BitmapDescriptorFactory.HUE_GREEN);
//					mMap.addMarker(new MarkerOptions()
//					.position(latLngTemp)
//					.title(user.getUserName() + ":"
//							+ gpsDataInfo.getGpsTime())
//					.icon(bitmapDescriptorTemp));
//				}else if (i == (gpsDataInfoList.size() - 1)
//						&& gpsDataInfoList.size() > 1){
//					bitmapDescriptorTemp = BitmapDescriptorFactory
//							.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE);
//					mMap.addMarker(new MarkerOptions()
//					.position(latLngTemp)
//					.title(user.getUserName() + ":"
//							+ gpsDataInfo.getGpsTime())
//					.icon(bitmapDescriptorTemp));
//				}
//				
//				polylineOptions.add(latLngTemp);
//			}
//		}
//	}
//
//	private String checkInpAndReturnDateStr(int editTextId) {
//		currentDate = Calendar.getInstance();
//		mYear = currentDate.get(Calendar.YEAR);
//		mMonth = currentDate.get(Calendar.MONTH);
//		mDay = currentDate.get(Calendar.DAY_OF_MONTH);
//		mHour = currentDate.get(Calendar.HOUR_OF_DAY);
//		mMinute = currentDate.get(Calendar.MINUTE);
//
//		StringBuffer sb = new StringBuffer();
//		StringBuffer dateSb = new StringBuffer();
//		StringBuffer timeSb = new StringBuffer();
//
//		dateSb.append(mYear).append("-").append(mMonth + 1).append("-")// �õ����·�+1����Ϊ��0��ʼ
//				.append(mDay);
//
//		switch (editTextId) {
//		case R.id.startDateS:
//			if (StringUtil.isEmpty(startDateEt.getText().toString())
//					|| StringUtil.isEmpty(endDateEt.getText().toString())) {
//				timeSb.append(pad(mHour - 1)).append(":").append(pad(mMinute));
//
//				sb.append(dateSb).append(" ").append(timeSb);
//
//				isInputDateValid = false;
//			} else {
//				sb.append(startDateEt.getText()).append(" ")
//						.append(startTimeEt.getText());
//			}
//			break;
//		case R.id.endDateS:
//			if (StringUtil.isEmpty(startDateEt.getText().toString())
//					|| StringUtil.isEmpty(endDateEt.getText().toString())) {
//				timeSb.append(pad(mHour)).append(":").append(pad(mMinute));
//
//				sb.append(dateSb).append(" ").append(timeSb);
//
//				isInputDateValid = false;
//			} else {
//				sb.append(endDateEt.getText()).append(" ")
//						.append(endTimeEt.getText());
//			}
//			break;
//		}
//		return sb.toString().trim();
//	}
//
//	private class mapSearchDialogIbClickListener implements
//			View.OnClickListener {
//
//		@Override
//		public void onClick(View v) {
//
//			// ���ȷ��ת���¼�Ի���
//			LayoutInflater factory = LayoutInflater
//					.from(LocationMapActivity.this);
//			// �õ��Զ���Ի���
//			final View DialogView = factory.inflate(R.layout.dialog_map_search,
//					null);
//
//			phoneNumEt = (EditText) DialogView.findViewById(R.id.phoneNum_s);
//			startDateEt = (EditText) DialogView.findViewById(R.id.startDateS);
//			startTimeEt = (EditText) DialogView.findViewById(R.id.startTimeS);
//			endDateEt = (EditText) DialogView.findViewById(R.id.endDateS);
//			endTimeEt = (EditText) DialogView.findViewById(R.id.endTimeS);
//			quantumSp = (Spinner)DialogView.findViewById(R.id.QuantumSp);
//			quantumSpTv = (TextView)DialogView.findViewById(R.id.QuantumSpTxt);
//			if(gpsRequestQueryRtype != AppConstant.GpsRequestQueryRtype.SEARCH_DEFAULT){
//				String quantumSpTvTxt = (gpsRequestQueryRtype == AppConstant.GpsRequestQueryRtype.SEARCH_DAY)?LocationMapActivity.this.getString(R.string.dialog_map_search_trail_btn_today):LocationMapActivity.this.getString(R.string.dialog_map_search_trail_btn_month);
//				quantumSpTv.setText(quantumSpTvTxt+quantumSpTv.getText());
//				quantumSpTv.setVisibility(View.VISIBLE);
//				quantumSp.setVisibility(View.VISIBLE);
//				startDateEt.setEnabled(false);
//				startTimeEt.setEnabled(false);
//				endDateEt.setEnabled(false);
//				endTimeEt.setEnabled(false);
//				phoneNumEt.setEnabled(false);
//				
//				initCtrlValue();
//			}
//			
//			startDateEt.setInputType(InputType.TYPE_NULL);
//			startDateEt.setOnClickListener(new dateListener());
//			startTimeEt.setInputType(InputType.TYPE_NULL);
//			startTimeEt.setOnClickListener(new timeListener());
//			endDateEt.setInputType(InputType.TYPE_NULL);
//			endDateEt.setOnClickListener(new dateListener());
//			endTimeEt.setInputType(InputType.TYPE_NULL);
//			endTimeEt.setOnClickListener(new timeListener());
//			
//			StringBuffer titleSb = new StringBuffer(LocationMapActivity.this.getString(R.string.dialog_map_search_title));
//
//			// ����Ի���
//			AlertDialog.Builder builder = new Builder(LocationMapActivity.this);
//			builder.setTitle(titleSb.toString());
//			builder.setView(DialogView);
//			
//			if(gpsRequestQueryRtype == AppConstant.GpsRequestQueryRtype.SEARCH_DEFAULT){
//				//ʵʱ��Ϣ
//				builder.setPositiveButton(
//						R.string.dialog_map_search_title_bnt_Actual,
//						new OnClickListener() {
//							@Override
//							public void onClick(DialogInterface dialog, int which) {
//								if (!checkIptValid()) {
//									DialogUtil.closeCurrent(dialog, false);
//									return;
//								}
//	
//								DialogUtil.closeCurrent(dialog, true);
//								result = getUserLocationInfo(phoneNumEt.getText()
//										.toString(), "", "",null);
//								showGpsInfoIfValid(result, dialog);
//							}
//						});
//			}else{
//				titleSb.append("(")
//				.append(user.getUserName())
//				.append(")");
//				builder.setTitle(titleSb.toString());
//				//����
//				builder.setPositiveButton(
//						R.string.dialog_map_search_title_bnt_reset,
//						new OnClickListener() {
//							@Override
//							public void onClick(DialogInterface dialog, int which) {
//								gpsRequestQueryRtype = AppConstant.GpsRequestQueryRtype.SEARCH_DEFAULT;
//								quantumSpLastSelValue=null;
//								dialog.dismiss();
//								mapSearchDialogIb.performClick();
//							}
//						});
//			}
//			
//			// �켣
//			builder.setNegativeButton(
//					R.string.dialog_map_search_title_bnt_track,
//					new OnClickListener() {
//						@Override
//						public void onClick(DialogInterface dialog, int which) {
//							if (!checkIptValid()) {
//								DialogUtil.closeCurrent(dialog, false);
//								return;
//							}
//
//							DialogUtil.closeCurrent(dialog, true);
//							isInputDateValid = true;
//
//							String startDateTimeStr = checkInpAndReturnDateStr(startDateEt
//									.getId());
//							String endDateTimeStr = checkInpAndReturnDateStr(endDateEt
//									.getId());
//							if (!isInputDateValid) {
//								Toast.makeText(
//										LocationMapActivity.this,
//										getResources()
//												.getString(
//														R.string.gps_map_default_time_msg)
//												+ startDateTimeStr
//												+ "~"
//												+ endDateTimeStr,
//										Toast.LENGTH_LONG).show();
//								dialog.dismiss();
//							}
//
//							if(gpsRequestQueryRtype != AppConstant.GpsRequestQueryRtype.SEARCH_DEFAULT)
//								quantumSpLastSelValue = quantumSp.getSelectedItem().toString();
//							
//							result = getUserLocationInfo(phoneNumEt.getText()
//									.toString(), startDateTimeStr,
//									endDateTimeStr,LocationMapActivity.this.getResources().getString(R.string.value_all_ctrl).equals(quantumSpLastSelValue)?null:quantumSpLastSelValue);
//
//							showGpsInfoIfValid(result, dialog);
//						}
//					});
//			builder.setOnCancelListener(new OnCancelListener() {
//				@Override
//				public void onCancel(DialogInterface dialog) {
//					DialogUtil.closeCurrent(dialog, true);
//					dialog.dismiss();
//				}
//			});
//
//			Dialog noticeDialog = builder.create();
//			noticeDialog.setCanceledOnTouchOutside(false);
//			noticeDialog.show();
//		}
//
//	}
//
//	private boolean checkIptValid() {
//		if (StringUtil.isEmpty(phoneNumEt.getText().toString())) {
//			Toast.makeText(LocationMapActivity.this,
//					R.string.msg_phoneNum_iptAlert, Toast.LENGTH_SHORT).show();
//			return false;
//		}
//		return true;
//	}
//
//	private boolean checkSetUpMapEnvir() {
//		boolean isValid = true;
//
//		if (!SystemServiceUtil.isAppsInstalled(this,
//				AppConstant.GooglePlayPackageName.GOOGLE_PLAY_SERVICE)) {
//			builderGooglePlayDialog(
//					AppConstant.GooglePlayPackageName.GOOGLE_PLAY_SERVICE,
//					R.string.msg_google_play_service_Install);
//			isValid = false;
//		} else if (!SystemServiceUtil.isAppsInstalled(this,
//				AppConstant.GooglePlayPackageName.GOOGLE_PLAY_SOTRE)) {
//			builderGooglePlayDialog(
//					AppConstant.GooglePlayPackageName.GOOGLE_PLAY_SOTRE,
//					R.string.msg_google_play_store_Install);
//			isValid = false;
//		}
//
//		return isValid;
//	}
//
//	private void builderGooglePlayDialog(String googlePlayPackageName, int msgId) {
//		AlertDialog.Builder builder = new AlertDialog.Builder(this);
//		builder.setMessage(getResources().getString(msgId));
//		builder.setCancelable(false);
//		builder.setPositiveButton(R.string.soft_btn_continue,
//				getGoogleMapsListener(googlePlayPackageName));
//		builder.setNegativeButton(R.string.soft_btn_cancle,
//				new OnClickListener() {
//					@Override
//					public void onClick(DialogInterface dialog, int which) {
//						dialog.dismiss();
//						LocationMapActivity.this.finish();
//					}
//				});
//		AlertDialog dialog = builder.create();
//		dialog.setCanceledOnTouchOutside(false);
//		dialog.show();
//	}
//
//	private OnClickListener getGoogleMapsListener(
//			final String googlePlayPackageName) {
//		return new OnClickListener() {
//			@Override
//			public void onClick(DialogInterface dialog, int which) {
//				Intent intent = new Intent(Intent.ACTION_VIEW,
//						Uri.parse("market://details?id="
//								+ googlePlayPackageName));
//				startActivity(intent);
//
//				// Finish the activity so they can't circumvent the check
//				dialog.dismiss();
//				finish();
//			}
//		};
//	}
//	
//	@Override
//	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//		if(AppConstant.ResultCode.RESULT_CODE_SUCCESS==resultCode){
//			gpsRequestQueryRtype = data.getExtras().getInt("GpsRequestQueryRtype");
//			startDateStr = data.getExtras().getString("startDateStr");
//			endDateStr = data.getExtras().getString("endDateStr");
//			result = getUserLocationInfo(data.getExtras().getString("phoneNum"),data.getExtras().getString("UUID"),data.getExtras().getString("userId"),data.getExtras().getString("userName"),startDateStr,endDateStr,null);
//			timeQuantumList = user.getTimeQuantum();
//			
//			showGpsInfoIfValid(result, null);
//        }else if(AppConstant.ResultCode.RESULT_CODE_RESULT_NULL==resultCode){
//        	mMap.clear();
//        	gpsRequestQueryRtype = GpsRequestQueryRtype.SEARCH_DEFAULT;
//        	Toast.makeText(LocationMapActivity.this, R.string.gps_dataapi_result_noRecord, Toast.LENGTH_LONG).show();
//        }
//		super.onActivityResult(requestCode, resultCode, data);
//	}
//	
//	private void initCtrlValue(){
//		
//		phoneNumEt.setText(user.getPhoneNum());
//		startDateEt.setText(startDateStr.split(" ")[0]);
//		startTimeEt.setText(startDateStr.split(" ")[1]);
//		endDateEt.setText(endDateStr.split(" ")[0]);
//		endTimeEt.setText(endDateStr.split(" ")[1]);
//		
//		List<String> datalist = new ArrayList<String>();
//		if(timeQuantumList!=null && timeQuantumList.size()!=0){
//			datalist.add(0, this.getResources().getString(R.string.value_all_ctrl));
//		}
//		for (int i = 0; i < timeQuantumList.size(); i++) {
//			datalist.add(timeQuantumList.get(i).getDateValue());
//		}
//		
//		ArrayAdapter adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,datalist);  
//		
//		//����Spinner����ÿ����Ŀ����ʽ��ͬ��������һ��Androidϵͳ�ṩ�Ĳ����ļ�
//		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//		quantumSp.setAdapter(adapter);
//		quantumSp.setPromptId(R.string.dialog_map_search_name_ctrl);
//		
//		if(!StringUtil.isEmpty(quantumSpLastSelValue)){
//			quantumSp.setSelection(adapter.getPosition(quantumSpLastSelValue));
//		}
//	}

}
