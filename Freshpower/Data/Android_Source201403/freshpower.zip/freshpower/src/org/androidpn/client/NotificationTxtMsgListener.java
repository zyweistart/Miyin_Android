/*
 * Copyright (C) 2010 Moduad Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.androidpn.client;

import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.packet.Packet;

import android.content.Intent;
import android.util.Log;

/** 
 * This class notifies the receiver of incoming notifcation packets asynchronously.  
 *
 * @author Sehwan Noh (devnoh@gmail.com)
 * ֪ͨ��Ϣ����
 */
public class NotificationTxtMsgListener{

    private static final String LOGTAG = LogUtil
            .makeLogTag(NotificationTxtMsgListener.class);

    private final XmppManager xmppManager;
    
    public final static String MSG_TYPE_LOGIN="hetp99";
    public final static String MSG_TYPE_SWITCH="hetp01";//����״̬
    public final static String MSG_TYPE_ALARM="hetp02";//����
    public final static String MSG_TYPE_ALARM_CARGO="hetp03";//��ҵ���ɳ�����������
    public final static String MSG_TYPE_ALARM_POWER_FACTOR="hetp04";//��ҵ������������
   
    

    public NotificationTxtMsgListener(XmppManager xmppManager) {
        this.xmppManager = xmppManager;
    }

    public void processTxgMsg(String msg) {
        Log.d(LOGTAG, "NotificationTxtMsgListener.processPacket()...");
        Log.d("trmsDebug", "*****packet.processTxgMsg()=" + msg);

        if (null!=msg && !"".equals(msg)) {
            String notificationTitle = "����";
            String notificationMessage ="";
            String notificationUri = "";
            String notificationType = "";
            
            if(msg.indexOf(MSG_TYPE_SWITCH)!=-1){
            	notificationTitle = "����״̬";
            	notificationMessage = msg.substring(msg.indexOf(MSG_TYPE_SWITCH)+6, msg.length()-2);
            	notificationType = MSG_TYPE_SWITCH;
            }else if(msg.indexOf(MSG_TYPE_ALARM)!=-1){
            	notificationTitle = "����";
            	notificationMessage = msg.substring(msg.indexOf(MSG_TYPE_ALARM)+6, msg.length()-2);
            	notificationType = MSG_TYPE_ALARM;
            }else if(msg.indexOf(MSG_TYPE_ALARM_CARGO)!=-1){
            	notificationTitle = "���ɳ���";
            	notificationMessage = msg.substring(msg.indexOf(MSG_TYPE_ALARM_CARGO)+6, msg.length()-2);
            	notificationType = MSG_TYPE_ALARM_CARGO;
            }else if(msg.indexOf(MSG_TYPE_ALARM_POWER_FACTOR)!=-1){
            	notificationTitle = "������������";
            	notificationMessage = msg.substring(msg.indexOf(MSG_TYPE_ALARM_POWER_FACTOR)+6, msg.length()-2);
            	notificationType = MSG_TYPE_ALARM_POWER_FACTOR;
            }else if(msg.indexOf(MSG_TYPE_LOGIN)!=-1){
            	return;
            }
            
            Intent intent = new Intent(Constants.ACTION_SHOW_NOTIFICATION);
            intent.putExtra(Constants.NOTIFICATION_TITLE,notificationTitle);
            intent.putExtra(Constants.NOTIFICATION_MESSAGE, notificationMessage);
            intent.putExtra(Constants.NOTIFICATION_URI, notificationUri);
            intent.putExtra(Constants.NOTIFICATION_TYPE, notificationType);
            xmppManager.getContext().sendBroadcast(intent);
        }
    }

}
