/** Automatically generated file. DO NOT MODIFY */
package com.freshpower.android.elec;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}